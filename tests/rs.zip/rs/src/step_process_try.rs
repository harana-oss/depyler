#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn process_try(state: &State) {
    log::info!("{}", "[ProcessTry] Add try points for team in possession");
    add_try(state.clone());
    log::info!(
        "{}",
        "[ProcessTry] Player try assignment if players enabled"
    );
    if state.include_players {
        log::info!("{}", "[ProcessTry] Get player tries model result");
        let try_selection: PlayerTriesOutputs =
            player_tries(state.clone(), state.team_in_possession);
        log::info!("{}", "[ProcessTry] Assign try to selected player");
        assign_try(
            state.clone(),
            try_selection.player_index,
            state.team_in_possession,
        );
    }
    log::info!("{}", "[ProcessTry] Process conversion");
    conversion(state.clone());
    execute_events(state);
    return;
}
