#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[derive(Debug, Clone)]
pub struct IndexError {
    message: String,
}
impl std::fmt::Display for IndexError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "index out of range: {}", self.message)
    }
}
impl std::error::Error for IndexError {}
impl IndexError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub fn assign_try(state: &mut State, player_index: i32, team: &Team) {
    let mut period_idx: i32 = 0;
    let mut players: Vec<Player> = Vec::new();
    log::info!("{}", "[AssignTry] Get period index");
    period_idx = state.period.number - 1;
    log::info!("{}", "[AssignTry] Get players list based on team");
    players = if team.clone() == Team.Home {
        state.home_players
    } else {
        state.away_players
    };
    log::info!("{}", "[AssignTry] Find player by index");
    let mut player = players
        .iter()
        .find(|p| p.player_index == player_index)
        .cloned();
    let player_list_idx = players
        .iter()
        .enumerate()
        .map(|(i, x)| (i as i32, x.clone()))
        .filter(|(i, p)| p.player_index == player_index)
        .map(|(i, p)| i)
        .next()
        .unwrap_or(-1);
    log::info!("{}", "[AssignTry] Update period try scorers");
    state.total_try_scorers = state
        .total_try_scorers
        .iter()
        .chain(vec![player_list_idx.clone()].iter())
        .cloned()
        .collect::<Vec<_>>();
    state.period_try_scorers[period_idx as usize] = state
        .period_try_scorers
        .get(period_idx as usize)
        .cloned()
        .unwrap()
        .iter()
        .chain(vec![player_list_idx.clone()].iter())
        .cloned()
        .collect::<Vec<_>>();
    log::info!("{}", "[AssignTry] Update home team try scorers");
    if team.clone() == Team.Home {
        log::info!("{}", "[AssignTry] Set variables");
        state.home_total_try_scorers = state
            .home_total_try_scorers
            .iter()
            .chain(vec![player_list_idx.clone()].iter())
            .cloned()
            .collect::<Vec<_>>();
        state.home_period_try_scorers[period_idx as usize] = state
            .home_period_try_scorers
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .iter()
            .chain(vec![player_list_idx.clone()].iter())
            .cloned()
            .collect::<Vec<_>>();
    }
    log::info!("{}", "[AssignTry] Update away team try scorers");
    if team.clone() == Team.Away {
        log::info!("{}", "[AssignTry] Set variables");
        state.away_period_try_scorers[period_idx as usize] = state
            .away_period_try_scorers
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .iter()
            .chain(vec![player_list_idx.clone()].iter())
            .cloned()
            .collect::<Vec<_>>();
        state.away_total_try_scorers = state
            .away_total_try_scorers
            .iter()
            .chain(vec![player_list_idx.clone()].iter())
            .cloned()
            .collect::<Vec<_>>();
    }
    log::info!("{}", "[AssignTry] Update player period statistics");
    player
        .as_mut()
        .unwrap()
        .period_statistics
        .get_mut(period_idx as usize)
        .unwrap()
        .scores
        .total = player
        .as_ref()
        .unwrap()
        .period_statistics
        .get(period_idx as usize)
        .cloned()
        .unwrap()
        .scores
        .total
        + TRY_POINTS;
    player
        .as_mut()
        .unwrap()
        .period_statistics
        .get_mut(period_idx as usize)
        .unwrap()
        .scores
        .tries = player
        .as_ref()
        .unwrap()
        .period_statistics
        .get(period_idx as usize)
        .cloned()
        .unwrap()
        .scores
        .tries
        + 1;
    log::info!("{}", "[AssignTry] Update player total statistics");
    player.as_mut().unwrap().total_statistics.scores.tries =
        player.as_ref().unwrap().total_statistics.scores.tries + 1;
    player.as_mut().unwrap().total_statistics.scores.total =
        player.as_ref().unwrap().total_statistics.scores.total + TRY_POINTS;
    log::info!("{}", "[AssignTry] Get team statistics");
    let mut team_stats = if *team == Team.Home {
        state.home_statistics
    } else {
        state.away_statistics
    };
    log::info!("{}", "[AssignTry] Update team player statistics");
    team_stats
        .player_statistics
        .get_mut(player_list_idx as usize)
        .unwrap()
        .scores
        .tries = team_stats
        .player_statistics
        .get(player_list_idx as usize)
        .cloned()
        .unwrap()
        .scores
        .tries
        + 1;
    team_stats
        .player_statistics
        .get_mut(player_list_idx as usize)
        .unwrap()
        .scores
        .total = team_stats
        .player_statistics
        .get(player_list_idx as usize)
        .cloned()
        .unwrap()
        .scores
        .total
        + TRY_POINTS;
    execute_events(state);
    return;
}
