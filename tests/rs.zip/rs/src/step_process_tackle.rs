#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn process_tackle(state: &mut State) {
    const TACKLES_PER_SET: i32 = 6;
    log::info!("{}", "[ProcessTackle] Get period index");
    let period_idx = state.period.number - 1;
    log::info!("{}", "[ProcessTackle] Get team statistics");
    let mut team_stats = if state.team_in_possession == Team.Home {
        state.home_statistics
    } else {
        state.away_statistics
    };
    log::info!("{}", "[ProcessTackle] Update period tackles");
    team_stats.period_statistics[period_idx as usize].tackles = team_stats
        .period_statistics
        .get(period_idx as usize)
        .cloned()
        .unwrap()
        .tackles
        + 1;
    log::info!("{}", "[ProcessTackle] Update total tackles");
    team_stats.total_statistics.tackles = team_stats.total_statistics.tackles + 1;
    log::info!("{}", "[ProcessTackle] Add tackle");
    state.tackles = state.tackles + 1;
    log::info!("{}", "[ProcessTackle] Check if tackle limit exceeded");
    if state.tackles > TACKLES_PER_SET {
        swap_possession(state.clone());
    }
    execute_events(state);
    return;
}
