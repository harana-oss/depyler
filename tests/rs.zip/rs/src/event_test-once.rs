#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn test_once_event(state: &State) {
    if state.home_match_score > 0 {
        log::info!("{}", "[Test Once Event] Log once");
        log::info!("{}", "This should only appear once when home team scores");
    }
    return;
}
