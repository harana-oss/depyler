#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct PlayerSinBinInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl PlayerSinBinInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn player_sin_bin(state: &State, sin_bin_team_is_home: bool) {
    let mut is_home: f64 = 0.0;
    let mut penalty_team_is_home: bool = false;
    let mut sin_bin_player_index: i32 = 0;
    let mut sin_bin_team: Option<Team> = None;
    log::info!("{}", "[PlayerSinBin] Determine penalty team side");
    penalty_team_is_home = sin_bin_team_is_home;
    log::info!("{}", "[PlayerSinBin] Set is_home variable");
    is_home = if penalty_team_is_home { 1.0 } else { 0.0 };
    log::info!("{}", "[PlayerSinBin] Sample player sin bin model");
    let model: PlayerSinBinInferOutputs0 = infer::<PlayerSinBinInferOutputs0>(
        "player_sin_bin".to_string(),
        vec![
            is_home,
            (state.time_elapsed) as f64,
            (state.set) as f64,
            (state.tackles) as f64,
            (if penalty_team_is_home {
                state.simulation_invariants.home_price
            } else {
                state.simulation_invariants.away_price
            }) as f64,
            (state.simulation_invariants.total_points) as f64,
            (state.home_match_score + state.away_match_score) as f64,
            (calculate_foul_team_margin(state.clone())) as f64,
        ],
    );
    log::info!("{}", "[PlayerSinBin] Persist sin bin selection");
    sin_bin_team = Some(if penalty_team_is_home {
        Team.Home
    } else {
        Team.Away
    });
    sin_bin_player_index = sample(model.probabilities, random());
    log::info!("{}", "[PlayerSinBin] Record player sin bin event");
    if sin_bin_player_index >= 0 {
        record_player_sin_bin(
            state.clone(),
            sin_bin_player_index,
            SinBinStatus.YellowCard,
            sin_bin_team,
        );
    }
    log::info!(
        "{}",
        "[PlayerSinBin] Update state markers for sin bin event"
    );
    if sin_bin_player_index >= 0 {
        let last_sin_bin_player_index = sin_bin_player_index;
        let last_sin_bin_team = sin_bin_team.clone();
        let last_event = "PLAYER_SIN_BIN".to_string();
    }
    execute_events(state);
    return;
}
