#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[derive(Debug, Clone)]
pub struct ZeroDivisionError {
    message: String,
}
impl std::fmt::Display for ZeroDivisionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "division by zero: {}", self.message)
    }
}
impl std::error::Error for ZeroDivisionError {}
impl ZeroDivisionError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub fn first_to_score_tracking_event(state: &State) {
    let mut away_first_try_incident: Option<Incident> = None;
    let mut away_first_try_time: Option<i32> = None;
    let mut extra_time_first_score_incident: Option<Incident> = None;
    let mut extra_time_first_try_incident: Option<Incident> = None;
    let mut half2_et_first_score_incident: Option<Incident> = None;
    let mut half2_et_first_try_incident: Option<Incident> = None;
    let mut home_first_try_incident: Option<Incident> = None;
    let mut home_first_try_time: Option<i32> = None;
    let mut last_score_incident: Option<Incident> = None;
    let mut last_try_incident: Option<Incident> = None;
    let mut last_try_time: Option<i32> = None;
    let mut match_first_score_incident: Option<Incident> = None;
    let mut match_first_try_incident: Option<Incident> = None;
    let mut match_first_try_time: Option<i32> = None;
    let mut points_confirmed_incidents: Vec<Incident> = Vec::new();
    let mut try_incidents: Vec<Incident> = Vec::new();
    let _cse_temp_0 = state.incidents.len() as i32;
    let _cse_temp_1 = (_cse_temp_0 > 0) || (state.is_over);
    if _cse_temp_1 {
        log::info!(
            "{}",
            "[First To Score Tracking Event] Collect confirmed scoring incidents"
        );
        points_confirmed_incidents = state
            .incidents
            .iter()
            .cloned()
            .filter(|incident| {
                incident.has_points_confirmed
                    && [Team.Home, Team.Away].contains(&incident.points_scored_team)
            })
            .collect::<Vec<_>>();
        log::info!(
            "{}",
            "[First To Score Tracking Event] Collect confirmed try incidents"
        );
        try_incidents = points_confirmed_incidents
            .clone()
            .iter()
            .cloned()
            .filter(|incident| incident.points_confirmed_score_type == ScoreType.Try)
            .collect::<Vec<_>>();
        log::info!(
            "{}",
            "[First To Score Tracking Event] Resolve key incidents across periods"
        );
        half2_et_first_try_incident = try_incidents
            .clone()
            .iter()
            .find(|incident| (incident.period.number) as i32 - 1 >= SECOND_HALF_INDEX)
            .cloned();
        extra_time_first_try_incident = try_incidents
            .iter()
            .find(|incident| (incident.period.number) as i32 - 1 == EXTRA_TIME_INDEX)
            .cloned();
        half2_et_first_score_incident = points_confirmed_incidents
            .clone()
            .iter()
            .find(|incident| (incident.period.number) as i32 - 1 >= SECOND_HALF_INDEX)
            .cloned();
        extra_time_first_score_incident = points_confirmed_incidents
            .iter()
            .find(|incident| (incident.period.number) as i32 - 1 == EXTRA_TIME_INDEX)
            .cloned();
        home_first_try_incident = try_incidents
            .iter()
            .find(|incident| incident.points_scored_team == Team.Home)
            .cloned();
        match_first_score_incident = if !points_confirmed_incidents.is_empty() {
            Some(points_confirmed_incidents.get(0usize).cloned().unwrap())
        } else {
            None
        };
        away_first_try_incident = try_incidents
            .iter()
            .find(|incident| incident.points_scored_team == Team.Away)
            .cloned();
        last_try_incident = if !try_incidents.is_empty() {
            Some(try_incidents.last().cloned().unwrap())
        } else {
            None
        };
        match_first_try_incident = if !try_incidents.is_empty() {
            Some(try_incidents.get(0usize).cloned().unwrap())
        } else {
            None
        };
        last_score_incident = if !points_confirmed_incidents.is_empty() {
            Some(points_confirmed_incidents.last().cloned().unwrap())
        } else {
            None
        };
        log::info!("{}", "[First To Score Tracking Event] Compute try timings");
        last_try_time = if last_try_incident.is_some() {
            Some(
                ((last_try_incident.as_ref().unwrap().time_elapsed as f64) / (60 as f64)) as i32
                    + 1,
            )
        } else {
            None
        };
        home_first_try_time = if home_first_try_incident.is_some() {
            Some(
                ((home_first_try_incident.as_ref().unwrap().time_elapsed as f64) / (60 as f64))
                    as i32
                    + 1,
            )
        } else {
            None
        };
        away_first_try_time = if away_first_try_incident.is_some() {
            Some(
                ((away_first_try_incident.as_ref().unwrap().time_elapsed as f64) / (60 as f64))
                    as i32
                    + 1,
            )
        } else {
            None
        };
        match_first_try_time = if match_first_try_incident.is_some() {
            Some(
                ((match_first_try_incident.as_ref().unwrap().time_elapsed as f64) / (60 as f64))
                    as i32
                    + 1,
            )
        } else {
            None
        };
        log::info!(
            "{}",
            "[First To Score Tracking Event] Record match first scores"
        );
        if match_first_score_incident.is_some() {
            record_bool(
                "FirstToScore_Match_A".to_string(),
                match_first_score_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team.Home,
            );
            record_bool(
                "FirstToScore_Match_B".to_string(),
                match_first_score_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team.Away,
            );
            record_bool(
                "FirstTry_Match_A".to_string(),
                match_first_try_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team.Home,
            );
            record_bool(
                "FirstTry_Match_B".to_string(),
                match_first_try_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team.Away,
            );
        }
        log::info!(
            "{}",
            "[First To Score Tracking Event] Record Half 2 and Extra Time first scores"
        );
        if half2_et_first_score_incident.is_some() {
            record_bool(
                "FirstToScore_Half2AndExtraTime_A".to_string(),
                half2_et_first_score_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team.Home,
            );
            record_bool(
                "FirstToScore_Half2AndExtraTime_B".to_string(),
                half2_et_first_score_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team.Away,
            );
            record_bool(
                "FirstTry_Half2AndExtraTime_A".to_string(),
                half2_et_first_try_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team.Home,
            );
            record_bool(
                "FirstTry_Half2AndExtraTime_B".to_string(),
                half2_et_first_try_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team.Away,
            );
        }
        log::info!(
            "{}",
            "[First To Score Tracking Event] Record Extra Time first scores"
        );
        if extra_time_first_score_incident.is_some() {
            record_bool(
                "FirstToScore_ExtraTime_A".to_string(),
                extra_time_first_score_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team.Home,
            );
            record_bool(
                "FirstToScore_ExtraTime_B".to_string(),
                extra_time_first_score_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team.Away,
            );
            record_bool(
                "FirstTry_ExtraTime_A".to_string(),
                extra_time_first_try_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team.Home,
            );
            record_bool(
                "FirstTry_ExtraTime_B".to_string(),
                extra_time_first_try_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team.Away,
            );
        }
        log::info!(
            "{}",
            "[First To Score Tracking Event] Record Half 2 and Extra Time try timings"
        );
        if half2_et_first_try_incident.is_some() {
            record_int(
                "FirstTryTime_Half2AndExtraTime".to_string(),
                ((half2_et_first_try_incident.as_ref().unwrap().time_elapsed as f64) / (60 as f64))
                    as i32
                    + 1,
            );
            record_int(
                "FirstTryTime_Half2AndExtraTime_A".to_string(),
                if (half2_et_first_try_incident.is_some())
                    && (half2_et_first_try_incident
                        .as_ref()
                        .unwrap()
                        .points_scored_team
                        == Team.Home)
                {
                    ((half2_et_first_try_incident.as_ref().unwrap().time_elapsed as f64)
                        / (60 as f64)) as i32
                        + 1
                } else {
                    0
                },
            );
            record_int(
                "FirstTryTime_Half2AndExtraTime_B".to_string(),
                if (half2_et_first_try_incident.is_some())
                    && (half2_et_first_try_incident
                        .as_ref()
                        .unwrap()
                        .points_scored_team
                        == Team.Away)
                {
                    ((half2_et_first_try_incident.as_ref().unwrap().time_elapsed as f64)
                        / (60 as f64)) as i32
                        + 1
                } else {
                    0
                },
            );
        }
        log::info!(
            "{}",
            "[First To Score Tracking Event] Record Extra Time try timings"
        );
        if extra_time_first_try_incident.is_some() {
            record_int(
                "FirstTryTime_ExtraTime".to_string(),
                if extra_time_first_try_incident.is_some() {
                    ((extra_time_first_try_incident.as_ref().unwrap().time_elapsed as f64)
                        / (60 as f64)) as i32
                        + 1
                } else {
                    0
                },
            );
            record_int(
                "FirstTryTime_ExtraTime_A".to_string(),
                if (extra_time_first_try_incident.is_some())
                    && (extra_time_first_try_incident
                        .as_ref()
                        .unwrap()
                        .points_scored_team
                        == Team.Home)
                {
                    ((extra_time_first_try_incident.as_ref().unwrap().time_elapsed as f64)
                        / (60 as f64)) as i32
                        + 1
                } else {
                    0
                },
            );
            record_int(
                "FirstTryTime_ExtraTime_B".to_string(),
                if (extra_time_first_try_incident.is_some())
                    && (extra_time_first_try_incident
                        .as_ref()
                        .unwrap()
                        .points_scored_team
                        == Team.Away)
                {
                    ((extra_time_first_try_incident.as_ref().unwrap().time_elapsed as f64)
                        / (60 as f64)) as i32
                        + 1
                } else {
                    0
                },
            );
        }
        log::info!(
            "{}",
            "[First To Score Tracking Event] Record match first try timings"
        );
        if match_first_try_incident.is_some() {
            record_int(
                "FirstTryTime_Match".to_string(),
                if match_first_try_time.is_some() {
                    match_first_try_time.unwrap()
                } else {
                    0
                },
            );
            record_int(
                "FirstTryTime_Match_A".to_string(),
                if home_first_try_time.is_some() {
                    home_first_try_time.unwrap()
                } else {
                    0
                },
            );
            record_int(
                "FirstTryTime_Match_B".to_string(),
                if away_first_try_time.is_some() {
                    away_first_try_time.unwrap()
                } else {
                    0
                },
            );
        }
        log::info!(
            "{}",
            "[First To Score Tracking Event] Record last scoring outputs when match ended"
        );
        if state.is_over {
            record_bool(
                "LastTry_Match_A".to_string(),
                (last_try_incident.is_some())
                    && (last_try_incident.as_ref().unwrap().points_scored_team == Team.Home),
            );
            record_bool(
                "LastTry_Match_B".to_string(),
                (last_try_incident.is_some())
                    && (last_try_incident.as_ref().unwrap().points_scored_team == Team.Away),
            );
            record_bool(
                "LastToScore_Match_A".to_string(),
                (last_score_incident.is_some())
                    && (last_score_incident.as_ref().unwrap().points_scored_team == Team.Home),
            );
            record_bool(
                "LastToScore_Match_B".to_string(),
                (last_score_incident.is_some())
                    && (last_score_incident.as_ref().unwrap().points_scored_team == Team.Away),
            );
            record_int(
                "LastTryTime_Match".to_string(),
                if last_try_time.is_some() {
                    last_try_time.unwrap()
                } else {
                    0
                },
            );
        }
    }
    return;
}
