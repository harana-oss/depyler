#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct NextPlayInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl NextPlayInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct NextPlayOutputs {
    pub play_type: Play,
}
impl NextPlayOutputs {
    pub fn new(play_type: Play) -> Self {
        Self { play_type }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "play_type" => Some(Box::new(self.play_type.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "play_type" => {
                if let Some(v) = value.downcast_ref::<Play>() {
                    self.play_type = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn next_play(state: &State) -> NextPlayOutputs {
    let mut distance_to_try_line: i32 = 0;
    let mut player_advantage: i32 = 0;
    let mut possessing_team_margin: f64 = 0.0;
    log::info!("{}", "[NextPlay] Set variables");
    let _cse_temp_0 = (if state.team_in_possession == Team.Home {
        (state.away_sin_bin.len() as i32).saturating_sub(state.home_sin_bin.len() as i32)
    } else {
        (state.home_sin_bin.len() as i32).saturating_sub(state.away_sin_bin.len() as i32)
    }) as i32;
    player_advantage = _cse_temp_0;
    let _cse_temp_1 = (calculate_margin(state.clone())) as f64;
    possessing_team_margin = _cse_temp_1;
    distance_to_try_line = calculate_dist_to_try_line(state.clone());
    log::info!("{}", "[NextPlay] Run next play model");
    let model: NextPlayInferOutputs0 = infer::<NextPlayInferOutputs0>(
        "next_play".to_string(),
        vec![
            (state.tackles) as f64,
            (distance_to_try_line) as f64,
            (calculate_dist_from_centre(state.clone())) as f64,
            (get_team_handicap(state)) as f64,
            (state.simulation_invariants.total_points) as f64,
            (state.home_match_score + state.away_match_score) as f64,
            (f64::max(f64::min(possessing_team_margin / 2.0, 10.0), -10.0)) as f64,
            btf(player_advantage == 1),
            btf(player_advantage > 1),
            btf(player_advantage == -1),
            btf(player_advantage < -1),
            (if (0 < distance_to_try_line) && (distance_to_try_line <= 10) {
                0.8
            } else {
                if (10 < distance_to_try_line) && (distance_to_try_line <= 20) {
                    0.06
                } else {
                    0.0
                }
            }) as f64,
        ],
    );
    log::info!("{}", "[NextPlay] Return next play");
    return NextPlayOutputs::new(Play::new((sample(model.probabilities, random())) as i32));
}
