#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct PlayerTriesInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl PlayerTriesInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlayerTriesOutputs {
    pub player_index: i32,
}
impl PlayerTriesOutputs {
    pub fn new(player_index: i32) -> Self {
        Self { player_index }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "player_index" => Some(Box::new(self.player_index.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "player_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.player_index = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn player_tries(state: &State) -> PlayerTriesOutputs {
    let player_index: i32 = 0;
    log::info!("{}", "[PlayerTries] Calculate player try distributions");
    let percentage: Vec<f64> = get_team_try_distributions(state);
    log::info!("{}", "[PlayerTries] Run player tries model");
    let model: PlayerTriesInferOutputs0 = infer::<PlayerTriesInferOutputs0>(
        "player_tries".to_string(),
        vec![
            percentage.get(0usize).cloned().unwrap(),
            percentage.get(1usize).cloned().unwrap(),
            percentage.get(2usize).cloned().unwrap(),
            percentage.get(3usize).cloned().unwrap(),
            percentage.get(4usize).cloned().unwrap(),
            percentage.get(5usize).cloned().unwrap(),
            percentage.get(6usize).cloned().unwrap(),
            percentage.get(7usize).cloned().unwrap(),
            percentage.get(8usize).cloned().unwrap(),
            percentage.get(9usize).cloned().unwrap(),
            percentage.get(10usize).cloned().unwrap(),
            percentage.get(11usize).cloned().unwrap(),
            percentage.get(12usize).cloned().unwrap(),
        ],
    );
    log::info!("{}", "[PlayerTries] Return sampled player context");
    return PlayerTriesOutputs::new(sample(model.probabilities, random()));
}
