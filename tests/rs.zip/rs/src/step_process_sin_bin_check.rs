#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn process_sin_bin_check(state: &State) {
    log::info!("{}", "[ProcessSinBinCheck] Run sin bin model");
    let send_off_result: SinBinOutputs = sin_bin(state.clone());
    log::info!("{}", "[ProcessSinBinCheck] Run player sin bin model");
    if send_off_result.sent_off {
        player_sin_bin(
            state.clone(),
            ((state.current_play == Play.WonPenalty) && (state.team_in_possession == Team.Home))
                || ((state.current_play != Play.WonPenalty)
                    && (state.team_in_possession == Team.Away)),
        );
    }
    execute_events(state);
    return;
}
