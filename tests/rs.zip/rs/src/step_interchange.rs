#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone)]
pub struct IndexError {
    message: String,
}
impl std::fmt::Display for IndexError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "index out of range: {}", self.message)
    }
}
impl std::error::Error for IndexError {}
impl IndexError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct InterchangeInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl InterchangeInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct InterchangeInferOutputs1 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl InterchangeInferOutputs1 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn interchange(state: &State) {
    let mut away_interchange_executed: bool = false;
    let mut away_off_player_index: Option<i32> = None;
    let mut away_on_player_index: Option<i32> = None;
    let mut away_should_interchange: bool = false;
    let mut home_interchange_executed: bool = false;
    let mut home_off_player_index: Option<i32> = None;
    let mut home_on_player_index: Option<i32> = None;
    let mut home_should_interchange: bool = false;
    log::info!("{}", "[Interchange] Reset interchange context");
    away_on_player_index = None;
    home_on_player_index = None;
    home_interchange_executed = false;
    home_should_interchange = false;
    away_should_interchange = false;
    away_off_player_index = None;
    home_off_player_index = None;
    away_interchange_executed = false;
    log::info!("{}", "[Interchange] Sample home interchange decision");
    if state.home_remaining_interchanges > 0 {
        log::info!("{}", "[Interchange] Infer home interchange model");
        let home_interchange_model: InterchangeInferOutputs0 = infer::<InterchangeInferOutputs0>(
            "interchange".to_string(),
            vec![
                (((state.time_elapsed as f64) / (60 as f64)) as i32) as f64,
                (get_time_on_field_for_position(state.clone(), Team.Home, PlayerPosition.FullBack))
                    as f64,
                (get_time_on_field_for_position(state, Team.Home, PlayerPosition.WingerOne)) as f64,
                (get_time_on_field_for_position(state, Team.Home, PlayerPosition.CentreOne)) as f64,
                (get_time_on_field_for_position(state, Team.Home, PlayerPosition.CentreTwo)) as f64,
                (get_time_on_field_for_position(state, Team.Home, PlayerPosition.WingerTwo)) as f64,
                (get_time_on_field_for_position(state, Team.Home, PlayerPosition.FiveEighth))
                    as f64,
                (get_time_on_field_for_position(state, Team.Home, PlayerPosition.HalfBack)) as f64,
                (get_time_on_field_for_position(state, Team.Home, PlayerPosition.PropOne)) as f64,
                (get_time_on_field_for_position(state, Team.Home, PlayerPosition.Hooker)) as f64,
                (get_time_on_field_for_position(state, Team.Home, PlayerPosition.PropTwo)) as f64,
                (get_time_on_field_for_position(state, Team.Home, PlayerPosition.SecondRowOne))
                    as f64,
                (get_time_on_field_for_position(state, Team.Home, PlayerPosition.SecondRowTwo))
                    as f64,
                (get_time_on_field_for_position(state, Team.Home, PlayerPosition.Lock)) as f64,
                (get_interchanges_used(state, Team.Home)) as f64,
            ],
        );
        log::info!("{}", "[Interchange] Decide home interchange outcome");
        let _cse_temp_0 = (home_interchange_model
            .probabilities
            .get(0usize)
            .cloned()
            .unwrap()) as i32;
        home_should_interchange = _cse_temp_0 == 1;
    }
    log::info!("{}", "[Interchange] Sample home player selection");
    if home_should_interchange {
        log::info!("{}", "[Interchange] Infer home player selection");
        let home_execution: PlayerInterchangeOutputs =
            player_interchange(state.clone(), home_selection.position_index, Team.Home);
        log::info!("{}", "[Interchange] Finalise home interchange");
        if home_execution.executed {
            home_interchange_executed = true;
            home_off_player_index = Some(home_execution.off_player_index);
            home_on_player_index = Some(home_execution.on_player_index);
        }
    }
    log::info!("{}", "[Interchange] Reduce home interchange counter");
    if home_interchange_executed {
        decrement_remaining_interchanges(state.clone(), Team.Home);
    }
    log::info!("{}", "[Interchange] Sample away interchange decision");
    if state.away_remaining_interchanges > 0 {
        log::info!("{}", "[Interchange] Infer away interchange model");
        let away_interchange_model: InterchangeInferOutputs1 = infer::<InterchangeInferOutputs1>(
            "Interchange".to_string(),
            vec![
                (((state.time_elapsed as f64) / (60 as f64)) as i32) as f64,
                (get_time_on_field_for_position(state.clone(), Team.Away, PlayerPosition.FullBack))
                    as f64,
                (get_time_on_field_for_position(state, Team.Away, PlayerPosition.WingerOne)) as f64,
                (get_time_on_field_for_position(state, Team.Away, PlayerPosition.CentreOne)) as f64,
                (get_time_on_field_for_position(state, Team.Away, PlayerPosition.CentreTwo)) as f64,
                (get_time_on_field_for_position(state, Team.Away, PlayerPosition.WingerTwo)) as f64,
                (get_time_on_field_for_position(state, Team.Away, PlayerPosition.FiveEighth))
                    as f64,
                (get_time_on_field_for_position(state, Team.Away, PlayerPosition.HalfBack)) as f64,
                (get_time_on_field_for_position(state, Team.Away, PlayerPosition.PropOne)) as f64,
                (get_time_on_field_for_position(state, Team.Away, PlayerPosition.Hooker)) as f64,
                (get_time_on_field_for_position(state, Team.Away, PlayerPosition.PropTwo)) as f64,
                (get_time_on_field_for_position(state, Team.Away, PlayerPosition.SecondRowOne))
                    as f64,
                (get_time_on_field_for_position(state, Team.Away, PlayerPosition.SecondRowTwo))
                    as f64,
                (get_time_on_field_for_position(state, Team.Away, PlayerPosition.Lock)) as f64,
                (get_interchanges_used(state, Team.Away)) as f64,
            ],
        );
        log::info!("{}", "[Interchange] Decide away interchange outcome");
        let _cse_temp_1 = (away_interchange_model
            .probabilities
            .get(0usize)
            .cloned()
            .unwrap()) as i32;
        away_should_interchange = _cse_temp_1 == 1;
    }
    log::info!("{}", "[Interchange] Sample away player selection");
    if away_should_interchange {
        log::info!("{}", "[Interchange] Infer away player selection");
        let away_execution: PlayerInterchangeOutputs =
            player_interchange(state.clone(), away_selection.position_index, Team.Away);
        log::info!("{}", "[Interchange] Finalise away interchange");
        if away_execution.executed {
            away_interchange_executed = true;
            away_off_player_index = Some(away_execution.off_player_index);
            away_on_player_index = Some(away_execution.on_player_index);
        }
    }
    log::info!("{}", "[Interchange] Reduce away interchange counter");
    if away_interchange_executed {
        decrement_remaining_interchanges(state.clone(), Team.Away);
    }
    log::info!("{}", "[Interchange] Update game state after interchanges");
    if (home_interchange_executed) || (away_interchange_executed) {
        let away_off_index = away_off_player_index;
        let home_off_index = home_off_player_index;
        let away_executed = away_interchange_executed;
        let home_on_index = home_on_player_index;
        let home_executed = home_interchange_executed;
        let last_event = "INTERCHANGE".to_string();
        let away_on_index = away_on_player_index;
    }
    execute_events(state.clone());
    return;
}
