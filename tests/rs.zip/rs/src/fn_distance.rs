#[doc = "Distance from centre of the field from the perspective of the team in possession."]
pub fn calculate_dist_from_centre(state: &State) -> i32 {
    if state.team_in_possession == Team.Home {
        return ((CENTRE_OF_THE_FIELD_Y - state.ball_location.y).abs()) as i32;
    } else {
        return ((CENTRE_OF_THE_FIELD_Y - PLAYING_FIELD_HEIGHT - state.ball_location.y).abs())
            as i32;
    }
}
#[doc = "Distance to the try line from the perspective of the team in possession."]
pub fn calculate_dist_to_try_line(state: &State) -> i32 {
    if state.team_in_possession == Team.Home {
        return PLAYING_FIELD_WIDTH - state.ball_location.x;
    } else {
        return state.ball_location.x;
    }
}
