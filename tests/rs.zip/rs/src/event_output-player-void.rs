#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn player_void_output_event(state: &State) {
    let mut away_trader_players: Vec<Player> = Vec::new();
    let mut home_trader_players: Vec<Player> = Vec::new();
    if state.include_players {
        log::info!("{}", "[Player Void Output Event] Bind trader state players");
        away_trader_players = state.away_players;
        home_trader_players = state.home_players;
        log::info!(
            "{}",
            "[Player Void Output Event] Output home player void status"
        );
        for player in home_trader_players.iter().cloned() {
            log::info!("{}", "[Player Void Output Event] record");
            record_bool(
                format!("Player_Voided_{}", player.player_index),
                player.is_voided,
            );
        }
        log::info!(
            "{}",
            "[Player Void Output Event] Output away player void status"
        );
        for player in away_trader_players.iter().cloned() {
            log::info!("{}", "[Player Void Output Event] record");
            record_bool(
                format!("Player_Voided_{}", player.player_index),
                player.is_voided,
            );
        }
    }
    return;
}
