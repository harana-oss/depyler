#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone)]
pub struct IndexError {
    message: String,
}
impl std::fmt::Display for IndexError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "index out of range: {}", self.message)
    }
}
impl std::error::Error for IndexError {}
impl IndexError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct ClockInferOutputs0 {
    pub variable: Vec<f64>,
}
impl ClockInferOutputs0 {
    pub fn new(variable: Vec<f64>) -> Self {
        Self { variable }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "variable" => Some(Box::new(self.variable.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "variable" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.variable = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct ClockOutputs {
    pub seconds_to_add: f64,
}
impl ClockOutputs {
    pub fn new(seconds_to_add: f64) -> Self {
        Self { seconds_to_add }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "seconds_to_add" => {
                Some(Box::new(self.seconds_to_add.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "seconds_to_add" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.seconds_to_add = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn clock(state: &mut State) -> ClockOutputs {
    let mut seconds_to_add: f64 = 0.0;
    let mut seconds_to_add_initial: f64 = 0.0;
    let mut time_adjustment: f64 = 0.0;
    log::info!("{}", "[Clock] Run clock model");
    let model: ClockInferOutputs0 = infer::<ClockInferOutputs0>(
        "clock".to_string(),
        vec![
            btf(state.current_play == Play.Pass),
            btf(state.current_play == Play.RunTackle),
            btf(state.current_play == Play.KickTurnover),
            btf(state.current_play == Play.ErrorAttack),
            btf(state.current_play == Play.ErrorDefence),
            btf(state.current_play == Play.RunTry),
            btf(state.current_play == Play.ConcededPenalty),
            btf(state.current_play == Play.WonPenalty),
            btf(state.current_play == Play.LineDropout),
            btf(state.current_play == Play.KickRetainTackle),
            btf(state.current_play == Play.KickRetainTry),
            btf(state.current_play == Play.KickRetain),
            btf(state.previous_play == Play.Pass),
            btf(state.previous_play == Play.RunTackle),
            (state.tackles) as f64,
            (if (state.time_elapsed) as i32 > FULL_TIME_SECONDS {
                NEAR_END_SECONDS
            } else {
                (state.time_elapsed) as i32
            }) as f64,
            (if state.team_in_possession == Team.Home {
                state.ball_location.x
            } else {
                (PLAYING_FIELD_WIDTH - state.ball_location.x).abs()
            }) as f64,
            (if state.team_in_possession == Team.Home {
                state.ball_location.y
            } else {
                (PLAYING_FIELD_HEIGHT - state.ball_location.y).abs()
            }) as f64,
            (if state.team_in_possession == Team.Home {
                state.previous_ball_location.x
            } else {
                (PLAYING_FIELD_WIDTH - state.previous_ball_location.x).abs()
            }) as f64,
            (if state.team_in_possession == Team.Home {
                state.previous_ball_location.y
            } else {
                (PLAYING_FIELD_HEIGHT - state.previous_ball_location.y).abs()
            }) as f64,
        ],
    );
    log::info!("{}", "[Clock] Round to 1 decimal place");
    let _cse_temp_0 = (model.variable.get(0usize).cloned().unwrap()) as f64;
    let _cse_temp_1 = {
        let multiplier = (10.0_f64).powi(1 as i32);
        (_cse_temp_0 * multiplier).round() / multiplier
    };
    seconds_to_add_initial = _cse_temp_1;
    log::info!("{}", "[Clock] Cap non-try increments at 20 seconds");
    if ![Play.RunTry, Play.KickRetainTry].contains(&state.current_play) {
        let _cse_temp_2 = f64::max(seconds_to_add_initial, 20.0);
        seconds_to_add_initial = _cse_temp_2;
    }
    log::info!("{}", "[Clock] Default time adjustment");
    time_adjustment = 1.0;
    log::info!("{}", "[Clock] Apply period-specific time adjustment");
    if state.period.name == PeriodName.FirstHalf {
        log::info!("{}", "[Clock] Set variables");
        time_adjustment = 0.86;
    }
    log::info!("{}", "[Clock] Calculate final seconds to add");
    seconds_to_add = seconds_to_add_initial * time_adjustment;
    log::info!("{}", "[Clock] Update game state");
    let _cse_temp_3 = (seconds_to_add) as i32;
    state.time_elapsed = state.time_elapsed + _cse_temp_3;
    log::info!("{}", "[Clock] Return seconds added");
    return ClockOutputs::new(seconds_to_add);
}
