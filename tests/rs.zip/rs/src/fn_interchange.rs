use rand as random;
use rand::prelude::*;
use rand::rngs::SmallRng;
use rand::seq::SliceRandom;
use rand::Rng;
use rand::SeedableRng;
thread_local! {
    static DEPYLER_RNG: std::cell::RefCell<SmallRng>= std::cell::RefCell::new(SmallRng::from_os_rng());

}
pub fn get_time_on_field_for_position(
    state: &State,
    team: &Team,
    position: &PlayerPosition,
) -> f64 {
    let players = _team_players(state, team);
    let candidate = players
        .iter()
        .find(|p| p.position == *position)
        .cloned()
        .expect("StopIteration: iterator is empty");
    return (candidate.total_statistics.time_on_field) as f64;
}
pub fn get_interchanges_used(state: &State, team: &Team) -> f64 {
    let remaining = _get_remaining_interchanges(state, team);
    let used = MAX_INTERCHANGES - remaining;
    return (std::cmp::max(0, used)) as f64;
}
pub fn get_team_margin(state: &State, team: &Team) -> f64 {
    let home_score = state.home_match_score;
    let away_score = state.away_match_score;
    return if *team == Team.Home {
        (home_score - away_score) as f64
    } else {
        (away_score - home_score) as f64
    };
}
pub fn decrement_remaining_interchanges(state: &mut State, team: &Team) {
    let current = _get_remaining_interchanges(state, team);
    let _cse_temp_0 = std::cmp::max(0, current - 1);
    let remaining = _cse_temp_0;
    _set_remaining_interchanges(state, team, remaining);
}
pub fn _select_bench_player_index(players: &Vec<Player>, starters: i32) -> i32 {
    let available = (starters..players.len() as i32)
        .filter(|&idx| !players.get(idx as usize).cloned().unwrap().is_injured)
        .collect::<Vec<_>>();
    return DEPYLER_RNG.with(|rng| *available.choose(&mut *rng.borrow_mut()).unwrap());
}
pub fn _refresh_all_players(state: &mut State) {
    let mut combined = vec![];
    for team in [Team.Home, Team.Away] {
        combined.extend(_team_players(state, &team).iter().cloned());
    }
    state.all_players.clear();
    state.all_players.extend(combined);
}
pub fn _team_players(state: &State, team: &Team) -> Vec<Player> {
    return if *team == Team.Home {
        state.home_players
    } else {
        state.away_players
    };
}
pub fn _team_statistic(state: &State, team: &Team) -> TeamStatistics {
    return if *team == Team.Home {
        state.home_statistics
    } else {
        state.away_statistics
    };
}
pub fn _get_remaining_interchanges(state: &State, team: &Team) -> i32 {
    return if *team == Team.Home {
        state.home_remaining_interchanges
    } else {
        state.away_remaining_interchanges
    };
}
pub fn _set_remaining_interchanges(state: &mut State, team: &Team, value: i32) {
    if *team == Team.Home {
        state.home_remaining_interchanges = value;
    } else {
        state.away_remaining_interchanges = value;
    }
}
