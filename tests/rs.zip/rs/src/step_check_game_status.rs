#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn check_game_status(state: &mut State) {
    log::info!(
        "{}",
        "[CheckGameStatus] Check if normal time half is complete"
    );
    let _cse_temp_0 = (state.time_elapsed > HALF_LENGTH_IN_SECONDS)
        && (state.period.name != PeriodName.ExtraTime);
    if _cse_temp_0 {
        log::info!("{}", "[CheckGameStatus] Handle end of first half");
        if state.period.name == PeriodName.FirstHalf {
            log::info!("{}", "[CheckGameStatus] Transition to second half");
            state.period.name = PeriodName.SecondHalf;
            state.period.number = 2;
            state.game_status = GameStatus.Period2;
        } else {
            log::info!("{}", "[CheckGameStatus] Check if normal time is complete");
            if state.time_elapsed >= GAME_LENGTH_IN_SECONDS {
                log::info!("{}", "[CheckGameStatus] Check for extra time or game end");
                if state.home_match_score == state.away_match_score {
                    log::info!("{}", "[CheckGameStatus] Enter extra time");
                    state.period.number = 3;
                    state.period.name = PeriodName.ExtraTime;
                    state.game_status = GameStatus.ExtraTime;
                    state.is_extratime = true;
                } else {
                    log::info!("{}", "[CheckGameStatus] End game");
                    state.is_over = true;
                    state.game_status = GameStatus.Ended;
                }
            }
        }
    }
    log::info!("{}", "[CheckGameStatus] Check extra time conditions");
    if state.period.name == PeriodName.ExtraTime {
        log::info!("{}", "[CheckGameStatus] Check if extra time should end");
        let _cse_temp_1 =
            state.time_elapsed >= GAME_LENGTH_IN_SECONDS + EXTRA_TIME_LENGTH_IN_SECONDS;
        let _cse_temp_2 = (_cse_temp_1) || (state.home_match_score != state.away_match_score);
        if _cse_temp_2 {
            log::info!("{}", "[CheckGameStatus] End game");
            state.game_status = GameStatus.Ended;
            state.is_over = true;
        }
    }
    execute_events(state);
    return;
}
