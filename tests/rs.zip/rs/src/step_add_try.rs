#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn add_try(state: &mut State) {
    log::info!("{}", "[AddTry] Get period index");
    let period_idx = state.period.number - 1;
    log::info!("{}", "[AddTry] Add try points to home team");
    if state.team_in_possession == Team.Home {
        log::info!("{}", "[AddTry] Update home match score");
        state.home_match_score = state.home_match_score + TRY_POINTS;
        log::info!("{}", "[AddTry] Update home period statistics");
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + TRY_POINTS;
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .tries = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .tries
            + 1;
        log::info!("{}", "[AddTry] Update home total statistics");
        state.home_statistics.total_statistics.scores.total =
            state.home_statistics.total_statistics.scores.total + TRY_POINTS;
        state.home_statistics.total_statistics.scores.tries =
            state.home_statistics.total_statistics.scores.tries + 1;
    }
    log::info!("{}", "[AddTry] Add try points to away team");
    if state.team_in_possession == Team.Away {
        log::info!("{}", "[AddTry] Update away match score");
        state.away_match_score = state.away_match_score + TRY_POINTS;
        log::info!("{}", "[AddTry] Update away period statistics");
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .tries = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .tries
            + 1;
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + TRY_POINTS;
        log::info!("{}", "[AddTry] Update away total statistics");
        state.away_statistics.total_statistics.scores.tries =
            state.away_statistics.total_statistics.scores.tries + 1;
        state.away_statistics.total_statistics.scores.total =
            state.away_statistics.total_statistics.scores.total + TRY_POINTS;
    }
    execute_events(state);
    return;
}
