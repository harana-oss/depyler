use crate::*;
use bevy_reflect::Reflect;
use quantsim_modules::log::*;
use quantsim_modules::infer::*;
use quantsim_modules::monitoring::*;
use quantsim_modules::output::*;
use quantsim_modules::rng::*;
use quantsim_macro::*;
use std::any::Any;

#[doc = "// NOTE: Map Python module 'enum'()"]
#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module '__future__'()"]
#[doc = "// NOTE: Map Python module '__future__'()"]
#[doc = "// NOTE: Map Python module 'sin_bin'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'enum'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
use rand as random;
use std::f64 as math;
pub const CENTRE_OF_THE_FIELD_X: i32 = 500;
pub const CENTRE_OF_THE_FIELD_Y: i32 = 350;
pub const CONVERSION_POINTS: i32 = 2;
pub const DROPOUT_X: i32 = 0;
pub const DROPOUT_Y: i32 = 350;
pub const EXTRA_TIME_INDEX: i32 = 2;
pub const EXTRA_TIME_LENGTH_IN_SECONDS: i32 = 600;
pub const FIELD_GOAL_ATTEMPT_EXTRA_TIME_SECONDS: i32 = 180;
pub const FIELD_GOAL_MAX_ABSOLUTE: i32 = 900;
pub const FIELD_GOAL_MAX_TIME_FIRST: i32 = 2400;
pub const FIELD_GOAL_MIN_ABSOLUTE: i32 = 100;
pub const FIELD_GOAL_MIN_AWAY: i32 = 400;
pub const FIELD_GOAL_MIN_HOME: i32 = 600;
pub const FIELD_GOAL_MIN_TIME_FIRST: i32 = 2340;
pub const FIELD_GOAL_MIN_TIME_SECOND: i32 = 4200;
pub const FIELD_GOAL_PARAM_EXTRA_TIME_VALUE: i32 = 25;
pub const FIELD_GOAL_POINTS: i32 = 1;
pub const FIRST_EIGHT_MINUTES_SECONDS: i32 = 480;
pub const FIRST_HALF_INDEX: i32 = 0;
pub const FULL_TIME_SECONDS: i32 = 4800;
pub const GAME_LENGTH_IN_SECONDS: i32 = 4800;
pub const GOAL_LINE_GRID_START_INDEX: i32 = 60;
pub const GOAL_LINE_X_WIDTH: i32 = 20;
pub const GOAL_LINE_Y_HEIGHT_INCREMENT: i32 = 113;
pub const GOAL_LINE_Y_WIDTH: f64 = 23.34;
pub const HALF_LENGTH_IN_SECONDS: i32 = 2400;
pub const HOOKER_METRES_PER_MINUTE: f64 = 0.75057377;
pub const HOOKER_TACKLES_PER_MINUTE: f64 = 0.547090164;
pub const HOOKER_TRIES_PER_MINUTE: f64 = 0.00232582;
pub const INITIAL_SOLVER_HANDICAP: i32 = -3;
pub const INITIAL_SOLVER_TOTAL_POINTS: i32 = 45;
pub const KICKOFF_X: i32 = 500;
pub const KICKOFF_Y: i32 = 350;
pub const LAST_EIGHT_MINUTES_SECONDS: i32 = 4500;
pub const LAST_MINUTE_SECONDS: i32 = 60;
pub const LAST_TEN_MINUTES_SECONDS: i32 = 600;
pub const LOCK_METRES_PER_MINUTE: f64 = 2.519467213;
pub const LOCK_TACKLES_PER_MINUTE: f64 = 0.563770492;
pub const LOCK_TRIES_PER_MINUTE: f64 = 0.001212746;
pub const MAX_INTERCHANGES: i32 = 8;
pub const MIN_POM_WEIGHT: f64 = 0.0001;
pub const MISSED_FIELD_GOAL_RESTART_X: i32 = 200;
pub const NEAR_END_SECONDS: i32 = 4700;
pub const NUDGES_PERCENT: f64 = 1.0;
pub const NUMBER_OF_INTERCHANGE_PLAYERS: i32 = 4;
pub const NUMBER_OF_SIMULATIONS_DEFAULT: i32 = 40000;
pub const NUM_PERIODS: i32 = 4;
pub const NUM_PLAYERS_PER_TEAM: i32 = 17;
pub const NUM_STARTING_PLAYERS_PER_TEAM: i32 = 13;
pub const PENALTY_POINTS: i32 = 2;
pub const PLAYING_FIELD_BASE: i32 = 0;
pub const PLAYING_FIELD_HEIGHT: i32 = 700;
pub const PLAYING_FIELD_WIDTH: i32 = 1000;
pub const PROP_METRES_PER_MINUTE: f64 = 2.519467213;
pub const PROP_TACKLES_PER_MINUTE: f64 = 0.563770492;
pub const PROP_TRIES_PER_MINUTE: f64 = 0.001212746;
pub const SECOND_HALF_INDEX: i32 = 1;
pub const SOLVER_INITIAL_GRADIENT_NUMBER_OF_SIMULATIONS: i32 = 15000;
pub const STARTING_TACKLE: i32 = 1;
pub const TACKLES_PER_SET: i32 = 6;
pub const TRY_POINTS: i32 = 4;
pub const TRY_SCORER_DEFAULT_INDEXES: i32 = 1;
pub const TRY_SCORER_MATCH_INDEXES: i32 = 15;
pub const TWO_POINT_FIELD_GOAL_DISTANCE: i32 = 400;
pub const TWO_POINT_FIELD_GOAL_POINTS: i32 = 2;
pub const YELLOW_CARD_SECONDS: i32 = 600;
lazy_static! {
    pub static ref CONVERSION_X_VALUES: Vec<i32> = vec![
        769, 773, 779, 788, 801, 823, 845, 866, 878, 890, 890, 882, 868, 847, 825, 801, 786, 779,
        771, 769
    ];
    pub static ref GOAL_LINE_Y_VALUES: Vec<(i32, i32)> = vec![
        (0, 113),
        (113, 226),
        (226, 339),
        (339, 452),
        (452, 565),
        (565, 678),
        (678, 700)
    ];
    pub static ref GOAL_LINE_ZONE_WEIGHTS: Vec<Vec<f64>> = vec![
        vec![
            0.338255506,
            0.161521868,
            0.028635414,
            0.011633486,
            0.008945708,
            0.063982141,
            0.059955556,
            0.028635414,
            0.008948757,
            0.003132014,
            0.040716185,
            0.043848199,
            0.022818671,
            0.016107357,
            0.0035793,
            0.038031456,
            0.038478742,
            0.024161543,
            0.013869913,
            0.005369458,
            0.015660071,
            0.012324,
            0.005722,
            0.003967,
            0.0017
        ],
        vec![
            0.006393969,
            0.065970006,
            0.021313621,
            0.033491996,
            0.005074616,
            0.07510408,
            0.08931277,
            0.02841738,
            0.039581769,
            0.008118916,
            0.082209011,
            0.099462002,
            0.042627242,
            0.038566612,
            0.008118916,
            0.061910548,
            0.079163538,
            0.031462853,
            0.024357922,
            0.004059458,
            0.050746158,
            0.049731001,
            0.035522311,
            0.016239005,
            0.003044301
        ],
        vec![
            0.04926153,
            0.045038504,
            0.028853258,
            0.021815592,
            0.00492562,
            0.065446776,
            0.068261416,
            0.027445938,
            0.020408272,
            0.00281464,
            0.071077122,
            0.064743116,
            0.023222912,
            0.016186312,
            0.00281464,
            0.038705564,
            0.033075218,
            0.031667898,
            0.021111932,
            0.00211098,
            0.10696698,
            0.098521994,
            0.084447728,
            0.067557756,
            0.0035183
        ],
        vec![
            0.10696698,
            0.098521994,
            0.084447728,
            0.067557756,
            0.0035183,
            0.038705564,
            0.033075218,
            0.031667898,
            0.021111932,
            0.00211098,
            0.071077122,
            0.064743116,
            0.023222912,
            0.016186312,
            0.00281464,
            0.065446776,
            0.068261416,
            0.027445938,
            0.020408272,
            0.00281464,
            0.04926153,
            0.045038504,
            0.028853258,
            0.021815592,
            0.00492562
        ],
        vec![
            0.050746158,
            0.049731001,
            0.035522311,
            0.016239005,
            0.003044301,
            0.061910548,
            0.079163538,
            0.031462853,
            0.024357922,
            0.004059458,
            0.082209011,
            0.099462002,
            0.042627242,
            0.038566612,
            0.008118916,
            0.07510408,
            0.08931277,
            0.02841738,
            0.039581769,
            0.008118916,
            0.006393969,
            0.065970006,
            0.021313621,
            0.033491996,
            0.005074616
        ],
        vec![
            0.015660071,
            0.012324,
            0.005722,
            0.003961,
            0.0017,
            0.038031456,
            0.038478742,
            0.024161543,
            0.013869913,
            0.005369458,
            0.040716185,
            0.043848199,
            0.022818671,
            0.016107357,
            0.0035793,
            0.063982141,
            0.059955556,
            0.028635414,
            0.008948757,
            0.003132014,
            0.338255506,
            0.161521868,
            0.028635414,
            0.011633486,
            0.008949708
        ]
    ];
    pub static ref GRID_RESULT: Vec<String> = vec![
        "A1".to_string(),
        "A2".to_string(),
        "A3".to_string(),
        "A4".to_string(),
        "A5".to_string(),
        "A6".to_string(),
        "B1".to_string(),
        "B2".to_string(),
        "B3".to_string(),
        "B4".to_string(),
        "B5".to_string(),
        "B6".to_string(),
        "C1".to_string(),
        "C2".to_string(),
        "C3".to_string(),
        "C4".to_string(),
        "C5".to_string(),
        "C6".to_string(),
        "D1".to_string(),
        "D2".to_string(),
        "D3".to_string(),
        "D4".to_string(),
        "D5".to_string(),
        "D6".to_string(),
        "E1".to_string(),
        "E2".to_string(),
        "E3".to_string(),
        "E4".to_string(),
        "E5".to_string(),
        "E6".to_string(),
        "F1".to_string(),
        "F2".to_string(),
        "F3".to_string(),
        "F4".to_string(),
        "F5".to_string(),
        "F6".to_string(),
        "G1".to_string(),
        "G2".to_string(),
        "G3".to_string(),
        "G4".to_string(),
        "G5".to_string(),
        "G6".to_string(),
        "H1".to_string(),
        "H2".to_string(),
        "H3".to_string(),
        "H4".to_string(),
        "H5".to_string(),
        "H6".to_string(),
        "I1".to_string(),
        "I2".to_string(),
        "I3".to_string(),
        "I4".to_string(),
        "I5".to_string(),
        "I6".to_string(),
        "J1".to_string(),
        "J2".to_string(),
        "J3".to_string(),
        "J4".to_string(),
        "J5".to_string(),
        "J6".to_string(),
        "ZA1".to_string(),
        "ZA2".to_string(),
        "ZA3".to_string(),
        "ZA4".to_string(),
        "ZA5".to_string(),
        "ZA6".to_string(),
        "ZJ1".to_string(),
        "ZJ2".to_string(),
        "ZJ3".to_string(),
        "ZJ4".to_string(),
        "ZJ5".to_string(),
        "ZJ6".to_string()
    ];
    pub static ref KICKOFF_RESULTS: Vec<String> = vec![
        "A1KickAway".to_string(),
        "A1Retain".to_string(),
        "A2KickAway".to_string(),
        "A2Retain".to_string(),
        "A4KickAway".to_string(),
        "A4Retain".to_string(),
        "A5Retain".to_string(),
        "B1KickAway".to_string(),
        "B1Retain".to_string(),
        "B2KickAway".to_string(),
        "B2Retain".to_string(),
        "B3KickAway".to_string(),
        "B3Retain".to_string(),
        "B4KickAway".to_string(),
        "B4Retain".to_string(),
        "B5KickAway".to_string(),
        "B5Retain".to_string(),
        "B6KickAway".to_string(),
        "B6Retain".to_string(),
        "C1KickAway".to_string(),
        "C2KickAway".to_string(),
        "C2Retain".to_string(),
        "C3KickAway".to_string(),
        "C3Retain".to_string(),
        "C4KickAway".to_string(),
        "C4Retain".to_string(),
        "C5KickAway".to_string(),
        "C5Retain".to_string(),
        "C6KickAway".to_string(),
        "C6Retain".to_string(),
        "D1KickAway".to_string(),
        "D2KickAway".to_string(),
        "D3KickAway".to_string(),
        "D4KickAway".to_string(),
        "D4Retain".to_string(),
        "D5KickAway".to_string(),
        "D6KickAway".to_string(),
        "E1KickAway".to_string(),
        "E1Retain".to_string(),
        "E2KickAway".to_string(),
        "E2Retain".to_string(),
        "E3KickAway".to_string(),
        "E4KickAway".to_string(),
        "E4Retain".to_string(),
        "E5KickAway".to_string(),
        "E6KickAway".to_string(),
        "F1KickAway".to_string(),
        "F1Retain".to_string(),
        "F2KickAway".to_string(),
        "F2Retain".to_string(),
        "F3KickAway".to_string(),
        "F4KickAway".to_string(),
        "F4Retain".to_string(),
        "F5KickAway".to_string(),
        "F6KickAway".to_string(),
        "F6Retain".to_string(),
        "G1KickAway".to_string(),
        "G1Retain".to_string(),
        "G2KickAway".to_string(),
        "G2Retain".to_string(),
        "G3KickAway".to_string(),
        "G3Retain".to_string(),
        "G4KickAway".to_string(),
        "G4Retain".to_string(),
        "G5KickAway".to_string(),
        "G5Retain".to_string(),
        "G6KickAway".to_string(),
        "G6Retain".to_string(),
        "H1KickAway".to_string(),
        "H1Retain".to_string(),
        "H2KickAway".to_string(),
        "H2Retain".to_string(),
        "H3KickAway".to_string(),
        "H4KickAway".to_string(),
        "H4Retain".to_string(),
        "H5KickAway".to_string(),
        "H5Retain".to_string(),
        "H6KickAway".to_string(),
        "H6Retain".to_string(),
        "I1KickAway".to_string(),
        "I1Retain".to_string(),
        "I2KickAway".to_string(),
        "I2Retain".to_string(),
        "I3KickAway".to_string(),
        "I3Retain".to_string(),
        "I4KickAway".to_string(),
        "I4Retain".to_string(),
        "I5KickAway".to_string(),
        "I5Retain".to_string(),
        "I6KickAway".to_string(),
        "I6Retain".to_string(),
        "J1KickAway".to_string(),
        "J2KickAway".to_string(),
        "J3KickAway".to_string(),
        "J4KickAway".to_string(),
        "J5KickAway".to_string(),
        "J6KickAway".to_string(),
        "J6Retain".to_string()
    ];
    pub static ref KICKOFF_RETAIN_RESULTS: Vec<String> = vec![
        "A1Retain".to_string(),
        "A2Retain".to_string(),
        "A4Retain".to_string(),
        "A5Retain".to_string(),
        "B1Retain".to_string(),
        "B2Retain".to_string(),
        "B3Retain".to_string(),
        "B4Retain".to_string(),
        "B5Retain".to_string(),
        "B6Retain".to_string(),
        "C2Retain".to_string(),
        "C3Retain".to_string(),
        "C4Retain".to_string(),
        "C6Retain".to_string(),
        "D4Retain".to_string(),
        "E1Retain".to_string(),
        "E2Retain".to_string(),
        "E4Retain".to_string(),
        "F1Retain".to_string(),
        "F2Retain".to_string(),
        "F4Retain".to_string(),
        "F6Retain".to_string(),
        "G1Retain".to_string(),
        "G2Retain".to_string(),
        "G3Retain".to_string(),
        "G4Retain".to_string(),
        "G5Retain".to_string(),
        "G6Retain".to_string(),
        "H1Retain".to_string(),
        "H2Retain".to_string(),
        "H4Retain".to_string(),
        "H5Retain".to_string(),
        "H6Retain".to_string(),
        "I1Retain".to_string(),
        "I2Retain".to_string(),
        "I3Retain".to_string(),
        "I4Retain".to_string(),
        "I6Retain".to_string(),
        "J6Retain".to_string()
    ];
    pub static ref KICKOFF_TO_GRID_RESULT: HashMap<String, String> = {
        let mut map = HashMap::new();
        map.insert("A1Retain".to_string(), "A1".to_string());
        map.insert("A1KickAway".to_string(), "A1".to_string());
        map.insert("A2Retain".to_string(), "A2".to_string());
        map.insert("A2KickAway".to_string(), "A2".to_string());
        map.insert("A4Retain".to_string(), "A4".to_string());
        map.insert("A4KickAway".to_string(), "A4".to_string());
        map.insert("A5Retain".to_string(), "A5".to_string());
        map.insert("B1Retain".to_string(), "B1".to_string());
        map.insert("B1KickAway".to_string(), "B1".to_string());
        map.insert("B2Retain".to_string(), "B2".to_string());
        map.insert("B2KickAway".to_string(), "B2".to_string());
        map.insert("B3Retain".to_string(), "B3".to_string());
        map.insert("B3KickAway".to_string(), "B3".to_string());
        map.insert("B4Retain".to_string(), "B4".to_string());
        map.insert("B4KickAway".to_string(), "B4".to_string());
        map.insert("B5Retain".to_string(), "B5".to_string());
        map.insert("B5KickAway".to_string(), "B5".to_string());
        map.insert("B6Retain".to_string(), "B6".to_string());
        map.insert("B6KickAway".to_string(), "B6".to_string());
        map.insert("C1KickAway".to_string(), "C1".to_string());
        map.insert("C2Retain".to_string(), "C2".to_string());
        map.insert("C2KickAway".to_string(), "C2".to_string());
        map.insert("C3Retain".to_string(), "C3".to_string());
        map.insert("C3KickAway".to_string(), "C3".to_string());
        map.insert("C4Retain".to_string(), "C4".to_string());
        map.insert("C4KickAway".to_string(), "C4".to_string());
        map.insert("C5KickAway".to_string(), "C5".to_string());
        map.insert("C6Retain".to_string(), "C6".to_string());
        map.insert("C6KickAway".to_string(), "C6".to_string());
        map.insert("D1KickAway".to_string(), "D1".to_string());
        map.insert("D2KickAway".to_string(), "D2".to_string());
        map.insert("D3KickAway".to_string(), "D3".to_string());
        map.insert("D4Retain".to_string(), "D4".to_string());
        map.insert("D4KickAway".to_string(), "D4".to_string());
        map.insert("D5KickAway".to_string(), "D5".to_string());
        map.insert("D6KickAway".to_string(), "D6".to_string());
        map.insert("E1Retain".to_string(), "E1".to_string());
        map.insert("E1KickAway".to_string(), "E1".to_string());
        map.insert("E2Retain".to_string(), "E2".to_string());
        map.insert("E2KickAway".to_string(), "E2".to_string());
        map.insert("E3KickAway".to_string(), "E3".to_string());
        map.insert("E4Retain".to_string(), "E4".to_string());
        map.insert("E4KickAway".to_string(), "E4".to_string());
        map.insert("E5KickAway".to_string(), "E5".to_string());
        map.insert("E6KickAway".to_string(), "E6".to_string());
        map.insert("F1Retain".to_string(), "F1".to_string());
        map.insert("F1KickAway".to_string(), "F1".to_string());
        map.insert("F2Retain".to_string(), "F2".to_string());
        map.insert("F2KickAway".to_string(), "F2".to_string());
        map.insert("F3KickAway".to_string(), "F3".to_string());
        map.insert("F4Retain".to_string(), "F4".to_string());
        map.insert("F4KickAway".to_string(), "F4".to_string());
        map.insert("F5KickAway".to_string(), "F5".to_string());
        map.insert("F6Retain".to_string(), "F6".to_string());
        map.insert("F6KickAway".to_string(), "F6".to_string());
        map.insert("G1Retain".to_string(), "G1".to_string());
        map.insert("G1KickAway".to_string(), "G1".to_string());
        map.insert("G2Retain".to_string(), "G2".to_string());
        map.insert("G2KickAway".to_string(), "G2".to_string());
        map.insert("G3Retain".to_string(), "G3".to_string());
        map.insert("G3KickAway".to_string(), "G3".to_string());
        map.insert("G4Retain".to_string(), "G4".to_string());
        map.insert("G4KickAway".to_string(), "G4".to_string());
        map.insert("G5Retain".to_string(), "G5".to_string());
        map.insert("G5KickAway".to_string(), "G5".to_string());
        map.insert("G6Retain".to_string(), "G6".to_string());
        map.insert("G6KickAway".to_string(), "G6".to_string());
        map.insert("H1Retain".to_string(), "H1".to_string());
        map.insert("H1KickAway".to_string(), "H1".to_string());
        map.insert("H2Retain".to_string(), "H2".to_string());
        map.insert("H2KickAway".to_string(), "H2".to_string());
        map.insert("H3KickAway".to_string(), "H3".to_string());
        map.insert("H4Retain".to_string(), "H4".to_string());
        map.insert("H4KickAway".to_string(), "H4".to_string());
        map.insert("H5Retain".to_string(), "H5".to_string());
        map.insert("H5KickAway".to_string(), "H5".to_string());
        map.insert("H6Retain".to_string(), "H6".to_string());
        map.insert("H6KickAway".to_string(), "H6".to_string());
        map.insert("I1Retain".to_string(), "I1".to_string());
        map.insert("I1KickAway".to_string(), "I1".to_string());
        map.insert("I2Retain".to_string(), "I2".to_string());
        map.insert("I2KickAway".to_string(), "I2".to_string());
        map.insert("I3Retain".to_string(), "I3".to_string());
        map.insert("I3KickAway".to_string(), "I3".to_string());
        map.insert("I4Retain".to_string(), "I4".to_string());
        map.insert("I4KickAway".to_string(), "I4".to_string());
        map.insert("I5KickAway".to_string(), "I5".to_string());
        map.insert("I6Retain".to_string(), "I6".to_string());
        map.insert("I6KickAway".to_string(), "I6".to_string());
        map.insert("J1KickAway".to_string(), "J1".to_string());
        map.insert("J2KickAway".to_string(), "J2".to_string());
        map.insert("J3KickAway".to_string(), "J3".to_string());
        map.insert("J4KickAway".to_string(), "J4".to_string());
        map.insert("J5KickAway".to_string(), "J5".to_string());
        map.insert("J6Retain".to_string(), "J6".to_string());
        map.insert("J6KickAway".to_string(), "J6".to_string());
        map
    };
    pub static ref NEXT_PLAY_TYPES: Vec<String> = vec![
        "Pass".to_string(),
        "Run".to_string(),
        "RunTackle".to_string(),
        "RunTry".to_string(),
        "KickRetain".to_string(),
        "KickRetainTackle".to_string(),
        "KickRetainTry".to_string(),
        "KickTurnover".to_string(),
        "ErrorAttack".to_string(),
        "ErrorDefence".to_string(),
        "ConcededPenalty".to_string(),
        "WonPenalty".to_string(),
        "LineDropout".to_string(),
        "FieldGoalAttempt".to_string()
    ];
    pub static ref PLAYER_MODEL_POSITIONS: Vec<String> = vec![
        "FullBack".to_string(),
        "WingerOne".to_string(),
        "CentreOne".to_string(),
        "CentreTwo".to_string(),
        "WingerTwo".to_string(),
        "FiveEighth".to_string(),
        "HalfBack".to_string(),
        "PropOne".to_string(),
        "Hooker".to_string(),
        "PropTwo".to_string(),
        "SecondRowOne".to_string(),
        "SecondRowTwo".to_string(),
        "Lock".to_string()
    ];
    pub static ref PLAYER_POSITION_SEQUENCE: Vec<String> = vec![
        "FullBack".to_string(),
        "WingerOne".to_string(),
        "CentreOne".to_string(),
        "CentreTwo".to_string(),
        "WingerTwo".to_string(),
        "FiveEighth".to_string(),
        "HalfBack".to_string(),
        "PropOne".to_string(),
        "Hooker".to_string(),
        "PropTwo".to_string(),
        "SecondRowOne".to_string(),
        "SecondRowTwo".to_string(),
        "Lock".to_string()
    ];
    pub static ref X_VALUES: Vec<(i32, i32)> = vec![
        (0, 100),
        (100, 200),
        (200, 300),
        (300, 400),
        (400, 500),
        (500, 600),
        (600, 700),
        (700, 800),
        (800, 900),
        (900, 1000),
        (-100, 1),
        (1000, 1100)
    ];
    pub static ref X_VALUES_AWAY: Vec<(i32, i32)> = vec![
        (900, 1000),
        (800, 900),
        (700, 800),
        (600, 700),
        (500, 600),
        (400, 500),
        (300, 400),
        (200, 300),
        (100, 200),
        (0, 100),
        (1000, 1100),
        (-100, 1)
    ];
    pub static ref Y_VALUES: Vec<(i32, i32)> = vec![
        (0, 118),
        (118, 234),
        (234, 351),
        (351, 468),
        (468, 584),
        (584, 700)
    ];
    pub static ref Y_VALUES_AWAY: Vec<(i32, i32)> = vec![
        (584, 700),
        (468, 584),
        (351, 468),
        (234, 351),
        (118, 234),
        (0, 118)
    ];
}
use lazy_static::lazy_static;
use rand::prelude::*;
use rand::rngs::SmallRng;
use rand::seq::SliceRandom;
use rand::Rng;
use rand::SeedableRng;
use std::collections::HashMap;
thread_local! {
    static DEPYLER_RNG: std::cell::RefCell<SmallRng>= std::cell::RefCell::new(SmallRng::from_os_rng());

}
#[derive(Debug, Clone)]
pub struct ZeroDivisionError {
    message: String,
}
impl std::fmt::Display for ZeroDivisionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "division by zero: {}", self.message)
    }
}
impl std::error::Error for ZeroDivisionError {}
impl ZeroDivisionError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
#[derive(Debug, Clone)]
pub struct IndexError {
    message: String,
}
impl std::fmt::Display for IndexError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "index out of range: {}", self.message)
    }
}
impl std::error::Error for IndexError {}
impl IndexError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub struct ExecutedEvents;
impl ExecutedEvents {
    pub const NONE: i32 = 0;
    pub const PERIOD_FIRST_LAST_SCORE: i32 = 1;
    pub const FIRST_HALF_OUTPUT: i32 = 2;
    pub const NORMAL_TIME_OUTPUT: i32 = 4;
    pub const MINUTE_WINNER_TRACKING: i32 = 16;
    pub const DEBUG: i32 = 32;
    pub const PLAYER_VOID_OUTPUT: i32 = 64;
    pub const END_OF_GAME_OUTPUT: i32 = 128;
    pub const TEST_ONCE: i32 = 256;
    pub const FIRST_TO_SCORE_TRACKING: i32 = 1024;
    pub const RACE_TO_POINTS_TRACKING: i32 = 2048;
    pub const ANYTIME_OUTPUT: i32 = 4096;
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum GameStatus {
    #[default]
    Abandoned = 0,
    AwaitingExtraTime = 1,
    Delayed = 2,
    Ended = 3,
    ExtraTime = 4,
    HalfTime = 5,
    Interrupted = 6,
    NotStarted = 7,
    Period1 = 8,
    Period2 = 9,
    Postponed = 10,
    UnknownStatus = 11,
}
impl GameStatus {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::Abandoned),
            1 => Some(Self::AwaitingExtraTime),
            2 => Some(Self::Delayed),
            3 => Some(Self::Ended),
            4 => Some(Self::ExtraTime),
            5 => Some(Self::HalfTime),
            6 => Some(Self::Interrupted),
            7 => Some(Self::NotStarted),
            8 => Some(Self::Period1),
            9 => Some(Self::Period2),
            10 => Some(Self::Postponed),
            11 => Some(Self::UnknownStatus),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::Abandoned)
    }
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Strength {
    #[default]
    Low = 0,
    Mid = 1,
    High = 2,
}
impl Strength {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::Low),
            1 => Some(Self::Mid),
            2 => Some(Self::High),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::Low)
    }
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum ScoreType {
    #[default]
    NotSet = 0,
    Try = 1,
    Conversion = 2,
    PenaltyGoal = 3,
    FieldGoal = 4,
}
impl ScoreType {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::NotSet),
            1 => Some(Self::Try),
            2 => Some(Self::Conversion),
            3 => Some(Self::PenaltyGoal),
            4 => Some(Self::FieldGoal),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::NotSet)
    }
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Play {
    #[default]
    NotSet = 0,
    KickRetain = 1,
    KickRetainTackle = 2,
    KickTurnover = 3,
    KickRetainTry = 4,
    Pass = 5,
    Run = 6,
    RunTackle = 7,
    RunTry = 8,
    WonPenalty = 9,
    ConcededPenalty = 10,
    ErrorAttack = 11,
    ErrorDefence = 12,
    LineDropout = 13,
}
impl Play {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::NotSet),
            1 => Some(Self::KickRetain),
            2 => Some(Self::KickRetainTackle),
            3 => Some(Self::KickTurnover),
            4 => Some(Self::KickRetainTry),
            5 => Some(Self::Pass),
            6 => Some(Self::Run),
            7 => Some(Self::RunTackle),
            8 => Some(Self::RunTry),
            9 => Some(Self::WonPenalty),
            10 => Some(Self::ConcededPenalty),
            11 => Some(Self::ErrorAttack),
            12 => Some(Self::ErrorDefence),
            13 => Some(Self::LineDropout),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::NotSet)
    }
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum PeriodName {
    #[default]
    NotSet = 0,
    FirstHalf = 1,
    SecondHalf = 2,
    ExtraTime = 3,
}
impl PeriodName {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::NotSet),
            1 => Some(Self::FirstHalf),
            2 => Some(Self::SecondHalf),
            3 => Some(Self::ExtraTime),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::NotSet)
    }
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum PlayerPosition {
    #[default]
    NotSet = 0,
    FullBack = 1,
    WingerOne = 2,
    CentreOne = 3,
    CentreTwo = 4,
    WingerTwo = 5,
    FiveEighth = 6,
    HalfBack = 7,
    PropOne = 8,
    Hooker = 9,
    PropTwo = 10,
    SecondRowOne = 11,
    SecondRowTwo = 12,
    Lock = 13,
    Interchange = 14,
}
impl PlayerPosition {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::NotSet),
            1 => Some(Self::FullBack),
            2 => Some(Self::WingerOne),
            3 => Some(Self::CentreOne),
            4 => Some(Self::CentreTwo),
            5 => Some(Self::WingerTwo),
            6 => Some(Self::FiveEighth),
            7 => Some(Self::HalfBack),
            8 => Some(Self::PropOne),
            9 => Some(Self::Hooker),
            10 => Some(Self::PropTwo),
            11 => Some(Self::SecondRowOne),
            12 => Some(Self::SecondRowTwo),
            13 => Some(Self::Lock),
            14 => Some(Self::Interchange),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::NotSet)
    }
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Team {
    #[default]
    NotSet = 0,
    Home = 1,
    Away = 2,
}
impl Team {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::NotSet),
            1 => Some(Self::Home),
            2 => Some(Self::Away),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::NotSet)
    }
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum SinBinStatus {
    #[default]
    NotSet = 0,
    YellowCard = 1,
    RedCard = 2,
}
impl SinBinStatus {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::NotSet),
            1 => Some(Self::YellowCard),
            2 => Some(Self::RedCard),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::NotSet)
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct State {
    pub all_players: Vec<Player>,
    pub away_match_score: i32,
    pub away_period_try_scorers: Vec<Vec<i32>>,
    pub away_player_selected_for_points_market: Player,
    pub away_players_trader_state: Vec<Player>,
    pub away_players: Vec<Player>,
    pub away_remaining_interchanges: i32,
    pub away_sin_bin: Vec<Player>,
    pub away_statistics: TeamStatistics,
    pub away_total_try_scorers: Vec<i32>,
    pub ball_location: FieldPosition,
    pub current_play: Play,
    pub end_zone_type: String,
    pub executed_events: i32,
    pub has_started: bool,
    pub is_extratime: bool,
    pub game_status: GameStatus,
    pub home_match_score: i32,
    pub home_period_try_scorers: Vec<Vec<i32>>,
    pub home_player_selected_for_points_market: Player,
    pub home_players_trader_state: Vec<Player>,
    pub home_players: Vec<Player>,
    pub home_remaining_interchanges: i32,
    pub home_sin_bin: Vec<Player>,
    pub home_statistics: TeamStatistics,
    pub home_total_try_scorers: Vec<i32>,
    pub incidents: Vec<Incident>,
    pub include_players: bool,
    pub is_in_end_zone: bool,
    pub is_over: bool,
    pub period_try_scorers: Vec<Vec<i32>>,
    pub period: Period,
    pub player_of_the_match: i32,
    pub previous_ball_location: FieldPosition,
    pub previous_play: Play,
    pub set: i32,
    pub simulation_invariants: SimulationInvariants,
    pub tackles: i32,
    pub team_in_possession: Team,
    pub three_unanswered_tries_team: Team,
    pub time_elapsed: i32,
    pub total_match_score: i32,
    pub total_period: String,
    pub total_try_scorers: Vec<i32>,
}
impl State {
    pub fn new(
        all_players: Vec<Player>,
        away_match_score: i32,
        away_period_try_scorers: Vec<Vec<i32>>,
        away_player_selected_for_points_market: Player,
        away_players_trader_state: Vec<Player>,
        away_players: Vec<Player>,
        away_remaining_interchanges: i32,
        away_sin_bin: Vec<Player>,
        away_statistics: TeamStatistics,
        away_total_try_scorers: Vec<i32>,
        ball_location: FieldPosition,
        current_play: Play,
        end_zone_type: String,
        has_started: bool,
        is_extratime: bool,
        game_status: GameStatus,
        home_match_score: i32,
        home_period_try_scorers: Vec<Vec<i32>>,
        home_player_selected_for_points_market: Player,
        home_players_trader_state: Vec<Player>,
        home_players: Vec<Player>,
        home_remaining_interchanges: i32,
        home_sin_bin: Vec<Player>,
        home_statistics: TeamStatistics,
        home_total_try_scorers: Vec<i32>,
        incidents: Vec<Incident>,
        include_players: bool,
        is_in_end_zone: bool,
        is_over: bool,
        period_try_scorers: Vec<Vec<i32>>,
        period: Period,
        player_of_the_match: i32,
        previous_ball_location: FieldPosition,
        previous_play: Play,
        set: i32,
        simulation_invariants: SimulationInvariants,
        tackles: i32,
        team_in_possession: Team,
        three_unanswered_tries_team: Team,
        time_elapsed: i32,
        total_match_score: i32,
        total_period: String,
        total_try_scorers: Vec<i32>,
    ) -> Self {
        Self {
            all_players,
            away_match_score,
            away_period_try_scorers,
            away_player_selected_for_points_market,
            away_players_trader_state,
            away_players,
            away_remaining_interchanges,
            away_sin_bin,
            away_statistics,
            away_total_try_scorers,
            ball_location,
            current_play,
            end_zone_type,
            executed_events: 0,
            has_started,
            is_extratime,
            game_status,
            home_match_score,
            home_period_try_scorers,
            home_player_selected_for_points_market,
            home_players_trader_state,
            home_players,
            home_remaining_interchanges,
            home_sin_bin,
            home_statistics,
            home_total_try_scorers,
            incidents,
            include_players,
            is_in_end_zone,
            is_over,
            period_try_scorers,
            period,
            player_of_the_match,
            previous_ball_location,
            previous_play,
            set,
            simulation_invariants,
            tackles,
            team_in_possession,
            three_unanswered_tries_team,
            time_elapsed,
            total_match_score,
            total_period,
            total_try_scorers,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "all_players" => Some(Box::new(self.all_players.clone()) as Box<dyn std::any::Any>),
            "away_match_score" => {
                Some(Box::new(self.away_match_score.clone()) as Box<dyn std::any::Any>)
            }
            "away_period_try_scorers" => {
                Some(Box::new(self.away_period_try_scorers.clone()) as Box<dyn std::any::Any>)
            }
            "away_player_selected_for_points_market" => Some(Box::new(
                self.away_player_selected_for_points_market.clone(),
            )
                as Box<dyn std::any::Any>),
            "away_players_trader_state" => {
                Some(Box::new(self.away_players_trader_state.clone()) as Box<dyn std::any::Any>)
            }
            "away_players" => Some(Box::new(self.away_players.clone()) as Box<dyn std::any::Any>),
            "away_remaining_interchanges" => {
                Some(Box::new(self.away_remaining_interchanges.clone()) as Box<dyn std::any::Any>)
            }
            "away_sin_bin" => Some(Box::new(self.away_sin_bin.clone()) as Box<dyn std::any::Any>),
            "away_statistics" => {
                Some(Box::new(self.away_statistics.clone()) as Box<dyn std::any::Any>)
            }
            "away_total_try_scorers" => {
                Some(Box::new(self.away_total_try_scorers.clone()) as Box<dyn std::any::Any>)
            }
            "ball_location" => Some(Box::new(self.ball_location.clone()) as Box<dyn std::any::Any>),
            "current_play" => Some(Box::new(self.current_play.clone()) as Box<dyn std::any::Any>),
            "end_zone_type" => Some(Box::new(self.end_zone_type.clone()) as Box<dyn std::any::Any>),
            "executed_events" => {
                Some(Box::new(self.executed_events.clone()) as Box<dyn std::any::Any>)
            }
            "has_started" => Some(Box::new(self.has_started.clone()) as Box<dyn std::any::Any>),
            "is_extratime" => Some(Box::new(self.is_extratime.clone()) as Box<dyn std::any::Any>),
            "game_status" => Some(Box::new(self.game_status.clone()) as Box<dyn std::any::Any>),
            "home_match_score" => {
                Some(Box::new(self.home_match_score.clone()) as Box<dyn std::any::Any>)
            }
            "home_period_try_scorers" => {
                Some(Box::new(self.home_period_try_scorers.clone()) as Box<dyn std::any::Any>)
            }
            "home_player_selected_for_points_market" => Some(Box::new(
                self.home_player_selected_for_points_market.clone(),
            )
                as Box<dyn std::any::Any>),
            "home_players_trader_state" => {
                Some(Box::new(self.home_players_trader_state.clone()) as Box<dyn std::any::Any>)
            }
            "home_players" => Some(Box::new(self.home_players.clone()) as Box<dyn std::any::Any>),
            "home_remaining_interchanges" => {
                Some(Box::new(self.home_remaining_interchanges.clone()) as Box<dyn std::any::Any>)
            }
            "home_sin_bin" => Some(Box::new(self.home_sin_bin.clone()) as Box<dyn std::any::Any>),
            "home_statistics" => {
                Some(Box::new(self.home_statistics.clone()) as Box<dyn std::any::Any>)
            }
            "home_total_try_scorers" => {
                Some(Box::new(self.home_total_try_scorers.clone()) as Box<dyn std::any::Any>)
            }
            "incidents" => Some(Box::new(self.incidents.clone()) as Box<dyn std::any::Any>),
            "include_players" => {
                Some(Box::new(self.include_players.clone()) as Box<dyn std::any::Any>)
            }
            "is_in_end_zone" => {
                Some(Box::new(self.is_in_end_zone.clone()) as Box<dyn std::any::Any>)
            }
            "is_over" => Some(Box::new(self.is_over.clone()) as Box<dyn std::any::Any>),
            "period_try_scorers" => {
                Some(Box::new(self.period_try_scorers.clone()) as Box<dyn std::any::Any>)
            }
            "period" => Some(Box::new(self.period.clone()) as Box<dyn std::any::Any>),
            "player_of_the_match" => {
                Some(Box::new(self.player_of_the_match.clone()) as Box<dyn std::any::Any>)
            }
            "previous_ball_location" => {
                Some(Box::new(self.previous_ball_location.clone()) as Box<dyn std::any::Any>)
            }
            "previous_play" => Some(Box::new(self.previous_play.clone()) as Box<dyn std::any::Any>),
            "set" => Some(Box::new(self.set.clone()) as Box<dyn std::any::Any>),
            "simulation_invariants" => {
                Some(Box::new(self.simulation_invariants.clone()) as Box<dyn std::any::Any>)
            }
            "tackles" => Some(Box::new(self.tackles.clone()) as Box<dyn std::any::Any>),
            "team_in_possession" => {
                Some(Box::new(self.team_in_possession.clone()) as Box<dyn std::any::Any>)
            }
            "three_unanswered_tries_team" => {
                Some(Box::new(self.three_unanswered_tries_team.clone()) as Box<dyn std::any::Any>)
            }
            "time_elapsed" => Some(Box::new(self.time_elapsed.clone()) as Box<dyn std::any::Any>),
            "total_match_score" => {
                Some(Box::new(self.total_match_score.clone()) as Box<dyn std::any::Any>)
            }
            "total_period" => Some(Box::new(self.total_period.clone()) as Box<dyn std::any::Any>),
            "total_try_scorers" => {
                Some(Box::new(self.total_try_scorers.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "all_players" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.all_players = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_match_score" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.away_match_score = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_period_try_scorers" => {
                if let Some(v) = value.downcast_ref::<Vec<Vec<i32>>>() {
                    self.away_period_try_scorers = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_player_selected_for_points_market" => {
                if let Some(v) = value.downcast_ref::<Player>() {
                    self.away_player_selected_for_points_market = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_players_trader_state" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.away_players_trader_state = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_players" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.away_players = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_remaining_interchanges" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.away_remaining_interchanges = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_sin_bin" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.away_sin_bin = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_statistics" => {
                if let Some(v) = value.downcast_ref::<TeamStatistics>() {
                    self.away_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_total_try_scorers" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.away_total_try_scorers = v.clone();
                    true
                } else {
                    false
                }
            }
            "ball_location" => {
                if let Some(v) = value.downcast_ref::<FieldPosition>() {
                    self.ball_location = v.clone();
                    true
                } else {
                    false
                }
            }
            "current_play" => {
                if let Some(v) = value.downcast_ref::<Play>() {
                    self.current_play = v.clone();
                    true
                } else {
                    false
                }
            }
            "end_zone_type" => {
                if let Some(v) = value.downcast_ref::<String>() {
                    self.end_zone_type = v.clone();
                    true
                } else {
                    false
                }
            }
            "executed_events" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.executed_events = v.clone();
                    true
                } else {
                    false
                }
            }
            "has_started" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.has_started = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_extratime" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_extratime = v.clone();
                    true
                } else {
                    false
                }
            }
            "game_status" => {
                if let Some(v) = value.downcast_ref::<GameStatus>() {
                    self.game_status = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_match_score" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.home_match_score = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_period_try_scorers" => {
                if let Some(v) = value.downcast_ref::<Vec<Vec<i32>>>() {
                    self.home_period_try_scorers = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_player_selected_for_points_market" => {
                if let Some(v) = value.downcast_ref::<Player>() {
                    self.home_player_selected_for_points_market = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_players_trader_state" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.home_players_trader_state = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_players" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.home_players = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_remaining_interchanges" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.home_remaining_interchanges = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_sin_bin" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.home_sin_bin = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_statistics" => {
                if let Some(v) = value.downcast_ref::<TeamStatistics>() {
                    self.home_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_total_try_scorers" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.home_total_try_scorers = v.clone();
                    true
                } else {
                    false
                }
            }
            "incidents" => {
                if let Some(v) = value.downcast_ref::<Vec<Incident>>() {
                    self.incidents = v.clone();
                    true
                } else {
                    false
                }
            }
            "include_players" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.include_players = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_in_end_zone" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_in_end_zone = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_over" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_over = v.clone();
                    true
                } else {
                    false
                }
            }
            "period_try_scorers" => {
                if let Some(v) = value.downcast_ref::<Vec<Vec<i32>>>() {
                    self.period_try_scorers = v.clone();
                    true
                } else {
                    false
                }
            }
            "period" => {
                if let Some(v) = value.downcast_ref::<Period>() {
                    self.period = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_of_the_match" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.player_of_the_match = v.clone();
                    true
                } else {
                    false
                }
            }
            "previous_ball_location" => {
                if let Some(v) = value.downcast_ref::<FieldPosition>() {
                    self.previous_ball_location = v.clone();
                    true
                } else {
                    false
                }
            }
            "previous_play" => {
                if let Some(v) = value.downcast_ref::<Play>() {
                    self.previous_play = v.clone();
                    true
                } else {
                    false
                }
            }
            "set" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.set = v.clone();
                    true
                } else {
                    false
                }
            }
            "simulation_invariants" => {
                if let Some(v) = value.downcast_ref::<SimulationInvariants>() {
                    self.simulation_invariants = v.clone();
                    true
                } else {
                    false
                }
            }
            "tackles" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.tackles = v.clone();
                    true
                } else {
                    false
                }
            }
            "team_in_possession" => {
                if let Some(v) = value.downcast_ref::<Team>() {
                    self.team_in_possession = v.clone();
                    true
                } else {
                    false
                }
            }
            "three_unanswered_tries_team" => {
                if let Some(v) = value.downcast_ref::<Team>() {
                    self.three_unanswered_tries_team = v.clone();
                    true
                } else {
                    false
                }
            }
            "time_elapsed" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.time_elapsed = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_match_score" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.total_match_score = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_period" => {
                if let Some(v) = value.downcast_ref::<String>() {
                    self.total_period = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_try_scorers" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.total_try_scorers = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct FieldPosition {
    pub x: i32,
    pub y: i32,
}
impl FieldPosition {
    pub fn new(x: i32, y: i32) -> Self {
        Self { x, y }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "x" => Some(Box::new(self.x.clone()) as Box<dyn std::any::Any>),
            "y" => Some(Box::new(self.y.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "x" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.x = v.clone();
                    true
                } else {
                    false
                }
            }
            "y" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.y = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Incident {
    pub has_points_confirmed: bool,
    pub has_points_scored: bool,
    pub period: Period,
    pub points_confirmed_player_index: i32,
    pub points_confirmed_score_id: String,
    pub points_confirmed_score_type: ScoreType,
    pub points_scored_points: i32,
    pub points_scored_score_id: String,
    pub points_scored_score_type: ScoreType,
    pub points_scored_team: Team,
    pub time_elapsed: i32,
}
impl Incident {
    pub fn new(
        has_points_confirmed: bool,
        has_points_scored: bool,
        period: Period,
        points_confirmed_player_index: i32,
        points_confirmed_score_id: String,
        points_confirmed_score_type: ScoreType,
        points_scored_points: i32,
        points_scored_score_id: String,
        points_scored_score_type: ScoreType,
        points_scored_team: Team,
        time_elapsed: i32,
    ) -> Self {
        Self {
            has_points_confirmed,
            has_points_scored,
            period,
            points_confirmed_player_index,
            points_confirmed_score_id,
            points_confirmed_score_type,
            points_scored_points,
            points_scored_score_id,
            points_scored_score_type,
            points_scored_team,
            time_elapsed,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "has_points_confirmed" => {
                Some(Box::new(self.has_points_confirmed.clone()) as Box<dyn std::any::Any>)
            }
            "has_points_scored" => {
                Some(Box::new(self.has_points_scored.clone()) as Box<dyn std::any::Any>)
            }
            "period" => Some(Box::new(self.period.clone()) as Box<dyn std::any::Any>),
            "points_confirmed_player_index" => {
                Some(Box::new(self.points_confirmed_player_index.clone()) as Box<dyn std::any::Any>)
            }
            "points_confirmed_score_id" => {
                Some(Box::new(self.points_confirmed_score_id.clone()) as Box<dyn std::any::Any>)
            }
            "points_confirmed_score_type" => {
                Some(Box::new(self.points_confirmed_score_type.clone()) as Box<dyn std::any::Any>)
            }
            "points_scored_points" => {
                Some(Box::new(self.points_scored_points.clone()) as Box<dyn std::any::Any>)
            }
            "points_scored_score_id" => {
                Some(Box::new(self.points_scored_score_id.clone()) as Box<dyn std::any::Any>)
            }
            "points_scored_score_type" => {
                Some(Box::new(self.points_scored_score_type.clone()) as Box<dyn std::any::Any>)
            }
            "points_scored_team" => {
                Some(Box::new(self.points_scored_team.clone()) as Box<dyn std::any::Any>)
            }
            "time_elapsed" => Some(Box::new(self.time_elapsed.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "has_points_confirmed" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.has_points_confirmed = v.clone();
                    true
                } else {
                    false
                }
            }
            "has_points_scored" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.has_points_scored = v.clone();
                    true
                } else {
                    false
                }
            }
            "period" => {
                if let Some(v) = value.downcast_ref::<Period>() {
                    self.period = v.clone();
                    true
                } else {
                    false
                }
            }
            "points_confirmed_player_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.points_confirmed_player_index = v.clone();
                    true
                } else {
                    false
                }
            }
            "points_confirmed_score_id" => {
                if let Some(v) = value.downcast_ref::<String>() {
                    self.points_confirmed_score_id = v.clone();
                    true
                } else {
                    false
                }
            }
            "points_confirmed_score_type" => {
                if let Some(v) = value.downcast_ref::<ScoreType>() {
                    self.points_confirmed_score_type = v.clone();
                    true
                } else {
                    false
                }
            }
            "points_scored_points" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.points_scored_points = v.clone();
                    true
                } else {
                    false
                }
            }
            "points_scored_score_id" => {
                if let Some(v) = value.downcast_ref::<String>() {
                    self.points_scored_score_id = v.clone();
                    true
                } else {
                    false
                }
            }
            "points_scored_score_type" => {
                if let Some(v) = value.downcast_ref::<ScoreType>() {
                    self.points_scored_score_type = v.clone();
                    true
                } else {
                    false
                }
            }
            "points_scored_team" => {
                if let Some(v) = value.downcast_ref::<Team>() {
                    self.points_scored_team = v.clone();
                    true
                } else {
                    false
                }
            }
            "time_elapsed" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.time_elapsed = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Period {
    pub number: i32,
    pub name: PeriodName,
}
impl Period {
    pub fn new(number: i32, name: PeriodName) -> Self {
        Self { number, name }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "number" => Some(Box::new(self.number.clone()) as Box<dyn std::any::Any>),
            "name" => Some(Box::new(self.name.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "number" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.number = v.clone();
                    true
                } else {
                    false
                }
            }
            "name" => {
                if let Some(v) = value.downcast_ref::<PeriodName>() {
                    self.name = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Player {
    pub delta_strength: Strength,
    pub expected_tries_per_min: f64,
    pub is_home_team: bool,
    pub is_injured: bool,
    pub is_interchange: bool,
    pub is_starter: bool,
    pub is_suspended: bool,
    pub is_voided: bool,
    pub jersey_number: i32,
    pub on_field: bool,
    pub period_statistics: Vec<PlayerStatistics>,
    pub player_index: i32,
    pub player_of_the_match_percentage: f64,
    pub position: PlayerPosition,
    pub return_from_sin_bin_time: i32,
    pub selected_for_points_market: bool,
    pub sin_bin_sent_off: i32,
    pub sin_bin_status: SinBinStatus,
    pub total_statistics: PlayerStatistics,
    pub total_strength: Strength,
    pub tries_per_minute_in_use: bool,
    pub tries_per_minute: f64,
    pub tries_percentage_in_use: bool,
    pub tries_percentage: f64,
    pub tries_strength: Strength,
}
impl Player {
    pub fn new(
        delta_strength: Strength,
        expected_tries_per_min: f64,
        is_home_team: bool,
        is_injured: bool,
        is_interchange: bool,
        is_starter: bool,
        is_suspended: bool,
        is_voided: bool,
        jersey_number: i32,
        on_field: bool,
        period_statistics: Vec<PlayerStatistics>,
        player_index: i32,
        player_of_the_match_percentage: f64,
        position: PlayerPosition,
        return_from_sin_bin_time: i32,
        selected_for_points_market: bool,
        sin_bin_sent_off: i32,
        sin_bin_status: SinBinStatus,
        total_statistics: PlayerStatistics,
        total_strength: Strength,
        tries_per_minute_in_use: bool,
        tries_per_minute: f64,
        tries_percentage_in_use: bool,
        tries_percentage: f64,
        tries_strength: Strength,
    ) -> Self {
        Self {
            delta_strength,
            expected_tries_per_min,
            is_home_team,
            is_injured,
            is_interchange,
            is_starter,
            is_suspended,
            is_voided,
            jersey_number,
            on_field,
            period_statistics,
            player_index,
            player_of_the_match_percentage,
            position,
            return_from_sin_bin_time,
            selected_for_points_market,
            sin_bin_sent_off,
            sin_bin_status,
            total_statistics,
            total_strength,
            tries_per_minute_in_use,
            tries_per_minute,
            tries_percentage_in_use,
            tries_percentage,
            tries_strength,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "delta_strength" => {
                Some(Box::new(self.delta_strength.clone()) as Box<dyn std::any::Any>)
            }
            "expected_tries_per_min" => {
                Some(Box::new(self.expected_tries_per_min.clone()) as Box<dyn std::any::Any>)
            }
            "is_home_team" => Some(Box::new(self.is_home_team.clone()) as Box<dyn std::any::Any>),
            "is_injured" => Some(Box::new(self.is_injured.clone()) as Box<dyn std::any::Any>),
            "is_interchange" => {
                Some(Box::new(self.is_interchange.clone()) as Box<dyn std::any::Any>)
            }
            "is_starter" => Some(Box::new(self.is_starter.clone()) as Box<dyn std::any::Any>),
            "is_suspended" => Some(Box::new(self.is_suspended.clone()) as Box<dyn std::any::Any>),
            "is_voided" => Some(Box::new(self.is_voided.clone()) as Box<dyn std::any::Any>),
            "jersey_number" => Some(Box::new(self.jersey_number.clone()) as Box<dyn std::any::Any>),
            "on_field" => Some(Box::new(self.on_field.clone()) as Box<dyn std::any::Any>),
            "period_statistics" => {
                Some(Box::new(self.period_statistics.clone()) as Box<dyn std::any::Any>)
            }
            "player_index" => Some(Box::new(self.player_index.clone()) as Box<dyn std::any::Any>),
            "player_of_the_match_percentage" => {
                Some(Box::new(self.player_of_the_match_percentage.clone()) as Box<dyn std::any::Any>)
            }
            "position" => Some(Box::new(self.position.clone()) as Box<dyn std::any::Any>),
            "return_from_sin_bin_time" => {
                Some(Box::new(self.return_from_sin_bin_time.clone()) as Box<dyn std::any::Any>)
            }
            "selected_for_points_market" => {
                Some(Box::new(self.selected_for_points_market.clone()) as Box<dyn std::any::Any>)
            }
            "sin_bin_sent_off" => {
                Some(Box::new(self.sin_bin_sent_off.clone()) as Box<dyn std::any::Any>)
            }
            "sin_bin_status" => {
                Some(Box::new(self.sin_bin_status.clone()) as Box<dyn std::any::Any>)
            }
            "total_statistics" => {
                Some(Box::new(self.total_statistics.clone()) as Box<dyn std::any::Any>)
            }
            "total_strength" => {
                Some(Box::new(self.total_strength.clone()) as Box<dyn std::any::Any>)
            }
            "tries_per_minute_in_use" => {
                Some(Box::new(self.tries_per_minute_in_use.clone()) as Box<dyn std::any::Any>)
            }
            "tries_per_minute" => {
                Some(Box::new(self.tries_per_minute.clone()) as Box<dyn std::any::Any>)
            }
            "tries_percentage_in_use" => {
                Some(Box::new(self.tries_percentage_in_use.clone()) as Box<dyn std::any::Any>)
            }
            "tries_percentage" => {
                Some(Box::new(self.tries_percentage.clone()) as Box<dyn std::any::Any>)
            }
            "tries_strength" => {
                Some(Box::new(self.tries_strength.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "delta_strength" => {
                if let Some(v) = value.downcast_ref::<Strength>() {
                    self.delta_strength = v.clone();
                    true
                } else {
                    false
                }
            }
            "expected_tries_per_min" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.expected_tries_per_min = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_home_team" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_home_team = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_injured" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_injured = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_interchange" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_interchange = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_starter" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_starter = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_suspended" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_suspended = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_voided" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_voided = v.clone();
                    true
                } else {
                    false
                }
            }
            "jersey_number" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.jersey_number = v.clone();
                    true
                } else {
                    false
                }
            }
            "on_field" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.on_field = v.clone();
                    true
                } else {
                    false
                }
            }
            "period_statistics" => {
                if let Some(v) = value.downcast_ref::<Vec<PlayerStatistics>>() {
                    self.period_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.player_index = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_of_the_match_percentage" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.player_of_the_match_percentage = v.clone();
                    true
                } else {
                    false
                }
            }
            "position" => {
                if let Some(v) = value.downcast_ref::<PlayerPosition>() {
                    self.position = v.clone();
                    true
                } else {
                    false
                }
            }
            "return_from_sin_bin_time" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.return_from_sin_bin_time = v.clone();
                    true
                } else {
                    false
                }
            }
            "selected_for_points_market" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.selected_for_points_market = v.clone();
                    true
                } else {
                    false
                }
            }
            "sin_bin_sent_off" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.sin_bin_sent_off = v.clone();
                    true
                } else {
                    false
                }
            }
            "sin_bin_status" => {
                if let Some(v) = value.downcast_ref::<SinBinStatus>() {
                    self.sin_bin_status = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_statistics" => {
                if let Some(v) = value.downcast_ref::<PlayerStatistics>() {
                    self.total_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_strength" => {
                if let Some(v) = value.downcast_ref::<Strength>() {
                    self.total_strength = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_per_minute_in_use" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.tries_per_minute_in_use = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_per_minute" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.tries_per_minute = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_percentage_in_use" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.tries_percentage_in_use = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_percentage" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.tries_percentage = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_strength" => {
                if let Some(v) = value.downcast_ref::<Strength>() {
                    self.tries_strength = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlayerStatistics {
    pub jersey_number: i32,
    pub metres_gained: i32,
    pub period_statistics: Vec<Statistics>,
    pub player_index: i32,
    pub scores: Scores,
    pub tackles: i32,
    pub time_on_field: f64,
    pub total_statistics: Statistics,
}
impl PlayerStatistics {
    pub fn new(
        jersey_number: i32,
        metres_gained: i32,
        period_statistics: Vec<Statistics>,
        player_index: i32,
        scores: Scores,
        tackles: i32,
        time_on_field: f64,
        total_statistics: Statistics,
    ) -> Self {
        Self {
            jersey_number,
            metres_gained,
            period_statistics,
            player_index,
            scores,
            tackles,
            time_on_field,
            total_statistics,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "jersey_number" => Some(Box::new(self.jersey_number.clone()) as Box<dyn std::any::Any>),
            "metres_gained" => Some(Box::new(self.metres_gained.clone()) as Box<dyn std::any::Any>),
            "period_statistics" => {
                Some(Box::new(self.period_statistics.clone()) as Box<dyn std::any::Any>)
            }
            "player_index" => Some(Box::new(self.player_index.clone()) as Box<dyn std::any::Any>),
            "scores" => Some(Box::new(self.scores.clone()) as Box<dyn std::any::Any>),
            "tackles" => Some(Box::new(self.tackles.clone()) as Box<dyn std::any::Any>),
            "time_on_field" => Some(Box::new(self.time_on_field.clone()) as Box<dyn std::any::Any>),
            "total_statistics" => {
                Some(Box::new(self.total_statistics.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "jersey_number" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.jersey_number = v.clone();
                    true
                } else {
                    false
                }
            }
            "metres_gained" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.metres_gained = v.clone();
                    true
                } else {
                    false
                }
            }
            "period_statistics" => {
                if let Some(v) = value.downcast_ref::<Vec<Statistics>>() {
                    self.period_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.player_index = v.clone();
                    true
                } else {
                    false
                }
            }
            "scores" => {
                if let Some(v) = value.downcast_ref::<Scores>() {
                    self.scores = v.clone();
                    true
                } else {
                    false
                }
            }
            "tackles" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.tackles = v.clone();
                    true
                } else {
                    false
                }
            }
            "time_on_field" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.time_on_field = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_statistics" => {
                if let Some(v) = value.downcast_ref::<Statistics>() {
                    self.total_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Scores {
    pub conversions: i32,
    pub field_goals: i32,
    pub penalties: i32,
    pub total: i32,
    pub tries: i32,
}
impl Scores {
    pub fn new(conversions: i32, field_goals: i32, penalties: i32, total: i32, tries: i32) -> Self {
        Self {
            conversions,
            field_goals,
            penalties,
            total,
            tries,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "conversions" => Some(Box::new(self.conversions.clone()) as Box<dyn std::any::Any>),
            "field_goals" => Some(Box::new(self.field_goals.clone()) as Box<dyn std::any::Any>),
            "penalties" => Some(Box::new(self.penalties.clone()) as Box<dyn std::any::Any>),
            "total" => Some(Box::new(self.total.clone()) as Box<dyn std::any::Any>),
            "tries" => Some(Box::new(self.tries.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "conversions" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.conversions = v.clone();
                    true
                } else {
                    false
                }
            }
            "field_goals" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.field_goals = v.clone();
                    true
                } else {
                    false
                }
            }
            "penalties" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.penalties = v.clone();
                    true
                } else {
                    false
                }
            }
            "total" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.total = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.tries = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Statistics {
    pub conversions_missed: i32,
    pub penalties_awarded: i32,
    pub scores: Scores,
    pub tackles: i32,
    pub turnovers: i32,
}
impl Statistics {
    pub fn new(
        conversions_missed: i32,
        penalties_awarded: i32,
        scores: Scores,
        tackles: i32,
        turnovers: i32,
    ) -> Self {
        Self {
            conversions_missed,
            penalties_awarded,
            scores,
            tackles,
            turnovers,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "conversions_missed" => {
                Some(Box::new(self.conversions_missed.clone()) as Box<dyn std::any::Any>)
            }
            "penalties_awarded" => {
                Some(Box::new(self.penalties_awarded.clone()) as Box<dyn std::any::Any>)
            }
            "scores" => Some(Box::new(self.scores.clone()) as Box<dyn std::any::Any>),
            "tackles" => Some(Box::new(self.tackles.clone()) as Box<dyn std::any::Any>),
            "turnovers" => Some(Box::new(self.turnovers.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "conversions_missed" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.conversions_missed = v.clone();
                    true
                } else {
                    false
                }
            }
            "penalties_awarded" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.penalties_awarded = v.clone();
                    true
                } else {
                    false
                }
            }
            "scores" => {
                if let Some(v) = value.downcast_ref::<Scores>() {
                    self.scores = v.clone();
                    true
                } else {
                    false
                }
            }
            "tackles" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.tackles = v.clone();
                    true
                } else {
                    false
                }
            }
            "turnovers" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.turnovers = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct TeamStatistics {
    pub period_statistics: Vec<Statistics>,
    pub player_statistics: Vec<PlayerStatistics>,
    pub sin_bin_players: Vec<Player>,
    pub total_statistics: Statistics,
}
impl TeamStatistics {
    pub fn new(
        period_statistics: Vec<Statistics>,
        player_statistics: Vec<PlayerStatistics>,
        sin_bin_players: Vec<Player>,
        total_statistics: Statistics,
    ) -> Self {
        Self {
            period_statistics,
            player_statistics,
            sin_bin_players,
            total_statistics,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "period_statistics" => {
                Some(Box::new(self.period_statistics.clone()) as Box<dyn std::any::Any>)
            }
            "player_statistics" => {
                Some(Box::new(self.player_statistics.clone()) as Box<dyn std::any::Any>)
            }
            "sin_bin_players" => {
                Some(Box::new(self.sin_bin_players.clone()) as Box<dyn std::any::Any>)
            }
            "total_statistics" => {
                Some(Box::new(self.total_statistics.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "period_statistics" => {
                if let Some(v) = value.downcast_ref::<Vec<Statistics>>() {
                    self.period_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_statistics" => {
                if let Some(v) = value.downcast_ref::<Vec<PlayerStatistics>>() {
                    self.player_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            "sin_bin_players" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.sin_bin_players = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_statistics" => {
                if let Some(v) = value.downcast_ref::<Statistics>() {
                    self.total_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlayerInvariants {
    pub player_solution: PlayerSolution,
    pub player_trader_state: PlayerTraderState,
}
impl PlayerInvariants {
    pub fn new(player_solution: PlayerSolution, player_trader_state: PlayerTraderState) -> Self {
        Self {
            player_solution,
            player_trader_state,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "player_solution" => {
                Some(Box::new(self.player_solution.clone()) as Box<dyn std::any::Any>)
            }
            "player_trader_state" => {
                Some(Box::new(self.player_trader_state.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "player_solution" => {
                if let Some(v) = value.downcast_ref::<PlayerSolution>() {
                    self.player_solution = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_trader_state" => {
                if let Some(v) = value.downcast_ref::<PlayerTraderState>() {
                    self.player_trader_state = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlayerSolution {
    pub solved_expected_tries_per_min: f64,
    pub solved_expected_tries_percentage: f64,
}
impl PlayerSolution {
    pub fn new(solved_expected_tries_per_min: f64, solved_expected_tries_percentage: f64) -> Self {
        Self {
            solved_expected_tries_per_min,
            solved_expected_tries_percentage,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "solved_expected_tries_per_min" => {
                Some(Box::new(self.solved_expected_tries_per_min.clone()) as Box<dyn std::any::Any>)
            }
            "solved_expected_tries_percentage" => {
                Some(Box::new(self.solved_expected_tries_percentage.clone())
                    as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "solved_expected_tries_per_min" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.solved_expected_tries_per_min = v.clone();
                    true
                } else {
                    false
                }
            }
            "solved_expected_tries_percentage" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.solved_expected_tries_percentage = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct SimulationInvariants {
    pub all_players_invariants: Vec<PlayerInvariants>,
    pub away_handicap: f64,
    pub away_price: f64,
    pub away_team_players_invariants: Vec<PlayerInvariants>,
    pub home_handicap: f64,
    pub home_price: f64,
    pub home_team_player_invariants: Vec<PlayerInvariants>,
    pub include_players: bool,
    pub player_of_the_total_enabled: bool,
    pub total_points: f64,
}
impl SimulationInvariants {
    pub fn new(
        all_players_invariants: Vec<PlayerInvariants>,
        away_handicap: f64,
        away_price: f64,
        away_team_players_invariants: Vec<PlayerInvariants>,
        home_handicap: f64,
        home_price: f64,
        home_team_player_invariants: Vec<PlayerInvariants>,
        include_players: bool,
        player_of_the_total_enabled: bool,
        total_points: f64,
    ) -> Self {
        Self {
            all_players_invariants,
            away_handicap,
            away_price,
            away_team_players_invariants,
            home_handicap,
            home_price,
            home_team_player_invariants,
            include_players,
            player_of_the_total_enabled,
            total_points,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "all_players_invariants" => {
                Some(Box::new(self.all_players_invariants.clone()) as Box<dyn std::any::Any>)
            }
            "away_handicap" => Some(Box::new(self.away_handicap.clone()) as Box<dyn std::any::Any>),
            "away_price" => Some(Box::new(self.away_price.clone()) as Box<dyn std::any::Any>),
            "away_team_players_invariants" => {
                Some(Box::new(self.away_team_players_invariants.clone()) as Box<dyn std::any::Any>)
            }
            "home_handicap" => Some(Box::new(self.home_handicap.clone()) as Box<dyn std::any::Any>),
            "home_price" => Some(Box::new(self.home_price.clone()) as Box<dyn std::any::Any>),
            "home_team_player_invariants" => {
                Some(Box::new(self.home_team_player_invariants.clone()) as Box<dyn std::any::Any>)
            }
            "include_players" => {
                Some(Box::new(self.include_players.clone()) as Box<dyn std::any::Any>)
            }
            "player_of_the_total_enabled" => {
                Some(Box::new(self.player_of_the_total_enabled.clone()) as Box<dyn std::any::Any>)
            }
            "total_points" => Some(Box::new(self.total_points.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "all_players_invariants" => {
                if let Some(v) = value.downcast_ref::<Vec<PlayerInvariants>>() {
                    self.all_players_invariants = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_handicap" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.away_handicap = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_price" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.away_price = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_team_players_invariants" => {
                if let Some(v) = value.downcast_ref::<Vec<PlayerInvariants>>() {
                    self.away_team_players_invariants = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_handicap" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.home_handicap = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_price" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.home_price = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_team_player_invariants" => {
                if let Some(v) = value.downcast_ref::<Vec<PlayerInvariants>>() {
                    self.home_team_player_invariants = v.clone();
                    true
                } else {
                    false
                }
            }
            "include_players" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.include_players = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_of_the_total_enabled" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.player_of_the_total_enabled = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_points" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.total_points = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlayerTraderState {
    pub expected_tries_per_minute: f64,
    pub home_team: bool,
    pub is_injured: bool,
    pub is_interchange: bool,
    pub is_starter: bool,
    pub player_index: i32,
    pub player_of_the_match_percentage: f64,
    pub position: PlayerPosition,
    pub selected_for_points_market: bool,
    pub tries_per_minute_in_use: bool,
    pub tries_percentage_in_use: bool,
    pub tries_percentage: f64,
}
impl PlayerTraderState {
    pub fn new(
        expected_tries_per_minute: f64,
        home_team: bool,
        is_injured: bool,
        is_interchange: bool,
        is_starter: bool,
        player_index: i32,
        player_of_the_match_percentage: f64,
        position: PlayerPosition,
        selected_for_points_market: bool,
        tries_per_minute_in_use: bool,
        tries_percentage_in_use: bool,
        tries_percentage: f64,
    ) -> Self {
        Self {
            expected_tries_per_minute,
            home_team,
            is_injured,
            is_interchange,
            is_starter,
            player_index,
            player_of_the_match_percentage,
            position,
            selected_for_points_market,
            tries_per_minute_in_use,
            tries_percentage_in_use,
            tries_percentage,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "expected_tries_per_minute" => {
                Some(Box::new(self.expected_tries_per_minute.clone()) as Box<dyn std::any::Any>)
            }
            "home_team" => Some(Box::new(self.home_team.clone()) as Box<dyn std::any::Any>),
            "is_injured" => Some(Box::new(self.is_injured.clone()) as Box<dyn std::any::Any>),
            "is_interchange" => {
                Some(Box::new(self.is_interchange.clone()) as Box<dyn std::any::Any>)
            }
            "is_starter" => Some(Box::new(self.is_starter.clone()) as Box<dyn std::any::Any>),
            "player_index" => Some(Box::new(self.player_index.clone()) as Box<dyn std::any::Any>),
            "player_of_the_match_percentage" => {
                Some(Box::new(self.player_of_the_match_percentage.clone()) as Box<dyn std::any::Any>)
            }
            "position" => Some(Box::new(self.position.clone()) as Box<dyn std::any::Any>),
            "selected_for_points_market" => {
                Some(Box::new(self.selected_for_points_market.clone()) as Box<dyn std::any::Any>)
            }
            "tries_per_minute_in_use" => {
                Some(Box::new(self.tries_per_minute_in_use.clone()) as Box<dyn std::any::Any>)
            }
            "tries_percentage_in_use" => {
                Some(Box::new(self.tries_percentage_in_use.clone()) as Box<dyn std::any::Any>)
            }
            "tries_percentage" => {
                Some(Box::new(self.tries_percentage.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "expected_tries_per_minute" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.expected_tries_per_minute = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_team" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.home_team = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_injured" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_injured = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_interchange" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_interchange = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_starter" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_starter = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.player_index = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_of_the_match_percentage" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.player_of_the_match_percentage = v.clone();
                    true
                } else {
                    false
                }
            }
            "position" => {
                if let Some(v) = value.downcast_ref::<PlayerPosition>() {
                    self.position = v.clone();
                    true
                } else {
                    false
                }
            }
            "selected_for_points_market" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.selected_for_points_market = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_per_minute_in_use" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.tries_per_minute_in_use = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_percentage_in_use" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.tries_percentage_in_use = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_percentage" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.tries_percentage = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct ClockInferOutputs0 {
    pub variable: Vec<f64>,
}
impl ClockInferOutputs0 {
    pub fn new(variable: Vec<f64>) -> Self {
        Self { variable }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "variable" => Some(Box::new(self.variable.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "variable" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.variable = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct ClockOutputs {
    pub seconds_to_add: f64,
}
impl ClockOutputs {
    pub fn new(seconds_to_add: f64) -> Self {
        Self { seconds_to_add }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "seconds_to_add" => {
                Some(Box::new(self.seconds_to_add.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "seconds_to_add" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.seconds_to_add = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct FieldGoalAttemptInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl FieldGoalAttemptInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct FieldGoalAttemptOutputs {
    pub attempt: i32,
}
impl FieldGoalAttemptOutputs {
    pub fn new(attempt: i32) -> Self {
        Self { attempt }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "attempt" => Some(Box::new(self.attempt.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "attempt" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.attempt = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct FieldGoalDecisionOutputs {
    pub attempt: bool,
}
impl FieldGoalDecisionOutputs {
    pub fn new(attempt: bool) -> Self {
        Self { attempt }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "attempt" => Some(Box::new(self.attempt.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "attempt" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.attempt = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct GetConversionModelResultInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl GetConversionModelResultInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct GetConversionModelResultInferOutputs1 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl GetConversionModelResultInferOutputs1 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct GetConversionModelResultOutputs {
    pub scored: bool,
}
impl GetConversionModelResultOutputs {
    pub fn new(scored: bool) -> Self {
        Self { scored }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "scored" => Some(Box::new(self.scored.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "scored" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.scored = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct GetFieldGoalModelResultInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl GetFieldGoalModelResultInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct GetFieldGoalModelResultOutputs {
    pub scored: bool,
}
impl GetFieldGoalModelResultOutputs {
    pub fn new(scored: bool) -> Self {
        Self { scored }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "scored" => Some(Box::new(self.scored.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "scored" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.scored = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct GetKickoffModelResultInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl GetKickoffModelResultInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct GetKickoffModelResultOutputs {
    pub change_possession: bool,
    pub grid_result: String,
}
impl GetKickoffModelResultOutputs {
    pub fn new(change_possession: bool, grid_result: String) -> Self {
        Self {
            change_possession,
            grid_result,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "change_possession" => {
                Some(Box::new(self.change_possession.clone()) as Box<dyn std::any::Any>)
            }
            "grid_result" => Some(Box::new(self.grid_result.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "change_possession" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.change_possession = v.clone();
                    true
                } else {
                    false
                }
            }
            "grid_result" => {
                if let Some(v) = value.downcast_ref::<String>() {
                    self.grid_result = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct InterchangeInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl InterchangeInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct InterchangeInferOutputs1 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl InterchangeInferOutputs1 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct NextPlayInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl NextPlayInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct NextPlayOutputs {
    pub play_type: Play,
}
impl NextPlayOutputs {
    pub fn new(play_type: Play) -> Self {
        Self { play_type }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "play_type" => Some(Box::new(self.play_type.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "play_type" => {
                if let Some(v) = value.downcast_ref::<Play>() {
                    self.play_type = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct PenaltyTypeInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl PenaltyTypeInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PenaltyTypeOutputs {
    pub result: i32,
    pub result_index: i32,
}
impl PenaltyTypeOutputs {
    pub fn new(result: i32, result_index: i32) -> Self {
        Self {
            result,
            result_index,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "result" => Some(Box::new(self.result.clone()) as Box<dyn std::any::Any>),
            "result_index" => Some(Box::new(self.result_index.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "result" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.result = v.clone();
                    true
                } else {
                    false
                }
            }
            "result_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.result_index = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct PlayerInterchangeInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl PlayerInterchangeInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlayerInterchangeOutputs {
    pub executed: bool,
    pub off_player_index: i32,
    pub on_player_index: i32,
    pub team: Team,
}
impl PlayerInterchangeOutputs {
    pub fn new(executed: bool, off_player_index: i32, on_player_index: i32, team: Team) -> Self {
        Self {
            executed,
            off_player_index,
            on_player_index,
            team,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "executed" => Some(Box::new(self.executed.clone()) as Box<dyn std::any::Any>),
            "off_player_index" => {
                Some(Box::new(self.off_player_index.clone()) as Box<dyn std::any::Any>)
            }
            "on_player_index" => {
                Some(Box::new(self.on_player_index.clone()) as Box<dyn std::any::Any>)
            }
            "team" => Some(Box::new(self.team.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "executed" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.executed = v.clone();
                    true
                } else {
                    false
                }
            }
            "off_player_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.off_player_index = v.clone();
                    true
                } else {
                    false
                }
            }
            "on_player_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.on_player_index = v.clone();
                    true
                } else {
                    false
                }
            }
            "team" => {
                if let Some(v) = value.downcast_ref::<Team>() {
                    self.team = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlayerOfTheMatchOutputs {
    pub player_of_the_match: i32,
}
impl PlayerOfTheMatchOutputs {
    pub fn new(player_of_the_match: i32) -> Self {
        Self {
            player_of_the_match,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "player_of_the_match" => {
                Some(Box::new(self.player_of_the_match.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "player_of_the_match" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.player_of_the_match = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct PlayerSinBinInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl PlayerSinBinInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct PlayerTriesInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl PlayerTriesInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlayerTriesOutputs {
    pub player_index: i32,
}
impl PlayerTriesOutputs {
    pub fn new(player_index: i32) -> Self {
        Self { player_index }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "player_index" => Some(Box::new(self.player_index.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "player_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.player_index = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct SinBinInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl SinBinInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct SinBinOutputs {
    pub sent_off: bool,
}
impl SinBinOutputs {
    pub fn new(sent_off: bool) -> Self {
        Self { sent_off }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "sent_off" => Some(Box::new(self.sent_off.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "sent_off" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.sent_off = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct XyInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl XyInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct XyOutputs {
    pub field_position: FieldPosition,
}
impl XyOutputs {
    pub fn new(field_position: FieldPosition) -> Self {
        Self { field_position }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "field_position" => {
                Some(Box::new(self.field_position.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "field_position" => {
                if let Some(v) = value.downcast_ref::<FieldPosition>() {
                    self.field_position = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn debug(state: &State) {
    let race_to_targets: Vec<i32> = Vec::new();
    let remaining_targets: Vec<i32> = Vec::new();
    let target_index: i32 = 0;
    if false {
        log::info!("{}", "[Debug] Log");
        log::info!(
            "{}",
            format!(
                "State is over, home score = {}, away score = {}",
                state.home_match_score, state.away_match_score
            )
        );
    }
    return;
}
pub fn anytime_output_event(state: &State) {
    let mut away_extra_time_stats: Option<Statistics> = None;
    let mut away_second_half_stats: Option<Statistics> = None;
    let mut ended_half_1: bool = false;
    let mut ended_match: bool = false;
    let mut home_extra_time_stats: Option<Statistics> = None;
    let mut home_second_half_stats: Option<Statistics> = None;
    let mut team_a_second_half_points: i32 = 0;
    let mut team_b_second_half_points: i32 = 0;
    if ![GameStatus::UnknownStatus, GameStatus::NotStarted].contains(&state.game_status) {
        log::info!(
            "{}",
            "[Anytime Output Event] Get period and match statistics"
        );
        home_second_half_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(SECOND_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        away_extra_time_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(EXTRA_TIME_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        away_second_half_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(SECOND_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        home_extra_time_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(EXTRA_TIME_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        log::info!("{}", "[Anytime Output Event] Calculate status flags");
        ended_match = state.is_over;
        ended_half_1 = state.period.number > 1;
        team_b_second_half_points = away_second_half_stats.as_ref().unwrap().scores.total;
        team_a_second_half_points = home_second_half_stats.as_ref().unwrap().scores.total;
        log::info!("{}", "[Anytime Output Event] Output match status");
        record_bool("EndedHalf1".to_string(), ended_half_1);
        record_bool("EndedMatch".to_string(), ended_match);
        log::info!("{}", "[Anytime Output Event] Output second half points");
        record_int("PointsHalf2A".to_string(), team_a_second_half_points);
        record_int("PointsHalf2B".to_string(), team_b_second_half_points);
        log::info!("{}", "[Anytime Output Event] Output match tries");
        record_int(
            "TriesMatchA".to_string(),
            state.home_statistics.total_statistics.scores.tries,
        );
        record_int(
            "TriesMatchB".to_string(),
            state.away_statistics.total_statistics.scores.tries,
        );
        log::info!("{}", "[Anytime Output Event] Output extra time tries");
        record_int(
            "TriesExtraTimeA".to_string(),
            home_extra_time_stats.as_ref().unwrap().scores.tries,
        );
        record_int(
            "TriesExtraTimeB".to_string(),
            away_extra_time_stats.as_ref().unwrap().scores.tries,
        );
    }
    return;
}
pub fn end_of_game_output_event(state: &State) {
    let mut away_extra_time_points: i32 = 0;
    let mut away_extra_time_stats: Option<Statistics> = None;
    let mut away_first_half_stats: Option<Statistics> = None;
    let mut away_second_half_stats: Option<Statistics> = None;
    let mut away_second_half_with_et: i32 = 0;
    let mut draw_match: bool = false;
    let mut home_extra_time_points: i32 = 0;
    let mut home_extra_time_stats: Option<Statistics> = None;
    let mut home_first_half_stats: Option<Statistics> = None;
    let mut home_second_half_stats: Option<Statistics> = None;
    let mut home_second_half_with_et: i32 = 0;
    let mut team_a_won_match: bool = false;
    let mut team_a_won_second_half_and_et: bool = false;
    let mut team_b_won_second_half_and_et: bool = false;
    let _cse_temp_0 = (state.game_status == GameStatus::Ended) || (state.is_over);
    if _cse_temp_0 {
        log::info!("{}", "[End Of Game Output Event] Get period statistics");
        home_second_half_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(SECOND_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        away_first_half_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(FIRST_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        away_second_half_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(SECOND_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        home_extra_time_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(EXTRA_TIME_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        away_extra_time_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(EXTRA_TIME_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        home_first_half_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(FIRST_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        log::info!(
            "{}",
            "[End Of Game Output Event] Calculate extra time and combined scores"
        );
        away_second_half_with_et = away_second_half_stats.as_ref().unwrap().scores.total
            + away_extra_time_stats.as_ref().unwrap().scores.total;
        away_extra_time_points = away_extra_time_stats.as_ref().unwrap().scores.total;
        home_extra_time_points = home_extra_time_stats.as_ref().unwrap().scores.total;
        home_second_half_with_et = home_second_half_stats.as_ref().unwrap().scores.total
            + home_extra_time_stats.as_ref().unwrap().scores.total;
        log::info!(
            "{}",
            "[End Of Game Output Event] Determine second half and extra time winner"
        );
        team_a_won_second_half_and_et = home_second_half_with_et > away_second_half_with_et;
        team_b_won_second_half_and_et = home_second_half_with_et < away_second_half_with_et;
        log::info!("{}", "[End Of Game Output Event] Determine match results");
        draw_match = state.home_match_score == state.away_match_score;
        let team_b_won_match = state.away_match_score > state.home_match_score;
        team_a_won_match = state.home_match_score > state.away_match_score;
        log::info!("{}", "[End Of Game Output Event] Output match totals");
        record_int("PointsMatchA".to_string(), state.home_match_score);
        record_int("PointsMatchB".to_string(), state.away_match_score);
        log::info!("{}", "[End Of Game Output Event] Output extra time points");
        record_int("PointsExtraTimeA".to_string(), home_extra_time_points);
        record_int("PointsExtraTimeB".to_string(), away_extra_time_points);
        log::info!(
            "{}",
            "[End Of Game Output Event] Output second half and extra time results"
        );
        record_bool(
            "WinHalf2AndExtraTimeA".to_string(),
            team_a_won_second_half_and_et,
        );
        record_bool(
            "WinHalf2AndExtraTimeB".to_string(),
            team_b_won_second_half_and_et,
        );
        log::info!("{}", "[End Of Game Output Event] Output match results");
        record_bool("DrawMatch".to_string(), draw_match);
        record_bool("WinMatchA".to_string(), team_a_won_match);
        record_bool("WinMatchB".to_string(), team_b_won_match);
    }
    return;
}
pub fn first_half_output_event(state: &State) {
    let mut away_first_half_stats: Option<Statistics> = None;
    let mut away_first_half_total: i32 = 0;
    let mut away_first_half_tries: i32 = 0;
    let mut draw_first_half: bool = false;
    let mut home_first_half_stats: Option<Statistics> = None;
    let mut home_first_half_total: i32 = 0;
    let mut home_first_half_tries: i32 = 0;
    let mut team_a_won_first_half: bool = false;
    let mut team_b_won_first_half: bool = false;
    let _cse_temp_0 = ([
        GameStatus::HalfTime,
        GameStatus::Period2,
        GameStatus::AwaitingExtraTime,
        GameStatus::ExtraTime,
        GameStatus::Ended,
    ]
    .contains(&state.game_status))
        || (state.is_over);
    if _cse_temp_0 {
        log::info!(
            "{}",
            "[First Half Output Event] Get first half period statistics"
        );
        home_first_half_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(FIRST_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        away_first_half_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(FIRST_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        log::info!(
            "{}",
            "[First Half Output Event] Calculate first half scores"
        );
        home_first_half_tries = home_first_half_stats.as_ref().unwrap().scores.tries;
        away_first_half_tries = away_first_half_stats.as_ref().unwrap().scores.tries;
        away_first_half_total = away_first_half_stats.as_ref().unwrap().scores.total;
        home_first_half_total = home_first_half_stats.as_ref().unwrap().scores.total;
        log::info!(
            "{}",
            "[First Half Output Event] Determine first half results"
        );
        draw_first_half = home_first_half_total == away_first_half_total;
        team_b_won_first_half = away_first_half_total > home_first_half_total;
        team_a_won_first_half = home_first_half_total > away_first_half_total;
        log::info!("{}", "[First Half Output Event] Output first half points");
        record_int("PointsHalf1A".to_string(), home_first_half_total);
        record_int("PointsHalf1B".to_string(), away_first_half_total);
        log::info!(
            "{}",
            "[First Half Output Event] Output first half win/draw results"
        );
        record_bool("WinHalf1A".to_string(), team_a_won_first_half);
        record_bool("WinHalf1B".to_string(), team_b_won_first_half);
        record_bool("DrawHalf1".to_string(), draw_first_half);
        log::info!("{}", "[First Half Output Event] Output first half tries");
        record_int("TriesHalf1A".to_string(), home_first_half_tries);
        record_int("TriesHalf1B".to_string(), away_first_half_tries);
    }
    return;
}
pub fn normal_time_output_event(state: &State) {
    let mut away_first_half_stats: Option<Statistics> = None;
    let mut away_normal_time_score: i32 = 0;
    let mut away_second_half_stats: Option<Statistics> = None;
    let mut extra_time_occurred: bool = false;
    let mut home_first_half_stats: Option<Statistics> = None;
    let mut home_normal_time_score: i32 = 0;
    let mut home_second_half_stats: Option<Statistics> = None;
    if [
        GameStatus::AwaitingExtraTime,
        GameStatus::ExtraTime,
        GameStatus::Ended,
    ]
    .contains(&state.game_status)
    {
        log::info!("{}", "[Normal Time Output Event] Get period statistics");
        away_first_half_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(FIRST_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        home_second_half_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(SECOND_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        home_first_half_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(FIRST_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        away_second_half_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(SECOND_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        log::info!(
            "{}",
            "[Normal Time Output Event] Calculate normal time scores"
        );
        home_normal_time_score = home_first_half_stats.as_ref().unwrap().scores.total
            + home_second_half_stats.as_ref().unwrap().scores.total;
        away_normal_time_score = away_first_half_stats.as_ref().unwrap().scores.total
            + away_second_half_stats.as_ref().unwrap().scores.total;
        log::info!(
            "{}",
            "[Normal Time Output Event] Determine extra time occurrence"
        );
        extra_time_occurred = home_normal_time_score == away_normal_time_score;
        log::info!(
            "{}",
            "[Normal Time Output Event] Output normal time results"
        );
        record_bool("ExtraTimeOccurredMatch".to_string(), extra_time_occurred);
        record_int("PointsNormalTimeA".to_string(), home_normal_time_score);
        record_int("PointsNormalTimeB".to_string(), away_normal_time_score);
        record_bool(
            "WinNormalTimeA".to_string(),
            home_normal_time_score > away_normal_time_score,
        );
        record_bool(
            "WinNormalTimeB".to_string(),
            away_normal_time_score > home_normal_time_score,
        );
        log::info!("{}", "[Normal Time Output Event] Output second half tries");
        record_int(
            "TriesHalf2A".to_string(),
            home_second_half_stats.as_ref().unwrap().scores.tries,
        );
        record_int(
            "TriesHalf2B".to_string(),
            away_second_half_stats.as_ref().unwrap().scores.tries,
        );
    }
    return;
}
pub fn player_void_output_event(state: &State) {
    let mut away_trader_players: Vec<Player> = Vec::new();
    let mut home_trader_players: Vec<Player> = Vec::new();
    if state.include_players {
        log::info!("{}", "[Player Void Output Event] Bind trader state players");
        away_trader_players = state.away_players.clone();
        home_trader_players = state.home_players.clone();
        log::info!(
            "{}",
            "[Player Void Output Event] Output home player void status"
        );
        for player in home_trader_players.iter().cloned() {
            log::info!("{}", "[Player Void Output Event] record");
            record_bool(
                format!("Player_Voided_{}", player.player_index),
                player.is_voided,
            );
        }
        log::info!(
            "{}",
            "[Player Void Output Event] Output away player void status"
        );
        for player in away_trader_players.iter().cloned() {
            log::info!("{}", "[Player Void Output Event] record");
            record_bool(
                format!("Player_Voided_{}", player.player_index),
                player.is_voided,
            );
        }
    }
    return;
}
pub fn period_first_last_score_helper(state: &State) {
    let mut away_first_try_time: i32 = 0;
    let mut first_score_team: Option<Team> = None;
    let mut first_try_team: Option<Team> = None;
    let mut first_try_time: i32 = 0;
    let mut home_first_try_time: i32 = 0;
    let period_filter: bool = false;
    let period_name: String = "".to_string();
    if false {
        log::info!(
            "{}",
            "[Period First Last Score Helper] Find first try in period"
        );
        first_try_team = Some(
            state
                .incidents
                .iter()
                .find(|incident| {
                    period_filter
                        && incident.has_points_confirmed
                        && incident.points_confirmed_score_type == ScoreType::Try
                })
                .cloned()
                .unwrap()
                .points_scored_team,
        );
        log::info!(
            "{}",
            "[Period First Last Score Helper] Find first score in period"
        );
        first_score_team = Some(
            state
                .incidents
                .iter()
                .find(|incident| period_filter && incident.has_points_confirmed)
                .cloned()
                .unwrap()
                .points_scored_team,
        );
        log::info!(
            "{}",
            "[Period First Last Score Helper] Calculate first try times"
        );
        let _cse_temp_0 = {
            let a = state
                .incidents
                .iter()
                .find(|incident| {
                    period_filter
                        && incident.has_points_confirmed
                        && incident.points_confirmed_score_type == ScoreType::Try
                        && incident.points_scored_team == Team::Away
                })
                .cloned()
                .unwrap()
                .time_elapsed;
            let b = 60;
            let q = a / b;
            let r = a % b;
            let r_negative = r < 0;
            let b_negative = b < 0;
            let r_nonzero = r != 0;
            let signs_differ = r_negative != b_negative;
            let needs_adjustment = r_nonzero && signs_differ;
            if needs_adjustment {
                q - 1
            } else {
                q
            }
        } + 1;
        away_first_try_time = _cse_temp_0;
        home_first_try_time = _cse_temp_0;
        first_try_time = _cse_temp_0;
        log::info!(
            "{}",
            "[Period First Last Score Helper] Output first try results"
        );
        record_bool(
            format!("FirstTry{}A", period_name),
            first_try_team.unwrap() == Team::Home,
        );
        record_bool(
            format!("FirstTry{}B", period_name),
            first_try_team.unwrap() == Team::Away,
        );
        log::info!(
            "{}",
            "[Period First Last Score Helper] Output first to score results"
        );
        record_bool(
            format!("FirstToScore{}A", period_name),
            first_score_team.unwrap() == Team::Home,
        );
        record_bool(
            format!("FirstToScore{}B", period_name),
            first_score_team.unwrap() == Team::Away,
        );
        log::info!(
            "{}",
            "[Period First Last Score Helper] Output first try time results"
        );
        record_int(format!("FirstTryTime{}", period_name), first_try_time);
        record_int(format!("FirstTryTime{}A", period_name), home_first_try_time);
        record_int(format!("FirstTryTime{}B", period_name), away_first_try_time);
    }
    return;
}
pub fn test_once_event(state: &State) {
    if state.home_match_score > 0 {
        log::info!("{}", "[Test Once Event] Log once");
        log::info!("{}", "This should only appear once when home team scores");
    }
    return;
}
pub fn first_to_score_tracking_event(state: &State) {
    let mut away_first_try_incident: Option<Incident> = None;
    let mut away_first_try_time: Option<i32> = None;
    let mut extra_time_first_score_incident: Option<Incident> = None;
    let mut extra_time_first_try_incident: Option<Incident> = None;
    let mut half2_et_first_score_incident: Option<Incident> = None;
    let mut half2_et_first_try_incident: Option<Incident> = None;
    let mut home_first_try_incident: Option<Incident> = None;
    let mut home_first_try_time: Option<i32> = None;
    let mut last_score_incident: Option<Incident> = None;
    let mut last_try_incident: Option<Incident> = None;
    let mut last_try_time: Option<i32> = None;
    let mut match_first_score_incident: Option<Incident> = None;
    let mut match_first_try_incident: Option<Incident> = None;
    let mut match_first_try_time: Option<i32> = None;
    let mut points_confirmed_incidents: Vec<Incident> = Vec::new();
    let mut try_incidents: Vec<Incident> = Vec::new();
    let _cse_temp_0 = state.incidents.len() as i32;
    let _cse_temp_1 = (_cse_temp_0 > 0) || (state.is_over);
    if _cse_temp_1 {
        log::info!(
            "{}",
            "[First To Score Tracking Event] Collect confirmed scoring incidents"
        );
        points_confirmed_incidents = state
            .incidents
            .iter()
            .cloned()
            .filter(|incident| {
                incident.has_points_confirmed
                    && [Team::Home, Team::Away].contains(&incident.points_scored_team)
            })
            .collect::<Vec<_>>();
        log::info!(
            "{}",
            "[First To Score Tracking Event] Collect confirmed try incidents"
        );
        try_incidents = points_confirmed_incidents
            .clone()
            .iter()
            .cloned()
            .filter(|incident| incident.points_confirmed_score_type == ScoreType::Try)
            .collect::<Vec<_>>();
        log::info!(
            "{}",
            "[First To Score Tracking Event] Resolve key incidents across periods"
        );
        half2_et_first_try_incident = try_incidents
            .clone()
            .iter()
            .find(|incident| (incident.period.number) as i32 - 1 >= SECOND_HALF_INDEX)
            .cloned();
        extra_time_first_try_incident = try_incidents
            .iter()
            .find(|incident| (incident.period.number) as i32 - 1 == EXTRA_TIME_INDEX)
            .cloned();
        half2_et_first_score_incident = points_confirmed_incidents
            .clone()
            .iter()
            .find(|incident| (incident.period.number) as i32 - 1 >= SECOND_HALF_INDEX)
            .cloned();
        extra_time_first_score_incident = points_confirmed_incidents
            .iter()
            .find(|incident| (incident.period.number) as i32 - 1 == EXTRA_TIME_INDEX)
            .cloned();
        home_first_try_incident = try_incidents
            .iter()
            .find(|incident| incident.points_scored_team == Team::Home)
            .cloned();
        match_first_score_incident = if !points_confirmed_incidents.is_empty() {
            Some(points_confirmed_incidents.get(0usize).cloned().unwrap())
        } else {
            None
        };
        away_first_try_incident = try_incidents
            .iter()
            .find(|incident| incident.points_scored_team == Team::Away)
            .cloned();
        last_try_incident = if !try_incidents.is_empty() {
            Some(try_incidents.last().cloned().unwrap())
        } else {
            None
        };
        match_first_try_incident = if !try_incidents.is_empty() {
            Some(try_incidents.get(0usize).cloned().unwrap())
        } else {
            None
        };
        last_score_incident = if !points_confirmed_incidents.is_empty() {
            Some(points_confirmed_incidents.last().cloned().unwrap())
        } else {
            None
        };
        log::info!("{}", "[First To Score Tracking Event] Compute try timings");
        last_try_time = if last_try_incident.is_some() {
            Some(
                ((last_try_incident.as_ref().unwrap().time_elapsed as f64) / (60 as f64)) as i32
                    + 1,
            )
        } else {
            None
        };
        home_first_try_time = if home_first_try_incident.is_some() {
            Some(
                ((home_first_try_incident.as_ref().unwrap().time_elapsed as f64) / (60 as f64))
                    as i32
                    + 1,
            )
        } else {
            None
        };
        away_first_try_time = if away_first_try_incident.is_some() {
            Some(
                ((away_first_try_incident.as_ref().unwrap().time_elapsed as f64) / (60 as f64))
                    as i32
                    + 1,
            )
        } else {
            None
        };
        match_first_try_time = if match_first_try_incident.is_some() {
            Some(
                ((match_first_try_incident.as_ref().unwrap().time_elapsed as f64) / (60 as f64))
                    as i32
                    + 1,
            )
        } else {
            None
        };
        log::info!(
            "{}",
            "[First To Score Tracking Event] Record match first scores"
        );
        if match_first_score_incident.is_some() {
            record_bool(
                "FirstToScore_Match_A".to_string(),
                match_first_score_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team::Home,
            );
            record_bool(
                "FirstToScore_Match_B".to_string(),
                match_first_score_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team::Away,
            );
            record_bool(
                "FirstTry_Match_A".to_string(),
                match_first_try_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team::Home,
            );
            record_bool(
                "FirstTry_Match_B".to_string(),
                match_first_try_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team::Away,
            );
        }
        log::info!(
            "{}",
            "[First To Score Tracking Event] Record Half 2 and Extra Time first scores"
        );
        if half2_et_first_score_incident.is_some() {
            record_bool(
                "FirstToScore_Half2AndExtraTime_A".to_string(),
                half2_et_first_score_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team::Home,
            );
            record_bool(
                "FirstToScore_Half2AndExtraTime_B".to_string(),
                half2_et_first_score_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team::Away,
            );
            record_bool(
                "FirstTry_Half2AndExtraTime_A".to_string(),
                half2_et_first_try_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team::Home,
            );
            record_bool(
                "FirstTry_Half2AndExtraTime_B".to_string(),
                half2_et_first_try_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team::Away,
            );
        }
        log::info!(
            "{}",
            "[First To Score Tracking Event] Record Extra Time first scores"
        );
        if extra_time_first_score_incident.is_some() {
            record_bool(
                "FirstToScore_ExtraTime_A".to_string(),
                extra_time_first_score_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team::Home,
            );
            record_bool(
                "FirstToScore_ExtraTime_B".to_string(),
                extra_time_first_score_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team::Away,
            );
            record_bool(
                "FirstTry_ExtraTime_A".to_string(),
                extra_time_first_try_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team::Home,
            );
            record_bool(
                "FirstTry_ExtraTime_B".to_string(),
                extra_time_first_try_incident
                    .as_ref()
                    .unwrap()
                    .points_scored_team
                    == Team::Away,
            );
        }
        log::info!(
            "{}",
            "[First To Score Tracking Event] Record Half 2 and Extra Time try timings"
        );
        if half2_et_first_try_incident.is_some() {
            record_int(
                "FirstTryTime_Half2AndExtraTime".to_string(),
                ((half2_et_first_try_incident.as_ref().unwrap().time_elapsed as f64) / (60 as f64))
                    as i32
                    + 1,
            );
            record_int(
                "FirstTryTime_Half2AndExtraTime_A".to_string(),
                if (half2_et_first_try_incident.is_some())
                    && (half2_et_first_try_incident
                        .as_ref()
                        .unwrap()
                        .points_scored_team
                        == Team::Home)
                {
                    ((half2_et_first_try_incident.as_ref().unwrap().time_elapsed as f64)
                        / (60 as f64)) as i32
                        + 1
                } else {
                    0
                },
            );
            record_int(
                "FirstTryTime_Half2AndExtraTime_B".to_string(),
                if (half2_et_first_try_incident.is_some())
                    && (half2_et_first_try_incident
                        .as_ref()
                        .unwrap()
                        .points_scored_team
                        == Team::Away)
                {
                    ((half2_et_first_try_incident.as_ref().unwrap().time_elapsed as f64)
                        / (60 as f64)) as i32
                        + 1
                } else {
                    0
                },
            );
        }
        log::info!(
            "{}",
            "[First To Score Tracking Event] Record Extra Time try timings"
        );
        if extra_time_first_try_incident.is_some() {
            record_int(
                "FirstTryTime_ExtraTime".to_string(),
                if extra_time_first_try_incident.is_some() {
                    ((extra_time_first_try_incident.as_ref().unwrap().time_elapsed as f64)
                        / (60 as f64)) as i32
                        + 1
                } else {
                    0
                },
            );
            record_int(
                "FirstTryTime_ExtraTime_A".to_string(),
                if (extra_time_first_try_incident.is_some())
                    && (extra_time_first_try_incident
                        .as_ref()
                        .unwrap()
                        .points_scored_team
                        == Team::Home)
                {
                    ((extra_time_first_try_incident.as_ref().unwrap().time_elapsed as f64)
                        / (60 as f64)) as i32
                        + 1
                } else {
                    0
                },
            );
            record_int(
                "FirstTryTime_ExtraTime_B".to_string(),
                if (extra_time_first_try_incident.is_some())
                    && (extra_time_first_try_incident
                        .as_ref()
                        .unwrap()
                        .points_scored_team
                        == Team::Away)
                {
                    ((extra_time_first_try_incident.as_ref().unwrap().time_elapsed as f64)
                        / (60 as f64)) as i32
                        + 1
                } else {
                    0
                },
            );
        }
        log::info!(
            "{}",
            "[First To Score Tracking Event] Record match first try timings"
        );
        if match_first_try_incident.is_some() {
            record_int(
                "FirstTryTime_Match".to_string(),
                if match_first_try_time.is_some() {
                    match_first_try_time.unwrap()
                } else {
                    0
                },
            );
            record_int(
                "FirstTryTime_Match_A".to_string(),
                if home_first_try_time.is_some() {
                    home_first_try_time.unwrap()
                } else {
                    0
                },
            );
            record_int(
                "FirstTryTime_Match_B".to_string(),
                if away_first_try_time.is_some() {
                    away_first_try_time.unwrap()
                } else {
                    0
                },
            );
        }
        log::info!(
            "{}",
            "[First To Score Tracking Event] Record last scoring outputs when match ended"
        );
        if state.is_over {
            record_bool(
                "LastTry_Match_A".to_string(),
                (last_try_incident.is_some())
                    && (last_try_incident.as_ref().unwrap().points_scored_team == Team::Home),
            );
            record_bool(
                "LastTry_Match_B".to_string(),
                (last_try_incident.is_some())
                    && (last_try_incident.as_ref().unwrap().points_scored_team == Team::Away),
            );
            record_bool(
                "LastToScore_Match_A".to_string(),
                (last_score_incident.is_some())
                    && (last_score_incident.as_ref().unwrap().points_scored_team == Team::Home),
            );
            record_bool(
                "LastToScore_Match_B".to_string(),
                (last_score_incident.is_some())
                    && (last_score_incident.as_ref().unwrap().points_scored_team == Team::Away),
            );
            record_int(
                "LastTryTime_Match".to_string(),
                if last_try_time.is_some() {
                    last_try_time.unwrap()
                } else {
                    0
                },
            );
        }
    }
    return;
}
pub fn minute_winner_tracking_event(state: &State) {
    let mut final_minute: i32 = 0;
    let mut minute_intervals: Vec<i32> = Vec::new();
    let _cse_temp_0 = state.incidents.len() as i32;
    let _cse_temp_1 = (_cse_temp_0 > 0) || (state.is_over);
    if _cse_temp_1 {
        log::info!(
            "{}",
            "[Minute Winner Tracking Event] Initialize interval context"
        );
        let _cse_temp_2 = ((state.time_elapsed as f64) / (60 as f64)) as i32;
        final_minute = _cse_temp_2;
        minute_intervals = vec![10, 20, 30, 50, 60];
        log::info!(
            "{}",
            "[Minute Winner Tracking Event] Track winner at each minute interval"
        );
        for minute in minute_intervals.iter().cloned() {
            log::info!(
                "{}",
                "[Minute Winner Tracking Event] Record minute winners when interval elapsed"
            );
            if final_minute > minute {
                log::info!(
                    "{}",
                    "[Minute Winner Tracking Event] Calculate scores through interval"
                );
                let away_points_at_minute = state
                    .incidents
                    .iter()
                    .cloned()
                    .filter(|incident| {
                        ((incident.has_points_confirmed)
                            && (incident.points_scored_team == Team::Away))
                            && (incident.time_elapsed <= minute * 60)
                    })
                    .map(|incident| incident.points_scored_points)
                    .sum::<i32>();
                let home_points_at_minute = state
                    .incidents
                    .iter()
                    .cloned()
                    .filter(|incident| {
                        ((incident.has_points_confirmed)
                            && (incident.points_scored_team == Team::Home))
                            && (incident.time_elapsed <= minute * 60)
                    })
                    .map(|incident| incident.points_scored_points)
                    .sum::<i32>();
                log::info!(
                    "{}",
                    "[Minute Winner Tracking Event] Output minute winner results"
                );
                record_bool(
                    format!("WinMinute{}MatchA", minute),
                    home_points_at_minute > away_points_at_minute,
                );
                record_bool(
                    format!("WinMinute{}MatchB", minute),
                    away_points_at_minute > home_points_at_minute,
                );
            }
        }
    }
    return;
}
pub fn player_score_tracking_event(state: &State) {
    let mut away_first_try_jersey: i32 = 0;
    let mut away_try_scorer_indices: Vec<i32> = Vec::new();
    let mut first_try_jersey: i32 = 0;
    let mut home_first_try_jersey: i32 = 0;
    let mut home_try_scorer_indices: Vec<i32> = Vec::new();
    let mut last_try_jersey: i32 = 0;
    let three_unanswered_tries_team: Option<Team> = None;
    let mut try_scorer_indices: Vec<i32> = Vec::new();
    let mut try_teams: Vec<Team> = Vec::new();
    if state.include_players {
        log::info!(
            "{}",
            "[Player Score Tracking Event] Collect try scorer information"
        );
        home_try_scorer_indices = state
            .incidents
            .iter()
            .cloned()
            .filter(|incident| {
                incident.has_points_confirmed
                    && incident.points_confirmed_score_type == ScoreType::Try
                    && incident.points_scored_team == Team::Home
            })
            .map(|incident| incident.points_confirmed_player_index)
            .collect::<Vec<_>>();
        try_scorer_indices = state
            .incidents
            .iter()
            .cloned()
            .filter(|incident| {
                incident.has_points_confirmed
                    && incident.points_confirmed_score_type == ScoreType::Try
            })
            .map(|incident| incident.points_confirmed_player_index)
            .collect::<Vec<_>>();
        try_teams = state
            .incidents
            .iter()
            .cloned()
            .filter(|incident| {
                incident.has_points_confirmed
                    && incident.points_confirmed_score_type == ScoreType::Try
            })
            .map(|incident| incident.points_scored_team)
            .collect::<Vec<_>>();
        away_try_scorer_indices = state
            .incidents
            .iter()
            .cloned()
            .filter(|incident| {
                incident.has_points_confirmed
                    && incident.points_confirmed_score_type == ScoreType::Try
                    && incident.points_scored_team == Team::Away
            })
            .map(|incident| incident.points_confirmed_player_index)
            .collect::<Vec<_>>();
        log::info!(
            "{}",
            "[Player Score Tracking Event] Find jersey numbers for first and last try scorers"
        );
        home_first_try_jersey = {
            let base = &state.home_players;
            let idx: i32 = home_try_scorer_indices.get(0usize).cloned().unwrap();
            let actual_idx = if idx < 0 {
                base.len().saturating_sub(idx.abs() as usize)
            } else {
                idx as usize
            };
            base.get(actual_idx).cloned().unwrap()
        }
        .jersey_number;
        away_first_try_jersey = {
            let base = &state.away_players;
            let idx: i32 = away_try_scorer_indices.get(0usize).cloned().unwrap();
            let actual_idx = if idx < 0 {
                base.len().saturating_sub(idx.abs() as usize)
            } else {
                idx as usize
            };
            base.get(actual_idx).cloned().unwrap()
        }
        .jersey_number;
        last_try_jersey = {
            let base = &state.all_players;
            let idx: i32 = {
                let base = &try_scorer_indices;
                let idx: i32 = (try_scorer_indices.len() as i32).saturating_sub(1);
                let actual_idx = if idx < 0 {
                    base.len().saturating_sub(idx.abs() as usize)
                } else {
                    idx as usize
                };
                base.get(actual_idx).cloned().unwrap()
            };
            let actual_idx = if idx < 0 {
                base.len().saturating_sub(idx.abs() as usize)
            } else {
                idx as usize
            };
            base.get(actual_idx).cloned().unwrap()
        }
        .jersey_number;
        first_try_jersey = {
            let base = &state.all_players;
            let idx: i32 = try_scorer_indices.get(0usize).cloned().unwrap();
            let actual_idx = if idx < 0 {
                base.len().saturating_sub(idx.abs() as usize)
            } else {
                idx as usize
            };
            base.get(actual_idx).cloned().unwrap()
        }
        .jersey_number;
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output try scorer sequence(up to 15 tries)"
        );
        for index in 1..std::cmp::min(15, try_scorer_indices.len() as i32) {
            log::info!("{}", "[Player Score Tracking Event] record");
            record_int(format!("{}thTryScorer_Match", index), {
                let base = &try_scorer_indices;
                let idx: i32 = index - 1;
                let actual_idx = if idx < 0 {
                    base.len().saturating_sub(idx.abs() as usize)
                } else {
                    idx as usize
                };
                base.get(actual_idx).cloned().unwrap()
            });
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output try team sequence"
        );
        for index in 1..try_teams.len() as i32 {
            log::info!("{}", "[Player Score Tracking Event] record");
            record_bool(
                format!("{}thTry_Match_A", index),
                {
                    let base = &try_teams;
                    let idx: i32 = index - 1;
                    let actual_idx = if idx < 0 {
                        base.len().saturating_sub(idx.abs() as usize)
                    } else {
                        idx as usize
                    };
                    base.get(actual_idx).cloned().unwrap()
                } == Team::Home,
            );
            record_bool(
                format!("{}thTry_Match_B", index),
                {
                    let base = &try_teams;
                    let idx: i32 = index - 1;
                    let actual_idx = if idx < 0 {
                        base.len().saturating_sub(idx.abs() as usize)
                    } else {
                        idx as usize
                    };
                    base.get(actual_idx).cloned().unwrap()
                } == Team::Away,
            );
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output first try scorer information"
        );
        let _cse_temp_0 = try_scorer_indices.len() as i32;
        if _cse_temp_0 > 0 {
            record_int("FirstTryScorerJerseyMatch".to_string(), first_try_jersey);
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output home team first try scorer"
        );
        let _cse_temp_1 = home_try_scorer_indices.len() as i32;
        if _cse_temp_1 > 0 {
            record_int(
                "HomeFirstTryScorerMatch".to_string(),
                home_try_scorer_indices.get(0usize).cloned().unwrap(),
            );
            record_int(
                "HomeFirstTryScorerJerseyMatch".to_string(),
                home_first_try_jersey,
            );
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output away team first try scorer"
        );
        let _cse_temp_2 = away_try_scorer_indices.len() as i32;
        if _cse_temp_2 > 0 {
            record_int(
                "AwayFirstTryScorerMatch".to_string(),
                away_try_scorer_indices.get(0usize).cloned().unwrap(),
            );
            record_int(
                "AwayFirstTryScorerJerseyMatch".to_string(),
                away_first_try_jersey,
            );
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output three unanswered tries"
        );
        if state.three_unanswered_tries_team != Team::NotSet {
            record_bool("ThreeUnansweredTries".to_string(), true);
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output last try scorer(end of match only)"
        );
        let _cse_temp_3 = (state.is_over) && (_cse_temp_0 > 0);
        if _cse_temp_3 {
            record_int("LastTryScorerMatch".to_string(), {
                let base = &try_scorer_indices;
                let idx: i32 = (try_scorer_indices.len() as i32).saturating_sub(1);
                let actual_idx = if idx < 0 {
                    base.len().saturating_sub(idx.abs() as usize)
                } else {
                    idx as usize
                };
                base.get(actual_idx).cloned().unwrap()
            });
            record_int("LastTryScorerJerseyMatch".to_string(), last_try_jersey);
            record_int("HomeLastTryScorerMatch".to_string(), {
                let base = &home_try_scorer_indices;
                let idx: i32 = (home_try_scorer_indices.len() as i32).saturating_sub(1);
                let actual_idx = if idx < 0 {
                    base.len().saturating_sub(idx.abs() as usize)
                } else {
                    idx as usize
                };
                base.get(actual_idx).cloned().unwrap()
            });
            record_int("AwayLastTryScorerMatch".to_string(), {
                let base = &away_try_scorer_indices;
                let idx: i32 = (away_try_scorer_indices.len() as i32).saturating_sub(1);
                let actual_idx = if idx < 0 {
                    base.len().saturating_sub(idx.abs() as usize)
                } else {
                    idx as usize
                };
                base.get(actual_idx).cloned().unwrap()
            });
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output player statistics from trader state"
        );
        for player in &state.home_players {
            let player = player.clone();
            log::info!("{}", "[Player Score Tracking Event] record");
            record_bool(
                format!("Player_{}_AnytimeTryScorer", player.player_index),
                player.total_statistics.scores.tries > 0,
            );
            record_bool(
                format!("Player_{}_2PlusTryScorer", player.player_index),
                player.total_statistics.scores.tries >= 2,
            );
            record_bool(
                format!("Player_{}_3PlusTryScorer", player.player_index),
                player.total_statistics.scores.tries >= 3,
            );
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output away player statistics from trader state"
        );
        for player in &state.away_players {
            let player = player.clone();
            log::info!("{}", "[Player Score Tracking Event] record");
            record_bool(
                format!("Player_{}_AnytimeTryScorer", player.player_index),
                player.total_statistics.scores.tries > 0,
            );
            record_bool(
                format!("Player_{}_2PlusTryScorer", player.player_index),
                player.total_statistics.scores.tries >= 2,
            );
            record_bool(
                format!("Player_{}_3PlusTryScorer", player.player_index),
                player.total_statistics.scores.tries >= 3,
            );
        }
    }
    return;
}
pub fn race_to_points_tracking_event(state: &State) {
    let mut away_running_score: i32 = 0;
    let mut home_running_score: i32 = 0;
    let mut race_to_targets: Vec<i32> = Vec::new();
    let mut remaining_targets: Vec<i32> = Vec::new();
    let mut target_index: i32 = 0;
    let _cse_temp_0 = state.incidents.len() as i32;
    let _cse_temp_1 = (_cse_temp_0 > 0) || (state.is_over);
    if _cse_temp_1 {
        log::info!(
            "{}",
            "[Race To Points Tracking Event] Initialize race to context"
        );
        away_running_score = 0;
        target_index = 0;
        home_running_score = 0;
        race_to_targets = vec![10, 15, 20, 25, 30, 35, 40];
        log::info!(
            "{}",
            "[Race To Points Tracking Event] Process scoring incidents for race targets"
        );
        for incident in &state.incidents {
            let incident = incident.clone();
            log::info!(
                "{}",
                "[Race To Points Tracking Event] Apply confirmed score to running totals"
            );
            if ((incident.has_points_confirmed)
                && ([Team::Home, Team::Away].contains(&incident.points_scored_team)))
                && (target_index < race_to_targets.len() as i32)
            {
                log::info!("{}", "[Race To Points Tracking Event] Update team totals");
                if incident.points_scored_team == Team::Home {
                    log::info!("{}", "[Race To Points Tracking Event] Set variables");
                    home_running_score = home_running_score + incident.points_scored_points;
                } else {
                    log::info!("{}", "[Race To Points Tracking Event] Set variables");
                    away_running_score = away_running_score + incident.points_scored_points;
                }
                log::info!(
                    "{}",
                    "[Race To Points Tracking Event] Set current race target"
                );
                let current_target = race_to_targets.get(target_index as usize).cloned().unwrap();
                log::info!(
                    "{}",
                    "[Race To Points Tracking Event] Check target completion"
                );
                let away_reached_target = away_running_score >= current_target;
                let home_reached_target = home_running_score >= current_target;
                log::info!("{}", "[Race To Points Tracking Event] Record race winner when exactly one team reaches target");
                if home_reached_target != away_reached_target {
                    log::info!("{}", "[Race To Points Tracking Event] Record");
                    record_bool(
                        format!("FirstToPoints{}A", current_target),
                        home_reached_target,
                    );
                    record_bool(
                        format!("FirstToPoints{}B", current_target),
                        away_reached_target,
                    );
                    log::info!("{}", "[Race To Points Tracking Event] Set variables");
                    target_index = target_index + 1;
                }
            }
        }
        log::info!(
            "{}",
            "[Race To Points Tracking Event] Capture remaining targets as false"
        );
        remaining_targets = {
            let base = &race_to_targets.clone();
            let start = (target_index).max(0) as usize;
            if start < base.len() {
                base[start..].to_vec()
            } else {
                Vec::new()
            }
        };
        log::info!(
            "{}",
            "[Race To Points Tracking Event] Record unresolved race targets"
        );
        for pending_target in remaining_targets.iter().cloned() {
            log::info!("{}", "[Race To Points Tracking Event] Record");
            record_bool(format!("FirstToPoints{}A", pending_target), false);
            record_bool(format!("FirstToPoints{}B", pending_target), false);
        }
    }
    return;
}
pub fn update_game_status(state: &mut State) {
    if true {
        log::info!(
            "{}",
            "[Update Game Status] Check if normal time half is complete"
        );
        let _cse_temp_0 = (state.time_elapsed > HALF_LENGTH_IN_SECONDS)
            && (state.period.name != PeriodName::ExtraTime);
        if _cse_temp_0 {
            log::info!("{}", "[Update Game Status] Handle end of first half");
            if state.period.name == PeriodName::FirstHalf {
                log::info!("{}", "[Update Game Status] Transition to second half");
                state.game_status = GameStatus::Period2;
                state.period.number = 2;
                state.period.name = PeriodName::SecondHalf;
            } else {
                log::info!(
                    "{}",
                    "[Update Game Status] Check if normal time is complete"
                );
                if state.time_elapsed >= GAME_LENGTH_IN_SECONDS {
                    log::info!(
                        "{}",
                        "[Update Game Status] Check for extra time or game end"
                    );
                    if state.home_match_score == state.away_match_score {
                        log::info!("{}", "[Update Game Status] Enter extra time");
                        state.period.name = PeriodName::ExtraTime;
                        state.period.number = 3;
                        state.is_extratime = true;
                        state.game_status = GameStatus::ExtraTime;
                    } else {
                        log::info!("{}", "[Update Game Status] End game");
                        state.is_over = true;
                        state.game_status = GameStatus::Ended;
                    }
                }
            }
        }
        log::info!("{}", "[Update Game Status] Check extra time conditions");
        if state.period.name == PeriodName::ExtraTime {
            log::info!("{}", "[Update Game Status] Check if extra time should end");
            let _cse_temp_1 =
                state.time_elapsed >= GAME_LENGTH_IN_SECONDS + EXTRA_TIME_LENGTH_IN_SECONDS;
            let _cse_temp_2 = (_cse_temp_1) || (state.home_match_score != state.away_match_score);
            if _cse_temp_2 {
                log::info!("{}", "[Update Game Status] End game");
                state.game_status = GameStatus::Ended;
                state.is_over = true;
            }
        }
    }
    return;
}
#[doc = "Distance from centre of the field from the perspective of the team in possession."]
pub fn calculate_dist_from_centre(state: &State) -> i32 {
    if state.team_in_possession == Team::Home {
        return ((CENTRE_OF_THE_FIELD_Y - state.ball_location.y).abs()) as i32;
    } else {
        return ((CENTRE_OF_THE_FIELD_Y - PLAYING_FIELD_HEIGHT - state.ball_location.y).abs())
            as i32;
    }
}
#[doc = "Distance to the try line from the perspective of the team in possession."]
pub fn calculate_dist_to_try_line(state: &State) -> i32 {
    if state.team_in_possession == Team::Home {
        return PLAYING_FIELD_WIDTH - state.ball_location.x;
    } else {
        return state.ball_location.x;
    }
}
pub fn get_time_on_field_for_position(
    state: &State,
    team: &Team,
    position: &PlayerPosition,
) -> f64 {
    let players = _team_players(state, team);
    let candidate = players
        .iter()
        .find(|p| p.position == *position)
        .cloned()
        .expect("StopIteration: iterator is empty");
    return (candidate.total_statistics.time_on_field) as f64;
}
pub fn get_interchanges_used(state: &State, team: &Team) -> f64 {
    let remaining = _get_remaining_interchanges(state, team);
    let used = MAX_INTERCHANGES - remaining;
    return (std::cmp::max(0, used)) as f64;
}
pub fn get_team_margin(state: &State, team: &Team) -> f64 {
    let home_score = state.home_match_score;
    let away_score = state.away_match_score;
    return if *team == Team::Home {
        (home_score - away_score) as f64
    } else {
        (away_score - home_score) as f64
    };
}
pub fn decrement_remaining_interchanges(state: &mut State, team: &Team) {
    let current = _get_remaining_interchanges(state, team);
    let _cse_temp_0 = std::cmp::max(0, current - 1);
    let remaining = _cse_temp_0;
    _set_remaining_interchanges(state, team, remaining);
}
pub fn _select_bench_player_index(players: &Vec<Player>, starters: i32) -> i32 {
    let available = (starters..players.len() as i32)
        .filter(|&idx| !players.get(idx as usize).cloned().unwrap().is_injured)
        .collect::<Vec<_>>();
    return DEPYLER_RNG.with(|rng| *available.choose(&mut *rng.borrow_mut()).unwrap());
}
pub fn _refresh_all_players(state: &mut State) {
    let mut combined = vec![];
    for team in [Team::Home, Team::Away] {
        combined.extend(_team_players(state, &team).iter().cloned());
    }
    state.all_players.clear();
    state.all_players.extend(combined);
}
pub fn _team_players(state: &State, team: &Team) -> Vec<Player> {
    return if *team == Team::Home {
        state.home_players.clone()
    } else {
        state.away_players.clone()
    };
}
pub fn _team_statistic(state: &State, team: &Team) -> TeamStatistics {
    return if *team == Team::Home {
        state.home_statistics.clone()
    } else {
        state.away_statistics.clone()
    };
}
pub fn _get_remaining_interchanges(state: &State, team: &Team) -> i32 {
    return if *team == Team::Home {
        state.home_remaining_interchanges
    } else {
        state.away_remaining_interchanges
    };
}
pub fn _set_remaining_interchanges(state: &mut State, team: &Team, value: i32) {
    if *team == Team::Home {
        state.home_remaining_interchanges = value;
    } else {
        state.away_remaining_interchanges = value;
    }
}
#[doc = "Margin from the perspective of the penalty-awarded team(matches C# processors)."]
pub fn calculate_foul_team_margin(state: &State) -> i32 {
    let penalty_team;
    if state.current_play == Play::WonPenalty {
        penalty_team = state.team_in_possession;
    } else {
        penalty_team = if state.team_in_possession == Team::Home {
            Team::Away
        } else {
            Team::Home
        };
    }
    if penalty_team == Team::Home {
        return state.home_match_score - state.away_match_score;
    } else {
        return state.away_match_score - state.home_match_score;
    }
}
#[doc = "Margin from the perspective of the team in possession."]
pub fn calculate_margin(state: &State) -> i32 {
    if state.team_in_possession == Team::Home {
        return state.home_match_score - state.away_match_score;
    } else {
        return state.away_match_score - state.home_match_score;
    }
}
pub fn btf(value: bool) -> f64 {
    return if value { 1.0 } else { 0.0 };
}
#[doc = "Sample from a discrete distribution using inverse transform sampling."]
pub fn sample(distribution: &Vec<f64>, k: f64) -> i32 {
    let mut cumulative = 0.0;
    for (i, p) in distribution
        .clone()
        .iter()
        .enumerate()
        .map(|(i, x)| (i as i32, x.clone()))
    {
        let i = i as i32;
        cumulative = cumulative + p;
        if k < cumulative {
            return i;
        }
    }
    return (distribution.len() as i32).saturating_sub(1) as i32;
}
#[doc = "Sample from an unnormalized distribution, scaling k by the sum."]
pub fn sample_scaled(distribution: &Vec<f64>, distribution_sum: f64, k: f64) -> i32 {
    let threshold = k * distribution_sum;
    let mut cumulative = 0.0;
    for (i, p) in distribution
        .clone()
        .iter()
        .enumerate()
        .map(|(i, x)| (i as i32, x.clone()))
    {
        let i = i as i32;
        cumulative = cumulative + p;
        if threshold < cumulative {
            return i;
        }
    }
    return (distribution.len() as i32).saturating_sub(1) as i32;
}
#[doc = "Apply softmax transformation, returning a new list."]
pub fn softmax(logits: Vec<f64>) -> Vec<f64> {
    let _cse_temp_0 = logits
        .clone()
        .iter()
        .fold(f64::NEG_INFINITY, |a, &b| a.max(b));
    let max_logit = _cse_temp_0;
    let exps = logits
        .iter()
        .cloned()
        .map(|x| (x - max_logit as f64).exp())
        .collect::<Vec<_>>();
    let _cse_temp_1 = exps.clone().iter().sum::<f64>();
    let total = _cse_temp_1;
    return exps
        .iter()
        .cloned()
        .map(|e| (e as f64) / (total as f64))
        .collect::<Vec<_>>();
}
#[doc = "Normalize values to sum to 1, returning a new list."]
pub fn normalize(values: Vec<f64>) -> Vec<f64> {
    let _cse_temp_0 = values.clone().iter().sum::<f64>();
    let total = _cse_temp_0;
    return values
        .iter()
        .cloned()
        .map(|v| (v as f64) / (total as f64))
        .collect::<Vec<_>>();
}
pub fn calculate_player_of_match_distributions(state: &State) -> Vec<f64> {
    let players = &state.all_players;
    let home_score = state.home_match_score;
    let away_score = state.away_match_score;
    let margin = home_score - away_score;
    let total_points = home_score + away_score;
    return players
        .iter()
        .cloned()
        .map(|player| _calculate_percentage_chance(&player, margin, total_points))
        .collect::<Vec<_>>();
}
pub fn _calculate_percentage_chance(player: &Player, margin: i32, total_points: i32) -> f64 {
    let margin_factor = _calculate_margin_factor(&player.delta_strength, margin);
    let match_stats = &player.total_statistics;
    let match_tries = match_stats.scores.tries;
    let match_score = match_stats.scores.total;
    let pom_percentage = player.player_of_the_match_percentage;
    let team_won = _team_won(player, margin);
    let pom_factor = _calculate_pom_chance(
        &player.tries_strength,
        match_tries,
        match_score,
        pom_percentage,
        team_won,
    );
    let total_factor = _calculate_total_factor(&player.total_strength, total_points);
    return margin_factor * pom_factor * total_factor + 0.5 * pom_percentage;
}
pub fn _calculate_margin_factor(strength: &Strength, margin: i32) -> f64 {
    let _cse_temp_0 = margin.abs();
    let abs_margin = _cse_temp_0;
    if *strength == Strength::Low {
        return f64::max(2.5 - (abs_margin as f64) / 10.0, 0.5);
    }
    if *strength == Strength::High {
        return f64::min(0.5 * ((abs_margin) as f64) / 10.0, 2.5);
    }
    return 1.0;
}
pub fn _calculate_total_factor(strength: &Strength, total_points: i32) -> f64 {
    if *strength == Strength::Low {
        return f64::max(
            3.0 - (0.175 * ((total_points) as f64) / 10.0 as f64).exp(),
            0.1,
        );
    }
    if *strength == Strength::High {
        return (0.175 * ((total_points) as f64) / 9.9 as f64).exp() - 1.0;
    }
    return 1.0;
}
pub fn _calculate_pom_chance(
    tries_strength: &Strength,
    match_tries: i32,
    match_score: i32,
    pom_percentage: f64,
    team_won: bool,
) -> f64 {
    let try_factor = _calculate_try_factor(tries_strength, match_tries);
    let win_factor = if team_won { 500 } else { 0 };
    let _cse_temp_0 = match_score - match_tries * 4;
    let points_scored = _cse_temp_0;
    let _cse_temp_1 = 0.3357 * ((points_scored) as f64) - 1.75;
    let _cse_temp_2 = f64::max(1.0, _cse_temp_1);
    let points_factor = _cse_temp_2;
    let _cse_temp_3 = pom_percentage + pom_percentage * ((win_factor) as f64);
    let _cse_temp_4 = _cse_temp_3 + try_factor * points_factor;
    let pom_weight = _cse_temp_4;
    return f64::max(pom_weight, MIN_POM_WEIGHT);
}
pub fn _calculate_try_factor(strength: &Strength, tries: i32) -> f64 {
    let _cse_temp_0 = {
        let mut map = HashMap::new();
        map.insert(Strength::Low, 1.0);
        map.insert(Strength::Mid, 3.0);
        map.insert(Strength::High, 10.0);
        map
    }
    .get(&strength)
    .cloned()
    .unwrap_or(3.0);
    let coefficient = _cse_temp_0;
    if tries <= 0 {
        return 0.0;
    }
    return (coefficient * (tries as f64).powf(4.5 as f64) as f64) / 2.0;
}
pub fn _team_won(player: &Player, margin: i32) -> bool {
    let is_home = player.is_home_team;
    if margin == 0 {
        return false;
    }
    return if is_home { margin > 0 } else { margin < 0 };
}
pub fn _goal_line_bucket(grid_coordinate: i32, k: f64) -> i32 {
    if grid_coordinate < GOAL_LINE_GRID_START_INDEX {
        return -1;
    }
    let y_band = grid_coordinate % 6;
    let weights = GOAL_LINE_ZONE_WEIGHTS
        .get(y_band as usize)
        .cloned()
        .unwrap();
    return sample(&weights, k);
}
pub fn compute_conversion_location_from_grid(grid_coordinate: i32, k: f64) -> i32 {
    let bucket = _goal_line_bucket(grid_coordinate, k);
    if bucket < 0 {
        let _cse_temp_0 = CONVERSION_X_VALUES.len() as i32;
        let default_band = (_cse_temp_0 as f64) / (2 as f64);
        return CONVERSION_X_VALUES
            .get(default_band as usize)
            .cloned()
            .unwrap();
    }
    let bucket_row = (bucket as f64) / (5 as f64);
    let _cse_temp_1 = bucket_row * GOAL_LINE_Y_WIDTH + GOAL_LINE_Y_WIDTH / (2 as f64);
    let _cse_temp_2 = (_cse_temp_1) as i32;
    let base_y = _cse_temp_2;
    let _cse_temp_3 = grid_coordinate % 6 * GOAL_LINE_Y_HEIGHT_INCREMENT;
    let goal_line_field_y = base_y + _cse_temp_3;
    let mut conversion_band = (goal_line_field_y as f64) / (35 as f64);
    let _cse_temp_4 = CONVERSION_X_VALUES.len() as i32;
    let _cse_temp_5 = f64::min(conversion_band, (_cse_temp_4 - 1) as f64);
    let _cse_temp_6 = f64::max((0) as f64, _cse_temp_5);
    conversion_band = _cse_temp_6;
    let conversion_location = CONVERSION_X_VALUES
        .get(conversion_band as usize)
        .cloned()
        .unwrap();
    return conversion_location;
}
pub fn goal_line_position(goal_line_index: i32, grid_index: i32) -> FieldPosition {
    let _cse_temp_0 = goal_line_index % 5 * GOAL_LINE_X_WIDTH;
    let _cse_temp_1 =
        ((PLAYING_FIELD_WIDTH + _cse_temp_0) as f64) + (GOAL_LINE_X_WIDTH as f64) / (2 as f64);
    let x = _cse_temp_1;
    let _cse_temp_2 = (({
        let a = goal_line_index;
        let b = 5;
        let q = a / b;
        let r = a % b;
        let r_negative = r < 0;
        let b_negative = b < 0;
        let r_nonzero = r != 0;
        let signs_differ = r_negative != b_negative;
        let needs_adjustment = r_nonzero && signs_differ;
        if needs_adjustment {
            q - 1
        } else {
            q
        }
    }) as f64)
        * GOAL_LINE_Y_WIDTH;
    let _cse_temp_3 = _cse_temp_2 + GOAL_LINE_Y_WIDTH / (2 as f64);
    let _cse_temp_4 = (_cse_temp_3) as i32;
    let mut y = _cse_temp_4;
    let _cse_temp_5 = grid_index % 6 * GOAL_LINE_Y_HEIGHT_INCREMENT;
    y = y + _cse_temp_5;
    return FieldPosition::new((x) as i32, y);
}
pub fn convert_field_position(state: &State, grid_result: String, team: &Team) -> FieldPosition {
    let _cse_temp_0 = GRID_RESULT
        .iter()
        .position(|x| x == &grid_result)
        .map(|i| i as i32)
        .expect("ValueError: value is not in list");
    let y_position = _cse_temp_0 % 6;
    let x_position = {
        let a = _cse_temp_0;
        let b = 6;
        let q = a / b;
        let r = a % b;
        let r_negative = r < 0;
        let b_negative = b < 0;
        let r_nonzero = r != 0;
        let signs_differ = r_negative != b_negative;
        let needs_adjustment = r_nonzero && signs_differ;
        if needs_adjustment {
            q - 1
        } else {
            q
        }
    };
    let y_range;
    let x_range;
    if *team == Team::Home {
        x_range = X_VALUES.get(x_position as usize).cloned().unwrap();
        y_range = Y_VALUES.get(y_position as usize).cloned().unwrap();
    } else {
        x_range = X_VALUES_AWAY.get(x_position as usize).cloned().unwrap();
        y_range = Y_VALUES_AWAY.get(y_position as usize).cloned().unwrap();
    }
    return FieldPosition::new(x_range.0, y_range.1);
}
pub fn derive_grid_coordinate(position: &FieldPosition, team: &Team) -> i32 {
    let y_ranges;
    let x_ranges;
    if *team == Team::Away {
        x_ranges = X_VALUES_AWAY.clone();
        y_ranges = Y_VALUES_AWAY.clone();
    } else {
        x_ranges = X_VALUES.clone();
        y_ranges = Y_VALUES.clone();
    }
    let x_index = _resolve_index(position.x, x_ranges);
    let y_index = _resolve_index(position.y, y_ranges);
    let _cse_temp_0 = (x_index < 0) || (y_index < 0);
    if _cse_temp_0 {
        return -1;
    }
    return x_index * 6 + y_index;
}
pub fn get_goal_line_coordinate(state: &State) -> i32 {
    let grid_coordinate =
        derive_grid_coordinate(&state.ball_location.clone(), &state.team_in_possession);
    if grid_coordinate < 0 {
        return 65;
    }
    return 65 + grid_coordinate % 6;
}
pub fn _resolve_index(coordinate: i32, ranges: Vec<(i32, i32)>) -> i32 {
    for (index, range_bounds) in ranges
        .iter()
        .enumerate()
        .map(|(i, x)| (i as i32, x.clone()))
    {
        let index = index as i32;
        let (lower, upper) = range_bounds;
        if (lower <= coordinate) && (coordinate < upper) {
            return index;
        }
    }
    return -1;
}
pub fn record_player_sin_bin(
    state: &State,
    player_index: i32,
    team: &Team,
    sin_bin_status: &SinBinStatus,
) {
    let players = if *team == Team::Home {
        state.home_players.clone()
    } else {
        state.away_players.clone()
    };
    let mut player = _resolve_player(&players, player_index);
    if player.is_some() {
        let mut sin_bin_collection = if *team == Team::Home {
            state.home_sin_bin.clone()
        } else {
            state.away_sin_bin.clone()
        };
        if !sin_bin_collection.contains(&player.clone().as_ref().unwrap()) {
            sin_bin_collection.push(player.clone().unwrap());
        }
        let seconds_elapsed = state.time_elapsed;
        let duration = if *sin_bin_status == SinBinStatus::YellowCard {
            YELLOW_CARD_SECONDS
        } else {
            0
        };
        player.as_mut().unwrap().sin_bin_status = sin_bin_status.clone();
        player.as_mut().unwrap().return_from_sin_bin_time = seconds_elapsed + duration;
        player.as_mut().unwrap().on_field = false;
        player.as_mut().unwrap().sin_bin_sent_off = seconds_elapsed;
        rebuild_sin_bin_players(state, team);
    }
}
pub fn _resolve_player(players: &Vec<Player>, candidate_index: i32) -> Option<Player> {
    for player in players.iter().cloned() {
        if player.player_index == candidate_index {
            return Some(player.clone());
        }
    }
    let target_position = PlayerPosition::from_i32_or_default(candidate_index);
    for player in players.iter().cloned() {
        if (player.position == target_position) && (player.on_field) {
            return Some(player.clone());
        }
    }
    for player in players.iter().cloned() {
        if player.position == target_position {
            return Some(player);
        }
    }
    return None;
}
pub fn rebuild_sin_bin_players(state: &State, team: &Team) {
    for team in vec![Team::Home, Team::Away] {
        let sin_bin_collection = if team == Team::Home {
            state.home_sin_bin.clone()
        } else {
            state.away_sin_bin.clone()
        };
        let sin_bin_players = sin_bin_collection
            .iter()
            .cloned()
            .filter(|player| player.sin_bin_status != SinBinStatus::NotSet)
            .collect::<Vec<_>>();
        let mut team_stats = if team == Team::Home {
            state.home_statistics.clone()
        } else {
            state.away_statistics.clone()
        };
        team_stats.sin_bin_players = sin_bin_players;
    }
}
pub fn _create_scores() -> Scores {
    return Scores::new(0, 0, 0, 0, 0);
}
pub fn _create_statistics() -> Statistics {
    return Statistics::new(0, 0, _create_scores(), 0, 0);
}
pub fn _create_player_statistics(player: &Player) -> PlayerStatistics {
    let period_breakdown = (0..NUM_PERIODS)
        .map(|_| _create_statistics())
        .collect::<Vec<_>>();
    return PlayerStatistics::new(
        player.jersey_number,
        0,
        period_breakdown,
        player.player_index,
        _create_scores(),
        0,
        0.0,
        _create_statistics(),
    );
}
pub fn _create_team_statistics() -> TeamStatistics {
    return TeamStatistics::new(
        (0..NUM_PERIODS)
            .map(|_| _create_statistics())
            .collect::<Vec<_>>(),
        vec![],
        vec![],
        _create_statistics(),
    );
}
pub fn get_team_handicap(state: &State) -> f64 {
    if state.team_in_possession == Team::Home {
        return state.simulation_invariants.home_handicap;
    }
    return state.simulation_invariants.away_handicap;
}
pub fn swap_possession(state: &mut State) {
    state.set = state.set + 1;
    state.team_in_possession = if state.team_in_possession == Team::Home {
        Team::Away
    } else {
        Team::Home
    };
    state.tackles = STARTING_TACKLE;
}
pub fn setup_statistics(state: &mut State) {
    state.home_statistics = _create_team_statistics();
    state.away_statistics = _create_team_statistics();
    state.home_sin_bin = vec![];
    state.away_sin_bin = vec![];
    for team in [Team::Home, Team::Away] {
        let players = _get_players(state, &team);
        let mut team_stats = _get_team_stats(state, &team);
        team_stats.player_statistics = vec![];
        for mut player in players.iter().cloned() {
            player.period_statistics = (0..NUM_PERIODS)
                .map(|_| _create_player_statistics(&player))
                .collect::<Vec<_>>();
            let total_statistics = _create_player_statistics(&player);
            player.total_statistics = total_statistics.clone();
            team_stats.player_statistics.push(total_statistics);
        }
        rebuild_sin_bin_players(state, &team);
    }
}
pub fn log_state(state: &State) {
    log::info!("{:?}", state);
}
pub fn get_team_try_distributions(state: &State) -> Vec<f64> {
    let players = _get_players(state, &state.team_in_possession);
    return players
        .iter()
        .cloned()
        .map(|p| p.tries_percentage)
        .collect::<Vec<_>>();
}
pub fn apply_time_on_ground(state: &State, team: &Team, seconds: f64) {
    let players = _get_players(state, team);
    let period_idx = state.period.number - 1;
    for mut player in {
        let base = &players;
        let stop = (NUM_STARTING_PLAYERS_PER_TEAM).max(0) as usize;
        base[..stop.min(base.len())].to_vec()
    } {
        player.period_statistics[period_idx as usize].time_on_field = player
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .time_on_field
            + seconds;
        player.total_statistics.time_on_field = player.total_statistics.time_on_field + seconds;
    }
    for mut s in {
        let base = &_get_team_stats(state, team).player_statistics;
        let stop = (NUM_STARTING_PLAYERS_PER_TEAM).max(0) as usize;
        base[..stop.min(base.len())].to_vec()
    } {
        s.time_on_field = s.time_on_field + seconds;
    }
}
pub fn _get_team_stats(state: &State, team: &Team) -> TeamStatistics {
    return if *team == Team::Home {
        state.home_statistics.clone()
    } else {
        state.away_statistics.clone()
    };
}
pub fn _get_players(state: &State, team: &Team) -> Vec<Player> {
    return if *team == Team::Home {
        state.home_players.clone()
    } else {
        state.away_players.clone()
    };
}
pub fn game(state: &mut State) {
    let mut current_minute: i32 = 0;
    let mut field_goal_attempt_result: i32 = 0;
    let mut minute_delta: i32 = 0;
    let mut previous_minute: i32 = 0;
    log::info!("{}", "[NRL] Setup Statistics");
    setup_statistics(state);
    execute_events(state);
    log::info!("{}", "[NRL] Setup State");
    state.period.number = 1;
    state.include_players = false;
    state.period.name = PeriodName::FirstHalf;
    execute_events(state);
    log::info!("{}", "[NRL] Log State");
    log_state(state);
    execute_events(state);
    log::info!("{}", "[NRL] Game Loop");
    while true {
        log::info!("{}", "[NRL] Store previous state");
        state.previous_ball_location = state.ball_location.clone();
        state.previous_play = state.current_play;
        execute_events(state);
        log::info!("{}", "[NRL] Evaluate field goal");
        let field_goal_decision: FieldGoalDecisionOutputs = field_goal_decision(state);
        execute_events(state);
        log::info!(
            "{}",
            "[NRL] Run field goal attempt model only if gating passes"
        );
        if field_goal_decision.attempt {
            log::info!("{}", "[NRL] Run field_goal_attempt");
            let field_goal_attempt_outcome: FieldGoalAttemptOutputs = field_goal_attempt(state);
            execute_events(state);
            log::info!("{}", "[NRL] Set variables");
            field_goal_attempt_result = (field_goal_attempt_outcome.attempt) as i32;
            execute_events(state);
        } else {
            log::info!("{}", "[NRL] Set variables");
            field_goal_attempt_result = 0;
            execute_events(state);
        }
        execute_events(state);
        log::info!("{}", "[NRL] Branch on field goal attempt vs normal play");
        if field_goal_attempt_result == 1 {
            log::info!("{}", "[NRL] Run field_goal");
            field_goal(state);
            execute_events(state);
        } else {
            log::info!("{}", "[NRL] Get next play type");
            let next_play_result: NextPlayOutputs = next_play(state);
            execute_events(state);
            log::info!("{}", "[NRL] Set current play type");
            state.current_play = next_play_result.play_type;
            execute_events(state);
            log::info!("{}", "[NRL] Line Dropout");
            if state.current_play == Play::LineDropout {
                log::info!("{}", "[NRL] Run swap_possession");
                swap_possession(state);
                execute_events(state);
                log::info!("{}", "[NRL] Run kickoff");
                kickoff(state, true, true);
                execute_events(state);
            } else {
                log::info!("{}", "[NRL] Get XY model result");
                let xy_result: XyOutputs = xy(state);
                execute_events(state);
                log::info!("{}", "[NRL] Set ball location");
                state.ball_location = xy_result.field_position.clone();
                execute_events(state);
                log::info!("{}", "[NRL] Process play type");
                if state.current_play == Play::ErrorDefence {
                    log::info!("{}", "[NRL] Set variables");
                    state.tackles = STARTING_TACKLE;
                    execute_events(state);
                } else {
                    if state.current_play == Play::WonPenalty {
                        log::info!("{}", "[NRL] Run process_penalty");
                        process_penalty(state);
                        execute_events(state);
                    } else {
                        if state.current_play == Play::KickRetainTackle {
                            log::info!("{}", "[NRL] Run process_tackle");
                            process_tackle(state);
                            execute_events(state);
                        } else {
                            if state.current_play == Play::KickTurnover {
                                log::info!("{}", "[NRL] Run swap_possession");
                                swap_possession(state);
                                execute_events(state);
                            } else {
                                if state.current_play == Play::Run {
                                } else {
                                    if state.current_play == Play::Pass {
                                    } else {
                                        if state.current_play == Play::RunTackle {
                                            log::info!("{}", "[NRL] Run process_tackle");
                                            process_tackle(state);
                                            execute_events(state);
                                        } else {
                                            if state.current_play == Play::KickRetain {
                                            } else {
                                                if state.current_play == Play::KickRetainTry {
                                                    log::info!("{}", "[NRL] Run process_try");
                                                    process_try(state);
                                                    execute_events(state);
                                                } else {
                                                    if state.current_play == Play::RunTry {
                                                        log::info!("{}", "[NRL] Run process_try");
                                                        process_try(state);
                                                        execute_events(state);
                                                    } else {
                                                        if state.current_play == Play::ErrorAttack {
                                                            log::info!(
                                                                "{}",
                                                                "[NRL] Run swap_possession"
                                                            );
                                                            swap_possession(state);
                                                            execute_events(state);
                                                        } else {
                                                            if state.current_play
                                                                == Play::ConcededPenalty
                                                            {
                                                                log::info!(
                                                                    "{}",
                                                                    "[NRL] Run process_penalty"
                                                                );
                                                                process_penalty(state);
                                                                execute_events(state);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                execute_events(state);
            }
            execute_events(state);
        }
        execute_events(state);
        log::info!("{}", "[NRL] Snapshot elapsed minute before clock");
        previous_minute = ((state.time_elapsed as f64) / (60 as f64)) as i32;
        execute_events(state);
        log::info!("{}", "[NRL] Advance clock");
        clock(state);
        execute_events(state);
        log::info!("{}", "[NRL] Compute elapsed minute after clock");
        current_minute = ((state.time_elapsed as f64) / (60 as f64)) as i32;
        execute_events(state);
        log::info!("{}", "[NRL] Compute minute delta");
        minute_delta = current_minute - previous_minute;
        execute_events(state);
        log::info!("{}", "[NRL] Process interchanges when minute advances");
        if (state.include_players) && (minute_delta > 0) {
            log::info!("{}", "[NRL] Run apply_time_on_ground");
            apply_time_on_ground(state, &Team::Home, (minute_delta * 60) as f64);
            execute_events(state);
            log::info!("{}", "[NRL] Run apply_time_on_ground");
            apply_time_on_ground(state, &Team::Away, (minute_delta * 60) as f64);
            execute_events(state);
            log::info!("{}", "[NRL] Run interchange");
            interchange(state);
            execute_events(state);
        }
        execute_events(state);
        log::info!("{}", "[NRL] Check game status and period transitions");
        check_game_status(state);
        execute_events(state);
        log::info!("{}", "[NRL] Stop if complete");
        if state.is_over {
            log::info!("{}", "[NRL] Exit");
            break;
            execute_events(state);
        }
        execute_events(state);
    }
    execute_events(state);
    return;
}
pub fn unnamed(state: &State) {
    return;
}
pub fn add_conversion(state: &mut State) {
    log::info!("{}", "[AddConversion] Get period index");
    let period_idx = state.period.number - 1;
    log::info!("{}", "[AddConversion] Add conversion points to home team");
    if state.team_in_possession == Team::Home {
        log::info!("{}", "[AddConversion] Set variables");
        state.home_match_score = state.home_match_score + CONVERSION_POINTS;
    }
    log::info!("{}", "[AddConversion] Add conversion points to away team");
    if state.team_in_possession == Team::Away {
        log::info!("{}", "[AddConversion] Set variables");
        state.away_match_score = state.away_match_score + CONVERSION_POINTS;
    }
    log::info!("{}", "[AddConversion] Update home team statistics");
    if state.team_in_possession == Team::Home {
        log::info!("{}", "[AddConversion] Update home period conversions");
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .conversions = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .conversions
            + 1;
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + CONVERSION_POINTS;
        log::info!("{}", "[AddConversion] Update home total conversions");
        state.home_statistics.total_statistics.scores.total =
            state.home_statistics.total_statistics.scores.total + CONVERSION_POINTS;
        state.home_statistics.total_statistics.scores.conversions =
            state.home_statistics.total_statistics.scores.conversions + 1;
    }
    log::info!("{}", "[AddConversion] Update away team statistics");
    if state.team_in_possession == Team::Away {
        log::info!("{}", "[AddConversion] Update away period conversions");
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .conversions = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .conversions
            + 1;
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + CONVERSION_POINTS;
        log::info!("{}", "[AddConversion] Update away total conversions");
        state.away_statistics.total_statistics.scores.total =
            state.away_statistics.total_statistics.scores.total + CONVERSION_POINTS;
        state.away_statistics.total_statistics.scores.conversions =
            state.away_statistics.total_statistics.scores.conversions + 1;
    }
    log::info!("{}", "[AddConversion] Update player statistics if enabled");
    if state.include_players {
        log::info!("{}", "[AddConversion] Update home player statistics");
        if state.team_in_possession == Team::Home {
            log::info!("{}", "[AddConversion] Set variables");
            state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .total = state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .total
                + CONVERSION_POINTS;
            state
                .home_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .conversions = state
                .home_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .conversions
                + 1;
            state
                .home_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .total = state
                .home_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .total
                + CONVERSION_POINTS;
            state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions = state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions
                + 1;
        }
        log::info!("{}", "[AddConversion] Update away player statistics");
        if state.team_in_possession == Team::Away {
            log::info!("{}", "[AddConversion] Set variables");
            state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions = state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions
                + 1;
            state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .total = state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .total
                + CONVERSION_POINTS;
            state
                .away_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .total = state
                .away_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .total
                + CONVERSION_POINTS;
            state
                .away_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .conversions = state
                .away_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .conversions
                + 1;
        }
    }
    execute_events(state);
    return;
}
pub fn add_field_goal(state: &mut State, is_two_pointer: bool) {
    let mut period_idx: i32 = 0;
    let mut points: i32 = 0;
    log::info!("{}", "[AddFieldGoal] Get period index");
    period_idx = state.period.number - 1;
    log::info!("{}", "[AddFieldGoal] Calculate points");
    if is_two_pointer {
        log::info!("{}", "[AddFieldGoal] Set variables");
        points = TWO_POINT_FIELD_GOAL_POINTS;
    } else {
        log::info!("{}", "[AddFieldGoal] Set variables");
        points = FIELD_GOAL_POINTS;
    }
    log::info!("{}", "[AddFieldGoal] Add field goal points to home team");
    if state.team_in_possession == Team::Home {
        log::info!("{}", "[AddFieldGoal] Set variables");
        state.home_match_score = state.home_match_score + points;
    }
    log::info!("{}", "[AddFieldGoal] Add field goal points to away team");
    if state.team_in_possession == Team::Away {
        log::info!("{}", "[AddFieldGoal] Set variables");
        state.away_match_score = state.away_match_score + points;
    }
    log::info!("{}", "[AddFieldGoal] Update home team statistics");
    if state.team_in_possession == Team::Home {
        log::info!("{}", "[AddFieldGoal] Update home period field goals");
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + points;
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .field_goals = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .field_goals
            + 1;
        log::info!("{}", "[AddFieldGoal] Update home total field goals");
        state.home_statistics.total_statistics.scores.field_goals =
            state.home_statistics.total_statistics.scores.field_goals + 1;
        state.home_statistics.total_statistics.scores.total =
            state.home_statistics.total_statistics.scores.total + points;
    }
    log::info!("{}", "[AddFieldGoal] Update away team statistics");
    if state.team_in_possession == Team::Away {
        log::info!("{}", "[AddFieldGoal] Update away period field goals");
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .field_goals = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .field_goals
            + 1;
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + points;
        log::info!("{}", "[AddFieldGoal] Update away total field goals");
        state.away_statistics.total_statistics.scores.total =
            state.away_statistics.total_statistics.scores.total + points;
        state.away_statistics.total_statistics.scores.field_goals =
            state.away_statistics.total_statistics.scores.field_goals + 1;
    }
    log::info!("{}", "[AddFieldGoal] Update player statistics if enabled");
    if state.include_players {
        log::info!("{}", "[AddFieldGoal] Update home player statistics");
        if state.team_in_possession == Team::Home {
            log::info!("{}", "[AddFieldGoal] Set variables");
            state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .total = state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .total
                + points;
            state
                .home_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .total = state
                .home_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .total
                + points;
        }
        log::info!("{}", "[AddFieldGoal] Update away player statistics");
        if state.team_in_possession == Team::Away {
            log::info!("{}", "[AddFieldGoal] Set variables");
            state
                .away_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .total = state
                .away_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .total
                + points;
            state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .total = state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .total
                + points;
        }
    }
    execute_events(state);
    return;
}
pub fn add_penalty(state: &mut State) {
    let mut period_idx: i32 = 0;
    log::info!("{}", "[AddPenalty] Get period index");
    period_idx = state.period.number - 1;
    log::info!("{}", "[AddPenalty] Add penalty points to home team");
    if state.team_in_possession == Team::Home {
        log::info!("{}", "[AddPenalty] Set variables");
        state.home_match_score = state.home_match_score + PENALTY_POINTS;
    }
    log::info!("{}", "[AddPenalty] Add penalty points to away team");
    if state.team_in_possession == Team::Away {
        log::info!("{}", "[AddPenalty] Set variables");
        state.away_match_score = state.away_match_score + PENALTY_POINTS;
    }
    log::info!("{}", "[AddPenalty] Update home team statistics");
    if state.team_in_possession == Team::Home {
        log::info!("{}", "[AddPenalty] Update home total penalties");
        state.home_statistics.total_statistics.scores.penalties =
            state.home_statistics.total_statistics.scores.penalties + 1;
        state.home_statistics.total_statistics.scores.total =
            state.home_statistics.total_statistics.scores.total + PENALTY_POINTS;
        log::info!("{}", "[AddPenalty] Update home period penalties");
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .penalties = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .penalties
            + 1;
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + PENALTY_POINTS;
    }
    log::info!("{}", "[AddPenalty] Update away team statistics");
    if state.team_in_possession == Team::Away {
        log::info!("{}", "[AddPenalty] Update away total penalties");
        state.away_statistics.total_statistics.scores.penalties =
            state.away_statistics.total_statistics.scores.penalties + 1;
        state.away_statistics.total_statistics.scores.total =
            state.away_statistics.total_statistics.scores.total + PENALTY_POINTS;
        log::info!("{}", "[AddPenalty] Update away period penalties");
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + PENALTY_POINTS;
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .penalties = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .penalties
            + 1;
    }
    log::info!("{}", "[AddPenalty] Update player statistics if enabled");
    if state.include_players {
        log::info!("{}", "[AddPenalty] Update home player statistics");
        if state.team_in_possession == Team::Home {
            log::info!("{}", "[AddPenalty] Set variables");
            state
                .home_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .conversions = state
                .home_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .conversions
                + 1;
            state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions = state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions
                + 1;
            state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .total = state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .total
                + PENALTY_POINTS;
            state
                .home_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .total = state
                .home_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .total
                + PENALTY_POINTS;
        }
        log::info!("{}", "[AddPenalty] Update away player statistics");
        if state.team_in_possession == Team::Away {
            log::info!("{}", "[AddPenalty] Set variables");
            state
                .away_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .conversions = state
                .away_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .conversions
                + 1;
            state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .total = state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .total
                + PENALTY_POINTS;
            state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions = state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions
                + 1;
            state
                .away_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .total = state
                .away_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .total
                + PENALTY_POINTS;
        }
    }
    execute_events(state);
    return;
}
pub fn add_try(state: &mut State) {
    log::info!("{}", "[AddTry] Get period index");
    let period_idx = state.period.number - 1;
    log::info!("{}", "[AddTry] Add try points to home team");
    if state.team_in_possession == Team::Home {
        log::info!("{}", "[AddTry] Update home match score");
        state.home_match_score = state.home_match_score + TRY_POINTS;
        log::info!("{}", "[AddTry] Update home period statistics");
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + TRY_POINTS;
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .tries = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .tries
            + 1;
        log::info!("{}", "[AddTry] Update home total statistics");
        state.home_statistics.total_statistics.scores.total =
            state.home_statistics.total_statistics.scores.total + TRY_POINTS;
        state.home_statistics.total_statistics.scores.tries =
            state.home_statistics.total_statistics.scores.tries + 1;
    }
    log::info!("{}", "[AddTry] Add try points to away team");
    if state.team_in_possession == Team::Away {
        log::info!("{}", "[AddTry] Update away match score");
        state.away_match_score = state.away_match_score + TRY_POINTS;
        log::info!("{}", "[AddTry] Update away period statistics");
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .tries = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .tries
            + 1;
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + TRY_POINTS;
        log::info!("{}", "[AddTry] Update away total statistics");
        state.away_statistics.total_statistics.scores.tries =
            state.away_statistics.total_statistics.scores.tries + 1;
        state.away_statistics.total_statistics.scores.total =
            state.away_statistics.total_statistics.scores.total + TRY_POINTS;
    }
    execute_events(state);
    return;
}
pub fn assign_try(state: &mut State, player_index: i32, team: &Team) {
    let mut period_idx: i32 = 0;
    let mut players: Vec<Player> = Vec::new();
    log::info!("{}", "[AssignTry] Get period index");
    period_idx = state.period.number - 1;
    log::info!("{}", "[AssignTry] Get players list based on team");
    players = if *team == Team::Home {
        state.home_players.clone()
    } else {
        state.away_players.clone()
    };
    log::info!("{}", "[AssignTry] Find player by index");
    let mut player = players
        .iter()
        .find(|p| p.player_index == player_index)
        .cloned();
    let player_list_idx = players
        .iter()
        .enumerate()
        .map(|(i, x)| (i as i32, x.clone()))
        .filter(|(i, p)| p.player_index == player_index)
        .map(|(i, p)| i)
        .next()
        .unwrap_or(-1);
    log::info!("{}", "[AssignTry] Update period try scorers");
    state.total_try_scorers = state
        .total_try_scorers
        .clone()
        .iter()
        .chain(vec![player_list_idx.clone()].iter())
        .cloned()
        .collect::<Vec<_>>();
    state.period_try_scorers[period_idx as usize] = state
        .period_try_scorers
        .get(period_idx as usize)
        .cloned()
        .unwrap()
        .iter()
        .chain(vec![player_list_idx.clone()].iter())
        .cloned()
        .collect::<Vec<_>>();
    log::info!("{}", "[AssignTry] Update home team try scorers");
    if *team == Team::Home {
        log::info!("{}", "[AssignTry] Set variables");
        state.home_total_try_scorers = state
            .home_total_try_scorers
            .clone()
            .iter()
            .chain(vec![player_list_idx.clone()].iter())
            .cloned()
            .collect::<Vec<_>>();
        state.home_period_try_scorers[period_idx as usize] = state
            .home_period_try_scorers
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .iter()
            .chain(vec![player_list_idx.clone()].iter())
            .cloned()
            .collect::<Vec<_>>();
    }
    log::info!("{}", "[AssignTry] Update away team try scorers");
    if *team == Team::Away {
        log::info!("{}", "[AssignTry] Set variables");
        state.away_period_try_scorers[period_idx as usize] = state
            .away_period_try_scorers
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .iter()
            .chain(vec![player_list_idx.clone()].iter())
            .cloned()
            .collect::<Vec<_>>();
        state.away_total_try_scorers = state
            .away_total_try_scorers
            .clone()
            .iter()
            .chain(vec![player_list_idx.clone()].iter())
            .cloned()
            .collect::<Vec<_>>();
    }
    log::info!("{}", "[AssignTry] Update player period statistics");
    player
        .as_mut()
        .unwrap()
        .period_statistics
        .get_mut(period_idx as usize)
        .unwrap()
        .scores
        .total = player
        .as_ref()
        .unwrap()
        .period_statistics
        .get(period_idx as usize)
        .cloned()
        .unwrap()
        .scores
        .total
        + TRY_POINTS;
    player
        .as_mut()
        .unwrap()
        .period_statistics
        .get_mut(period_idx as usize)
        .unwrap()
        .scores
        .tries = player
        .as_ref()
        .unwrap()
        .period_statistics
        .get(period_idx as usize)
        .cloned()
        .unwrap()
        .scores
        .tries
        + 1;
    log::info!("{}", "[AssignTry] Update player total statistics");
    player.as_mut().unwrap().total_statistics.scores.tries =
        player.as_ref().unwrap().total_statistics.scores.tries + 1;
    player.as_mut().unwrap().total_statistics.scores.total =
        player.as_ref().unwrap().total_statistics.scores.total + TRY_POINTS;
    log::info!("{}", "[AssignTry] Get team statistics");
    let mut team_stats = if *team == Team::Home {
        state.home_statistics.clone()
    } else {
        state.away_statistics.clone()
    };
    log::info!("{}", "[AssignTry] Update team player statistics");
    team_stats
        .player_statistics
        .get_mut(player_list_idx as usize)
        .unwrap()
        .scores
        .tries = team_stats
        .player_statistics
        .get(player_list_idx as usize)
        .cloned()
        .unwrap()
        .scores
        .tries
        + 1;
    team_stats
        .player_statistics
        .get_mut(player_list_idx as usize)
        .unwrap()
        .scores
        .total = team_stats
        .player_statistics
        .get(player_list_idx as usize)
        .cloned()
        .unwrap()
        .scores
        .total
        + TRY_POINTS;
    execute_events(state);
    return;
}
pub fn check_game_status(state: &mut State) {
    log::info!(
        "{}",
        "[CheckGameStatus] Check if normal time half is complete"
    );
    let _cse_temp_0 = (state.time_elapsed > HALF_LENGTH_IN_SECONDS)
        && (state.period.name != PeriodName::ExtraTime);
    if _cse_temp_0 {
        log::info!("{}", "[CheckGameStatus] Handle end of first half");
        if state.period.name == PeriodName::FirstHalf {
            log::info!("{}", "[CheckGameStatus] Transition to second half");
            state.period.name = PeriodName::SecondHalf;
            state.period.number = 2;
            state.game_status = GameStatus::Period2;
        } else {
            log::info!("{}", "[CheckGameStatus] Check if normal time is complete");
            if state.time_elapsed >= GAME_LENGTH_IN_SECONDS {
                log::info!("{}", "[CheckGameStatus] Check for extra time or game end");
                if state.home_match_score == state.away_match_score {
                    log::info!("{}", "[CheckGameStatus] Enter extra time");
                    state.period.number = 3;
                    state.period.name = PeriodName::ExtraTime;
                    state.game_status = GameStatus::ExtraTime;
                    state.is_extratime = true;
                } else {
                    log::info!("{}", "[CheckGameStatus] End game");
                    state.is_over = true;
                    state.game_status = GameStatus::Ended;
                }
            }
        }
    }
    log::info!("{}", "[CheckGameStatus] Check extra time conditions");
    if state.period.name == PeriodName::ExtraTime {
        log::info!("{}", "[CheckGameStatus] Check if extra time should end");
        let _cse_temp_1 =
            state.time_elapsed >= GAME_LENGTH_IN_SECONDS + EXTRA_TIME_LENGTH_IN_SECONDS;
        let _cse_temp_2 = (_cse_temp_1) || (state.home_match_score != state.away_match_score);
        if _cse_temp_2 {
            log::info!("{}", "[CheckGameStatus] End game");
            state.game_status = GameStatus::Ended;
            state.is_over = true;
        }
    }
    execute_events(state);
    return;
}
pub fn clock(state: &mut State) -> ClockOutputs {
    let mut seconds_to_add: f64 = 0.0;
    let mut seconds_to_add_initial: f64 = 0.0;
    let mut time_adjustment: f64 = 0.0;
    log::info!("{}", "[Clock] Run clock model");
    let model: ClockInferOutputs0 = infer::<ClockInferOutputs0>(
        "clock".to_string(),
        vec![
            btf(state.current_play == Play::Pass),
            btf(state.current_play == Play::RunTackle),
            btf(state.current_play == Play::KickTurnover),
            btf(state.current_play == Play::ErrorAttack),
            btf(state.current_play == Play::ErrorDefence),
            btf(state.current_play == Play::RunTry),
            btf(state.current_play == Play::ConcededPenalty),
            btf(state.current_play == Play::WonPenalty),
            btf(state.current_play == Play::LineDropout),
            btf(state.current_play == Play::KickRetainTackle),
            btf(state.current_play == Play::KickRetainTry),
            btf(state.current_play == Play::KickRetain),
            btf(state.previous_play == Play::Pass),
            btf(state.previous_play == Play::RunTackle),
            (state.tackles) as f64,
            (if (state.time_elapsed) as i32 > FULL_TIME_SECONDS {
                NEAR_END_SECONDS
            } else {
                (state.time_elapsed) as i32
            }) as f64,
            (if state.team_in_possession == Team::Home {
                state.ball_location.x
            } else {
                (PLAYING_FIELD_WIDTH - state.ball_location.x).abs()
            }) as f64,
            (if state.team_in_possession == Team::Home {
                state.ball_location.y
            } else {
                (PLAYING_FIELD_HEIGHT - state.ball_location.y).abs()
            }) as f64,
            (if state.team_in_possession == Team::Home {
                state.previous_ball_location.x
            } else {
                (PLAYING_FIELD_WIDTH - state.previous_ball_location.x).abs()
            }) as f64,
            (if state.team_in_possession == Team::Home {
                state.previous_ball_location.y
            } else {
                (PLAYING_FIELD_HEIGHT - state.previous_ball_location.y).abs()
            }) as f64,
        ],
    );
    log::info!("{}", "[Clock] Round to 1 decimal place");
    let _cse_temp_0 = (model.variable.get(0usize).cloned().unwrap()) as f64;
    let _cse_temp_1 = {
        let multiplier = (10.0_f64).powi(1 as i32);
        (_cse_temp_0 * multiplier).round() / multiplier
    };
    seconds_to_add_initial = _cse_temp_1;
    log::info!("{}", "[Clock] Cap non-try increments at 20 seconds");
    if ![Play::RunTry, Play::KickRetainTry].contains(&state.current_play) {
        let _cse_temp_2 = f64::max(seconds_to_add_initial, 20.0);
        seconds_to_add_initial = _cse_temp_2;
    }
    log::info!("{}", "[Clock] Default time adjustment");
    time_adjustment = 1.0;
    log::info!("{}", "[Clock] Apply period-specific time adjustment");
    if state.period.name == PeriodName::FirstHalf {
        log::info!("{}", "[Clock] Set variables");
        time_adjustment = 0.86;
    }
    log::info!("{}", "[Clock] Calculate final seconds to add");
    seconds_to_add = seconds_to_add_initial * time_adjustment;
    log::info!("{}", "[Clock] Update game state");
    let _cse_temp_3 = (seconds_to_add) as i32;
    state.time_elapsed = state.time_elapsed + _cse_temp_3;
    log::info!("{}", "[Clock] Return seconds added");
    return ClockOutputs::new(seconds_to_add);
}
pub fn conversion(state: &mut State) {
    log::info!("{}", "[Conversion] Run conversion model");
    let conversion_result: GetConversionModelResultOutputs = get_conversion_model_result(state);
    log::info!("{}", "[Conversion] Add conversion points if scored");
    if conversion_result.scored {
        log::info!("{}", "[Conversion] Run add_conversion");
        add_conversion(state);
    }
    log::info!("{}", "[Conversion] Swap possession");
    swap_possession(state);
    log::info!(
        "{}",
        "[Conversion] Process kickoff with force possession change"
    );
    kickoff(state, true, false);
    execute_events(state);
    return;
}
pub fn end_zone(state: &mut State) {
    let mut grid_coordinate: i32 = 0;
    let mut is_end_zone: bool = false;
    let mut is_za_zone: bool = false;
    let mut is_zj_zone: bool = false;
    let mut zone_division: i32 = 0;
    let zone_type: String = "".to_string();
    log::info!("{}", "[EndZone] Derive grid coordinate from ball location");
    grid_coordinate =
        derive_grid_coordinate(&state.ball_location.clone(), &state.team_in_possession);
    log::info!(
        "{}",
        "[EndZone] Calculate end zone classification from grid coordinate"
    );
    let _cse_temp_0 = ((grid_coordinate as f64) / (6 as f64)) as i32;
    zone_division = _cse_temp_0;
    log::info!("{}", "[EndZone] Calculate zone type booleans");
    is_zj_zone = zone_division == 11;
    let _cse_temp_1 = (zone_division == 10) || (zone_division == 11);
    is_end_zone = _cse_temp_1;
    is_za_zone = zone_division == 10;
    log::info!("{}", "[EndZone] Update game state");
    state.end_zone_type = if is_za_zone {
        "za".to_string()
    } else {
        if is_zj_zone {
            "zj".to_string()
        } else {
            "none".to_string()
        }
    };
    state.is_in_end_zone = is_end_zone;
    execute_events(state);
    return;
}
pub fn field_goal(state: &mut State) {
    let mut adjusted_x: i32 = 0;
    let mut is_two_pointer: bool = false;
    log::info!("{}", "[FieldGoal] Run field goal model");
    let field_goal_result: GetFieldGoalModelResultOutputs = get_field_goal_model_result(state);
    log::info!("{}", "[FieldGoal] Handle scored field goal");
    if field_goal_result.scored {
        log::info!("{}", "[FieldGoal] Compute adjusted x for two-pointer check");
        if state.team_in_possession == Team::Home {
            log::info!("{}", "[FieldGoal] Set variables");
            adjusted_x = state.ball_location.x;
        } else {
            log::info!("{}", "[FieldGoal] Set variables");
            adjusted_x = PLAYING_FIELD_WIDTH - state.ball_location.x;
        }
        log::info!("{}", "[FieldGoal] Determine if two-pointer");
        let _cse_temp_0 = adjusted_x < PLAYING_FIELD_WIDTH - TWO_POINT_FIELD_GOAL_DISTANCE;
        is_two_pointer = _cse_temp_0;
        log::info!("{}", "[FieldGoal] Add field goal points");
        add_field_goal(state, is_two_pointer);
        log::info!("{}", "[FieldGoal] Process kickoff");
        kickoff(state, false, false);
    }
    log::info!("{}", "[FieldGoal] Handle missed field goal");
    if !field_goal_result.scored {
        log::info!("{}", "[FieldGoal] Swap possession");
        swap_possession(state);
        log::info!("{}", "[FieldGoal] Set ball location for missed field goal");
        if state.team_in_possession == Team::Home {
            log::info!("{}", "[FieldGoal] Set variables");
            state.ball_location.x = MISSED_FIELD_GOAL_RESTART_X;
            state.ball_location.y = CENTRE_OF_THE_FIELD_Y;
        } else {
            log::info!("{}", "[FieldGoal] Set variables");
            state.ball_location.x = PLAYING_FIELD_WIDTH - MISSED_FIELD_GOAL_RESTART_X;
            state.ball_location.y = CENTRE_OF_THE_FIELD_Y;
        }
    }
    execute_events(state);
    return;
}
pub fn field_goal_attempt(state: &State) -> FieldGoalAttemptOutputs {
    log::info!("{}", "[FieldGoalAttempt] Run field goal attempt model");
    let model: FieldGoalAttemptInferOutputs0 = infer::<FieldGoalAttemptInferOutputs0>(
        "field_goal_attempt".to_string(),
        vec![
            (if state.time_elapsed < HALF_LENGTH_IN_SECONDS {
                HALF_LENGTH_IN_SECONDS - state.time_elapsed
            } else {
                if state.time_elapsed < GAME_LENGTH_IN_SECONDS {
                    GAME_LENGTH_IN_SECONDS - state.time_elapsed
                } else {
                    FIELD_GOAL_ATTEMPT_EXTRA_TIME_SECONDS
                }
            }) as f64,
            (if (calculate_margin(state)).abs() < 2 {
                1.0
            } else {
                0.0
            }) as f64,
            (if calculate_margin(state) > 10 {
                1.0
            } else {
                0.0
            }) as f64,
            (std::cmp::max(calculate_dist_to_try_line(state), 0)) as f64,
            ((state.ball_location.y - CENTRE_OF_THE_FIELD_Y).abs()) as f64,
        ],
    );
    log::info!("{}", "[FieldGoalAttempt] Return result");
    return FieldGoalAttemptOutputs::new(sample(&model.probabilities, random()));
}
pub fn field_goal_decision(state: &State) -> FieldGoalDecisionOutputs {
    const FIELD_GOAL_MAX_ABSOLUTE: i32 = 900;
    const FIELD_GOAL_MAX_TIME_FIRST: i32 = 2400;
    const FIELD_GOAL_MIN_ABSOLUTE: i32 = 100;
    const FIELD_GOAL_MIN_AWAY: i32 = 400;
    const FIELD_GOAL_MIN_HOME: i32 = 600;
    const FIELD_GOAL_MIN_TIME_FIRST: i32 = 2340;
    const FIELD_GOAL_MIN_TIME_SECOND: i32 = 4200;
    let mut in_bounds: bool = false;
    let mut in_direction: bool = false;
    let mut in_time: bool = false;
    log::info!("{}", "[FieldGoalDecision] Evaluate spatial bounds");
    let _cse_temp_0 = (state.ball_location.x > FIELD_GOAL_MIN_ABSOLUTE)
        && (state.ball_location.x < FIELD_GOAL_MAX_ABSOLUTE);
    in_bounds = _cse_temp_0;
    let _cse_temp_1 =
        (state.team_in_possession == Team::Away) && (state.ball_location.x < FIELD_GOAL_MIN_AWAY);
    let _cse_temp_2 =
        (state.team_in_possession == Team::Home) && (state.ball_location.x > FIELD_GOAL_MIN_HOME);
    in_direction = (_cse_temp_1) || (_cse_temp_2);
    let _cse_temp_3 = (state.time_elapsed >= FIELD_GOAL_MIN_TIME_FIRST)
        && (state.time_elapsed <= FIELD_GOAL_MAX_TIME_FIRST);
    let _cse_temp_4 = (_cse_temp_3) || (state.time_elapsed >= FIELD_GOAL_MIN_TIME_SECOND);
    in_time = _cse_temp_4;
    log::info!("{}", "[FieldGoalDecision] Return decision");
    return FieldGoalDecisionOutputs::new(((in_bounds) && (in_time)) && (in_direction));
}
pub fn get_conversion_model_result(state: &State) -> GetConversionModelResultOutputs {
    let mut conversion_k: f64 = 0.0;
    let mut is_extra_time: bool = false;
    let mut player_advantage: i32 = 0;
    log::info!("{}", "[GetConversionModelResult] Set variables");
    conversion_k = random();
    is_extra_time = state.period.name == PeriodName::ExtraTime;
    let _cse_temp_0 = (if state.team_in_possession == Team::Home {
        (state.away_sin_bin.len() as i32).saturating_sub(state.home_sin_bin.len() as i32)
    } else {
        (state.home_sin_bin.len() as i32).saturating_sub(state.away_sin_bin.len() as i32)
    }) as i32;
    player_advantage = _cse_temp_0;
    log::info!(
        "{}",
        "[GetConversionModelResult] Run xy model to determine goal line grid"
    );
    let xy_model: GetConversionModelResultInferOutputs0 =
        infer::<GetConversionModelResultInferOutputs0>(
            "xy".to_string(),
            vec![
                (state.tackles) as f64,
                (if state.team_in_possession == Team::Home {
                    state.ball_location.x
                } else {
                    (PLAYING_FIELD_WIDTH - state.ball_location.x).abs()
                }) as f64,
                (if state.team_in_possession == Team::Home {
                    state.ball_location.y
                } else {
                    (700 - state.ball_location.y).abs()
                }) as f64,
                (state.simulation_invariants.total_points) as f64,
                (get_team_handicap(state)) as f64,
                btf(player_advantage == 1),
                btf(player_advantage > 1),
                btf(player_advantage == -1),
                btf(player_advantage < -1),
                (calculate_margin(state)) as f64,
                btf((state.current_play == Play::Pass) || (is_extra_time)),
                btf(([Play::Run, Play::RunTackle].contains(&state.current_play))
                    || ((state.current_play == Play::RunTry) && (!is_extra_time))),
                btf(
                    ([Play::KickRetain, Play::KickRetainTackle, Play::KickTurnover]
                        .contains(&state.current_play))
                        || ((state.current_play == Play::KickRetainTry) && (!is_extra_time)),
                ),
                btf((state.current_play == Play::RunTry)
                    || ((state.current_play == Play::KickRetainTry) && (!is_extra_time))),
            ],
        );
    log::info!("{}", "[GetConversionModelResult] Run conversion model");
    let conversion_model: GetConversionModelResultInferOutputs1 =
        infer::<GetConversionModelResultInferOutputs1>(
            "conversion".to_string(),
            vec![
                (compute_conversion_location_from_grid(
                    sample(&xy_model.probabilities, random()),
                    conversion_k,
                )) as f64,
                ((CENTRE_OF_THE_FIELD_Y - state.ball_location.y).abs()) as f64,
            ],
        );
    log::info!("{}", "[GetConversionModelResult] Return result");
    return GetConversionModelResultOutputs::new(
        sample(&conversion_model.probabilities, conversion_k) == 1,
    );
}
pub fn get_field_goal_model_result(state: &State) -> GetFieldGoalModelResultOutputs {
    log::info!("{}", "[GetFieldGoalModelResult] Run field goal model");
    let model: GetFieldGoalModelResultInferOutputs0 = infer::<GetFieldGoalModelResultInferOutputs0>(
        "field_goal".to_string(),
        vec![
            (calculate_dist_to_try_line(state)) as f64,
            ((CENTRE_OF_THE_FIELD_Y - state.ball_location.y).abs()) as f64,
        ],
    );
    log::info!("{}", "[GetFieldGoalModelResult] Return result");
    return GetFieldGoalModelResultOutputs::new(sample(&model.probabilities, random()) == 1);
}
pub fn get_kickoff_model_result(state: &State) -> GetKickoffModelResultOutputs {
    log::info!("{}", "[GetKickoffModelResult] Run kickoff model");
    let model: GetKickoffModelResultInferOutputs0 = infer::<GetKickoffModelResultInferOutputs0>(
        "kickoff".to_string(),
        vec![
            btf(state.team_in_possession == Team::Home),
            (state.time_elapsed) as f64,
            0.0,
            (if state.team_in_possession == Team::Home {
                (state.home_players.len() as i32).saturating_sub(state.away_players.len() as i32)
            } else {
                (state.away_players.len() as i32).saturating_sub(state.home_players.len() as i32)
            }) as f64,
            btf(state.current_play == Play::LineDropout),
        ],
    );
    log::info!("{}", "[GetKickoffModelResult] Get kickoff result");
    let kickoff_result = KICKOFF_RESULTS
        .get((sample(&model.probabilities, random())) as i32 as usize)
        .cloned()
        .unwrap();
    log::info!("{}", "[GetKickoffModelResult] Return result");
    return GetKickoffModelResultOutputs::new(
        !KICKOFF_RETAIN_RESULTS
            .clone()
            .contains(&kickoff_result.clone()),
        KICKOFF_TO_GRID_RESULT
            .clone()
            .get(&kickoff_result.to_string())
            .cloned()
            .unwrap_or("A1".to_string()),
    );
}
pub fn interchange(state: &mut State) {
    let mut away_interchange_executed: bool = false;
    let mut away_off_player_index: Option<i32> = None;
    let mut away_on_player_index: Option<i32> = None;
    let mut away_should_interchange: bool = false;
    let mut home_interchange_executed: bool = false;
    let mut home_off_player_index: Option<i32> = None;
    let mut home_on_player_index: Option<i32> = None;
    let mut home_should_interchange: bool = false;
    log::info!("{}", "[Interchange] Reset interchange context");
    away_on_player_index = None;
    home_on_player_index = None;
    home_interchange_executed = false;
    home_should_interchange = false;
    away_should_interchange = false;
    away_off_player_index = None;
    home_off_player_index = None;
    away_interchange_executed = false;
    log::info!("{}", "[Interchange] Sample home interchange decision");
    if state.home_remaining_interchanges > 0 {
        log::info!("{}", "[Interchange] Infer home interchange model");
        let home_interchange_model: InterchangeInferOutputs0 = infer::<InterchangeInferOutputs0>(
            "interchange".to_string(),
            vec![
                (((state.time_elapsed as f64) / (60 as f64)) as i32) as f64,
                (get_time_on_field_for_position(state, &Team::Home, &PlayerPosition::FullBack))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Home, &PlayerPosition::WingerOne))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Home, &PlayerPosition::CentreOne))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Home, &PlayerPosition::CentreTwo))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Home, &PlayerPosition::WingerTwo))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Home, &PlayerPosition::FiveEighth))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Home, &PlayerPosition::HalfBack))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Home, &PlayerPosition::PropOne))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Home, &PlayerPosition::Hooker))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Home, &PlayerPosition::PropTwo))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Home, &PlayerPosition::SecondRowOne))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Home, &PlayerPosition::SecondRowTwo))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Home, &PlayerPosition::Lock)) as f64,
                (get_interchanges_used(state, &Team::Home)) as f64,
            ],
        );
        log::info!("{}", "[Interchange] Decide home interchange outcome");
        let _cse_temp_0 = (home_interchange_model
            .probabilities
            .get(0usize)
            .cloned()
            .unwrap()) as i32;
        home_should_interchange = _cse_temp_0 == 1;
    }
    log::info!("{}", "[Interchange] Sample home player selection");
    if home_should_interchange {
        log::info!("{}", "[Interchange] Infer home player selection");
        let home_execution: PlayerInterchangeOutputs = player_interchange(state, &Team::Home);
        log::info!("{}", "[Interchange] Finalise home interchange");
        if home_execution.executed {
            home_interchange_executed = true;
            home_off_player_index = Some(home_execution.off_player_index);
            home_on_player_index = Some(home_execution.on_player_index);
        }
    }
    log::info!("{}", "[Interchange] Reduce home interchange counter");
    if home_interchange_executed {
        decrement_remaining_interchanges(state, &Team::Home);
    }
    log::info!("{}", "[Interchange] Sample away interchange decision");
    if state.away_remaining_interchanges > 0 {
        log::info!("{}", "[Interchange] Infer away interchange model");
        let away_interchange_model: InterchangeInferOutputs1 = infer::<InterchangeInferOutputs1>(
            "Interchange".to_string(),
            vec![
                (((state.time_elapsed as f64) / (60 as f64)) as i32) as f64,
                (get_time_on_field_for_position(state, &Team::Away, &PlayerPosition::FullBack))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Away, &PlayerPosition::WingerOne))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Away, &PlayerPosition::CentreOne))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Away, &PlayerPosition::CentreTwo))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Away, &PlayerPosition::WingerTwo))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Away, &PlayerPosition::FiveEighth))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Away, &PlayerPosition::HalfBack))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Away, &PlayerPosition::PropOne))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Away, &PlayerPosition::Hooker))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Away, &PlayerPosition::PropTwo))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Away, &PlayerPosition::SecondRowOne))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Away, &PlayerPosition::SecondRowTwo))
                    as f64,
                (get_time_on_field_for_position(state, &Team::Away, &PlayerPosition::Lock)) as f64,
                (get_interchanges_used(state, &Team::Away)) as f64,
            ],
        );
        log::info!("{}", "[Interchange] Decide away interchange outcome");
        let _cse_temp_1 = (away_interchange_model
            .probabilities
            .get(0usize)
            .cloned()
            .unwrap()) as i32;
        away_should_interchange = _cse_temp_1 == 1;
    }
    log::info!("{}", "[Interchange] Sample away player selection");
    if away_should_interchange {
        log::info!("{}", "[Interchange] Infer away player selection");
        let away_execution: PlayerInterchangeOutputs = player_interchange(state, &Team::Away);
        log::info!("{}", "[Interchange] Finalise away interchange");
        if away_execution.executed {
            away_interchange_executed = true;
            away_off_player_index = Some(away_execution.off_player_index);
            away_on_player_index = Some(away_execution.on_player_index);
        }
    }
    log::info!("{}", "[Interchange] Reduce away interchange counter");
    if away_interchange_executed {
        decrement_remaining_interchanges(state, &Team::Away);
    }
    log::info!("{}", "[Interchange] Update game state after interchanges");
    if (home_interchange_executed) || (away_interchange_executed) {
        let away_off_index = away_off_player_index;
        let home_off_index = home_off_player_index;
        let away_executed = away_interchange_executed;
        let home_on_index = home_on_player_index;
        let home_executed = home_interchange_executed;
        let last_event = "INTERCHANGE".to_string();
        let away_on_index = away_on_player_index;
    }
    execute_events(state);
    return;
}
pub fn kickoff(state: &mut State, force_possession_change: bool, is_line_dropout: bool) {
    let mut field_position: FieldPosition = FieldPosition::new(0, 0);
    let mut new_team_in_possession: Option<Team> = None;
    let mut valid: bool = false;
    log::info!("{}", "[Kickoff] Ensure team in possession is initialised");
    if state.team_in_possession == Team::NotSet {
        log::info!("{}", "[Kickoff] If statement");
        if random() > 0.5 {
            log::info!("{}", "[Kickoff] Set variables");
            state.team_in_possession = Team::Away;
        } else {
            log::info!("{}", "[Kickoff] Set variables");
            state.team_in_possession = Team::Home;
        }
    }
    log::info!("{}", "[Kickoff] Seed kickoff possession");
    new_team_in_possession = Some(state.team_in_possession);
    log::info!("{}", "[Kickoff] Loop until valid kickoff position is found");
    while true {
        log::info!("{}", "[Kickoff] Run kickoff model");
        let kickoff: GetKickoffModelResultOutputs = get_kickoff_model_result(state);
        log::info!("{}", "[Kickoff] Swap team if possession changed");
        if kickoff.change_possession {
            log::info!("{}", "[Kickoff] If statement");
            if new_team_in_possession.unwrap() == Team::Home {
                log::info!("{}", "[Kickoff] Set variables");
                new_team_in_possession = Some(Team::Away);
            } else {
                log::info!("{}", "[Kickoff] Set variables");
                new_team_in_possession = Some(Team::Home);
            }
        }
        log::info!("{}", "[Kickoff] Convert to field position");
        if !is_line_dropout {
            log::info!("{}", "[Kickoff] If statement");
            if new_team_in_possession.unwrap() == Team::Home {
                log::info!("{}", "[Kickoff] Set variables");
                field_position = convert_field_position(state, kickoff.grid_result, &Team::Away);
            } else {
                log::info!("{}", "[Kickoff] Set variables");
                field_position = convert_field_position(state, kickoff.grid_result, &Team::Home);
            }
        } else {
            log::info!("{}", "[Kickoff] Set variables");
            field_position = convert_field_position(
                state,
                kickoff.grid_result,
                &new_team_in_possession.unwrap(),
            );
        }
        log::info!("{}", "[Kickoff] Validate position constraints");
        valid = ((((is_line_dropout)
            && ((field_position.x >= DROPOUT_X) && (field_position.x <= PLAYING_FIELD_WIDTH)))
            || (((!is_line_dropout) && (new_team_in_possession.unwrap() == Team::Home))
                && (field_position.x <= KICKOFF_X)))
            || (((!is_line_dropout) && (new_team_in_possession.unwrap() == Team::Away))
                && (field_position.x >= KICKOFF_X)))
            && ((!force_possession_change) || (kickoff.change_possession));
        log::info!("{}", "[Kickoff] Exit loop if valid");
        if valid {
            log::info!("{}", "[Kickoff] Exit");
            break;
        }
    }
    log::info!("{}", "[Kickoff] Update game state");
    state.ball_location = field_position;
    state.team_in_possession = new_team_in_possession.unwrap();
    execute_events(state);
    return;
}
pub fn next_play(state: &State) -> NextPlayOutputs {
    let mut distance_to_try_line: i32 = 0;
    let mut player_advantage: i32 = 0;
    let mut possessing_team_margin: f64 = 0.0;
    log::info!("{}", "[NextPlay] Set variables");
    let _cse_temp_0 = (if state.team_in_possession == Team::Home {
        (state.away_sin_bin.len() as i32).saturating_sub(state.home_sin_bin.len() as i32)
    } else {
        (state.home_sin_bin.len() as i32).saturating_sub(state.away_sin_bin.len() as i32)
    }) as i32;
    player_advantage = _cse_temp_0;
    let _cse_temp_1 = (calculate_margin(state)) as f64;
    possessing_team_margin = _cse_temp_1;
    distance_to_try_line = calculate_dist_to_try_line(state);
    log::info!("{}", "[NextPlay] Run next play model");
    let model: NextPlayInferOutputs0 = infer::<NextPlayInferOutputs0>(
        "next_play".to_string(),
        vec![
            (state.tackles) as f64,
            (distance_to_try_line) as f64,
            (calculate_dist_from_centre(state)) as f64,
            (get_team_handicap(state)) as f64,
            (state.simulation_invariants.total_points) as f64,
            (state.home_match_score + state.away_match_score) as f64,
            (f64::max(f64::min(possessing_team_margin / 2.0, 10.0), -10.0)) as f64,
            btf(player_advantage == 1),
            btf(player_advantage > 1),
            btf(player_advantage == -1),
            btf(player_advantage < -1),
            (if (0 < distance_to_try_line) && (distance_to_try_line <= 10) {
                0.8
            } else {
                if (10 < distance_to_try_line) && (distance_to_try_line <= 20) {
                    0.06
                } else {
                    0.0
                }
            }) as f64,
        ],
    );
    log::info!("{}", "[NextPlay] Return next play");
    return NextPlayOutputs::new(Play::from_i32_or_default(
        (sample(&model.probabilities, random())) as i32,
    ));
}
pub fn penalty(state: &mut State) {
    log::info!("{}", "[Penalty] Execute penalty flow");
    process_penalty(state);
    execute_events(state);
    return;
}
pub fn penalty_type(state: &State) -> PenaltyTypeOutputs {
    log::info!("{}", "[PenaltyType] Run penalty type model");
    let model: PenaltyTypeInferOutputs0 = infer::<PenaltyTypeInferOutputs0>(
        "penalty_type".to_string(),
        vec![
            btf(state.current_play == Play::WonPenalty),
            if state.team_in_possession == Team::Home {
                (state.ball_location.x) as f64
            } else {
                ((1000 - state.ball_location.x).abs()) as f64
            },
            if state.team_in_possession == Team::Home {
                (state.ball_location.y) as f64
            } else {
                ((700 - state.ball_location.y).abs()) as f64
            },
            ((700 - state.ball_location.y).abs()) as f64,
            (if state.time_elapsed < 2400 {
                2400 - state.time_elapsed
            } else {
                2 * 2400 - state.time_elapsed
            }) as f64,
            (get_team_handicap(state)) as f64,
            (calculate_margin(state)) as f64,
        ],
    );
    log::info!("{}", "[PenaltyType] Return penalty type");
    return PenaltyTypeOutputs::new(
        sample(&model.probabilities, random()),
        sample(&model.probabilities, random()),
    );
}
pub fn player_interchange(state: &State, team: &Team) -> PlayerInterchangeOutputs {
    log::info!("{}", "[PlayerInterchange] Run player interchange model");
    let model: PlayerInterchangeInferOutputs0 = infer::<PlayerInterchangeInferOutputs0>(
        "player_interchange".to_string(),
        vec![
            (state.time_elapsed) as f64,
            (get_time_on_field_for_position(state, team, &PlayerPosition::FullBack)) as f64,
            (get_time_on_field_for_position(state, team, &PlayerPosition::WingerOne)) as f64,
            (get_time_on_field_for_position(state, team, &PlayerPosition::CentreOne)) as f64,
            (get_time_on_field_for_position(state, team, &PlayerPosition::CentreTwo)) as f64,
            (get_time_on_field_for_position(state, team, &PlayerPosition::WingerTwo)) as f64,
            (get_time_on_field_for_position(state, team, &PlayerPosition::FiveEighth)) as f64,
            (get_time_on_field_for_position(state, team, &PlayerPosition::HalfBack)) as f64,
            (get_time_on_field_for_position(state, team, &PlayerPosition::PropOne)) as f64,
            (get_time_on_field_for_position(state, team, &PlayerPosition::Hooker)) as f64,
            (get_time_on_field_for_position(state, team, &PlayerPosition::PropTwo)) as f64,
            (get_time_on_field_for_position(state, team, &PlayerPosition::SecondRowOne)) as f64,
            (get_time_on_field_for_position(state, team, &PlayerPosition::SecondRowTwo)) as f64,
            (get_time_on_field_for_position(state, team, &PlayerPosition::Lock)) as f64,
            (state.set) as f64,
            (get_team_margin(state, team)) as f64,
        ],
    );
    log::info!("{}", "[PlayerInterchange] Return interchange position");
    return PlayerInterchangeOutputs::new(true, -1, -1, team.clone());
}
pub fn player_of_the_match(state: &mut State, enabled: bool) -> PlayerOfTheMatchOutputs {
    let mut distribution_sum: f64 = 0.0;
    let mut player_distributions: Vec<f64> = Vec::new();
    let mut pom_player_index: i32 = 0;
    let mut sample_index: i32 = 0;
    log::info!(
        "{}",
        "[PlayerOfTheMatch] Skip processing when feature disabled"
    );
    if !enabled {
        log::info!("{}", "[PlayerOfTheMatch] Return");
        return PlayerOfTheMatchOutputs::new(state.player_of_the_match);
    }
    log::info!(
        "{}",
        "[PlayerOfTheMatch] Calculate player of the match distributions"
    );
    player_distributions = calculate_player_of_match_distributions(state);
    log::info!("{}", "[PlayerOfTheMatch] Aggregate distribution sum");
    let _cse_temp_0 = player_distributions.clone().iter().sum::<f64>();
    let _cse_temp_1 = (_cse_temp_0) as f64;
    distribution_sum = _cse_temp_1;
    log::info!("{}", "[PlayerOfTheMatch] Sample player index");
    if distribution_sum > 0.0 {
        log::info!("{}", "[PlayerOfTheMatch] Set variables");
        sample_index = sample_scaled(&player_distributions, distribution_sum, random());
    } else {
        log::info!("{}", "[PlayerOfTheMatch] Set variables");
        let _cse_temp_2 = player_distributions.len() as i32;
        let _cse_temp_3 = (_cse_temp_2) as f64;
        let _cse_temp_4 = random() * _cse_temp_3;
        let _cse_temp_5 = (_cse_temp_4) as i32;
        sample_index = _cse_temp_5;
    }
    log::info!("{}", "[PlayerOfTheMatch] Clamp sampled index to bounds");
    let _cse_temp_6 = (sample_index) as i32;
    let _cse_temp_7 = std::cmp::max(_cse_temp_6, 0);
    let _cse_temp_8 = player_distributions.len() as i32;
    let _cse_temp_9 = std::cmp::min(_cse_temp_7, _cse_temp_8 - 1);
    sample_index = _cse_temp_9;
    log::info!("{}", "[PlayerOfTheMatch] Resolve player index from state");
    pom_player_index = state
        .all_players
        .get(sample_index as usize)
        .cloned()
        .unwrap()
        .player_index;
    log::info!(
        "{}",
        "[PlayerOfTheMatch] Persist player of the match on state"
    );
    state.player_of_the_match = pom_player_index;
    log::info!("{}", "[PlayerOfTheMatch] Return");
    return PlayerOfTheMatchOutputs::new(pom_player_index);
}
pub fn player_sin_bin(state: &mut State, sin_bin_team_is_home: bool) {
    let mut is_home: f64 = 0.0;
    let mut penalty_team_is_home: bool = false;
    let mut sin_bin_player_index: i32 = 0;
    let mut sin_bin_team: Option<Team> = None;
    log::info!("{}", "[PlayerSinBin] Determine penalty team side");
    penalty_team_is_home = sin_bin_team_is_home;
    log::info!("{}", "[PlayerSinBin] Set is_home variable");
    is_home = if penalty_team_is_home { 1.0 } else { 0.0 };
    log::info!("{}", "[PlayerSinBin] Sample player sin bin model");
    let model: PlayerSinBinInferOutputs0 = infer::<PlayerSinBinInferOutputs0>(
        "player_sin_bin".to_string(),
        vec![
            is_home,
            (state.time_elapsed) as f64,
            (state.set) as f64,
            (state.tackles) as f64,
            (if penalty_team_is_home {
                state.simulation_invariants.home_price
            } else {
                state.simulation_invariants.away_price
            }) as f64,
            (state.simulation_invariants.total_points) as f64,
            (state.home_match_score + state.away_match_score) as f64,
            (calculate_foul_team_margin(state)) as f64,
        ],
    );
    log::info!("{}", "[PlayerSinBin] Persist sin bin selection");
    sin_bin_team = Some(if penalty_team_is_home {
        Team::Home
    } else {
        Team::Away
    });
    sin_bin_player_index = sample(&model.probabilities, random());
    log::info!("{}", "[PlayerSinBin] Record player sin bin event");
    if sin_bin_player_index >= 0 {
        record_player_sin_bin(
            state,
            sin_bin_player_index,
            &sin_bin_team.unwrap(),
            &SinBinStatus::YellowCard,
        );
    }
    log::info!(
        "{}",
        "[PlayerSinBin] Update state markers for sin bin event"
    );
    if sin_bin_player_index >= 0 {
        let last_sin_bin_player_index = sin_bin_player_index;
        let last_sin_bin_team = sin_bin_team;
        let last_event = "PLAYER_SIN_BIN".to_string();
    }
    execute_events(state);
    return;
}
pub fn player_tries(state: &State) -> PlayerTriesOutputs {
    let player_index: i32 = 0;
    log::info!("{}", "[PlayerTries] Calculate player try distributions");
    let percentage: Vec<f64> = get_team_try_distributions(state);
    log::info!("{}", "[PlayerTries] Run player tries model");
    let model: PlayerTriesInferOutputs0 = infer::<PlayerTriesInferOutputs0>(
        "player_tries".to_string(),
        vec![
            percentage.get(0usize).cloned().unwrap(),
            percentage.get(1usize).cloned().unwrap(),
            percentage.get(2usize).cloned().unwrap(),
            percentage.get(3usize).cloned().unwrap(),
            percentage.get(4usize).cloned().unwrap(),
            percentage.get(5usize).cloned().unwrap(),
            percentage.get(6usize).cloned().unwrap(),
            percentage.get(7usize).cloned().unwrap(),
            percentage.get(8usize).cloned().unwrap(),
            percentage.get(9usize).cloned().unwrap(),
            percentage.get(10usize).cloned().unwrap(),
            percentage.get(11usize).cloned().unwrap(),
            percentage.get(12usize).cloned().unwrap(),
        ],
    );
    log::info!("{}", "[PlayerTries] Return sampled player context");
    return PlayerTriesOutputs::new(sample(&model.probabilities, random()));
}
pub fn process_penalty(state: &mut State) {
    log::info!(
        "{}",
        "[ProcessPenalty] Swap possession if penalty was conceded before sampling"
    );
    if state.current_play == Play::ConcededPenalty {
        swap_possession(state);
    }
    log::info!("{}", "[ProcessPenalty] Get penalty type outcome");
    let penalty_outcome_result: PenaltyTypeOutputs = penalty_type(state);
    log::info!("{}", "[ProcessPenalty] Handle penalty shot");
    if penalty_outcome_result.result_index == 0 {
        log::info!(
            "{}",
            "[ProcessPenalty] Run conversion model for penalty shot"
        );
        let conversion_result: GetConversionModelResultOutputs = get_conversion_model_result(state);
        log::info!("{}", "[ProcessPenalty] Add penalty points if scored");
        if conversion_result.scored {
            log::info!("{}", "[ProcessPenalty] Run add_penalty");
            add_penalty(state);
        }
        log::info!("{}", "[ProcessPenalty] Process kickoff after penalty shot");
        kickoff(state, false, false);
    }
    log::info!("{}", "[ProcessPenalty] Handle scrum lost");
    if penalty_outcome_result.result_index == 2 {
        swap_possession(state);
    }
    log::info!("{}", "[ProcessPenalty] Always check sin bin after penalty");
    process_sin_bin_check(state);
    execute_events(state);
    return;
}
pub fn process_sin_bin_check(state: &mut State) {
    log::info!("{}", "[ProcessSinBinCheck] Run sin bin model");
    let send_off_result: SinBinOutputs = sin_bin(state);
    log::info!("{}", "[ProcessSinBinCheck] Run player sin bin model");
    if send_off_result.sent_off {
        player_sin_bin(
            state,
            ((state.current_play == Play::WonPenalty) && (state.team_in_possession == Team::Home))
                || ((state.current_play != Play::WonPenalty)
                    && (state.team_in_possession == Team::Away)),
        );
    }
    execute_events(state);
    return;
}
pub fn process_tackle(state: &mut State) {
    const TACKLES_PER_SET: i32 = 6;
    log::info!("{}", "[ProcessTackle] Get period index");
    let period_idx = state.period.number - 1;
    log::info!("{}", "[ProcessTackle] Get team statistics");
    let mut team_stats = if state.team_in_possession == Team::Home {
        state.home_statistics.clone()
    } else {
        state.away_statistics.clone()
    };
    log::info!("{}", "[ProcessTackle] Update period tackles");
    team_stats.period_statistics[period_idx as usize].tackles = team_stats
        .period_statistics
        .get(period_idx as usize)
        .cloned()
        .unwrap()
        .tackles
        + 1;
    log::info!("{}", "[ProcessTackle] Update total tackles");
    team_stats.total_statistics.tackles = team_stats.total_statistics.tackles + 1;
    log::info!("{}", "[ProcessTackle] Add tackle");
    state.tackles = state.tackles + 1;
    log::info!("{}", "[ProcessTackle] Check if tackle limit exceeded");
    if state.tackles > TACKLES_PER_SET {
        swap_possession(state);
    }
    execute_events(state);
    return;
}
pub fn process_try(state: &mut State) {
    log::info!("{}", "[ProcessTry] Add try points for team in possession");
    add_try(state);
    log::info!(
        "{}",
        "[ProcessTry] Player try assignment if players enabled"
    );
    if state.include_players {
        log::info!("{}", "[ProcessTry] Get player tries model result");
        let try_selection: PlayerTriesOutputs = player_tries(state);
        log::info!("{}", "[ProcessTry] Assign try to selected player");
        assign_try(
            state,
            try_selection.player_index,
            &state.team_in_possession.clone(),
        );
    }
    log::info!("{}", "[ProcessTry] Process conversion");
    conversion(state);
    execute_events(state);
    return;
}
pub fn sin_bin(state: &State) -> SinBinOutputs {
    log::info!("{}", "[SinBin] Run sin bin model");
    let model: SinBinInferOutputs0 = infer::<SinBinInferOutputs0>(
        "sin_bin".to_string(),
        vec![
            (state.ball_location.x) as f64,
            (state.ball_location.y) as f64,
            (calculate_foul_team_margin(state)) as f64,
        ],
    );
    log::info!("{}", "[SinBin] Record event");
    return SinBinOutputs::new(sample(&model.probabilities, random()) == 1);
}
pub fn xy(state: &State) -> XyOutputs {
    let mut is_extra_time: bool = false;
    let mut player_advantage: i32 = 0;
    log::info!("{}", "[Xy] Set variables");
    is_extra_time = state.period.name == PeriodName::ExtraTime;
    let _cse_temp_0 = (if state.team_in_possession == Team::Home {
        (state.away_sin_bin.len() as i32).saturating_sub(state.home_sin_bin.len() as i32)
    } else {
        (state.home_sin_bin.len() as i32).saturating_sub(state.away_sin_bin.len() as i32)
    }) as i32;
    player_advantage = _cse_temp_0;
    log::info!("{}", "[Xy] Run xy model");
    let model: XyInferOutputs0 = infer::<XyInferOutputs0>(
        "xy".to_string(),
        vec![
            (state.tackles) as f64,
            (if state.team_in_possession == Team::Home {
                state.ball_location.x
            } else {
                (1000 - state.ball_location.x).abs()
            }) as f64,
            (if state.team_in_possession == Team::Home {
                state.ball_location.y
            } else {
                (700 - state.ball_location.y).abs()
            }) as f64,
            (state.simulation_invariants.total_points) as f64,
            (get_team_handicap(state)) as f64,
            btf(player_advantage == 1),
            btf(player_advantage > 1),
            btf(player_advantage == -1),
            btf(player_advantage < -1),
            (calculate_margin(state)) as f64,
            btf((state.current_play == Play::Pass) || (is_extra_time)),
            btf(([Play::Run, Play::RunTackle].contains(&state.current_play))
                || ((state.current_play == Play::RunTry) && (!is_extra_time))),
            btf(
                ([Play::KickRetain, Play::KickRetainTackle, Play::KickTurnover]
                    .contains(&state.current_play))
                    || ((state.current_play == Play::KickRetainTry) && (!is_extra_time)),
            ),
            btf((state.current_play == Play::RunTry)
                || ((state.current_play == Play::KickRetainTry) && (!is_extra_time))),
        ],
    );
    log::info!("{}", "[Xy] Get grid result");
    let grid_result = GRID_RESULT
        .get((sample(&model.probabilities, random())) as i32 as usize)
        .cloned()
        .unwrap();
    log::info!("{}", "[Xy] Convert grid to field position");
    return XyOutputs::new(convert_field_position(
        state,
        grid_result,
        &state.team_in_possession,
    ));
}
#[doc = "Execute all registered event functions."]
pub fn execute_events(state: &mut State) {
    if ((state.executed_events & ExecutedEvents::PERIOD_FIRST_LAST_SCORE) == 0) && (false) {
        period_first_last_score_helper(state);
        state.executed_events = state.executed_events | ExecutedEvents::PERIOD_FIRST_LAST_SCORE;
    }
    let _cse_temp_0 = ([
        GameStatus::HalfTime,
        GameStatus::Period2,
        GameStatus::AwaitingExtraTime,
        GameStatus::ExtraTime,
        GameStatus::Ended,
    ]
    .contains(&state.game_status))
        || (state.is_over);
    if ((state.executed_events & ExecutedEvents::FIRST_HALF_OUTPUT) == 0) && (_cse_temp_0) {
        first_half_output_event(state);
        state.executed_events = state.executed_events | ExecutedEvents::FIRST_HALF_OUTPUT;
    }
    let _cse_temp_1 = ((state.executed_events & ExecutedEvents::NORMAL_TIME_OUTPUT) == 0)
        && ([
            GameStatus::AwaitingExtraTime,
            GameStatus::ExtraTime,
            GameStatus::Ended,
        ]
        .contains(&state.game_status));
    if _cse_temp_1 {
        normal_time_output_event(state);
        state.executed_events = state.executed_events | ExecutedEvents::NORMAL_TIME_OUTPUT;
    }
    if state.include_players {
        player_score_tracking_event(state);
    }
    let _cse_temp_2 = state.incidents.len() as i32;
    let _cse_temp_3 = (_cse_temp_2 > 0) || (state.is_over);
    if ((state.executed_events & ExecutedEvents::MINUTE_WINNER_TRACKING) == 0) && (_cse_temp_3) {
        minute_winner_tracking_event(state);
        state.executed_events = state.executed_events | ExecutedEvents::MINUTE_WINNER_TRACKING;
    }
    if ((state.executed_events & ExecutedEvents::DEBUG) == 0) && (false) {
        debug(state);
        state.executed_events = state.executed_events | ExecutedEvents::DEBUG;
    }
    if ((state.executed_events & ExecutedEvents::PLAYER_VOID_OUTPUT) == 0)
        && (state.include_players)
    {
        player_void_output_event(state);
        state.executed_events = state.executed_events | ExecutedEvents::PLAYER_VOID_OUTPUT;
    }
    let _cse_temp_4 = (state.game_status == GameStatus::Ended) || (state.is_over);
    if ((state.executed_events & ExecutedEvents::END_OF_GAME_OUTPUT) == 0) && (_cse_temp_4) {
        end_of_game_output_event(state);
        state.executed_events = state.executed_events | ExecutedEvents::END_OF_GAME_OUTPUT;
    }
    let _cse_temp_5 =
        ((state.executed_events & ExecutedEvents::TEST_ONCE) == 0) && (state.home_match_score > 0);
    if _cse_temp_5 {
        test_once_event(state);
        state.executed_events = state.executed_events | ExecutedEvents::TEST_ONCE;
    }
    if true {
        update_game_status(state);
    }
    if ((state.executed_events & ExecutedEvents::FIRST_TO_SCORE_TRACKING) == 0) && (_cse_temp_3) {
        first_to_score_tracking_event(state);
        state.executed_events = state.executed_events | ExecutedEvents::FIRST_TO_SCORE_TRACKING;
    }
    if ((state.executed_events & ExecutedEvents::RACE_TO_POINTS_TRACKING) == 0) && (_cse_temp_3) {
        race_to_points_tracking_event(state);
        state.executed_events = state.executed_events | ExecutedEvents::RACE_TO_POINTS_TRACKING;
    }
    let _cse_temp_6 = ((state.executed_events & ExecutedEvents::ANYTIME_OUTPUT) == 0)
        && (![GameStatus::UnknownStatus, GameStatus::NotStarted].contains(&state.game_status));
    if _cse_temp_6 {
        anytime_output_event(state);
        state.executed_events = state.executed_events | ExecutedEvents::ANYTIME_OUTPUT;
    }
}
