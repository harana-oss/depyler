#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn debug(state: &State) {
    let race_to_targets: Vec<i32> = Vec::new();
    let remaining_targets: Vec<i32> = Vec::new();
    let target_index: i32 = 0;
    if false {
        log::info!("{}", "[Debug] Log");
        log::info!(
            "{}",
            format!(
                "State is over, home score = {}, away score = {}",
                state.home_match_score, state.away_match_score
            )
        );
    }
    return;
}
