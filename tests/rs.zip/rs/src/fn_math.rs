use std::f64 as math;
pub fn btf(value: bool) -> f64 {
    return if value { 1.0 } else { 0.0 };
}
#[doc = "Sample from a discrete distribution using inverse transform sampling."]
pub fn sample(distribution: &Vec<f64>, k: f64) -> i32 {
    let mut cumulative = 0.0;
    for (i, p) in distribution
        .clone()
        .iter()
        .enumerate()
        .map(|(i, x)| (i as i32, x.clone()))
    {
        let i = i as i32;
        cumulative = cumulative + p;
        if k < cumulative {
            return i;
        }
    }
    return (distribution.len() as i32).saturating_sub(1) as i32;
}
#[doc = "Sample from an unnormalized distribution, scaling k by the sum."]
pub fn sample_scaled(distribution: &Vec<f64>, distribution_sum: f64, k: f64) -> i32 {
    let threshold = k * distribution_sum;
    let mut cumulative = 0.0;
    for (i, p) in distribution
        .clone()
        .iter()
        .enumerate()
        .map(|(i, x)| (i as i32, x.clone()))
    {
        let i = i as i32;
        cumulative = cumulative + p;
        if threshold < cumulative {
            return i;
        }
    }
    return (distribution.len() as i32).saturating_sub(1) as i32;
}
#[doc = "Apply softmax transformation, returning a new list."]
pub fn softmax(logits: Vec<f64>) -> Vec<f64> {
    let _cse_temp_0 = logits
        .clone()
        .iter()
        .fold(f64::NEG_INFINITY, |a, &b| a.max(b));
    let max_logit = _cse_temp_0;
    let exps = logits
        .iter()
        .cloned()
        .map(|x| (x - max_logit as f64).exp())
        .collect::<Vec<_>>();
    let _cse_temp_1 = exps.clone().iter().sum::<f64>();
    let total = _cse_temp_1;
    return exps
        .iter()
        .cloned()
        .map(|e| (e as f64) / (total as f64))
        .collect::<Vec<_>>();
}
#[doc = "Normalize values to sum to 1, returning a new list."]
pub fn normalize(values: Vec<f64>) -> Vec<f64> {
    let _cse_temp_0 = values.clone().iter().sum::<f64>();
    let total = _cse_temp_0;
    return values
        .iter()
        .cloned()
        .map(|v| (v as f64) / (total as f64))
        .collect::<Vec<_>>();
}
