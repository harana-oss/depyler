#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn conversion(state: &State) {
    log::info!("{}", "[Conversion] Run conversion model");
    let conversion_result: GetConversionModelResultOutputs =
        get_conversion_model_result(state.clone());
    log::info!("{}", "[Conversion] Add conversion points if scored");
    if conversion_result.scored {
        log::info!("{}", "[Conversion] Run add_conversion");
        add_conversion(state.clone());
    }
    log::info!("{}", "[Conversion] Swap possession");
    swap_possession(state.clone());
    log::info!(
        "{}",
        "[Conversion] Process kickoff with force possession change"
    );
    kickoff(state.clone(), false, true);
    execute_events(state);
    return;
}
