#[doc = "// NOTE: Map Python module '__future__'()"]
#[doc = "// NOTE: Map Python module 'sin_bin'()"]
pub fn _create_scores() -> Scores {
    return Scores::new(0, 0, 0, 0, 0);
}
pub fn _create_statistics() -> Statistics {
    return Statistics::new(0, 0, _create_scores(), 0, 0);
}
pub fn _create_player_statistics(player: &Player) -> PlayerStatistics {
    let period_breakdown = (0..NUM_PERIODS)
        .map(|_| _create_statistics())
        .collect::<Vec<_>>();
    return PlayerStatistics::new(
        player.jersey_number,
        0,
        period_breakdown,
        player.player_index,
        _create_scores(),
        0,
        0.0,
        _create_statistics(),
    );
}
pub fn _create_team_statistics() -> TeamStatistics {
    return TeamStatistics::new(
        (0..NUM_PERIODS)
            .map(|_| _create_statistics())
            .collect::<Vec<_>>(),
        vec![],
        vec![],
        _create_statistics(),
    );
}
pub fn get_team_handicap(state: &State) -> f64 {
    if state.team_in_possession == Team.Home {
        return state.simulation_invariants.home_handicap;
    }
    return state.simulation_invariants.away_handicap;
}
pub fn swap_possession(state: &mut State) {
    state.set = state.set + 1;
    state.team_in_possession = if state.team_in_possession == Team.Home {
        Team.Away
    } else {
        Team.Home
    };
    state.tackles = STARTING_TACKLE;
}
pub fn setup_statistics(state: &mut State) {
    state.home_statistics = _create_team_statistics();
    state.away_statistics = _create_team_statistics();
    state.home_sin_bin = vec![];
    state.away_sin_bin = vec![];
    for team in [Team.Home, Team.Away] {
        let players = _get_players(state, &team);
        let mut team_stats = _get_team_stats(state, &team);
        team_stats.player_statistics = vec![];
        for mut player in players.iter().cloned() {
            player.period_statistics = (0..NUM_PERIODS)
                .map(|_| _create_player_statistics(&player))
                .collect::<Vec<_>>();
            let total_statistics = _create_player_statistics(&player);
            player.total_statistics = total_statistics.clone();
            team_stats.player_statistics.push(total_statistics);
        }
        rebuild_sin_bin_players(state, team);
    }
}
pub fn log_state(state: &State) {
    log::info!("{:?}", state);
}
pub fn get_team_try_distributions(state: &State) -> Vec<f64> {
    let players = _get_players(state, &state.team_in_possession);
    return players
        .iter()
        .cloned()
        .map(|p| p.tries_percentage)
        .collect::<Vec<_>>();
}
pub fn apply_time_on_ground(state: &State, team: &Team, seconds: f64) {
    let players = _get_players(state, team);
    let period_idx = state.period.number - 1;
    for mut player in {
        let base = &players;
        let stop = (NUM_STARTING_PLAYERS_PER_TEAM).max(0) as usize;
        base[..stop.min(base.len())].to_vec()
    } {
        player.period_statistics[period_idx as usize].time_on_field = player
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .time_on_field
            + seconds;
        player.total_statistics.time_on_field = player.total_statistics.time_on_field + seconds;
    }
    for mut s in {
        let base = &_get_team_stats(state, team).player_statistics;
        let stop = (NUM_STARTING_PLAYERS_PER_TEAM).max(0) as usize;
        base[..stop.min(base.len())].to_vec()
    } {
        s.time_on_field = s.time_on_field + seconds;
    }
}
pub fn _get_team_stats(state: &State, team: &Team) -> TeamStatistics {
    return if *team == Team.Home {
        state.home_statistics
    } else {
        state.away_statistics
    };
}
pub fn _get_players(state: &State, team: &Team) -> Vec<Player> {
    return if *team == Team.Home {
        state.home_players
    } else {
        state.away_players
    };
}
