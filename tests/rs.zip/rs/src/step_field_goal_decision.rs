#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone, PartialEq, Default)]
pub struct FieldGoalDecisionOutputs {
    pub attempt: bool,
}
impl FieldGoalDecisionOutputs {
    pub fn new(attempt: bool) -> Self {
        Self { attempt }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "attempt" => Some(Box::new(self.attempt.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "attempt" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.attempt = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn field_goal_decision(state: &State) -> FieldGoalDecisionOutputs {
    const FIELD_GOAL_MAX_ABSOLUTE: i32 = 900;
    const FIELD_GOAL_MAX_TIME_FIRST: i32 = 2400;
    const FIELD_GOAL_MIN_ABSOLUTE: i32 = 100;
    const FIELD_GOAL_MIN_AWAY: i32 = 400;
    const FIELD_GOAL_MIN_HOME: i32 = 600;
    const FIELD_GOAL_MIN_TIME_FIRST: i32 = 2340;
    const FIELD_GOAL_MIN_TIME_SECOND: i32 = 4200;
    let mut in_bounds: bool = false;
    let mut in_direction: bool = false;
    let mut in_time: bool = false;
    log::info!("{}", "[FieldGoalDecision] Evaluate spatial bounds");
    let _cse_temp_0 = (state.ball_location.x > FIELD_GOAL_MIN_ABSOLUTE)
        && (state.ball_location.x < FIELD_GOAL_MAX_ABSOLUTE);
    in_bounds = _cse_temp_0;
    let _cse_temp_1 =
        (state.team_in_possession == Team.Away) && (state.ball_location.x < FIELD_GOAL_MIN_AWAY);
    let _cse_temp_2 =
        (state.team_in_possession == Team.Home) && (state.ball_location.x > FIELD_GOAL_MIN_HOME);
    in_direction = (_cse_temp_1) || (_cse_temp_2);
    let _cse_temp_3 = (state.time_elapsed >= FIELD_GOAL_MIN_TIME_FIRST)
        && (state.time_elapsed <= FIELD_GOAL_MAX_TIME_FIRST);
    let _cse_temp_4 = (_cse_temp_3) || (state.time_elapsed >= FIELD_GOAL_MIN_TIME_SECOND);
    in_time = _cse_temp_4;
    log::info!("{}", "[FieldGoalDecision] Return decision");
    return FieldGoalDecisionOutputs::new(((in_bounds) && (in_time)) && (in_direction));
}
