#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn add_penalty(state: &mut State) {
    let mut period_idx: i32 = 0;
    log::info!("{}", "[AddPenalty] Get period index");
    period_idx = state.period.number - 1;
    log::info!("{}", "[AddPenalty] Add penalty points to home team");
    if state.team_in_possession == Team.Home {
        log::info!("{}", "[AddPenalty] Set variables");
        state.home_match_score = state.home_match_score + PENALTY_POINTS;
    }
    log::info!("{}", "[AddPenalty] Add penalty points to away team");
    if state.team_in_possession == Team.Away {
        log::info!("{}", "[AddPenalty] Set variables");
        state.away_match_score = state.away_match_score + PENALTY_POINTS;
    }
    log::info!("{}", "[AddPenalty] Update home team statistics");
    if state.team_in_possession == Team.Home {
        log::info!("{}", "[AddPenalty] Update home total penalties");
        state.home_statistics.total_statistics.scores.penalties =
            state.home_statistics.total_statistics.scores.penalties + 1;
        state.home_statistics.total_statistics.scores.total =
            state.home_statistics.total_statistics.scores.total + PENALTY_POINTS;
        log::info!("{}", "[AddPenalty] Update home period penalties");
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .penalties = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .penalties
            + 1;
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + PENALTY_POINTS;
    }
    log::info!("{}", "[AddPenalty] Update away team statistics");
    if state.team_in_possession == Team.Away {
        log::info!("{}", "[AddPenalty] Update away total penalties");
        state.away_statistics.total_statistics.scores.penalties =
            state.away_statistics.total_statistics.scores.penalties + 1;
        state.away_statistics.total_statistics.scores.total =
            state.away_statistics.total_statistics.scores.total + PENALTY_POINTS;
        log::info!("{}", "[AddPenalty] Update away period penalties");
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + PENALTY_POINTS;
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .penalties = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .penalties
            + 1;
    }
    log::info!("{}", "[AddPenalty] Update player statistics if enabled");
    if state.include_players {
        log::info!("{}", "[AddPenalty] Update home player statistics");
        if state.team_in_possession == Team.Home {
            log::info!("{}", "[AddPenalty] Set variables");
            state
                .home_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .conversions = state
                .home_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .conversions
                + 1;
            state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions = state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions
                + 1;
            state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .total = state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .total
                + PENALTY_POINTS;
            state
                .home_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .total = state
                .home_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .total
                + PENALTY_POINTS;
        }
        log::info!("{}", "[AddPenalty] Update away player statistics");
        if state.team_in_possession == Team.Away {
            log::info!("{}", "[AddPenalty] Set variables");
            state
                .away_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .conversions = state
                .away_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .conversions
                + 1;
            state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .total = state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .total
                + PENALTY_POINTS;
            state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions = state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions
                + 1;
            state
                .away_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .total = state
                .away_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .total
                + PENALTY_POINTS;
        }
    }
    execute_events(state);
    return;
}
