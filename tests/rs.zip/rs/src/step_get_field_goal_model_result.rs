#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct GetFieldGoalModelResultInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl GetFieldGoalModelResultInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct GetFieldGoalModelResultOutputs {
    pub scored: bool,
}
impl GetFieldGoalModelResultOutputs {
    pub fn new(scored: bool) -> Self {
        Self { scored }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "scored" => Some(Box::new(self.scored.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "scored" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.scored = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn get_field_goal_model_result(state: &State) -> GetFieldGoalModelResultOutputs {
    log::info!("{}", "[GetFieldGoalModelResult] Run field goal model");
    let model: GetFieldGoalModelResultInferOutputs0 = infer::<GetFieldGoalModelResultInferOutputs0>(
        "field_goal".to_string(),
        vec![
            (calculate_dist_to_try_line(state)) as f64,
            ((CENTRE_OF_THE_FIELD_Y - state.ball_location.y).abs()) as f64,
        ],
    );
    log::info!("{}", "[GetFieldGoalModelResult] Return result");
    return GetFieldGoalModelResultOutputs::new(sample(model.probabilities, random()) == 1);
}
