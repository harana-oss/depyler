use std::collections::HashMap;
use std::f64 as math;
#[derive(Debug, Clone)]
pub struct ZeroDivisionError {
    message: String,
}
impl std::fmt::Display for ZeroDivisionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "division by zero: {}", self.message)
    }
}
impl std::error::Error for ZeroDivisionError {}
impl ZeroDivisionError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub fn calculate_player_of_match_distributions(state: &State) -> Vec<f64> {
    let players = state.all_players;
    let home_score = state.home_match_score;
    let away_score = state.away_match_score;
    let margin = home_score - away_score;
    let total_points = home_score + away_score;
    return players
        .iter()
        .cloned()
        .map(|player| _calculate_percentage_chance(&player, margin, total_points))
        .collect::<Vec<_>>();
}
pub fn _calculate_percentage_chance(player: &Player, margin: i32, total_points: i32) -> f64 {
    let margin_factor = _calculate_margin_factor(&player.delta_strength, margin);
    let match_stats = player.total_statistics;
    let match_tries = match_stats.scores.tries;
    let match_score = match_stats.scores.total;
    let pom_percentage = player.player_of_the_match_percentage;
    let team_won = _team_won(player, margin);
    let pom_factor = _calculate_pom_chance(
        &player.tries_strength,
        match_tries,
        match_score,
        pom_percentage,
        team_won,
    );
    let total_factor = _calculate_total_factor(&player.total_strength, total_points);
    return margin_factor * pom_factor * total_factor + 0.5 * pom_percentage;
}
pub fn _calculate_margin_factor(strength: &Strength, margin: i32) -> f64 {
    let _cse_temp_0 = margin.abs();
    let abs_margin = _cse_temp_0;
    if strength.clone() == Strength.Low {
        return f64::max(2.5 - (abs_margin as f64) / 10.0, 0.5);
    }
    if *strength == Strength.High {
        return f64::min(0.5 * ((abs_margin) as f64) / 10.0, 2.5);
    }
    return 1.0;
}
pub fn _calculate_total_factor(strength: &Strength, total_points: i32) -> f64 {
    if strength.clone() == Strength.Low {
        return f64::max(
            3.0 - (0.175 * ((total_points) as f64) / 10.0 as f64).exp(),
            0.1,
        );
    }
    if *strength == Strength.High {
        return (0.175 * ((total_points) as f64) / 9.9 as f64).exp() - 1.0;
    }
    return 1.0;
}
pub fn _calculate_pom_chance(
    tries_strength: &Strength,
    match_tries: i32,
    match_score: i32,
    pom_percentage: f64,
    team_won: bool,
) -> f64 {
    let try_factor = _calculate_try_factor(tries_strength, match_tries);
    let win_factor = if team_won { 500 } else { 0 };
    let _cse_temp_0 = match_score - match_tries * 4;
    let points_scored = _cse_temp_0;
    let _cse_temp_1 = 0.3357 * ((points_scored) as f64) - 1.75;
    let _cse_temp_2 = f64::max(1.0, _cse_temp_1);
    let points_factor = _cse_temp_2;
    let _cse_temp_3 = pom_percentage + pom_percentage * ((win_factor) as f64);
    let _cse_temp_4 = _cse_temp_3 + try_factor * points_factor;
    let pom_weight = _cse_temp_4;
    return f64::max(pom_weight, (MIN_POM_WEIGHT) as f64);
}
pub fn _calculate_try_factor(strength: &Strength, tries: i32) -> f64 {
    let _cse_temp_0 = {
        let mut map = HashMap::new();
        map.insert(Strength.Low, 1.0);
        map.insert(Strength.Mid, 3.0);
        map.insert(Strength.High, 10.0);
        map
    }
    .get(&strength)
    .cloned()
    .unwrap_or(3.0);
    let coefficient = _cse_temp_0;
    if tries <= 0 {
        return 0.0;
    }
    return (coefficient * (tries as f64).powf(4.5 as f64) as f64) / 2.0;
}
pub fn _team_won(player: &Player, margin: i32) -> bool {
    let is_home = player.is_home_team;
    if margin == 0 {
        return false;
    }
    return if is_home { margin > 0 } else { margin < 0 };
}
