#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct PlayerInterchangeInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl PlayerInterchangeInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlayerInterchangeOutputs {
    pub executed: bool,
    pub off_player_index: i32,
    pub on_player_index: i32,
    pub team: Team,
}
impl PlayerInterchangeOutputs {
    pub fn new(executed: bool, off_player_index: i32, on_player_index: i32, team: Team) -> Self {
        Self {
            executed,
            off_player_index,
            on_player_index,
            team,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "executed" => Some(Box::new(self.executed.clone()) as Box<dyn std::any::Any>),
            "off_player_index" => {
                Some(Box::new(self.off_player_index.clone()) as Box<dyn std::any::Any>)
            }
            "on_player_index" => {
                Some(Box::new(self.on_player_index.clone()) as Box<dyn std::any::Any>)
            }
            "team" => Some(Box::new(self.team.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "executed" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.executed = v.clone();
                    true
                } else {
                    false
                }
            }
            "off_player_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.off_player_index = v.clone();
                    true
                } else {
                    false
                }
            }
            "on_player_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.on_player_index = v.clone();
                    true
                } else {
                    false
                }
            }
            "team" => {
                if let Some(v) = value.downcast_ref::<Team>() {
                    self.team = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn player_interchange(state: &State, team: &Team) -> PlayerInterchangeOutputs {
    log::info!("{}", "[PlayerInterchange] Run player interchange model");
    let model: PlayerInterchangeInferOutputs0 = infer::<PlayerInterchangeInferOutputs0>(
        "player_interchange".to_string(),
        vec![
            (state.time_elapsed) as f64,
            (get_time_on_field_for_position(state.clone(), team, PlayerPosition.FullBack)) as f64,
            (get_time_on_field_for_position(state, team, PlayerPosition.WingerOne)) as f64,
            (get_time_on_field_for_position(state, team, PlayerPosition.CentreOne)) as f64,
            (get_time_on_field_for_position(state, team, PlayerPosition.CentreTwo)) as f64,
            (get_time_on_field_for_position(state, team, PlayerPosition.WingerTwo)) as f64,
            (get_time_on_field_for_position(state, team, PlayerPosition.FiveEighth)) as f64,
            (get_time_on_field_for_position(state, team, PlayerPosition.HalfBack)) as f64,
            (get_time_on_field_for_position(state, team, PlayerPosition.PropOne)) as f64,
            (get_time_on_field_for_position(state, team, PlayerPosition.Hooker)) as f64,
            (get_time_on_field_for_position(state, team, PlayerPosition.PropTwo)) as f64,
            (get_time_on_field_for_position(state, team, PlayerPosition.SecondRowOne)) as f64,
            (get_time_on_field_for_position(state, team, PlayerPosition.SecondRowTwo)) as f64,
            (get_time_on_field_for_position(state, team, PlayerPosition.Lock)) as f64,
            (state.set) as f64,
            (get_team_margin(state, team)) as f64,
        ],
    );
    log::info!("{}", "[PlayerInterchange] Return interchange position");
    return PlayerInterchangeOutputs::new(true, -1, -1, team.clone().clone());
}
