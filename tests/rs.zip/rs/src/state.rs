#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[doc = "// NOTE: Map Python module 'enum'()"]
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum GameStatus {
    #[default]
    Abandoned = 0,
    AwaitingExtraTime = 1,
    Delayed = 2,
    Ended = 3,
    ExtraTime = 4,
    HalfTime = 5,
    Interrupted = 6,
    NotStarted = 7,
    Period1 = 8,
    Period2 = 9,
    Postponed = 10,
    UnknownStatus = 11,
}
impl GameStatus {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::Abandoned),
            1 => Some(Self::AwaitingExtraTime),
            2 => Some(Self::Delayed),
            3 => Some(Self::Ended),
            4 => Some(Self::ExtraTime),
            5 => Some(Self::HalfTime),
            6 => Some(Self::Interrupted),
            7 => Some(Self::NotStarted),
            8 => Some(Self::Period1),
            9 => Some(Self::Period2),
            10 => Some(Self::Postponed),
            11 => Some(Self::UnknownStatus),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::Abandoned)
    }
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Strength {
    #[default]
    Low = 0,
    Mid = 1,
    High = 2,
}
impl Strength {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::Low),
            1 => Some(Self::Mid),
            2 => Some(Self::High),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::Low)
    }
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum ScoreType {
    #[default]
    NotSet = 0,
    Try = 1,
    Conversion = 2,
    PenaltyGoal = 3,
    FieldGoal = 4,
}
impl ScoreType {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::NotSet),
            1 => Some(Self::Try),
            2 => Some(Self::Conversion),
            3 => Some(Self::PenaltyGoal),
            4 => Some(Self::FieldGoal),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::NotSet)
    }
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Play {
    #[default]
    NotSet = 0,
    KickRetain = 1,
    KickRetainTackle = 2,
    KickTurnover = 3,
    KickRetainTry = 4,
    Pass = 5,
    Run = 6,
    RunTackle = 7,
    RunTry = 8,
    WonPenalty = 9,
    ConcededPenalty = 10,
    ErrorAttack = 11,
    ErrorDefence = 12,
    LineDropout = 13,
}
impl Play {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::NotSet),
            1 => Some(Self::KickRetain),
            2 => Some(Self::KickRetainTackle),
            3 => Some(Self::KickTurnover),
            4 => Some(Self::KickRetainTry),
            5 => Some(Self::Pass),
            6 => Some(Self::Run),
            7 => Some(Self::RunTackle),
            8 => Some(Self::RunTry),
            9 => Some(Self::WonPenalty),
            10 => Some(Self::ConcededPenalty),
            11 => Some(Self::ErrorAttack),
            12 => Some(Self::ErrorDefence),
            13 => Some(Self::LineDropout),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::NotSet)
    }
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum PeriodName {
    #[default]
    NotSet = 0,
    FirstHalf = 1,
    SecondHalf = 2,
    ExtraTime = 3,
}
impl PeriodName {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::NotSet),
            1 => Some(Self::FirstHalf),
            2 => Some(Self::SecondHalf),
            3 => Some(Self::ExtraTime),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::NotSet)
    }
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum PlayerPosition {
    #[default]
    NotSet = 0,
    FullBack = 1,
    WingerOne = 2,
    CentreOne = 3,
    CentreTwo = 4,
    WingerTwo = 5,
    FiveEighth = 6,
    HalfBack = 7,
    PropOne = 8,
    Hooker = 9,
    PropTwo = 10,
    SecondRowOne = 11,
    SecondRowTwo = 12,
    Lock = 13,
    Interchange = 14,
}
impl PlayerPosition {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::NotSet),
            1 => Some(Self::FullBack),
            2 => Some(Self::WingerOne),
            3 => Some(Self::CentreOne),
            4 => Some(Self::CentreTwo),
            5 => Some(Self::WingerTwo),
            6 => Some(Self::FiveEighth),
            7 => Some(Self::HalfBack),
            8 => Some(Self::PropOne),
            9 => Some(Self::Hooker),
            10 => Some(Self::PropTwo),
            11 => Some(Self::SecondRowOne),
            12 => Some(Self::SecondRowTwo),
            13 => Some(Self::Lock),
            14 => Some(Self::Interchange),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::NotSet)
    }
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Team {
    #[default]
    NotSet = 0,
    Home = 1,
    Away = 2,
}
impl Team {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::NotSet),
            1 => Some(Self::Home),
            2 => Some(Self::Away),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::NotSet)
    }
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum SinBinStatus {
    #[default]
    NotSet = 0,
    YellowCard = 1,
    RedCard = 2,
}
impl SinBinStatus {
    pub fn from_i32(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::NotSet),
            1 => Some(Self::YellowCard),
            2 => Some(Self::RedCard),
            _ => None,
        }
    }
    pub fn from_i32_or_default(value: i32) -> Self {
        Self::from_i32(value).unwrap_or(Self::NotSet)
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct State {
    pub all_players: Vec<Player>,
    pub away_match_score: i32,
    pub away_period_try_scorers: Vec<Vec<i32>>,
    pub away_player_selected_for_points_market: Player,
    pub away_players_trader_state: Vec<Player>,
    pub away_players: Vec<Player>,
    pub away_remaining_interchanges: i32,
    pub away_sin_bin: Vec<Player>,
    pub away_statistics: TeamStatistics,
    pub away_total_try_scorers: Vec<i32>,
    pub ball_location: FieldPosition,
    pub current_play: Play,
    pub end_zone_type: String,
    pub executed_events: i32,
    pub has_started: bool,
    pub is_extratime: bool,
    pub game_status: GameStatus,
    pub home_match_score: i32,
    pub home_period_try_scorers: Vec<Vec<i32>>,
    pub home_player_selected_for_points_market: Player,
    pub home_players_trader_state: Vec<Player>,
    pub home_players: Vec<Player>,
    pub home_remaining_interchanges: i32,
    pub home_sin_bin: Vec<Player>,
    pub home_statistics: TeamStatistics,
    pub home_total_try_scorers: Vec<i32>,
    pub incidents: Vec<Incident>,
    pub include_players: bool,
    pub is_in_end_zone: bool,
    pub is_over: bool,
    pub period_try_scorers: Vec<Vec<i32>>,
    pub period: Period,
    pub player_of_the_match: i32,
    pub previous_ball_location: FieldPosition,
    pub previous_play: Play,
    pub set: i32,
    pub simulation_invariants: SimulationInvariants,
    pub tackles: i32,
    pub team_in_possession: Team,
    pub three_unanswered_tries_team: Team,
    pub time_elapsed: i32,
    pub total_match_score: i32,
    pub total_period: String,
    pub total_try_scorers: Vec<i32>,
}
impl State {
    pub fn new(
        all_players: Vec<Player>,
        away_match_score: i32,
        away_period_try_scorers: Vec<Vec<i32>>,
        away_player_selected_for_points_market: Player,
        away_players_trader_state: Vec<Player>,
        away_players: Vec<Player>,
        away_remaining_interchanges: i32,
        away_sin_bin: Vec<Player>,
        away_statistics: TeamStatistics,
        away_total_try_scorers: Vec<i32>,
        ball_location: FieldPosition,
        current_play: Play,
        end_zone_type: String,
        has_started: bool,
        is_extratime: bool,
        game_status: GameStatus,
        home_match_score: i32,
        home_period_try_scorers: Vec<Vec<i32>>,
        home_player_selected_for_points_market: Player,
        home_players_trader_state: Vec<Player>,
        home_players: Vec<Player>,
        home_remaining_interchanges: i32,
        home_sin_bin: Vec<Player>,
        home_statistics: TeamStatistics,
        home_total_try_scorers: Vec<i32>,
        incidents: Vec<Incident>,
        include_players: bool,
        is_in_end_zone: bool,
        is_over: bool,
        period_try_scorers: Vec<Vec<i32>>,
        period: Period,
        player_of_the_match: i32,
        previous_ball_location: FieldPosition,
        previous_play: Play,
        set: i32,
        simulation_invariants: SimulationInvariants,
        tackles: i32,
        team_in_possession: Team,
        three_unanswered_tries_team: Team,
        time_elapsed: i32,
        total_match_score: i32,
        total_period: String,
        total_try_scorers: Vec<i32>,
    ) -> Self {
        Self {
            all_players,
            away_match_score,
            away_period_try_scorers,
            away_player_selected_for_points_market,
            away_players_trader_state,
            away_players,
            away_remaining_interchanges,
            away_sin_bin,
            away_statistics,
            away_total_try_scorers,
            ball_location,
            current_play,
            end_zone_type,
            executed_events: 0,
            has_started,
            is_extratime,
            game_status,
            home_match_score,
            home_period_try_scorers,
            home_player_selected_for_points_market,
            home_players_trader_state,
            home_players,
            home_remaining_interchanges,
            home_sin_bin,
            home_statistics,
            home_total_try_scorers,
            incidents,
            include_players,
            is_in_end_zone,
            is_over,
            period_try_scorers,
            period,
            player_of_the_match,
            previous_ball_location,
            previous_play,
            set,
            simulation_invariants,
            tackles,
            team_in_possession,
            three_unanswered_tries_team,
            time_elapsed,
            total_match_score,
            total_period,
            total_try_scorers,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "all_players" => Some(Box::new(self.all_players.clone()) as Box<dyn std::any::Any>),
            "away_match_score" => {
                Some(Box::new(self.away_match_score.clone()) as Box<dyn std::any::Any>)
            }
            "away_period_try_scorers" => {
                Some(Box::new(self.away_period_try_scorers.clone()) as Box<dyn std::any::Any>)
            }
            "away_player_selected_for_points_market" => Some(Box::new(
                self.away_player_selected_for_points_market.clone(),
            )
                as Box<dyn std::any::Any>),
            "away_players_trader_state" => {
                Some(Box::new(self.away_players_trader_state.clone()) as Box<dyn std::any::Any>)
            }
            "away_players" => Some(Box::new(self.away_players.clone()) as Box<dyn std::any::Any>),
            "away_remaining_interchanges" => {
                Some(Box::new(self.away_remaining_interchanges.clone()) as Box<dyn std::any::Any>)
            }
            "away_sin_bin" => Some(Box::new(self.away_sin_bin.clone()) as Box<dyn std::any::Any>),
            "away_statistics" => {
                Some(Box::new(self.away_statistics.clone()) as Box<dyn std::any::Any>)
            }
            "away_total_try_scorers" => {
                Some(Box::new(self.away_total_try_scorers.clone()) as Box<dyn std::any::Any>)
            }
            "ball_location" => Some(Box::new(self.ball_location.clone()) as Box<dyn std::any::Any>),
            "current_play" => Some(Box::new(self.current_play.clone()) as Box<dyn std::any::Any>),
            "end_zone_type" => Some(Box::new(self.end_zone_type.clone()) as Box<dyn std::any::Any>),
            "executed_events" => {
                Some(Box::new(self.executed_events.clone()) as Box<dyn std::any::Any>)
            }
            "has_started" => Some(Box::new(self.has_started.clone()) as Box<dyn std::any::Any>),
            "is_extratime" => Some(Box::new(self.is_extratime.clone()) as Box<dyn std::any::Any>),
            "game_status" => Some(Box::new(self.game_status.clone()) as Box<dyn std::any::Any>),
            "home_match_score" => {
                Some(Box::new(self.home_match_score.clone()) as Box<dyn std::any::Any>)
            }
            "home_period_try_scorers" => {
                Some(Box::new(self.home_period_try_scorers.clone()) as Box<dyn std::any::Any>)
            }
            "home_player_selected_for_points_market" => Some(Box::new(
                self.home_player_selected_for_points_market.clone(),
            )
                as Box<dyn std::any::Any>),
            "home_players_trader_state" => {
                Some(Box::new(self.home_players_trader_state.clone()) as Box<dyn std::any::Any>)
            }
            "home_players" => Some(Box::new(self.home_players.clone()) as Box<dyn std::any::Any>),
            "home_remaining_interchanges" => {
                Some(Box::new(self.home_remaining_interchanges.clone()) as Box<dyn std::any::Any>)
            }
            "home_sin_bin" => Some(Box::new(self.home_sin_bin.clone()) as Box<dyn std::any::Any>),
            "home_statistics" => {
                Some(Box::new(self.home_statistics.clone()) as Box<dyn std::any::Any>)
            }
            "home_total_try_scorers" => {
                Some(Box::new(self.home_total_try_scorers.clone()) as Box<dyn std::any::Any>)
            }
            "incidents" => Some(Box::new(self.incidents.clone()) as Box<dyn std::any::Any>),
            "include_players" => {
                Some(Box::new(self.include_players.clone()) as Box<dyn std::any::Any>)
            }
            "is_in_end_zone" => {
                Some(Box::new(self.is_in_end_zone.clone()) as Box<dyn std::any::Any>)
            }
            "is_over" => Some(Box::new(self.is_over.clone()) as Box<dyn std::any::Any>),
            "period_try_scorers" => {
                Some(Box::new(self.period_try_scorers.clone()) as Box<dyn std::any::Any>)
            }
            "period" => Some(Box::new(self.period.clone()) as Box<dyn std::any::Any>),
            "player_of_the_match" => {
                Some(Box::new(self.player_of_the_match.clone()) as Box<dyn std::any::Any>)
            }
            "previous_ball_location" => {
                Some(Box::new(self.previous_ball_location.clone()) as Box<dyn std::any::Any>)
            }
            "previous_play" => Some(Box::new(self.previous_play.clone()) as Box<dyn std::any::Any>),
            "set" => Some(Box::new(self.set.clone()) as Box<dyn std::any::Any>),
            "simulation_invariants" => {
                Some(Box::new(self.simulation_invariants.clone()) as Box<dyn std::any::Any>)
            }
            "tackles" => Some(Box::new(self.tackles.clone()) as Box<dyn std::any::Any>),
            "team_in_possession" => {
                Some(Box::new(self.team_in_possession.clone()) as Box<dyn std::any::Any>)
            }
            "three_unanswered_tries_team" => {
                Some(Box::new(self.three_unanswered_tries_team.clone()) as Box<dyn std::any::Any>)
            }
            "time_elapsed" => Some(Box::new(self.time_elapsed.clone()) as Box<dyn std::any::Any>),
            "total_match_score" => {
                Some(Box::new(self.total_match_score.clone()) as Box<dyn std::any::Any>)
            }
            "total_period" => Some(Box::new(self.total_period.clone()) as Box<dyn std::any::Any>),
            "total_try_scorers" => {
                Some(Box::new(self.total_try_scorers.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "all_players" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.all_players = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_match_score" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.away_match_score = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_period_try_scorers" => {
                if let Some(v) = value.downcast_ref::<Vec<Vec<i32>>>() {
                    self.away_period_try_scorers = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_player_selected_for_points_market" => {
                if let Some(v) = value.downcast_ref::<Player>() {
                    self.away_player_selected_for_points_market = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_players_trader_state" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.away_players_trader_state = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_players" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.away_players = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_remaining_interchanges" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.away_remaining_interchanges = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_sin_bin" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.away_sin_bin = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_statistics" => {
                if let Some(v) = value.downcast_ref::<TeamStatistics>() {
                    self.away_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_total_try_scorers" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.away_total_try_scorers = v.clone();
                    true
                } else {
                    false
                }
            }
            "ball_location" => {
                if let Some(v) = value.downcast_ref::<FieldPosition>() {
                    self.ball_location = v.clone();
                    true
                } else {
                    false
                }
            }
            "current_play" => {
                if let Some(v) = value.downcast_ref::<Play>() {
                    self.current_play = v.clone();
                    true
                } else {
                    false
                }
            }
            "end_zone_type" => {
                if let Some(v) = value.downcast_ref::<String>() {
                    self.end_zone_type = v.clone();
                    true
                } else {
                    false
                }
            }
            "executed_events" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.executed_events = v.clone();
                    true
                } else {
                    false
                }
            }
            "has_started" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.has_started = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_extratime" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_extratime = v.clone();
                    true
                } else {
                    false
                }
            }
            "game_status" => {
                if let Some(v) = value.downcast_ref::<GameStatus>() {
                    self.game_status = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_match_score" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.home_match_score = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_period_try_scorers" => {
                if let Some(v) = value.downcast_ref::<Vec<Vec<i32>>>() {
                    self.home_period_try_scorers = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_player_selected_for_points_market" => {
                if let Some(v) = value.downcast_ref::<Player>() {
                    self.home_player_selected_for_points_market = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_players_trader_state" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.home_players_trader_state = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_players" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.home_players = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_remaining_interchanges" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.home_remaining_interchanges = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_sin_bin" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.home_sin_bin = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_statistics" => {
                if let Some(v) = value.downcast_ref::<TeamStatistics>() {
                    self.home_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_total_try_scorers" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.home_total_try_scorers = v.clone();
                    true
                } else {
                    false
                }
            }
            "incidents" => {
                if let Some(v) = value.downcast_ref::<Vec<Incident>>() {
                    self.incidents = v.clone();
                    true
                } else {
                    false
                }
            }
            "include_players" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.include_players = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_in_end_zone" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_in_end_zone = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_over" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_over = v.clone();
                    true
                } else {
                    false
                }
            }
            "period_try_scorers" => {
                if let Some(v) = value.downcast_ref::<Vec<Vec<i32>>>() {
                    self.period_try_scorers = v.clone();
                    true
                } else {
                    false
                }
            }
            "period" => {
                if let Some(v) = value.downcast_ref::<Period>() {
                    self.period = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_of_the_match" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.player_of_the_match = v.clone();
                    true
                } else {
                    false
                }
            }
            "previous_ball_location" => {
                if let Some(v) = value.downcast_ref::<FieldPosition>() {
                    self.previous_ball_location = v.clone();
                    true
                } else {
                    false
                }
            }
            "previous_play" => {
                if let Some(v) = value.downcast_ref::<Play>() {
                    self.previous_play = v.clone();
                    true
                } else {
                    false
                }
            }
            "set" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.set = v.clone();
                    true
                } else {
                    false
                }
            }
            "simulation_invariants" => {
                if let Some(v) = value.downcast_ref::<SimulationInvariants>() {
                    self.simulation_invariants = v.clone();
                    true
                } else {
                    false
                }
            }
            "tackles" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.tackles = v.clone();
                    true
                } else {
                    false
                }
            }
            "team_in_possession" => {
                if let Some(v) = value.downcast_ref::<Team>() {
                    self.team_in_possession = v.clone();
                    true
                } else {
                    false
                }
            }
            "three_unanswered_tries_team" => {
                if let Some(v) = value.downcast_ref::<Team>() {
                    self.three_unanswered_tries_team = v.clone();
                    true
                } else {
                    false
                }
            }
            "time_elapsed" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.time_elapsed = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_match_score" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.total_match_score = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_period" => {
                if let Some(v) = value.downcast_ref::<String>() {
                    self.total_period = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_try_scorers" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.total_try_scorers = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct FieldPosition {
    pub x: i32,
    pub y: i32,
}
impl FieldPosition {
    pub fn new(x: i32, y: i32) -> Self {
        Self { x, y }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "x" => Some(Box::new(self.x.clone()) as Box<dyn std::any::Any>),
            "y" => Some(Box::new(self.y.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "x" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.x = v.clone();
                    true
                } else {
                    false
                }
            }
            "y" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.y = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Incident {
    pub has_points_confirmed: bool,
    pub has_points_scored: bool,
    pub period: Period,
    pub points_confirmed_player_index: i32,
    pub points_confirmed_score_id: String,
    pub points_confirmed_score_type: ScoreType,
    pub points_scored_points: i32,
    pub points_scored_score_id: String,
    pub points_scored_score_type: ScoreType,
    pub points_scored_team: Team,
    pub time_elapsed: i32,
}
impl Incident {
    pub fn new(
        has_points_confirmed: bool,
        has_points_scored: bool,
        period: Period,
        points_confirmed_player_index: i32,
        points_confirmed_score_id: String,
        points_confirmed_score_type: ScoreType,
        points_scored_points: i32,
        points_scored_score_id: String,
        points_scored_score_type: ScoreType,
        points_scored_team: Team,
        time_elapsed: i32,
    ) -> Self {
        Self {
            has_points_confirmed,
            has_points_scored,
            period,
            points_confirmed_player_index,
            points_confirmed_score_id,
            points_confirmed_score_type,
            points_scored_points,
            points_scored_score_id,
            points_scored_score_type,
            points_scored_team,
            time_elapsed,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "has_points_confirmed" => {
                Some(Box::new(self.has_points_confirmed.clone()) as Box<dyn std::any::Any>)
            }
            "has_points_scored" => {
                Some(Box::new(self.has_points_scored.clone()) as Box<dyn std::any::Any>)
            }
            "period" => Some(Box::new(self.period.clone()) as Box<dyn std::any::Any>),
            "points_confirmed_player_index" => {
                Some(Box::new(self.points_confirmed_player_index.clone()) as Box<dyn std::any::Any>)
            }
            "points_confirmed_score_id" => {
                Some(Box::new(self.points_confirmed_score_id.clone()) as Box<dyn std::any::Any>)
            }
            "points_confirmed_score_type" => {
                Some(Box::new(self.points_confirmed_score_type.clone()) as Box<dyn std::any::Any>)
            }
            "points_scored_points" => {
                Some(Box::new(self.points_scored_points.clone()) as Box<dyn std::any::Any>)
            }
            "points_scored_score_id" => {
                Some(Box::new(self.points_scored_score_id.clone()) as Box<dyn std::any::Any>)
            }
            "points_scored_score_type" => {
                Some(Box::new(self.points_scored_score_type.clone()) as Box<dyn std::any::Any>)
            }
            "points_scored_team" => {
                Some(Box::new(self.points_scored_team.clone()) as Box<dyn std::any::Any>)
            }
            "time_elapsed" => Some(Box::new(self.time_elapsed.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "has_points_confirmed" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.has_points_confirmed = v.clone();
                    true
                } else {
                    false
                }
            }
            "has_points_scored" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.has_points_scored = v.clone();
                    true
                } else {
                    false
                }
            }
            "period" => {
                if let Some(v) = value.downcast_ref::<Period>() {
                    self.period = v.clone();
                    true
                } else {
                    false
                }
            }
            "points_confirmed_player_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.points_confirmed_player_index = v.clone();
                    true
                } else {
                    false
                }
            }
            "points_confirmed_score_id" => {
                if let Some(v) = value.downcast_ref::<String>() {
                    self.points_confirmed_score_id = v.clone();
                    true
                } else {
                    false
                }
            }
            "points_confirmed_score_type" => {
                if let Some(v) = value.downcast_ref::<ScoreType>() {
                    self.points_confirmed_score_type = v.clone();
                    true
                } else {
                    false
                }
            }
            "points_scored_points" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.points_scored_points = v.clone();
                    true
                } else {
                    false
                }
            }
            "points_scored_score_id" => {
                if let Some(v) = value.downcast_ref::<String>() {
                    self.points_scored_score_id = v.clone();
                    true
                } else {
                    false
                }
            }
            "points_scored_score_type" => {
                if let Some(v) = value.downcast_ref::<ScoreType>() {
                    self.points_scored_score_type = v.clone();
                    true
                } else {
                    false
                }
            }
            "points_scored_team" => {
                if let Some(v) = value.downcast_ref::<Team>() {
                    self.points_scored_team = v.clone();
                    true
                } else {
                    false
                }
            }
            "time_elapsed" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.time_elapsed = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Period {
    pub number: i32,
    pub name: PeriodName,
}
impl Period {
    pub fn new(number: i32, name: PeriodName) -> Self {
        Self { number, name }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "number" => Some(Box::new(self.number.clone()) as Box<dyn std::any::Any>),
            "name" => Some(Box::new(self.name.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "number" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.number = v.clone();
                    true
                } else {
                    false
                }
            }
            "name" => {
                if let Some(v) = value.downcast_ref::<PeriodName>() {
                    self.name = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Player {
    pub delta_strength: Strength,
    pub expected_tries_per_min: f64,
    pub is_home_team: bool,
    pub is_injured: bool,
    pub is_interchange: bool,
    pub is_starter: bool,
    pub is_suspended: bool,
    pub is_voided: bool,
    pub jersey_number: i32,
    pub on_field: bool,
    pub period_statistics: Vec<PlayerStatistics>,
    pub player_index: i32,
    pub player_of_the_match_percentage: f64,
    pub position: PlayerPosition,
    pub return_from_sin_bin_time: i32,
    pub selected_for_points_market: bool,
    pub sin_bin_sent_off: i32,
    pub sin_bin_status: SinBinStatus,
    pub total_statistics: PlayerStatistics,
    pub total_strength: Strength,
    pub tries_per_minute_in_use: bool,
    pub tries_per_minute: f64,
    pub tries_percentage_in_use: bool,
    pub tries_percentage: f64,
    pub tries_strength: Strength,
}
impl Player {
    pub fn new(
        delta_strength: Strength,
        expected_tries_per_min: f64,
        is_home_team: bool,
        is_injured: bool,
        is_interchange: bool,
        is_starter: bool,
        is_suspended: bool,
        is_voided: bool,
        jersey_number: i32,
        on_field: bool,
        period_statistics: Vec<PlayerStatistics>,
        player_index: i32,
        player_of_the_match_percentage: f64,
        position: PlayerPosition,
        return_from_sin_bin_time: i32,
        selected_for_points_market: bool,
        sin_bin_sent_off: i32,
        sin_bin_status: SinBinStatus,
        total_statistics: PlayerStatistics,
        total_strength: Strength,
        tries_per_minute_in_use: bool,
        tries_per_minute: f64,
        tries_percentage_in_use: bool,
        tries_percentage: f64,
        tries_strength: Strength,
    ) -> Self {
        Self {
            delta_strength,
            expected_tries_per_min,
            is_home_team,
            is_injured,
            is_interchange,
            is_starter,
            is_suspended,
            is_voided,
            jersey_number,
            on_field,
            period_statistics,
            player_index,
            player_of_the_match_percentage,
            position,
            return_from_sin_bin_time,
            selected_for_points_market,
            sin_bin_sent_off,
            sin_bin_status,
            total_statistics,
            total_strength,
            tries_per_minute_in_use,
            tries_per_minute,
            tries_percentage_in_use,
            tries_percentage,
            tries_strength,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "delta_strength" => {
                Some(Box::new(self.delta_strength.clone()) as Box<dyn std::any::Any>)
            }
            "expected_tries_per_min" => {
                Some(Box::new(self.expected_tries_per_min.clone()) as Box<dyn std::any::Any>)
            }
            "is_home_team" => Some(Box::new(self.is_home_team.clone()) as Box<dyn std::any::Any>),
            "is_injured" => Some(Box::new(self.is_injured.clone()) as Box<dyn std::any::Any>),
            "is_interchange" => {
                Some(Box::new(self.is_interchange.clone()) as Box<dyn std::any::Any>)
            }
            "is_starter" => Some(Box::new(self.is_starter.clone()) as Box<dyn std::any::Any>),
            "is_suspended" => Some(Box::new(self.is_suspended.clone()) as Box<dyn std::any::Any>),
            "is_voided" => Some(Box::new(self.is_voided.clone()) as Box<dyn std::any::Any>),
            "jersey_number" => Some(Box::new(self.jersey_number.clone()) as Box<dyn std::any::Any>),
            "on_field" => Some(Box::new(self.on_field.clone()) as Box<dyn std::any::Any>),
            "period_statistics" => {
                Some(Box::new(self.period_statistics.clone()) as Box<dyn std::any::Any>)
            }
            "player_index" => Some(Box::new(self.player_index.clone()) as Box<dyn std::any::Any>),
            "player_of_the_match_percentage" => {
                Some(Box::new(self.player_of_the_match_percentage.clone()) as Box<dyn std::any::Any>)
            }
            "position" => Some(Box::new(self.position.clone()) as Box<dyn std::any::Any>),
            "return_from_sin_bin_time" => {
                Some(Box::new(self.return_from_sin_bin_time.clone()) as Box<dyn std::any::Any>)
            }
            "selected_for_points_market" => {
                Some(Box::new(self.selected_for_points_market.clone()) as Box<dyn std::any::Any>)
            }
            "sin_bin_sent_off" => {
                Some(Box::new(self.sin_bin_sent_off.clone()) as Box<dyn std::any::Any>)
            }
            "sin_bin_status" => {
                Some(Box::new(self.sin_bin_status.clone()) as Box<dyn std::any::Any>)
            }
            "total_statistics" => {
                Some(Box::new(self.total_statistics.clone()) as Box<dyn std::any::Any>)
            }
            "total_strength" => {
                Some(Box::new(self.total_strength.clone()) as Box<dyn std::any::Any>)
            }
            "tries_per_minute_in_use" => {
                Some(Box::new(self.tries_per_minute_in_use.clone()) as Box<dyn std::any::Any>)
            }
            "tries_per_minute" => {
                Some(Box::new(self.tries_per_minute.clone()) as Box<dyn std::any::Any>)
            }
            "tries_percentage_in_use" => {
                Some(Box::new(self.tries_percentage_in_use.clone()) as Box<dyn std::any::Any>)
            }
            "tries_percentage" => {
                Some(Box::new(self.tries_percentage.clone()) as Box<dyn std::any::Any>)
            }
            "tries_strength" => {
                Some(Box::new(self.tries_strength.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "delta_strength" => {
                if let Some(v) = value.downcast_ref::<Strength>() {
                    self.delta_strength = v.clone();
                    true
                } else {
                    false
                }
            }
            "expected_tries_per_min" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.expected_tries_per_min = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_home_team" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_home_team = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_injured" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_injured = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_interchange" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_interchange = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_starter" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_starter = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_suspended" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_suspended = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_voided" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_voided = v.clone();
                    true
                } else {
                    false
                }
            }
            "jersey_number" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.jersey_number = v.clone();
                    true
                } else {
                    false
                }
            }
            "on_field" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.on_field = v.clone();
                    true
                } else {
                    false
                }
            }
            "period_statistics" => {
                if let Some(v) = value.downcast_ref::<Vec<PlayerStatistics>>() {
                    self.period_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.player_index = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_of_the_match_percentage" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.player_of_the_match_percentage = v.clone();
                    true
                } else {
                    false
                }
            }
            "position" => {
                if let Some(v) = value.downcast_ref::<PlayerPosition>() {
                    self.position = v.clone();
                    true
                } else {
                    false
                }
            }
            "return_from_sin_bin_time" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.return_from_sin_bin_time = v.clone();
                    true
                } else {
                    false
                }
            }
            "selected_for_points_market" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.selected_for_points_market = v.clone();
                    true
                } else {
                    false
                }
            }
            "sin_bin_sent_off" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.sin_bin_sent_off = v.clone();
                    true
                } else {
                    false
                }
            }
            "sin_bin_status" => {
                if let Some(v) = value.downcast_ref::<SinBinStatus>() {
                    self.sin_bin_status = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_statistics" => {
                if let Some(v) = value.downcast_ref::<PlayerStatistics>() {
                    self.total_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_strength" => {
                if let Some(v) = value.downcast_ref::<Strength>() {
                    self.total_strength = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_per_minute_in_use" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.tries_per_minute_in_use = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_per_minute" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.tries_per_minute = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_percentage_in_use" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.tries_percentage_in_use = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_percentage" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.tries_percentage = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_strength" => {
                if let Some(v) = value.downcast_ref::<Strength>() {
                    self.tries_strength = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlayerStatistics {
    pub jersey_number: i32,
    pub metres_gained: i32,
    pub period_statistics: Vec<Statistics>,
    pub player_index: i32,
    pub scores: Scores,
    pub tackles: i32,
    pub time_on_field: f64,
    pub total_statistics: Statistics,
}
impl PlayerStatistics {
    pub fn new(
        jersey_number: i32,
        metres_gained: i32,
        period_statistics: Vec<Statistics>,
        player_index: i32,
        scores: Scores,
        tackles: i32,
        time_on_field: f64,
        total_statistics: Statistics,
    ) -> Self {
        Self {
            jersey_number,
            metres_gained,
            period_statistics,
            player_index,
            scores,
            tackles,
            time_on_field,
            total_statistics,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "jersey_number" => Some(Box::new(self.jersey_number.clone()) as Box<dyn std::any::Any>),
            "metres_gained" => Some(Box::new(self.metres_gained.clone()) as Box<dyn std::any::Any>),
            "period_statistics" => {
                Some(Box::new(self.period_statistics.clone()) as Box<dyn std::any::Any>)
            }
            "player_index" => Some(Box::new(self.player_index.clone()) as Box<dyn std::any::Any>),
            "scores" => Some(Box::new(self.scores.clone()) as Box<dyn std::any::Any>),
            "tackles" => Some(Box::new(self.tackles.clone()) as Box<dyn std::any::Any>),
            "time_on_field" => Some(Box::new(self.time_on_field.clone()) as Box<dyn std::any::Any>),
            "total_statistics" => {
                Some(Box::new(self.total_statistics.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "jersey_number" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.jersey_number = v.clone();
                    true
                } else {
                    false
                }
            }
            "metres_gained" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.metres_gained = v.clone();
                    true
                } else {
                    false
                }
            }
            "period_statistics" => {
                if let Some(v) = value.downcast_ref::<Vec<Statistics>>() {
                    self.period_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.player_index = v.clone();
                    true
                } else {
                    false
                }
            }
            "scores" => {
                if let Some(v) = value.downcast_ref::<Scores>() {
                    self.scores = v.clone();
                    true
                } else {
                    false
                }
            }
            "tackles" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.tackles = v.clone();
                    true
                } else {
                    false
                }
            }
            "time_on_field" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.time_on_field = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_statistics" => {
                if let Some(v) = value.downcast_ref::<Statistics>() {
                    self.total_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Scores {
    pub conversions: i32,
    pub field_goals: i32,
    pub penalties: i32,
    pub total: i32,
    pub tries: i32,
}
impl Scores {
    pub fn new(conversions: i32, field_goals: i32, penalties: i32, total: i32, tries: i32) -> Self {
        Self {
            conversions,
            field_goals,
            penalties,
            total,
            tries,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "conversions" => Some(Box::new(self.conversions.clone()) as Box<dyn std::any::Any>),
            "field_goals" => Some(Box::new(self.field_goals.clone()) as Box<dyn std::any::Any>),
            "penalties" => Some(Box::new(self.penalties.clone()) as Box<dyn std::any::Any>),
            "total" => Some(Box::new(self.total.clone()) as Box<dyn std::any::Any>),
            "tries" => Some(Box::new(self.tries.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "conversions" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.conversions = v.clone();
                    true
                } else {
                    false
                }
            }
            "field_goals" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.field_goals = v.clone();
                    true
                } else {
                    false
                }
            }
            "penalties" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.penalties = v.clone();
                    true
                } else {
                    false
                }
            }
            "total" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.total = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.tries = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Statistics {
    pub conversions_missed: i32,
    pub penalties_awarded: i32,
    pub scores: Scores,
    pub tackles: i32,
    pub turnovers: i32,
}
impl Statistics {
    pub fn new(
        conversions_missed: i32,
        penalties_awarded: i32,
        scores: Scores,
        tackles: i32,
        turnovers: i32,
    ) -> Self {
        Self {
            conversions_missed,
            penalties_awarded,
            scores,
            tackles,
            turnovers,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "conversions_missed" => {
                Some(Box::new(self.conversions_missed.clone()) as Box<dyn std::any::Any>)
            }
            "penalties_awarded" => {
                Some(Box::new(self.penalties_awarded.clone()) as Box<dyn std::any::Any>)
            }
            "scores" => Some(Box::new(self.scores.clone()) as Box<dyn std::any::Any>),
            "tackles" => Some(Box::new(self.tackles.clone()) as Box<dyn std::any::Any>),
            "turnovers" => Some(Box::new(self.turnovers.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "conversions_missed" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.conversions_missed = v.clone();
                    true
                } else {
                    false
                }
            }
            "penalties_awarded" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.penalties_awarded = v.clone();
                    true
                } else {
                    false
                }
            }
            "scores" => {
                if let Some(v) = value.downcast_ref::<Scores>() {
                    self.scores = v.clone();
                    true
                } else {
                    false
                }
            }
            "tackles" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.tackles = v.clone();
                    true
                } else {
                    false
                }
            }
            "turnovers" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.turnovers = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct TeamStatistics {
    pub period_statistics: Vec<Statistics>,
    pub player_statistics: Vec<PlayerStatistics>,
    pub sin_bin_players: Vec<Player>,
    pub total_statistics: Statistics,
}
impl TeamStatistics {
    pub fn new(
        period_statistics: Vec<Statistics>,
        player_statistics: Vec<PlayerStatistics>,
        sin_bin_players: Vec<Player>,
        total_statistics: Statistics,
    ) -> Self {
        Self {
            period_statistics,
            player_statistics,
            sin_bin_players,
            total_statistics,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "period_statistics" => {
                Some(Box::new(self.period_statistics.clone()) as Box<dyn std::any::Any>)
            }
            "player_statistics" => {
                Some(Box::new(self.player_statistics.clone()) as Box<dyn std::any::Any>)
            }
            "sin_bin_players" => {
                Some(Box::new(self.sin_bin_players.clone()) as Box<dyn std::any::Any>)
            }
            "total_statistics" => {
                Some(Box::new(self.total_statistics.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "period_statistics" => {
                if let Some(v) = value.downcast_ref::<Vec<Statistics>>() {
                    self.period_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_statistics" => {
                if let Some(v) = value.downcast_ref::<Vec<PlayerStatistics>>() {
                    self.player_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            "sin_bin_players" => {
                if let Some(v) = value.downcast_ref::<Vec<Player>>() {
                    self.sin_bin_players = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_statistics" => {
                if let Some(v) = value.downcast_ref::<Statistics>() {
                    self.total_statistics = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlayerInvariants {
    pub player_solution: PlayerSolution,
    pub player_trader_state: PlayerTraderState,
}
impl PlayerInvariants {
    pub fn new(player_solution: PlayerSolution, player_trader_state: PlayerTraderState) -> Self {
        Self {
            player_solution,
            player_trader_state,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "player_solution" => {
                Some(Box::new(self.player_solution.clone()) as Box<dyn std::any::Any>)
            }
            "player_trader_state" => {
                Some(Box::new(self.player_trader_state.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "player_solution" => {
                if let Some(v) = value.downcast_ref::<PlayerSolution>() {
                    self.player_solution = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_trader_state" => {
                if let Some(v) = value.downcast_ref::<PlayerTraderState>() {
                    self.player_trader_state = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlayerSolution {
    pub solved_expected_tries_per_min: f64,
    pub solved_expected_tries_percentage: f64,
}
impl PlayerSolution {
    pub fn new(solved_expected_tries_per_min: f64, solved_expected_tries_percentage: f64) -> Self {
        Self {
            solved_expected_tries_per_min,
            solved_expected_tries_percentage,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "solved_expected_tries_per_min" => {
                Some(Box::new(self.solved_expected_tries_per_min.clone()) as Box<dyn std::any::Any>)
            }
            "solved_expected_tries_percentage" => {
                Some(Box::new(self.solved_expected_tries_percentage.clone())
                    as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "solved_expected_tries_per_min" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.solved_expected_tries_per_min = v.clone();
                    true
                } else {
                    false
                }
            }
            "solved_expected_tries_percentage" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.solved_expected_tries_percentage = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct SimulationInvariants {
    pub all_players_invariants: Vec<PlayerInvariants>,
    pub away_handicap: f64,
    pub away_price: f64,
    pub away_team_players_invariants: Vec<PlayerInvariants>,
    pub home_handicap: f64,
    pub home_price: f64,
    pub home_team_player_invariants: Vec<PlayerInvariants>,
    pub include_players: bool,
    pub player_of_the_total_enabled: bool,
    pub total_points: f64,
}
impl SimulationInvariants {
    pub fn new(
        all_players_invariants: Vec<PlayerInvariants>,
        away_handicap: f64,
        away_price: f64,
        away_team_players_invariants: Vec<PlayerInvariants>,
        home_handicap: f64,
        home_price: f64,
        home_team_player_invariants: Vec<PlayerInvariants>,
        include_players: bool,
        player_of_the_total_enabled: bool,
        total_points: f64,
    ) -> Self {
        Self {
            all_players_invariants,
            away_handicap,
            away_price,
            away_team_players_invariants,
            home_handicap,
            home_price,
            home_team_player_invariants,
            include_players,
            player_of_the_total_enabled,
            total_points,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "all_players_invariants" => {
                Some(Box::new(self.all_players_invariants.clone()) as Box<dyn std::any::Any>)
            }
            "away_handicap" => Some(Box::new(self.away_handicap.clone()) as Box<dyn std::any::Any>),
            "away_price" => Some(Box::new(self.away_price.clone()) as Box<dyn std::any::Any>),
            "away_team_players_invariants" => {
                Some(Box::new(self.away_team_players_invariants.clone()) as Box<dyn std::any::Any>)
            }
            "home_handicap" => Some(Box::new(self.home_handicap.clone()) as Box<dyn std::any::Any>),
            "home_price" => Some(Box::new(self.home_price.clone()) as Box<dyn std::any::Any>),
            "home_team_player_invariants" => {
                Some(Box::new(self.home_team_player_invariants.clone()) as Box<dyn std::any::Any>)
            }
            "include_players" => {
                Some(Box::new(self.include_players.clone()) as Box<dyn std::any::Any>)
            }
            "player_of_the_total_enabled" => {
                Some(Box::new(self.player_of_the_total_enabled.clone()) as Box<dyn std::any::Any>)
            }
            "total_points" => Some(Box::new(self.total_points.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "all_players_invariants" => {
                if let Some(v) = value.downcast_ref::<Vec<PlayerInvariants>>() {
                    self.all_players_invariants = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_handicap" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.away_handicap = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_price" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.away_price = v.clone();
                    true
                } else {
                    false
                }
            }
            "away_team_players_invariants" => {
                if let Some(v) = value.downcast_ref::<Vec<PlayerInvariants>>() {
                    self.away_team_players_invariants = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_handicap" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.home_handicap = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_price" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.home_price = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_team_player_invariants" => {
                if let Some(v) = value.downcast_ref::<Vec<PlayerInvariants>>() {
                    self.home_team_player_invariants = v.clone();
                    true
                } else {
                    false
                }
            }
            "include_players" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.include_players = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_of_the_total_enabled" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.player_of_the_total_enabled = v.clone();
                    true
                } else {
                    false
                }
            }
            "total_points" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.total_points = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlayerTraderState {
    pub expected_tries_per_minute: f64,
    pub home_team: bool,
    pub is_injured: bool,
    pub is_interchange: bool,
    pub is_starter: bool,
    pub player_index: i32,
    pub player_of_the_match_percentage: f64,
    pub position: PlayerPosition,
    pub selected_for_points_market: bool,
    pub tries_per_minute_in_use: bool,
    pub tries_percentage_in_use: bool,
    pub tries_percentage: f64,
}
impl PlayerTraderState {
    pub fn new(
        expected_tries_per_minute: f64,
        home_team: bool,
        is_injured: bool,
        is_interchange: bool,
        is_starter: bool,
        player_index: i32,
        player_of_the_match_percentage: f64,
        position: PlayerPosition,
        selected_for_points_market: bool,
        tries_per_minute_in_use: bool,
        tries_percentage_in_use: bool,
        tries_percentage: f64,
    ) -> Self {
        Self {
            expected_tries_per_minute,
            home_team,
            is_injured,
            is_interchange,
            is_starter,
            player_index,
            player_of_the_match_percentage,
            position,
            selected_for_points_market,
            tries_per_minute_in_use,
            tries_percentage_in_use,
            tries_percentage,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "expected_tries_per_minute" => {
                Some(Box::new(self.expected_tries_per_minute.clone()) as Box<dyn std::any::Any>)
            }
            "home_team" => Some(Box::new(self.home_team.clone()) as Box<dyn std::any::Any>),
            "is_injured" => Some(Box::new(self.is_injured.clone()) as Box<dyn std::any::Any>),
            "is_interchange" => {
                Some(Box::new(self.is_interchange.clone()) as Box<dyn std::any::Any>)
            }
            "is_starter" => Some(Box::new(self.is_starter.clone()) as Box<dyn std::any::Any>),
            "player_index" => Some(Box::new(self.player_index.clone()) as Box<dyn std::any::Any>),
            "player_of_the_match_percentage" => {
                Some(Box::new(self.player_of_the_match_percentage.clone()) as Box<dyn std::any::Any>)
            }
            "position" => Some(Box::new(self.position.clone()) as Box<dyn std::any::Any>),
            "selected_for_points_market" => {
                Some(Box::new(self.selected_for_points_market.clone()) as Box<dyn std::any::Any>)
            }
            "tries_per_minute_in_use" => {
                Some(Box::new(self.tries_per_minute_in_use.clone()) as Box<dyn std::any::Any>)
            }
            "tries_percentage_in_use" => {
                Some(Box::new(self.tries_percentage_in_use.clone()) as Box<dyn std::any::Any>)
            }
            "tries_percentage" => {
                Some(Box::new(self.tries_percentage.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "expected_tries_per_minute" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.expected_tries_per_minute = v.clone();
                    true
                } else {
                    false
                }
            }
            "home_team" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.home_team = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_injured" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_injured = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_interchange" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_interchange = v.clone();
                    true
                } else {
                    false
                }
            }
            "is_starter" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.is_starter = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.player_index = v.clone();
                    true
                } else {
                    false
                }
            }
            "player_of_the_match_percentage" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.player_of_the_match_percentage = v.clone();
                    true
                } else {
                    false
                }
            }
            "position" => {
                if let Some(v) = value.downcast_ref::<PlayerPosition>() {
                    self.position = v.clone();
                    true
                } else {
                    false
                }
            }
            "selected_for_points_market" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.selected_for_points_market = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_per_minute_in_use" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.tries_per_minute_in_use = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_percentage_in_use" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.tries_percentage_in_use = v.clone();
                    true
                } else {
                    false
                }
            }
            "tries_percentage" => {
                if let Some(v) = value.downcast_ref::<f64>() {
                    self.tries_percentage = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
