#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn update_game_status(state: &mut State) {
    if true {
        log::info!(
            "{}",
            "[Update Game Status] Check if normal time half is complete"
        );
        let _cse_temp_0 = (state.time_elapsed > HALF_LENGTH_IN_SECONDS)
            && (state.period.name != PeriodName.ExtraTime);
        if _cse_temp_0 {
            log::info!("{}", "[Update Game Status] Handle end of first half");
            if state.period.name == PeriodName.FirstHalf {
                log::info!("{}", "[Update Game Status] Transition to second half");
                state.game_status = GameStatus.Period2;
                state.period.number = 2;
                state.period.name = PeriodName.SecondHalf;
            } else {
                log::info!(
                    "{}",
                    "[Update Game Status] Check if normal time is complete"
                );
                if state.time_elapsed >= GAME_LENGTH_IN_SECONDS {
                    log::info!(
                        "{}",
                        "[Update Game Status] Check for extra time or game end"
                    );
                    if state.home_match_score == state.away_match_score {
                        log::info!("{}", "[Update Game Status] Enter extra time");
                        state.period.name = PeriodName.ExtraTime;
                        state.period.number = 3;
                        state.is_extratime = true;
                        state.game_status = GameStatus.ExtraTime;
                    } else {
                        log::info!("{}", "[Update Game Status] End game");
                        state.is_over = true;
                        state.game_status = GameStatus.Ended;
                    }
                }
            }
        }
        log::info!("{}", "[Update Game Status] Check extra time conditions");
        if state.period.name == PeriodName.ExtraTime {
            log::info!("{}", "[Update Game Status] Check if extra time should end");
            let _cse_temp_1 =
                state.time_elapsed >= GAME_LENGTH_IN_SECONDS + EXTRA_TIME_LENGTH_IN_SECONDS;
            let _cse_temp_2 = (_cse_temp_1) || (state.home_match_score != state.away_match_score);
            if _cse_temp_2 {
                log::info!("{}", "[Update Game Status] End game");
                state.game_status = GameStatus.Ended;
                state.is_over = true;
            }
        }
    }
    return;
}
