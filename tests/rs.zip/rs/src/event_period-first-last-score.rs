#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[derive(Debug, Clone)]
pub struct ZeroDivisionError {
    message: String,
}
impl std::fmt::Display for ZeroDivisionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "division by zero: {}", self.message)
    }
}
impl std::error::Error for ZeroDivisionError {}
impl ZeroDivisionError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub fn period_first_last_score_helper(state: &State) {
    let mut away_first_try_time: i32 = 0;
    let mut first_score_team: Option<Team> = None;
    let mut first_try_team: Option<Team> = None;
    let mut first_try_time: i32 = 0;
    let mut home_first_try_time: i32 = 0;
    let period_filter: bool = false;
    let period_name: String = "".to_string();
    if false {
        log::info!(
            "{}",
            "[Period First Last Score Helper] Find first try in period"
        );
        first_try_team = Some(
            state
                .incidents
                .iter()
                .find(|incident| {
                    period_filter
                        && incident.has_points_confirmed
                        && incident.points_confirmed_score_type == ScoreType.Try
                })
                .cloned()
                .unwrap()
                .points_scored_team,
        );
        log::info!(
            "{}",
            "[Period First Last Score Helper] Find first score in period"
        );
        first_score_team = Some(
            state
                .incidents
                .iter()
                .find(|incident| period_filter && incident.has_points_confirmed)
                .cloned()
                .unwrap()
                .points_scored_team,
        );
        log::info!(
            "{}",
            "[Period First Last Score Helper] Calculate first try times"
        );
        let _cse_temp_0 = {
            let a = state
                .incidents
                .iter()
                .find(|incident| {
                    period_filter
                        && incident.has_points_confirmed
                        && incident.points_confirmed_score_type == ScoreType.Try
                        && incident.points_scored_team == Team.Away
                })
                .cloned()
                .unwrap()
                .time_elapsed;
            let b = 60;
            let q = a / b;
            let r = a % b;
            let r_negative = r < 0;
            let b_negative = b < 0;
            let r_nonzero = r != 0;
            let signs_differ = r_negative != b_negative;
            let needs_adjustment = r_nonzero && signs_differ;
            if needs_adjustment {
                q - 1
            } else {
                q
            }
        } + 1;
        away_first_try_time = _cse_temp_0;
        home_first_try_time = _cse_temp_0;
        first_try_time = _cse_temp_0;
        log::info!(
            "{}",
            "[Period First Last Score Helper] Output first try results"
        );
        record_bool(
            format!("FirstTry{}A", period_name),
            first_try_team.clone().unwrap() == Team.Home,
        );
        record_bool(
            format!("FirstTry{}B", period_name),
            first_try_team.unwrap() == Team.Away,
        );
        log::info!(
            "{}",
            "[Period First Last Score Helper] Output first to score results"
        );
        record_bool(
            format!("FirstToScore{}A", period_name),
            first_score_team.clone().unwrap() == Team.Home,
        );
        record_bool(
            format!("FirstToScore{}B", period_name),
            first_score_team.unwrap() == Team.Away,
        );
        log::info!(
            "{}",
            "[Period First Last Score Helper] Output first try time results"
        );
        record_int(format!("FirstTryTime{}", period_name), first_try_time);
        record_int(format!("FirstTryTime{}A", period_name), home_first_try_time);
        record_int(format!("FirstTryTime{}B", period_name), away_first_try_time);
    }
    return;
}
