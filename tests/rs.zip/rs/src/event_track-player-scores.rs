#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[derive(Debug, Clone)]
pub struct IndexError {
    message: String,
}
impl std::fmt::Display for IndexError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "index out of range: {}", self.message)
    }
}
impl std::error::Error for IndexError {}
impl IndexError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub fn player_score_tracking_event(state: &State) {
    let mut away_first_try_jersey: i32 = 0;
    let mut away_try_scorer_indices: Vec<i32> = Vec::new();
    let mut first_try_jersey: i32 = 0;
    let mut home_first_try_jersey: i32 = 0;
    let mut home_try_scorer_indices: Vec<i32> = Vec::new();
    let mut last_try_jersey: i32 = 0;
    let three_unanswered_tries_team: Option<Team> = None;
    let mut try_scorer_indices: Vec<i32> = Vec::new();
    let mut try_teams: Vec<Team> = Vec::new();
    if state.include_players {
        log::info!(
            "{}",
            "[Player Score Tracking Event] Collect try scorer information"
        );
        home_try_scorer_indices = state
            .incidents
            .iter()
            .cloned()
            .filter(|incident| {
                incident.has_points_confirmed
                    && incident.points_confirmed_score_type == ScoreType.Try
                    && incident.points_scored_team == Team.Home
            })
            .map(|incident| incident.points_confirmed_player_index)
            .collect::<Vec<_>>();
        try_scorer_indices = state
            .incidents
            .iter()
            .cloned()
            .filter(|incident| {
                incident.has_points_confirmed
                    && incident.points_confirmed_score_type == ScoreType.Try
            })
            .map(|incident| incident.points_confirmed_player_index)
            .collect::<Vec<_>>();
        try_teams = state
            .incidents
            .iter()
            .cloned()
            .filter(|incident| {
                incident.has_points_confirmed
                    && incident.points_confirmed_score_type == ScoreType.Try
            })
            .map(|incident| incident.points_scored_team)
            .collect::<Vec<_>>();
        away_try_scorer_indices = state
            .incidents
            .iter()
            .cloned()
            .filter(|incident| {
                incident.has_points_confirmed
                    && incident.points_confirmed_score_type == ScoreType.Try
                    && incident.points_scored_team == Team.Away
            })
            .map(|incident| incident.points_confirmed_player_index)
            .collect::<Vec<_>>();
        log::info!(
            "{}",
            "[Player Score Tracking Event] Find jersey numbers for first and last try scorers"
        );
        home_first_try_jersey = {
            let base = &state.home_players;
            let idx: i32 = home_try_scorer_indices.get(0usize).cloned().unwrap();
            let actual_idx = if idx < 0 {
                base.len().saturating_sub(idx.abs() as usize)
            } else {
                idx as usize
            };
            base.get(actual_idx).cloned().unwrap()
        }
        .jersey_number;
        away_first_try_jersey = {
            let base = &state.away_players;
            let idx: i32 = away_try_scorer_indices.get(0usize).cloned().unwrap();
            let actual_idx = if idx < 0 {
                base.len().saturating_sub(idx.abs() as usize)
            } else {
                idx as usize
            };
            base.get(actual_idx).cloned().unwrap()
        }
        .jersey_number;
        last_try_jersey = {
            let base = &state.all_players;
            let idx: i32 = {
                let base = &try_scorer_indices;
                let idx: i32 = (try_scorer_indices.len() as i32).saturating_sub(1);
                let actual_idx = if idx < 0 {
                    base.len().saturating_sub(idx.abs() as usize)
                } else {
                    idx as usize
                };
                base.get(actual_idx).cloned().unwrap()
            };
            let actual_idx = if idx < 0 {
                base.len().saturating_sub(idx.abs() as usize)
            } else {
                idx as usize
            };
            base.get(actual_idx).cloned().unwrap()
        }
        .jersey_number;
        first_try_jersey = {
            let base = &state.all_players;
            let idx: i32 = try_scorer_indices.get(0usize).cloned().unwrap();
            let actual_idx = if idx < 0 {
                base.len().saturating_sub(idx.abs() as usize)
            } else {
                idx as usize
            };
            base.get(actual_idx).cloned().unwrap()
        }
        .jersey_number;
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output try scorer sequence(up to 15 tries)"
        );
        for index in 1..std::cmp::min(15, try_scorer_indices.len() as i32) {
            log::info!("{}", "[Player Score Tracking Event] record");
            record_int(format!("{}thTryScorer_Match", index), {
                let base = &try_scorer_indices;
                let idx: i32 = index - 1;
                let actual_idx = if idx < 0 {
                    base.len().saturating_sub(idx.abs() as usize)
                } else {
                    idx as usize
                };
                base.get(actual_idx).cloned().unwrap()
            });
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output try team sequence"
        );
        for index in 1..try_teams.len() as i32 {
            log::info!("{}", "[Player Score Tracking Event] record");
            record_bool(
                format!("{}thTry_Match_A", index),
                {
                    let base = &try_teams;
                    let idx: i32 = index - 1;
                    let actual_idx = if idx < 0 {
                        base.len().saturating_sub(idx.abs() as usize)
                    } else {
                        idx as usize
                    };
                    base.get(actual_idx).cloned().unwrap()
                } == Team.Home,
            );
            record_bool(
                format!("{}thTry_Match_B", index),
                {
                    let base = &try_teams;
                    let idx: i32 = index - 1;
                    let actual_idx = if idx < 0 {
                        base.len().saturating_sub(idx.abs() as usize)
                    } else {
                        idx as usize
                    };
                    base.get(actual_idx).cloned().unwrap()
                } == Team.Away,
            );
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output first try scorer information"
        );
        let _cse_temp_0 = try_scorer_indices.len() as i32;
        if _cse_temp_0 > 0 {
            record_int("FirstTryScorerJerseyMatch".to_string(), first_try_jersey);
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output home team first try scorer"
        );
        let _cse_temp_1 = home_try_scorer_indices.len() as i32;
        if _cse_temp_1 > 0 {
            record_int(
                "HomeFirstTryScorerMatch".to_string(),
                home_try_scorer_indices.get(0usize).cloned().unwrap(),
            );
            record_int(
                "HomeFirstTryScorerJerseyMatch".to_string(),
                home_first_try_jersey,
            );
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output away team first try scorer"
        );
        let _cse_temp_2 = away_try_scorer_indices.len() as i32;
        if _cse_temp_2 > 0 {
            record_int(
                "AwayFirstTryScorerMatch".to_string(),
                away_try_scorer_indices.get(0usize).cloned().unwrap(),
            );
            record_int(
                "AwayFirstTryScorerJerseyMatch".to_string(),
                away_first_try_jersey,
            );
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output three unanswered tries"
        );
        if state.three_unanswered_tries_team != Team.NotSet {
            record_bool("ThreeUnansweredTries".to_string(), true);
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output last try scorer(end of match only)"
        );
        let _cse_temp_3 = (state.is_over) && (_cse_temp_0 > 0);
        if _cse_temp_3 {
            record_int("LastTryScorerMatch".to_string(), {
                let base = &try_scorer_indices;
                let idx: i32 = (try_scorer_indices.len() as i32).saturating_sub(1);
                let actual_idx = if idx < 0 {
                    base.len().saturating_sub(idx.abs() as usize)
                } else {
                    idx as usize
                };
                base.get(actual_idx).cloned().unwrap()
            });
            record_int("LastTryScorerJerseyMatch".to_string(), last_try_jersey);
            record_int("HomeLastTryScorerMatch".to_string(), {
                let base = &home_try_scorer_indices;
                let idx: i32 = (home_try_scorer_indices.len() as i32).saturating_sub(1);
                let actual_idx = if idx < 0 {
                    base.len().saturating_sub(idx.abs() as usize)
                } else {
                    idx as usize
                };
                base.get(actual_idx).cloned().unwrap()
            });
            record_int("AwayLastTryScorerMatch".to_string(), {
                let base = &away_try_scorer_indices;
                let idx: i32 = (away_try_scorer_indices.len() as i32).saturating_sub(1);
                let actual_idx = if idx < 0 {
                    base.len().saturating_sub(idx.abs() as usize)
                } else {
                    idx as usize
                };
                base.get(actual_idx).cloned().unwrap()
            });
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output player statistics from trader state"
        );
        for player in &state.home_players {
            let player = player.clone();
            log::info!("{}", "[Player Score Tracking Event] record");
            record_bool(
                format!("Player_{}_AnytimeTryScorer", player.player_index),
                player.total_statistics.scores.tries > 0,
            );
            record_bool(
                format!("Player_{}_2PlusTryScorer", player.player_index),
                player.total_statistics.scores.tries >= 2,
            );
            record_bool(
                format!("Player_{}_3PlusTryScorer", player.player_index),
                player.total_statistics.scores.tries >= 3,
            );
        }
        log::info!(
            "{}",
            "[Player Score Tracking Event] Output away player statistics from trader state"
        );
        for player in &state.away_players {
            let player = player.clone();
            log::info!("{}", "[Player Score Tracking Event] record");
            record_bool(
                format!("Player_{}_AnytimeTryScorer", player.player_index),
                player.total_statistics.scores.tries > 0,
            );
            record_bool(
                format!("Player_{}_2PlusTryScorer", player.player_index),
                player.total_statistics.scores.tries >= 2,
            );
            record_bool(
                format!("Player_{}_3PlusTryScorer", player.player_index),
                player.total_statistics.scores.tries >= 3,
            );
        }
    }
    return;
}
