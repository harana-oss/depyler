#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[derive(Debug, Clone)]
pub struct IndexError {
    message: String,
}
impl std::fmt::Display for IndexError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "index out of range: {}", self.message)
    }
}
impl std::error::Error for IndexError {}
impl IndexError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub fn anytime_output_event(state: &State) {
    let mut away_extra_time_stats: Option<Statistics> = None;
    let mut away_second_half_stats: Option<Statistics> = None;
    let mut ended_half_1: bool = false;
    let mut ended_match: bool = false;
    let mut home_extra_time_stats: Option<Statistics> = None;
    let mut home_second_half_stats: Option<Statistics> = None;
    let mut team_a_second_half_points: i32 = 0;
    let mut team_b_second_half_points: i32 = 0;
    if ![GameStatus.UnknownStatus, GameStatus.NotStarted].contains(&state.game_status) {
        log::info!(
            "{}",
            "[Anytime Output Event] Get period and match statistics"
        );
        home_second_half_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(SECOND_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        away_extra_time_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(EXTRA_TIME_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        away_second_half_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(SECOND_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        home_extra_time_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(EXTRA_TIME_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        log::info!("{}", "[Anytime Output Event] Calculate status flags");
        ended_match = state.is_over;
        ended_half_1 = state.period.number > 1;
        team_b_second_half_points = away_second_half_stats.as_ref().unwrap().scores.total;
        team_a_second_half_points = home_second_half_stats.as_ref().unwrap().scores.total;
        log::info!("{}", "[Anytime Output Event] Output match status");
        record_bool("EndedHalf1".to_string(), ended_half_1);
        record_bool("EndedMatch".to_string(), ended_match);
        log::info!("{}", "[Anytime Output Event] Output second half points");
        record_int("PointsHalf2A".to_string(), team_a_second_half_points);
        record_int("PointsHalf2B".to_string(), team_b_second_half_points);
        log::info!("{}", "[Anytime Output Event] Output match tries");
        record_int(
            "TriesMatchA".to_string(),
            state.home_statistics.total_statistics.scores.tries,
        );
        record_int(
            "TriesMatchB".to_string(),
            state.away_statistics.total_statistics.scores.tries,
        );
        log::info!("{}", "[Anytime Output Event] Output extra time tries");
        record_int(
            "TriesExtraTimeA".to_string(),
            home_extra_time_stats.as_ref().unwrap().scores.tries,
        );
        record_int(
            "TriesExtraTimeB".to_string(),
            away_extra_time_stats.as_ref().unwrap().scores.tries,
        );
    }
    return;
}
