#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[derive(Debug, Clone)]
pub struct ZeroDivisionError {
    message: String,
}
impl std::fmt::Display for ZeroDivisionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "division by zero: {}", self.message)
    }
}
impl std::error::Error for ZeroDivisionError {}
impl ZeroDivisionError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub fn game(state: &mut State) {
    let mut current_minute: i32 = 0;
    let mut field_goal_attempt_result: i32 = 0;
    let mut minute_delta: i32 = 0;
    let mut previous_minute: i32 = 0;
    log::info!("{}", "[NRL] Setup Statistics");
    setup_statistics(state.clone());
    execute_events(state.clone());
    log::info!("{}", "[NRL] Setup State");
    state.period.number = 1;
    state.include_players = false;
    state.period.name = PeriodName.FirstHalf;
    execute_events(state.clone());
    log::info!("{}", "[NRL] Log State");
    log_state(state.clone());
    execute_events(state.clone());
    log::info!("{}", "[NRL] Game Loop");
    while true {
        log::info!("{}", "[NRL] Store previous state");
        state.previous_ball_location = state.ball_location;
        state.previous_play = state.current_play;
        execute_events(state.clone());
        log::info!("{}", "[NRL] Evaluate field goal");
        let field_goal_decision: FieldGoalDecisionOutputs = field_goal_decision(state.clone());
        execute_events(state.clone());
        log::info!(
            "{}",
            "[NRL] Run field goal attempt model only if gating passes"
        );
        if field_goal_decision.attempt {
            log::info!("{}", "[NRL] Run field_goal_attempt");
            let field_goal_attempt_outcome: FieldGoalAttemptOutputs =
                field_goal_attempt(state.clone());
            execute_events(state.clone());
            log::info!("{}", "[NRL] Set variables");
            field_goal_attempt_result = (field_goal_attempt_outcome.attempt) as i32;
            execute_events(state.clone());
        } else {
            log::info!("{}", "[NRL] Set variables");
            field_goal_attempt_result = 0;
            execute_events(state.clone());
        }
        execute_events(state.clone());
        log::info!("{}", "[NRL] Branch on field goal attempt vs normal play");
        if field_goal_attempt_result == 1 {
            log::info!("{}", "[NRL] Run field_goal");
            field_goal(state.clone());
            execute_events(state.clone());
        } else {
            log::info!("{}", "[NRL] Get next play type");
            let next_play_result: NextPlayOutputs = next_play(state.clone());
            execute_events(state.clone());
            log::info!("{}", "[NRL] Set current play type");
            state.current_play = next_play_result.play_type;
            execute_events(state.clone());
            log::info!("{}", "[NRL] Line Dropout");
            if state.current_play == Play.LineDropout {
                log::info!("{}", "[NRL] Run swap_possession");
                swap_possession(state.clone());
                execute_events(state.clone());
                log::info!("{}", "[NRL] Run kickoff");
                kickoff(state.clone(), true, true);
                execute_events(state.clone());
            } else {
                log::info!("{}", "[NRL] Get XY model result");
                let xy_result: XyOutputs = xy(state.clone());
                execute_events(state.clone());
                log::info!("{}", "[NRL] Set ball location");
                state.ball_location = xy_result.field_position;
                execute_events(state.clone());
                log::info!("{}", "[NRL] Process play type");
                if state.current_play == Play.ErrorDefence {
                    log::info!("{}", "[NRL] Set variables");
                    state.tackles = STARTING_TACKLE;
                    execute_events(state.clone());
                } else {
                    if state.current_play == Play.WonPenalty {
                        log::info!("{}", "[NRL] Run process_penalty");
                        process_penalty(state.clone());
                        execute_events(state.clone());
                    } else {
                        if state.current_play == Play.KickRetainTackle {
                            log::info!("{}", "[NRL] Run process_tackle");
                            process_tackle(state.clone());
                            execute_events(state.clone());
                        } else {
                            if state.current_play == Play.KickTurnover {
                                log::info!("{}", "[NRL] Run swap_possession");
                                swap_possession(state.clone());
                                execute_events(state.clone());
                            } else {
                                if state.current_play == Play.Run {
                                } else {
                                    if state.current_play == Play.Pass {
                                    } else {
                                        if state.current_play == Play.RunTackle {
                                            log::info!("{}", "[NRL] Run process_tackle");
                                            process_tackle(state.clone());
                                            execute_events(state.clone());
                                        } else {
                                            if state.current_play == Play.KickRetain {
                                            } else {
                                                if state.current_play == Play.KickRetainTry {
                                                    log::info!("{}", "[NRL] Run process_try");
                                                    process_try(state.clone());
                                                    execute_events(state.clone());
                                                } else {
                                                    if state.current_play == Play.RunTry {
                                                        log::info!("{}", "[NRL] Run process_try");
                                                        process_try(state.clone());
                                                        execute_events(state.clone());
                                                    } else {
                                                        if state.current_play == Play.ErrorAttack {
                                                            log::info!(
                                                                "{}",
                                                                "[NRL] Run swap_possession"
                                                            );
                                                            swap_possession(state.clone());
                                                            execute_events(state.clone());
                                                        } else {
                                                            if state.current_play
                                                                == Play.ConcededPenalty
                                                            {
                                                                log::info!(
                                                                    "{}",
                                                                    "[NRL] Run process_penalty"
                                                                );
                                                                process_penalty(state.clone());
                                                                execute_events(state.clone());
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                execute_events(state.clone());
            }
            execute_events(state.clone());
        }
        execute_events(state.clone());
        log::info!("{}", "[NRL] Snapshot elapsed minute before clock");
        previous_minute = ((state.time_elapsed as f64) / (60 as f64)) as i32;
        execute_events(state.clone());
        log::info!("{}", "[NRL] Advance clock");
        clock(state.clone());
        execute_events(state.clone());
        log::info!("{}", "[NRL] Compute elapsed minute after clock");
        current_minute = ((state.time_elapsed as f64) / (60 as f64)) as i32;
        execute_events(state.clone());
        log::info!("{}", "[NRL] Compute minute delta");
        minute_delta = current_minute - previous_minute;
        execute_events(state.clone());
        log::info!("{}", "[NRL] Process interchanges when minute advances");
        if (state.include_players) && (minute_delta > 0) {
            log::info!("{}", "[NRL] Run apply_time_on_ground");
            apply_time_on_ground(state.clone(), Team.Home, (minute_delta * 60) as f64);
            execute_events(state.clone());
            log::info!("{}", "[NRL] Run apply_time_on_ground");
            apply_time_on_ground(state.clone(), (minute_delta * 60) as f64, Team.Away);
            execute_events(state.clone());
            log::info!("{}", "[NRL] Run interchange");
            interchange(state.clone());
            execute_events(state.clone());
        }
        execute_events(state.clone());
        log::info!("{}", "[NRL] Check game status and period transitions");
        check_game_status(state.clone());
        execute_events(state.clone());
        log::info!("{}", "[NRL] Stop if complete");
        if state.is_over {
            log::info!("{}", "[NRL] Exit");
            break;
            execute_events(state.clone());
        }
        execute_events(state.clone());
    }
    execute_events(state);
    return;
}
