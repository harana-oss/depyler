#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlayerOfTheMatchOutputs {
    pub player_of_the_match: i32,
}
impl PlayerOfTheMatchOutputs {
    pub fn new(player_of_the_match: i32) -> Self {
        Self {
            player_of_the_match,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "player_of_the_match" => {
                Some(Box::new(self.player_of_the_match.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "player_of_the_match" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.player_of_the_match = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn player_of_the_match(state: &mut State, enabled: bool) -> PlayerOfTheMatchOutputs {
    let mut distribution_sum: f64 = 0.0;
    let mut player_distributions: Vec<f64> = Vec::new();
    let mut pom_player_index: i32 = 0;
    let mut sample_index: i32 = 0;
    log::info!(
        "{}",
        "[PlayerOfTheMatch] Skip processing when feature disabled"
    );
    if !enabled {
        log::info!("{}", "[PlayerOfTheMatch] Return");
        return PlayerOfTheMatchOutputs::new(state.player_of_the_match);
    }
    log::info!(
        "{}",
        "[PlayerOfTheMatch] Calculate player of the match distributions"
    );
    player_distributions = calculate_player_of_match_distributions(state);
    log::info!("{}", "[PlayerOfTheMatch] Aggregate distribution sum");
    let _cse_temp_0 = player_distributions.clone().iter().sum::<f64>();
    let _cse_temp_1 = (_cse_temp_0) as f64;
    distribution_sum = _cse_temp_1;
    log::info!("{}", "[PlayerOfTheMatch] Sample player index");
    if distribution_sum > 0.0 {
        log::info!("{}", "[PlayerOfTheMatch] Set variables");
        sample_index = sample_scaled(&player_distributions, distribution_sum, random());
    } else {
        log::info!("{}", "[PlayerOfTheMatch] Set variables");
        let _cse_temp_2 = player_distributions.len() as i32;
        let _cse_temp_3 = (_cse_temp_2) as f64;
        let _cse_temp_4 = random() * _cse_temp_3;
        let _cse_temp_5 = (_cse_temp_4) as i32;
        sample_index = _cse_temp_5;
    }
    log::info!("{}", "[PlayerOfTheMatch] Clamp sampled index to bounds");
    let _cse_temp_6 = (sample_index) as i32;
    let _cse_temp_7 = std::cmp::max(_cse_temp_6, 0);
    let _cse_temp_8 = player_distributions.len() as i32;
    let _cse_temp_9 = std::cmp::min(_cse_temp_7, _cse_temp_8 - 1);
    sample_index = _cse_temp_9;
    log::info!("{}", "[PlayerOfTheMatch] Resolve player index from state");
    pom_player_index = state
        .all_players
        .get(sample_index as usize)
        .cloned()
        .unwrap()
        .player_index;
    log::info!(
        "{}",
        "[PlayerOfTheMatch] Persist player of the match on state"
    );
    state.player_of_the_match = pom_player_index;
    log::info!("{}", "[PlayerOfTheMatch] Return");
    return PlayerOfTheMatchOutputs::new(pom_player_index);
}
