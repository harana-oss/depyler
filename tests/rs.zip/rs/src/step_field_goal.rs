#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn field_goal(state: &mut State) {
    let mut adjusted_x: i32 = 0;
    let mut is_two_pointer: bool = false;
    log::info!("{}", "[FieldGoal] Run field goal model");
    let field_goal_result: GetFieldGoalModelResultOutputs =
        get_field_goal_model_result(state.clone());
    log::info!("{}", "[FieldGoal] Handle scored field goal");
    if field_goal_result.scored {
        log::info!("{}", "[FieldGoal] Compute adjusted x for two-pointer check");
        if state.team_in_possession == Team.Home {
            log::info!("{}", "[FieldGoal] Set variables");
            adjusted_x = state.ball_location.x;
        } else {
            log::info!("{}", "[FieldGoal] Set variables");
            adjusted_x = PLAYING_FIELD_WIDTH - state.ball_location.x;
        }
        log::info!("{}", "[FieldGoal] Determine if two-pointer");
        let _cse_temp_0 = adjusted_x < PLAYING_FIELD_WIDTH - TWO_POINT_FIELD_GOAL_DISTANCE;
        is_two_pointer = _cse_temp_0;
        log::info!("{}", "[FieldGoal] Add field goal points");
        add_field_goal(state.clone(), is_two_pointer);
        log::info!("{}", "[FieldGoal] Process kickoff");
        kickoff(state.clone(), false, false);
    }
    log::info!("{}", "[FieldGoal] Handle missed field goal");
    if !field_goal_result.scored {
        log::info!("{}", "[FieldGoal] Swap possession");
        swap_possession(state.clone());
        log::info!("{}", "[FieldGoal] Set ball location for missed field goal");
        if state.team_in_possession == Team.Home {
            log::info!("{}", "[FieldGoal] Set variables");
            state.ball_location.x = MISSED_FIELD_GOAL_RESTART_X;
            state.ball_location.y = CENTRE_OF_THE_FIELD_Y;
        } else {
            log::info!("{}", "[FieldGoal] Set variables");
            state.ball_location.x = PLAYING_FIELD_WIDTH - MISSED_FIELD_GOAL_RESTART_X;
            state.ball_location.y = CENTRE_OF_THE_FIELD_Y;
        }
    }
    execute_events(state);
    return;
}
