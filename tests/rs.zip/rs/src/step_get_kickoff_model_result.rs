#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone)]
pub struct IndexError {
    message: String,
}
impl std::fmt::Display for IndexError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "index out of range: {}", self.message)
    }
}
impl std::error::Error for IndexError {}
impl IndexError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct GetKickoffModelResultInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl GetKickoffModelResultInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct GetKickoffModelResultOutputs {
    pub change_possession: bool,
    pub grid_result: String,
}
impl GetKickoffModelResultOutputs {
    pub fn new(change_possession: bool, grid_result: String) -> Self {
        Self {
            change_possession,
            grid_result,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "change_possession" => {
                Some(Box::new(self.change_possession.clone()) as Box<dyn std::any::Any>)
            }
            "grid_result" => Some(Box::new(self.grid_result.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "change_possession" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.change_possession = v.clone();
                    true
                } else {
                    false
                }
            }
            "grid_result" => {
                if let Some(v) = value.downcast_ref::<String>() {
                    self.grid_result = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn get_kickoff_model_result(state: &State) -> GetKickoffModelResultOutputs {
    log::info!("{}", "[GetKickoffModelResult] Run kickoff model");
    let model: GetKickoffModelResultInferOutputs0 = infer::<GetKickoffModelResultInferOutputs0>(
        "kickoff".to_string(),
        vec![
            btf(state.team_in_possession == Team.Home),
            (state.time_elapsed) as f64,
            0.0,
            (if state.team_in_possession == Team.Home {
                (state.home_players.len() as i32).saturating_sub(state.away_players.len() as i32)
            } else {
                (state.away_players.len() as i32).saturating_sub(state.home_players.len() as i32)
            }) as f64,
            btf(state.current_play == Play.LineDropout),
        ],
    );
    log::info!("{}", "[GetKickoffModelResult] Get kickoff result");
    let kickoff_result = KICKOFF_RESULTS
        .get((sample(model.probabilities, random())) as i32 as usize)
        .cloned()
        .unwrap();
    log::info!("{}", "[GetKickoffModelResult] Return result");
    return GetKickoffModelResultOutputs::new(
        !KICKOFF_RETAIN_RESULTS.contains(&kickoff_result),
        KICKOFF_TO_GRID_RESULT::get(kickoff_result.to_string(), "A1"),
    );
}
