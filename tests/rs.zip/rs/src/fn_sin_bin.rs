pub fn record_player_sin_bin(
    state: &State,
    player_index: i32,
    team: &Team,
    sin_bin_status: &SinBinStatus,
) {
    let players = if team.clone() == Team.Home {
        state.home_players
    } else {
        state.away_players
    };
    let mut player = _resolve_player(&players, player_index);
    if player.is_some() {
        let mut sin_bin_collection = if team.clone() == Team.Home {
            state.home_sin_bin
        } else {
            state.away_sin_bin
        };
        if !sin_bin_collection.contains(&player.clone().as_ref().unwrap()) {
            sin_bin_collection.push(player.clone().unwrap());
        }
        let seconds_elapsed = state.time_elapsed;
        let duration = if sin_bin_status.clone() == SinBinStatus.YellowCard {
            YELLOW_CARD_SECONDS
        } else {
            0
        };
        player.as_mut().unwrap().sin_bin_status = sin_bin_status.clone();
        player.as_mut().unwrap().return_from_sin_bin_time = seconds_elapsed + duration;
        player.as_mut().unwrap().on_field = false;
        player.as_mut().unwrap().sin_bin_sent_off = seconds_elapsed;
        rebuild_sin_bin_players(state, team);
    }
}
pub fn _resolve_player(players: &Vec<Player>, candidate_index: i32) -> Option<Player> {
    for player in players.iter().cloned() {
        if player.player_index == candidate_index {
            return Some(player.clone());
        }
    }
    let target_position = PlayerPosition::new(candidate_index);
    for player in players.iter().cloned() {
        if (player.position == target_position) && (player.on_field) {
            return Some(player.clone());
        }
    }
    for player in players.iter().cloned() {
        if player.position == target_position {
            return Some(player);
        }
    }
    return None;
}
pub fn rebuild_sin_bin_players(state: &State, team: &Team) {
    for team in vec![Team.Home, Team.Away] {
        let sin_bin_collection = if team.clone() == Team.Home {
            state.home_sin_bin
        } else {
            state.away_sin_bin
        };
        let sin_bin_players = sin_bin_collection
            .iter()
            .cloned()
            .filter(|player| player.sin_bin_status != SinBinStatus.NotSet)
            .collect::<Vec<_>>();
        let mut team_stats = if team == Team.Home {
            state.home_statistics
        } else {
            state.away_statistics
        };
        team_stats.sin_bin_players = sin_bin_players;
    }
}
