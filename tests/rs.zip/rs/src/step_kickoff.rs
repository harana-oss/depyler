#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn kickoff(state: &mut State, force_possession_change: bool, is_line_dropout: bool) {
    let mut field_position: FieldPosition = FieldPosition::new(0, 0);
    let mut new_team_in_possession: Option<Team> = None;
    let mut valid: bool = false;
    log::info!("{}", "[Kickoff] Ensure team in possession is initialised");
    if state.team_in_possession == Team.NotSet {
        log::info!("{}", "[Kickoff] If statement");
        if random() > 0.5 {
            log::info!("{}", "[Kickoff] Set variables");
            state.team_in_possession = Team.Away;
        } else {
            log::info!("{}", "[Kickoff] Set variables");
            state.team_in_possession = Team.Home;
        }
    }
    log::info!("{}", "[Kickoff] Seed kickoff possession");
    new_team_in_possession = Some(state.team_in_possession);
    log::info!("{}", "[Kickoff] Loop until valid kickoff position is found");
    while true {
        log::info!("{}", "[Kickoff] Run kickoff model");
        let kickoff: GetKickoffModelResultOutputs = get_kickoff_model_result(state.clone());
        log::info!("{}", "[Kickoff] Swap team if possession changed");
        if kickoff.change_possession {
            log::info!("{}", "[Kickoff] If statement");
            if new_team_in_possession.clone().unwrap() == Team.Home {
                log::info!("{}", "[Kickoff] Set variables");
                new_team_in_possession = Some(Team.Away);
            } else {
                log::info!("{}", "[Kickoff] Set variables");
                new_team_in_possession = Some(Team.Home);
            }
        }
        log::info!("{}", "[Kickoff] Convert to field position");
        if !is_line_dropout {
            log::info!("{}", "[Kickoff] If statement");
            if new_team_in_possession.clone().unwrap() == Team.Home {
                log::info!("{}", "[Kickoff] Set variables");
                field_position =
                    convert_field_position(state.clone(), kickoff.grid_result, Team.Away);
            } else {
                log::info!("{}", "[Kickoff] Set variables");
                field_position =
                    convert_field_position(state.clone(), kickoff.grid_result, Team.Home);
            }
        } else {
            log::info!("{}", "[Kickoff] Set variables");
            field_position =
                convert_field_position(state.clone(), kickoff.grid_result, new_team_in_possession);
        }
        log::info!("{}", "[Kickoff] Validate position constraints");
        valid = ((((is_line_dropout)
            && ((field_position.x >= DROPOUT_X) && (field_position.x <= PLAYING_FIELD_WIDTH)))
            || (((!is_line_dropout) && (new_team_in_possession.clone().unwrap() == Team.Home))
                && (field_position.x <= KICKOFF_X)))
            || (((!is_line_dropout) && (new_team_in_possession.clone().unwrap() == Team.Away))
                && (field_position.x >= KICKOFF_X)))
            && ((!force_possession_change) || (kickoff.change_possession));
        log::info!("{}", "[Kickoff] Exit loop if valid");
        if valid {
            log::info!("{}", "[Kickoff] Exit");
            break;
        }
    }
    log::info!("{}", "[Kickoff] Update game state");
    state.ball_location = field_position;
    state.team_in_possession = new_team_in_possession.clone().unwrap();
    execute_events(state);
    return;
}
