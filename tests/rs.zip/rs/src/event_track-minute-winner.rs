#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[derive(Debug, Clone)]
pub struct ZeroDivisionError {
    message: String,
}
impl std::fmt::Display for ZeroDivisionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "division by zero: {}", self.message)
    }
}
impl std::error::Error for ZeroDivisionError {}
impl ZeroDivisionError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub fn minute_winner_tracking_event(state: &State) {
    let mut final_minute: i32 = 0;
    let mut minute_intervals: Vec<i32> = Vec::new();
    let _cse_temp_0 = state.incidents.len() as i32;
    let _cse_temp_1 = (_cse_temp_0 > 0) || (state.is_over);
    if _cse_temp_1 {
        log::info!(
            "{}",
            "[Minute Winner Tracking Event] Initialize interval context"
        );
        let _cse_temp_2 = ((state.time_elapsed as f64) / (60 as f64)) as i32;
        final_minute = _cse_temp_2;
        minute_intervals = vec![10, 20, 30, 50, 60];
        log::info!(
            "{}",
            "[Minute Winner Tracking Event] Track winner at each minute interval"
        );
        for minute in minute_intervals.iter().cloned() {
            log::info!(
                "{}",
                "[Minute Winner Tracking Event] Record minute winners when interval elapsed"
            );
            if final_minute > minute {
                log::info!(
                    "{}",
                    "[Minute Winner Tracking Event] Calculate scores through interval"
                );
                let away_points_at_minute = state
                    .incidents
                    .iter()
                    .cloned()
                    .filter(|incident| {
                        ((incident.has_points_confirmed)
                            && (incident.points_scored_team == Team.Away))
                            && (incident.time_elapsed <= minute * 60)
                    })
                    .map(|incident| incident.points_scored_points)
                    .sum::<i32>();
                let home_points_at_minute = state
                    .incidents
                    .iter()
                    .cloned()
                    .filter(|incident| {
                        ((incident.has_points_confirmed)
                            && (incident.points_scored_team == Team.Home))
                            && (incident.time_elapsed <= minute * 60)
                    })
                    .map(|incident| incident.points_scored_points)
                    .sum::<i32>();
                log::info!(
                    "{}",
                    "[Minute Winner Tracking Event] Output minute winner results"
                );
                record_bool(
                    format!("WinMinute{}MatchA", minute),
                    home_points_at_minute > away_points_at_minute,
                );
                record_bool(
                    format!("WinMinute{}MatchB", minute),
                    away_points_at_minute > home_points_at_minute,
                );
            }
        }
    }
    return;
}
