#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct FieldGoalAttemptInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl FieldGoalAttemptInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct FieldGoalAttemptOutputs {
    pub attempt: i32,
}
impl FieldGoalAttemptOutputs {
    pub fn new(attempt: i32) -> Self {
        Self { attempt }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "attempt" => Some(Box::new(self.attempt.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "attempt" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.attempt = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn field_goal_attempt(state: &State) -> FieldGoalAttemptOutputs {
    log::info!("{}", "[FieldGoalAttempt] Run field goal attempt model");
    let model: FieldGoalAttemptInferOutputs0 = infer::<FieldGoalAttemptInferOutputs0>(
        "field_goal_attempt".to_string(),
        vec![
            (if state.time_elapsed < HALF_LENGTH_IN_SECONDS {
                HALF_LENGTH_IN_SECONDS - state.time_elapsed
            } else {
                if state.time_elapsed < GAME_LENGTH_IN_SECONDS {
                    GAME_LENGTH_IN_SECONDS - state.time_elapsed
                } else {
                    FIELD_GOAL_ATTEMPT_EXTRA_TIME_SECONDS
                }
            }) as f64,
            (if (calculate_margin(state.clone())).abs() < 2 {
                1.0
            } else {
                0.0
            }) as f64,
            (if calculate_margin(state.clone()) > 10 {
                1.0
            } else {
                0.0
            }) as f64,
            (std::cmp::max(calculate_dist_to_try_line(state), 0)) as f64,
            ((state.ball_location.y - CENTRE_OF_THE_FIELD_Y).abs()) as f64,
        ],
    );
    log::info!("{}", "[FieldGoalAttempt] Return result");
    return FieldGoalAttemptOutputs::new(sample(model.probabilities, random()));
}
