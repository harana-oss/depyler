#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn add_field_goal(state: &mut State, is_two_pointer: bool) {
    let mut period_idx: i32 = 0;
    let mut points: i32 = 0;
    log::info!("{}", "[AddFieldGoal] Get period index");
    period_idx = state.period.number - 1;
    log::info!("{}", "[AddFieldGoal] Calculate points");
    if is_two_pointer {
        log::info!("{}", "[AddFieldGoal] Set variables");
        points = TWO_POINT_FIELD_GOAL_POINTS;
    } else {
        log::info!("{}", "[AddFieldGoal] Set variables");
        points = FIELD_GOAL_POINTS;
    }
    log::info!("{}", "[AddFieldGoal] Add field goal points to home team");
    if state.team_in_possession == Team.Home {
        log::info!("{}", "[AddFieldGoal] Set variables");
        state.home_match_score = state.home_match_score + points;
    }
    log::info!("{}", "[AddFieldGoal] Add field goal points to away team");
    if state.team_in_possession == Team.Away {
        log::info!("{}", "[AddFieldGoal] Set variables");
        state.away_match_score = state.away_match_score + points;
    }
    log::info!("{}", "[AddFieldGoal] Update home team statistics");
    if state.team_in_possession == Team.Home {
        log::info!("{}", "[AddFieldGoal] Update home period field goals");
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + points;
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .field_goals = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .field_goals
            + 1;
        log::info!("{}", "[AddFieldGoal] Update home total field goals");
        state.home_statistics.total_statistics.scores.field_goals =
            state.home_statistics.total_statistics.scores.field_goals + 1;
        state.home_statistics.total_statistics.scores.total =
            state.home_statistics.total_statistics.scores.total + points;
    }
    log::info!("{}", "[AddFieldGoal] Update away team statistics");
    if state.team_in_possession == Team.Away {
        log::info!("{}", "[AddFieldGoal] Update away period field goals");
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .field_goals = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .field_goals
            + 1;
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + points;
        log::info!("{}", "[AddFieldGoal] Update away total field goals");
        state.away_statistics.total_statistics.scores.total =
            state.away_statistics.total_statistics.scores.total + points;
        state.away_statistics.total_statistics.scores.field_goals =
            state.away_statistics.total_statistics.scores.field_goals + 1;
    }
    log::info!("{}", "[AddFieldGoal] Update player statistics if enabled");
    if state.include_players {
        log::info!("{}", "[AddFieldGoal] Update home player statistics");
        if state.team_in_possession == Team.Home {
            log::info!("{}", "[AddFieldGoal] Set variables");
            state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .total = state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .total
                + points;
            state
                .home_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .total = state
                .home_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .total
                + points;
        }
        log::info!("{}", "[AddFieldGoal] Update away player statistics");
        if state.team_in_possession == Team.Away {
            log::info!("{}", "[AddFieldGoal] Set variables");
            state
                .away_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .total = state
                .away_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .total
                + points;
            state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .total = state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .total
                + points;
        }
    }
    execute_events(state);
    return;
}
