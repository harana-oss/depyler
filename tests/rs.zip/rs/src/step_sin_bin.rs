#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct SinBinInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl SinBinInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct SinBinOutputs {
    pub sent_off: bool,
}
impl SinBinOutputs {
    pub fn new(sent_off: bool) -> Self {
        Self { sent_off }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "sent_off" => Some(Box::new(self.sent_off.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "sent_off" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.sent_off = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn sin_bin(state: &State) -> SinBinOutputs {
    log::info!("{}", "[SinBin] Run sin bin model");
    let model: SinBinInferOutputs0 = infer::<SinBinInferOutputs0>(
        "sin_bin".to_string(),
        vec![
            (state.ball_location.x) as f64,
            (state.ball_location.y) as f64,
            (calculate_foul_team_margin(state)) as f64,
        ],
    );
    log::info!("{}", "[SinBin] Record event");
    return SinBinOutputs::new(sample(model.probabilities, random()) == 1);
}
