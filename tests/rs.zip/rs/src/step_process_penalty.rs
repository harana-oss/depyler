#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn process_penalty(state: &State) {
    log::info!(
        "{}",
        "[ProcessPenalty] Swap possession if penalty was conceded before sampling"
    );
    if state.current_play == Play.ConcededPenalty {
        swap_possession(state.clone());
    }
    log::info!("{}", "[ProcessPenalty] Get penalty type outcome");
    let penalty_outcome_result: PenaltyTypeOutputs = penalty_type(state.clone());
    log::info!("{}", "[ProcessPenalty] Handle penalty shot");
    if penalty_outcome_result.result_index == 0 {
        log::info!(
            "{}",
            "[ProcessPenalty] Run conversion model for penalty shot"
        );
        let conversion_result: GetConversionModelResultOutputs =
            get_conversion_model_result(state.clone());
        log::info!("{}", "[ProcessPenalty] Add penalty points if scored");
        if conversion_result.scored {
            log::info!("{}", "[ProcessPenalty] Run add_penalty");
            add_penalty(state.clone());
        }
        log::info!("{}", "[ProcessPenalty] Process kickoff after penalty shot");
        kickoff(state.clone(), false, false);
    }
    log::info!("{}", "[ProcessPenalty] Handle scrum lost");
    if penalty_outcome_result.result_index == 2 {
        swap_possession(state.clone());
    }
    log::info!("{}", "[ProcessPenalty] Always check sin bin after penalty");
    process_sin_bin_check(state.clone());
    execute_events(state);
    return;
}
