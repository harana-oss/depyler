#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[derive(Debug, Clone)]
pub struct ZeroDivisionError {
    message: String,
}
impl std::fmt::Display for ZeroDivisionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "division by zero: {}", self.message)
    }
}
impl std::error::Error for ZeroDivisionError {}
impl ZeroDivisionError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub fn end_zone(state: &mut State) {
    let mut grid_coordinate: i32 = 0;
    let mut is_end_zone: bool = false;
    let mut is_za_zone: bool = false;
    let mut is_zj_zone: bool = false;
    let mut zone_division: i32 = 0;
    let zone_type: String = "".to_string();
    log::info!("{}", "[EndZone] Derive grid coordinate from ball location");
    grid_coordinate = derive_grid_coordinate(
        state.ball_location.clone(),
        state.team_in_possession.clone(),
    );
    log::info!(
        "{}",
        "[EndZone] Calculate end zone classification from grid coordinate"
    );
    let _cse_temp_0 = ((grid_coordinate as f64) / (6 as f64)) as i32;
    zone_division = _cse_temp_0;
    log::info!("{}", "[EndZone] Calculate zone type booleans");
    is_zj_zone = zone_division == 11;
    let _cse_temp_1 = (zone_division == 10) || (zone_division == 11);
    is_end_zone = _cse_temp_1;
    is_za_zone = zone_division == 10;
    log::info!("{}", "[EndZone] Update game state");
    state.end_zone_type = if is_za_zone {
        "za".to_string()
    } else {
        if is_zj_zone {
            "zj".to_string()
        } else {
            "none".to_string()
        }
    };
    state.is_in_end_zone = is_end_zone;
    execute_events(state);
    return;
}
