#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct GetConversionModelResultInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl GetConversionModelResultInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct GetConversionModelResultInferOutputs1 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl GetConversionModelResultInferOutputs1 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct GetConversionModelResultOutputs {
    pub scored: bool,
}
impl GetConversionModelResultOutputs {
    pub fn new(scored: bool) -> Self {
        Self { scored }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "scored" => Some(Box::new(self.scored.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "scored" => {
                if let Some(v) = value.downcast_ref::<bool>() {
                    self.scored = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn get_conversion_model_result(state: &State) -> GetConversionModelResultOutputs {
    let mut conversion_k: f64 = 0.0;
    let mut is_extra_time: bool = false;
    let mut player_advantage: i32 = 0;
    log::info!("{}", "[GetConversionModelResult] Set variables");
    conversion_k = random();
    is_extra_time = state.period.name == PeriodName.ExtraTime;
    let _cse_temp_0 = (if state.team_in_possession == Team.Home {
        (state.away_sin_bin.len() as i32).saturating_sub(state.home_sin_bin.len() as i32)
    } else {
        (state.home_sin_bin.len() as i32).saturating_sub(state.away_sin_bin.len() as i32)
    }) as i32;
    player_advantage = _cse_temp_0;
    log::info!(
        "{}",
        "[GetConversionModelResult] Run xy model to determine goal line grid"
    );
    let xy_model: GetConversionModelResultInferOutputs0 =
        infer::<GetConversionModelResultInferOutputs0>(
            "xy".to_string(),
            vec![
                (state.tackles) as f64,
                (if state.team_in_possession == Team.Home {
                    state.ball_location.x
                } else {
                    (PLAYING_FIELD_WIDTH - state.ball_location.x).abs()
                }) as f64,
                (if state.team_in_possession == Team.Home {
                    state.ball_location.y
                } else {
                    (700 - state.ball_location.y).abs()
                }) as f64,
                (state.simulation_invariants.total_points) as f64,
                (get_team_handicap(state.clone())) as f64,
                btf(player_advantage == 1),
                btf(player_advantage > 1),
                btf(player_advantage == -1),
                btf(player_advantage < -1),
                (calculate_margin(state)) as f64,
                btf((state.current_play == Play.Pass) || (is_extra_time)),
                btf(([Play.Run, Play.RunTackle].contains(&state.current_play))
                    || ((state.current_play == Play.RunTry) && (!is_extra_time))),
                btf(([Play.KickRetain, Play.KickRetainTackle, Play.KickTurnover]
                    .contains(&state.current_play))
                    || ((state.current_play == Play.KickRetainTry) && (!is_extra_time))),
                btf((state.current_play == Play.RunTry)
                    || ((state.current_play == Play.KickRetainTry) && (!is_extra_time))),
            ],
        );
    log::info!("{}", "[GetConversionModelResult] Run conversion model");
    let conversion_model: GetConversionModelResultInferOutputs1 =
        infer::<GetConversionModelResultInferOutputs1>(
            "conversion".to_string(),
            vec![
                (compute_conversion_location_from_grid(
                    sample(xy_model.probabilities, random()),
                    conversion_k,
                )) as f64,
                ((CENTRE_OF_THE_FIELD_Y - state.ball_location.y).abs()) as f64,
            ],
        );
    log::info!("{}", "[GetConversionModelResult] Return result");
    return GetConversionModelResultOutputs::new(
        sample(conversion_model.probabilities, conversion_k) == 1,
    );
}
