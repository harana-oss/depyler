#[doc = "Margin from the perspective of the penalty-awarded team(matches C# processors)."]
pub fn calculate_foul_team_margin(state: &State) -> i32 {
    let penalty_team;
    if state.current_play == Play.WonPenalty {
        penalty_team = state.team_in_possession;
    } else {
        penalty_team = if state.team_in_possession == Team.Home {
            Team.Away
        } else {
            Team.Home
        };
    }
    if penalty_team == Team.Home {
        return state.home_match_score - state.away_match_score;
    } else {
        return state.away_match_score - state.home_match_score;
    }
}
#[doc = "Margin from the perspective of the team in possession."]
pub fn calculate_margin(state: &State) -> i32 {
    if state.team_in_possession == Team.Home {
        return state.home_match_score - state.away_match_score;
    } else {
        return state.away_match_score - state.home_match_score;
    }
}
