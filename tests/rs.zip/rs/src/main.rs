mod generated;

use gdt_cpus::{ThreadPriority, num_logical_cores, pin_thread_to_core, set_thread_priority};
use log::info;
use rayon::prelude::*;
use std::time::Instant;

#[global_allocator]
static GLOBAL: snmalloc_rs::SnMalloc = snmalloc_rs::SnMalloc;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    env_logger::init();
    let start = Instant::now();

    let cores = num_logical_cores().unwrap_or(1);
    let _ = rayon::ThreadPoolBuilder::new()
        .thread_name(|i| format!("rayon-w{}", i))
        .start_handler(move |index| {
            let _ = set_thread_priority(ThreadPriority::TimeCritical);
            let core_id = index % cores;
            let _ = pin_thread_to_core(core_id);
        })
        .build_global();

    (0..15000).into_par_iter().for_each(|_i| {
        let mut state = generated::State::default();
        generated::game(&mut state);
    });
    
    let duration = start.elapsed();
    let seconds = duration.as_secs_f64();
    println!("\nCompleted in {:.2} seconds", seconds);
    Ok(())
}