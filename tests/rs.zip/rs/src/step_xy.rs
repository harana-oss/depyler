#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone)]
pub struct IndexError {
    message: String,
}
impl std::fmt::Display for IndexError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "index out of range: {}", self.message)
    }
}
impl std::error::Error for IndexError {}
impl IndexError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct XyInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl XyInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct XyOutputs {
    pub field_position: FieldPosition,
}
impl XyOutputs {
    pub fn new(field_position: FieldPosition) -> Self {
        Self { field_position }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "field_position" => {
                Some(Box::new(self.field_position.clone()) as Box<dyn std::any::Any>)
            }
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "field_position" => {
                if let Some(v) = value.downcast_ref::<FieldPosition>() {
                    self.field_position = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn xy(state: &State) -> XyOutputs {
    let mut is_extra_time: bool = false;
    let mut player_advantage: i32 = 0;
    log::info!("{}", "[Xy] Set variables");
    is_extra_time = state.period.name == PeriodName.ExtraTime;
    let _cse_temp_0 = (if state.team_in_possession == Team.Home {
        (state.away_sin_bin.len() as i32).saturating_sub(state.home_sin_bin.len() as i32)
    } else {
        (state.home_sin_bin.len() as i32).saturating_sub(state.away_sin_bin.len() as i32)
    }) as i32;
    player_advantage = _cse_temp_0;
    log::info!("{}", "[Xy] Run xy model");
    let model: XyInferOutputs0 = infer::<XyInferOutputs0>(
        "xy".to_string(),
        vec![
            (state.tackles) as f64,
            (if state.team_in_possession == Team.Home {
                state.ball_location.x
            } else {
                (1000 - state.ball_location.x).abs()
            }) as f64,
            (if state.team_in_possession == Team.Home {
                state.ball_location.y
            } else {
                (700 - state.ball_location.y).abs()
            }) as f64,
            (state.simulation_invariants.total_points) as f64,
            (get_team_handicap(state.clone())) as f64,
            btf(player_advantage == 1),
            btf(player_advantage > 1),
            btf(player_advantage == -1),
            btf(player_advantage < -1),
            (calculate_margin(state.clone())) as f64,
            btf((state.current_play == Play.Pass) || (is_extra_time)),
            btf(([Play.Run, Play.RunTackle].contains(&state.current_play))
                || ((state.current_play == Play.RunTry) && (!is_extra_time))),
            btf(([Play.KickRetain, Play.KickRetainTackle, Play.KickTurnover]
                .contains(&state.current_play))
                || ((state.current_play == Play.KickRetainTry) && (!is_extra_time))),
            btf((state.current_play == Play.RunTry)
                || ((state.current_play == Play.KickRetainTry) && (!is_extra_time))),
        ],
    );
    log::info!("{}", "[Xy] Get grid result");
    let grid_result = GRID_RESULT
        .get((sample(model.probabilities, random())) as i32 as usize)
        .cloned()
        .unwrap();
    log::info!("{}", "[Xy] Convert grid to field position");
    return XyOutputs::new(convert_field_position(
        state,
        grid_result,
        state.team_in_possession,
    ));
}
