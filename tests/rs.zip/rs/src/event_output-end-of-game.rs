#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[derive(Debug, Clone)]
pub struct IndexError {
    message: String,
}
impl std::fmt::Display for IndexError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "index out of range: {}", self.message)
    }
}
impl std::error::Error for IndexError {}
impl IndexError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub fn end_of_game_output_event(state: &State) {
    let mut away_extra_time_points: i32 = 0;
    let mut away_extra_time_stats: Option<Statistics> = None;
    let mut away_first_half_stats: Option<Statistics> = None;
    let mut away_second_half_stats: Option<Statistics> = None;
    let mut away_second_half_with_et: i32 = 0;
    let mut draw_match: bool = false;
    let mut home_extra_time_points: i32 = 0;
    let mut home_extra_time_stats: Option<Statistics> = None;
    let mut home_first_half_stats: Option<Statistics> = None;
    let mut home_second_half_stats: Option<Statistics> = None;
    let mut home_second_half_with_et: i32 = 0;
    let mut team_a_won_match: bool = false;
    let mut team_a_won_second_half_and_et: bool = false;
    let mut team_b_won_second_half_and_et: bool = false;
    let _cse_temp_0 = (state.game_status == GameStatus.Ended) || (state.is_over);
    if _cse_temp_0 {
        log::info!("{}", "[End Of Game Output Event] Get period statistics");
        home_second_half_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(SECOND_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        away_first_half_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(FIRST_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        away_second_half_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(SECOND_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        home_extra_time_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(EXTRA_TIME_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        away_extra_time_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(EXTRA_TIME_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        home_first_half_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(FIRST_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        log::info!(
            "{}",
            "[End Of Game Output Event] Calculate extra time and combined scores"
        );
        away_second_half_with_et = away_second_half_stats.as_ref().unwrap().scores.total
            + away_extra_time_stats.as_ref().unwrap().scores.total;
        away_extra_time_points = away_extra_time_stats.as_ref().unwrap().scores.total;
        home_extra_time_points = home_extra_time_stats.as_ref().unwrap().scores.total;
        home_second_half_with_et = home_second_half_stats.as_ref().unwrap().scores.total
            + home_extra_time_stats.as_ref().unwrap().scores.total;
        log::info!(
            "{}",
            "[End Of Game Output Event] Determine second half and extra time winner"
        );
        team_a_won_second_half_and_et = home_second_half_with_et > away_second_half_with_et;
        team_b_won_second_half_and_et = home_second_half_with_et < away_second_half_with_et;
        log::info!("{}", "[End Of Game Output Event] Determine match results");
        draw_match = state.home_match_score == state.away_match_score;
        let team_b_won_match = state.away_match_score > state.home_match_score;
        team_a_won_match = state.home_match_score > state.away_match_score;
        log::info!("{}", "[End Of Game Output Event] Output match totals");
        record_int("PointsMatchA".to_string(), state.home_match_score);
        record_int("PointsMatchB".to_string(), state.away_match_score);
        log::info!("{}", "[End Of Game Output Event] Output extra time points");
        record_int("PointsExtraTimeA".to_string(), home_extra_time_points);
        record_int("PointsExtraTimeB".to_string(), away_extra_time_points);
        log::info!(
            "{}",
            "[End Of Game Output Event] Output second half and extra time results"
        );
        record_bool(
            "WinHalf2AndExtraTimeA".to_string(),
            team_a_won_second_half_and_et,
        );
        record_bool(
            "WinHalf2AndExtraTimeB".to_string(),
            team_b_won_second_half_and_et,
        );
        log::info!("{}", "[End Of Game Output Event] Output match results");
        record_bool("DrawMatch".to_string(), draw_match);
        record_bool("WinMatchA".to_string(), team_a_won_match);
        record_bool("WinMatchB".to_string(), team_b_won_match);
    }
    return;
}
