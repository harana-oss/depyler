#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[derive(Debug, Clone)]
pub struct IndexError {
    message: String,
}
impl std::fmt::Display for IndexError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "index out of range: {}", self.message)
    }
}
impl std::error::Error for IndexError {}
impl IndexError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub fn normal_time_output_event(state: &State) {
    let mut away_first_half_stats: Option<Statistics> = None;
    let mut away_normal_time_score: i32 = 0;
    let mut away_second_half_stats: Option<Statistics> = None;
    let mut extra_time_occurred: bool = false;
    let mut home_first_half_stats: Option<Statistics> = None;
    let mut home_normal_time_score: i32 = 0;
    let mut home_second_half_stats: Option<Statistics> = None;
    if [
        GameStatus.AwaitingExtraTime,
        GameStatus.ExtraTime,
        GameStatus.Ended,
    ]
    .contains(&state.game_status)
    {
        log::info!("{}", "[Normal Time Output Event] Get period statistics");
        away_first_half_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(FIRST_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        home_second_half_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(SECOND_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        home_first_half_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(FIRST_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        away_second_half_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(SECOND_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        log::info!(
            "{}",
            "[Normal Time Output Event] Calculate normal time scores"
        );
        home_normal_time_score = home_first_half_stats.as_ref().unwrap().scores.total
            + home_second_half_stats.as_ref().unwrap().scores.total;
        away_normal_time_score = away_first_half_stats.as_ref().unwrap().scores.total
            + away_second_half_stats.as_ref().unwrap().scores.total;
        log::info!(
            "{}",
            "[Normal Time Output Event] Determine extra time occurrence"
        );
        extra_time_occurred = home_normal_time_score == away_normal_time_score;
        log::info!(
            "{}",
            "[Normal Time Output Event] Output normal time results"
        );
        record_bool("ExtraTimeOccurredMatch".to_string(), extra_time_occurred);
        record_int("PointsNormalTimeA".to_string(), home_normal_time_score);
        record_int("PointsNormalTimeB".to_string(), away_normal_time_score);
        record_bool(
            "WinNormalTimeA".to_string(),
            home_normal_time_score > away_normal_time_score,
        );
        record_bool(
            "WinNormalTimeB".to_string(),
            away_normal_time_score > home_normal_time_score,
        );
        log::info!("{}", "[Normal Time Output Event] Output second half tries");
        record_int(
            "TriesHalf2A".to_string(),
            home_second_half_stats.as_ref().unwrap().scores.tries,
        );
        record_int(
            "TriesHalf2B".to_string(),
            away_second_half_stats.as_ref().unwrap().scores.tries,
        );
    }
    return;
}
