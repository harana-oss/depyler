#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[doc = "// NOTE: Map Python module 'dataclasses'()"]
#[derive(Debug, Clone, PartialEq, Default, Reflect)]
pub struct PenaltyTypeInferOutputs0 {
    pub label: Vec<i32>,
    pub probabilities: Vec<f64>,
}
impl PenaltyTypeInferOutputs0 {
    pub fn new(label: Vec<i32>, probabilities: Vec<f64>) -> Self {
        Self {
            label,
            probabilities,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "label" => Some(Box::new(self.label.clone()) as Box<dyn std::any::Any>),
            "probabilities" => Some(Box::new(self.probabilities.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "label" => {
                if let Some(v) = value.downcast_ref::<Vec<i32>>() {
                    self.label = v.clone();
                    true
                } else {
                    false
                }
            }
            "probabilities" => {
                if let Some(v) = value.downcast_ref::<Vec<f64>>() {
                    self.probabilities = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PenaltyTypeOutputs {
    pub result: i32,
    pub result_index: i32,
}
impl PenaltyTypeOutputs {
    pub fn new(result: i32, result_index: i32) -> Self {
        Self {
            result,
            result_index,
        }
    }
    pub fn _get_field(&self, name: &str) -> Option<Box<dyn std::any::Any>> {
        match name {
            "result" => Some(Box::new(self.result.clone()) as Box<dyn std::any::Any>),
            "result_index" => Some(Box::new(self.result_index.clone()) as Box<dyn std::any::Any>),
            _ => None,
        }
    }
    pub fn _set_field(&mut self, name: &str, value: &dyn std::any::Any) -> bool {
        match name {
            "result" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.result = v.clone();
                    true
                } else {
                    false
                }
            }
            "result_index" => {
                if let Some(v) = value.downcast_ref::<i32>() {
                    self.result_index = v.clone();
                    true
                } else {
                    false
                }
            }
            _ => false,
        }
    }
}
pub fn penalty_type(state: &State) -> PenaltyTypeOutputs {
    log::info!("{}", "[PenaltyType] Run penalty type model");
    let model: PenaltyTypeInferOutputs0 = infer::<PenaltyTypeInferOutputs0>(
        "penalty_type".to_string(),
        vec![
            btf(state.current_play == Play.WonPenalty),
            if state.team_in_possession == Team.Home {
                (state.ball_location.x) as f64
            } else {
                ((1000 - state.ball_location.x).abs()) as f64
            },
            if state.team_in_possession == Team.Home {
                (state.ball_location.y) as f64
            } else {
                ((700 - state.ball_location.y).abs()) as f64
            },
            ((700 - state.ball_location.y).abs()) as f64,
            (if state.time_elapsed < 2400 {
                2400 - state.time_elapsed
            } else {
                2 * 2400 - state.time_elapsed
            }) as f64,
            (get_team_handicap(state.clone())) as f64,
            (calculate_margin(state)) as f64,
        ],
    );
    log::info!("{}", "[PenaltyType] Return penalty type");
    return PenaltyTypeOutputs::new(
        sample(model.probabilities, random()),
        sample(model.probabilities, random()),
    );
}
