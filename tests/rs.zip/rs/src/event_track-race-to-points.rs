#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[derive(Debug, Clone)]
pub struct IndexError {
    message: String,
}
impl std::fmt::Display for IndexError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "index out of range: {}", self.message)
    }
}
impl std::error::Error for IndexError {}
impl IndexError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub fn race_to_points_tracking_event(state: &State) {
    let mut away_running_score: i32 = 0;
    let mut home_running_score: i32 = 0;
    let mut race_to_targets: Vec<i32> = Vec::new();
    let mut remaining_targets: Vec<i32> = Vec::new();
    let mut target_index: i32 = 0;
    let _cse_temp_0 = state.incidents.len() as i32;
    let _cse_temp_1 = (_cse_temp_0 > 0) || (state.is_over);
    if _cse_temp_1 {
        log::info!(
            "{}",
            "[Race To Points Tracking Event] Initialize race to context"
        );
        away_running_score = 0;
        target_index = 0;
        home_running_score = 0;
        race_to_targets = vec![10, 15, 20, 25, 30, 35, 40];
        log::info!(
            "{}",
            "[Race To Points Tracking Event] Process scoring incidents for race targets"
        );
        for incident in &state.incidents {
            let incident = incident.clone();
            log::info!(
                "{}",
                "[Race To Points Tracking Event] Apply confirmed score to running totals"
            );
            if ((incident.has_points_confirmed)
                && ([Team.Home, Team.Away].contains(&incident.points_scored_team)))
                && (target_index < race_to_targets.len() as i32)
            {
                log::info!("{}", "[Race To Points Tracking Event] Update team totals");
                if incident.points_scored_team == Team.Home {
                    log::info!("{}", "[Race To Points Tracking Event] Set variables");
                    home_running_score = home_running_score + incident.points_scored_points;
                } else {
                    log::info!("{}", "[Race To Points Tracking Event] Set variables");
                    away_running_score = away_running_score + incident.points_scored_points;
                }
                log::info!(
                    "{}",
                    "[Race To Points Tracking Event] Set current race target"
                );
                let current_target = race_to_targets.get(target_index as usize).cloned().unwrap();
                log::info!(
                    "{}",
                    "[Race To Points Tracking Event] Check target completion"
                );
                let away_reached_target = away_running_score >= current_target;
                let home_reached_target = home_running_score >= current_target;
                log::info!("{}", "[Race To Points Tracking Event] Record race winner when exactly one team reaches target");
                if home_reached_target != away_reached_target {
                    log::info!("{}", "[Race To Points Tracking Event] Record");
                    record_bool(
                        format!("FirstToPoints{}A", current_target),
                        home_reached_target,
                    );
                    record_bool(
                        format!("FirstToPoints{}B", current_target),
                        away_reached_target,
                    );
                    log::info!("{}", "[Race To Points Tracking Event] Set variables");
                    target_index = target_index + 1;
                }
            }
        }
        log::info!(
            "{}",
            "[Race To Points Tracking Event] Capture remaining targets as false"
        );
        remaining_targets = {
            let base = &race_to_targets.clone();
            let start = (target_index).max(0) as usize;
            if start < base.len() {
                base[start..].to_vec()
            } else {
                Vec::new()
            }
        };
        log::info!(
            "{}",
            "[Race To Points Tracking Event] Record unresolved race targets"
        );
        for pending_target in remaining_targets.iter().cloned() {
            log::info!("{}", "[Race To Points Tracking Event] Record");
            record_bool(format!("FirstToPoints{}A", pending_target), false);
            record_bool(format!("FirstToPoints{}B", pending_target), false);
        }
    }
    return;
}
