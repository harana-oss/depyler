#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
#[derive(Debug, Clone)]
pub struct IndexError {
    message: String,
}
impl std::fmt::Display for IndexError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "index out of range: {}", self.message)
    }
}
impl std::error::Error for IndexError {}
impl IndexError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub fn first_half_output_event(state: &State) {
    let mut away_first_half_stats: Option<Statistics> = None;
    let mut away_first_half_total: i32 = 0;
    let mut away_first_half_tries: i32 = 0;
    let mut draw_first_half: bool = false;
    let mut home_first_half_stats: Option<Statistics> = None;
    let mut home_first_half_total: i32 = 0;
    let mut home_first_half_tries: i32 = 0;
    let mut team_a_won_first_half: bool = false;
    let mut team_b_won_first_half: bool = false;
    let _cse_temp_0 = ([
        GameStatus.HalfTime,
        GameStatus.Period2,
        GameStatus.AwaitingExtraTime,
        GameStatus.ExtraTime,
        GameStatus.Ended,
    ]
    .contains(&state.game_status))
        || (state.is_over);
    if _cse_temp_0 {
        log::info!(
            "{}",
            "[First Half Output Event] Get first half period statistics"
        );
        home_first_half_stats = Some(
            state
                .home_statistics
                .period_statistics
                .get(FIRST_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        away_first_half_stats = Some(
            state
                .away_statistics
                .period_statistics
                .get(FIRST_HALF_INDEX as usize)
                .cloned()
                .unwrap(),
        );
        log::info!(
            "{}",
            "[First Half Output Event] Calculate first half scores"
        );
        home_first_half_tries = home_first_half_stats.as_ref().unwrap().scores.tries;
        away_first_half_tries = away_first_half_stats.as_ref().unwrap().scores.tries;
        away_first_half_total = away_first_half_stats.as_ref().unwrap().scores.total;
        home_first_half_total = home_first_half_stats.as_ref().unwrap().scores.total;
        log::info!(
            "{}",
            "[First Half Output Event] Determine first half results"
        );
        draw_first_half = home_first_half_total == away_first_half_total;
        team_b_won_first_half = away_first_half_total > home_first_half_total;
        team_a_won_first_half = home_first_half_total > away_first_half_total;
        log::info!("{}", "[First Half Output Event] Output first half points");
        record_int("PointsHalf1A".to_string(), home_first_half_total);
        record_int("PointsHalf1B".to_string(), away_first_half_total);
        log::info!(
            "{}",
            "[First Half Output Event] Output first half win/draw results"
        );
        record_bool("WinHalf1A".to_string(), team_a_won_first_half);
        record_bool("WinHalf1B".to_string(), team_b_won_first_half);
        record_bool("DrawHalf1".to_string(), draw_first_half);
        log::info!("{}", "[First Half Output Event] Output first half tries");
        record_int("TriesHalf1A".to_string(), home_first_half_tries);
        record_int("TriesHalf1B".to_string(), away_first_half_tries);
    }
    return;
}
