#[doc = "// NOTE: Map Python module 'state'()"]
#[doc = "// NOTE: Map Python module 'functions'()"]
pub fn add_conversion(state: &mut State) {
    log::info!("{}", "[AddConversion] Get period index");
    let period_idx = state.period.number - 1;
    log::info!("{}", "[AddConversion] Add conversion points to home team");
    if state.team_in_possession == Team.Home {
        log::info!("{}", "[AddConversion] Set variables");
        state.home_match_score = state.home_match_score + CONVERSION_POINTS;
    }
    log::info!("{}", "[AddConversion] Add conversion points to away team");
    if state.team_in_possession == Team.Away {
        log::info!("{}", "[AddConversion] Set variables");
        state.away_match_score = state.away_match_score + CONVERSION_POINTS;
    }
    log::info!("{}", "[AddConversion] Update home team statistics");
    if state.team_in_possession == Team.Home {
        log::info!("{}", "[AddConversion] Update home period conversions");
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .conversions = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .conversions
            + 1;
        state
            .home_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .home_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + CONVERSION_POINTS;
        log::info!("{}", "[AddConversion] Update home total conversions");
        state.home_statistics.total_statistics.scores.total =
            state.home_statistics.total_statistics.scores.total + CONVERSION_POINTS;
        state.home_statistics.total_statistics.scores.conversions =
            state.home_statistics.total_statistics.scores.conversions + 1;
    }
    log::info!("{}", "[AddConversion] Update away team statistics");
    if state.team_in_possession == Team.Away {
        log::info!("{}", "[AddConversion] Update away period conversions");
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .conversions = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .conversions
            + 1;
        state
            .away_statistics
            .period_statistics
            .get_mut(period_idx as usize)
            .unwrap()
            .scores
            .total = state
            .away_statistics
            .period_statistics
            .get(period_idx as usize)
            .cloned()
            .unwrap()
            .scores
            .total
            + CONVERSION_POINTS;
        log::info!("{}", "[AddConversion] Update away total conversions");
        state.away_statistics.total_statistics.scores.total =
            state.away_statistics.total_statistics.scores.total + CONVERSION_POINTS;
        state.away_statistics.total_statistics.scores.conversions =
            state.away_statistics.total_statistics.scores.conversions + 1;
    }
    log::info!("{}", "[AddConversion] Update player statistics if enabled");
    if state.include_players {
        log::info!("{}", "[AddConversion] Update home player statistics");
        if state.team_in_possession == Team.Home {
            log::info!("{}", "[AddConversion] Set variables");
            state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .total = state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .total
                + CONVERSION_POINTS;
            state
                .home_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .conversions = state
                .home_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .conversions
                + 1;
            state
                .home_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .total = state
                .home_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .total
                + CONVERSION_POINTS;
            state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions = state
                .home_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions
                + 1;
        }
        log::info!("{}", "[AddConversion] Update away player statistics");
        if state.team_in_possession == Team.Away {
            log::info!("{}", "[AddConversion] Set variables");
            state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions = state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .conversions
                + 1;
            state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .total = state
                .away_player_selected_for_points_market
                .total_statistics
                .scores
                .total
                + CONVERSION_POINTS;
            state
                .away_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .total = state
                .away_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .total
                + CONVERSION_POINTS;
            state
                .away_player_selected_for_points_market
                .period_statistics
                .get_mut(period_idx as usize)
                .unwrap()
                .scores
                .conversions = state
                .away_player_selected_for_points_market
                .period_statistics
                .get(period_idx as usize)
                .cloned()
                .unwrap()
                .scores
                .conversions
                + 1;
        }
    }
    execute_events(state);
    return;
}
