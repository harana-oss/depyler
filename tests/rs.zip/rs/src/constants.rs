pub const CENTRE_OF_THE_FIELD_X: i32 = 500;
pub const CENTRE_OF_THE_FIELD_Y: i32 = 350;
pub const CONVERSION_POINTS: i32 = 2;
pub const DROPOUT_X: i32 = 0;
pub const DROPOUT_Y: i32 = 350;
pub const EXTRA_TIME_INDEX: i32 = 2;
pub const EXTRA_TIME_LENGTH_IN_SECONDS: i32 = 600;
pub const FIELD_GOAL_ATTEMPT_EXTRA_TIME_SECONDS: i32 = 180;
pub const FIELD_GOAL_MAX_ABSOLUTE: i32 = 900;
pub const FIELD_GOAL_MAX_TIME_FIRST: i32 = 2400;
pub const FIELD_GOAL_MIN_ABSOLUTE: i32 = 100;
pub const FIELD_GOAL_MIN_AWAY: i32 = 400;
pub const FIELD_GOAL_MIN_HOME: i32 = 600;
pub const FIELD_GOAL_MIN_TIME_FIRST: i32 = 2340;
pub const FIELD_GOAL_MIN_TIME_SECOND: i32 = 4200;
pub const FIELD_GOAL_PARAM_EXTRA_TIME_VALUE: i32 = 25;
pub const FIELD_GOAL_POINTS: i32 = 1;
pub const FIRST_EIGHT_MINUTES_SECONDS: i32 = 480;
pub const FIRST_HALF_INDEX: i32 = 0;
pub const FULL_TIME_SECONDS: i32 = 4800;
pub const GAME_LENGTH_IN_SECONDS: i32 = 4800;
pub const GOAL_LINE_GRID_START_INDEX: i32 = 60;
pub const GOAL_LINE_X_WIDTH: i32 = 20;
pub const GOAL_LINE_Y_HEIGHT_INCREMENT: i32 = 113;
pub const GOAL_LINE_Y_WIDTH: f64 = 23.34;
pub const HALF_LENGTH_IN_SECONDS: i32 = 2400;
pub const HOOKER_METRES_PER_MINUTE: f64 = 0.75057377;
pub const HOOKER_TACKLES_PER_MINUTE: f64 = 0.547090164;
pub const HOOKER_TRIES_PER_MINUTE: f64 = 0.00232582;
pub const INITIAL_SOLVER_HANDICAP: i32 = -3;
pub const INITIAL_SOLVER_TOTAL_POINTS: i32 = 45;
pub const KICKOFF_X: i32 = 500;
pub const KICKOFF_Y: i32 = 350;
pub const LAST_EIGHT_MINUTES_SECONDS: i32 = 4500;
pub const LAST_MINUTE_SECONDS: i32 = 60;
pub const LAST_TEN_MINUTES_SECONDS: i32 = 600;
pub const LOCK_METRES_PER_MINUTE: f64 = 2.519467213;
pub const LOCK_TACKLES_PER_MINUTE: f64 = 0.563770492;
pub const LOCK_TRIES_PER_MINUTE: f64 = 0.001212746;
pub const MAX_INTERCHANGES: i32 = 8;
pub const MIN_POM_WEIGHT: f64 = 0.0001;
pub const MISSED_FIELD_GOAL_RESTART_X: i32 = 200;
pub const NEAR_END_SECONDS: i32 = 4700;
pub const NUDGES_PERCENT: f64 = 1.0;
pub const NUMBER_OF_INTERCHANGE_PLAYERS: i32 = 4;
pub const NUMBER_OF_SIMULATIONS_DEFAULT: i32 = 40000;
pub const NUM_PERIODS: i32 = 4;
pub const NUM_PLAYERS_PER_TEAM: i32 = 17;
pub const NUM_STARTING_PLAYERS_PER_TEAM: i32 = 13;
pub const PENALTY_POINTS: i32 = 2;
pub const PLAYING_FIELD_BASE: i32 = 0;
pub const PLAYING_FIELD_HEIGHT: i32 = 700;
pub const PLAYING_FIELD_WIDTH: i32 = 1000;
pub const PROP_METRES_PER_MINUTE: f64 = 2.519467213;
pub const PROP_TACKLES_PER_MINUTE: f64 = 0.563770492;
pub const PROP_TRIES_PER_MINUTE: f64 = 0.001212746;
pub const SECOND_HALF_INDEX: i32 = 1;
pub const SOLVER_INITIAL_GRADIENT_NUMBER_OF_SIMULATIONS: i32 = 15000;
pub const STARTING_TACKLE: i32 = 1;
pub const TACKLES_PER_SET: i32 = 6;
pub const TRY_POINTS: i32 = 4;
pub const TRY_SCORER_DEFAULT_INDEXES: i32 = 1;
pub const TRY_SCORER_MATCH_INDEXES: i32 = 15;
pub const TWO_POINT_FIELD_GOAL_DISTANCE: i32 = 400;
pub const TWO_POINT_FIELD_GOAL_POINTS: i32 = 2;
pub const YELLOW_CARD_SECONDS: i32 = 600;
lazy_static! {
    pub static ref CONVERSION_X_VALUES: Vec<i32> = vec![
        769, 773, 779, 788, 801, 823, 845, 866, 878, 890, 890, 882, 868, 847, 825, 801, 786, 779,
        771, 769
    ];
    pub static ref GOAL_LINE_Y_VALUES: Vec<(i32, i32)> = vec![
        (0, 113),
        (113, 226),
        (226, 339),
        (339, 452),
        (452, 565),
        (565, 678),
        (678, 700)
    ];
    pub static ref GOAL_LINE_ZONE_WEIGHTS: Vec<Vec<f64>> = vec![
        vec![
            0.338255506,
            0.161521868,
            0.028635414,
            0.011633486,
            0.008945708,
            0.063982141,
            0.059955556,
            0.028635414,
            0.008948757,
            0.003132014,
            0.040716185,
            0.043848199,
            0.022818671,
            0.016107357,
            0.0035793,
            0.038031456,
            0.038478742,
            0.024161543,
            0.013869913,
            0.005369458,
            0.015660071,
            0.012324,
            0.005722,
            0.003967,
            0.0017
        ],
        vec![
            0.006393969,
            0.065970006,
            0.021313621,
            0.033491996,
            0.005074616,
            0.07510408,
            0.08931277,
            0.02841738,
            0.039581769,
            0.008118916,
            0.082209011,
            0.099462002,
            0.042627242,
            0.038566612,
            0.008118916,
            0.061910548,
            0.079163538,
            0.031462853,
            0.024357922,
            0.004059458,
            0.050746158,
            0.049731001,
            0.035522311,
            0.016239005,
            0.003044301
        ],
        vec![
            0.04926153,
            0.045038504,
            0.028853258,
            0.021815592,
            0.00492562,
            0.065446776,
            0.068261416,
            0.027445938,
            0.020408272,
            0.00281464,
            0.071077122,
            0.064743116,
            0.023222912,
            0.016186312,
            0.00281464,
            0.038705564,
            0.033075218,
            0.031667898,
            0.021111932,
            0.00211098,
            0.10696698,
            0.098521994,
            0.084447728,
            0.067557756,
            0.0035183
        ],
        vec![
            0.10696698,
            0.098521994,
            0.084447728,
            0.067557756,
            0.0035183,
            0.038705564,
            0.033075218,
            0.031667898,
            0.021111932,
            0.00211098,
            0.071077122,
            0.064743116,
            0.023222912,
            0.016186312,
            0.00281464,
            0.065446776,
            0.068261416,
            0.027445938,
            0.020408272,
            0.00281464,
            0.04926153,
            0.045038504,
            0.028853258,
            0.021815592,
            0.00492562
        ],
        vec![
            0.050746158,
            0.049731001,
            0.035522311,
            0.016239005,
            0.003044301,
            0.061910548,
            0.079163538,
            0.031462853,
            0.024357922,
            0.004059458,
            0.082209011,
            0.099462002,
            0.042627242,
            0.038566612,
            0.008118916,
            0.07510408,
            0.08931277,
            0.02841738,
            0.039581769,
            0.008118916,
            0.006393969,
            0.065970006,
            0.021313621,
            0.033491996,
            0.005074616
        ],
        vec![
            0.015660071,
            0.012324,
            0.005722,
            0.003961,
            0.0017,
            0.038031456,
            0.038478742,
            0.024161543,
            0.013869913,
            0.005369458,
            0.040716185,
            0.043848199,
            0.022818671,
            0.016107357,
            0.0035793,
            0.063982141,
            0.059955556,
            0.028635414,
            0.008948757,
            0.003132014,
            0.338255506,
            0.161521868,
            0.028635414,
            0.011633486,
            0.008949708
        ]
    ];
    pub static ref GRID_RESULT: Vec<String> = vec![
        "A1".to_string(),
        "A2".to_string(),
        "A3".to_string(),
        "A4".to_string(),
        "A5".to_string(),
        "A6".to_string(),
        "B1".to_string(),
        "B2".to_string(),
        "B3".to_string(),
        "B4".to_string(),
        "B5".to_string(),
        "B6".to_string(),
        "C1".to_string(),
        "C2".to_string(),
        "C3".to_string(),
        "C4".to_string(),
        "C5".to_string(),
        "C6".to_string(),
        "D1".to_string(),
        "D2".to_string(),
        "D3".to_string(),
        "D4".to_string(),
        "D5".to_string(),
        "D6".to_string(),
        "E1".to_string(),
        "E2".to_string(),
        "E3".to_string(),
        "E4".to_string(),
        "E5".to_string(),
        "E6".to_string(),
        "F1".to_string(),
        "F2".to_string(),
        "F3".to_string(),
        "F4".to_string(),
        "F5".to_string(),
        "F6".to_string(),
        "G1".to_string(),
        "G2".to_string(),
        "G3".to_string(),
        "G4".to_string(),
        "G5".to_string(),
        "G6".to_string(),
        "H1".to_string(),
        "H2".to_string(),
        "H3".to_string(),
        "H4".to_string(),
        "H5".to_string(),
        "H6".to_string(),
        "I1".to_string(),
        "I2".to_string(),
        "I3".to_string(),
        "I4".to_string(),
        "I5".to_string(),
        "I6".to_string(),
        "J1".to_string(),
        "J2".to_string(),
        "J3".to_string(),
        "J4".to_string(),
        "J5".to_string(),
        "J6".to_string(),
        "ZA1".to_string(),
        "ZA2".to_string(),
        "ZA3".to_string(),
        "ZA4".to_string(),
        "ZA5".to_string(),
        "ZA6".to_string(),
        "ZJ1".to_string(),
        "ZJ2".to_string(),
        "ZJ3".to_string(),
        "ZJ4".to_string(),
        "ZJ5".to_string(),
        "ZJ6".to_string()
    ];
    pub static ref KICKOFF_RESULTS: Vec<String> = vec![
        "A1KickAway".to_string(),
        "A1Retain".to_string(),
        "A2KickAway".to_string(),
        "A2Retain".to_string(),
        "A4KickAway".to_string(),
        "A4Retain".to_string(),
        "A5Retain".to_string(),
        "B1KickAway".to_string(),
        "B1Retain".to_string(),
        "B2KickAway".to_string(),
        "B2Retain".to_string(),
        "B3KickAway".to_string(),
        "B3Retain".to_string(),
        "B4KickAway".to_string(),
        "B4Retain".to_string(),
        "B5KickAway".to_string(),
        "B5Retain".to_string(),
        "B6KickAway".to_string(),
        "B6Retain".to_string(),
        "C1KickAway".to_string(),
        "C2KickAway".to_string(),
        "C2Retain".to_string(),
        "C3KickAway".to_string(),
        "C3Retain".to_string(),
        "C4KickAway".to_string(),
        "C4Retain".to_string(),
        "C5KickAway".to_string(),
        "C5Retain".to_string(),
        "C6KickAway".to_string(),
        "C6Retain".to_string(),
        "D1KickAway".to_string(),
        "D2KickAway".to_string(),
        "D3KickAway".to_string(),
        "D4KickAway".to_string(),
        "D4Retain".to_string(),
        "D5KickAway".to_string(),
        "D6KickAway".to_string(),
        "E1KickAway".to_string(),
        "E1Retain".to_string(),
        "E2KickAway".to_string(),
        "E2Retain".to_string(),
        "E3KickAway".to_string(),
        "E4KickAway".to_string(),
        "E4Retain".to_string(),
        "E5KickAway".to_string(),
        "E6KickAway".to_string(),
        "F1KickAway".to_string(),
        "F1Retain".to_string(),
        "F2KickAway".to_string(),
        "F2Retain".to_string(),
        "F3KickAway".to_string(),
        "F4KickAway".to_string(),
        "F4Retain".to_string(),
        "F5KickAway".to_string(),
        "F6KickAway".to_string(),
        "F6Retain".to_string(),
        "G1KickAway".to_string(),
        "G1Retain".to_string(),
        "G2KickAway".to_string(),
        "G2Retain".to_string(),
        "G3KickAway".to_string(),
        "G3Retain".to_string(),
        "G4KickAway".to_string(),
        "G4Retain".to_string(),
        "G5KickAway".to_string(),
        "G5Retain".to_string(),
        "G6KickAway".to_string(),
        "G6Retain".to_string(),
        "H1KickAway".to_string(),
        "H1Retain".to_string(),
        "H2KickAway".to_string(),
        "H2Retain".to_string(),
        "H3KickAway".to_string(),
        "H4KickAway".to_string(),
        "H4Retain".to_string(),
        "H5KickAway".to_string(),
        "H5Retain".to_string(),
        "H6KickAway".to_string(),
        "H6Retain".to_string(),
        "I1KickAway".to_string(),
        "I1Retain".to_string(),
        "I2KickAway".to_string(),
        "I2Retain".to_string(),
        "I3KickAway".to_string(),
        "I3Retain".to_string(),
        "I4KickAway".to_string(),
        "I4Retain".to_string(),
        "I5KickAway".to_string(),
        "I5Retain".to_string(),
        "I6KickAway".to_string(),
        "I6Retain".to_string(),
        "J1KickAway".to_string(),
        "J2KickAway".to_string(),
        "J3KickAway".to_string(),
        "J4KickAway".to_string(),
        "J5KickAway".to_string(),
        "J6KickAway".to_string(),
        "J6Retain".to_string()
    ];
    pub static ref KICKOFF_RETAIN_RESULTS: Vec<String> = vec![
        "A1Retain".to_string(),
        "A2Retain".to_string(),
        "A4Retain".to_string(),
        "A5Retain".to_string(),
        "B1Retain".to_string(),
        "B2Retain".to_string(),
        "B3Retain".to_string(),
        "B4Retain".to_string(),
        "B5Retain".to_string(),
        "B6Retain".to_string(),
        "C2Retain".to_string(),
        "C3Retain".to_string(),
        "C4Retain".to_string(),
        "C6Retain".to_string(),
        "D4Retain".to_string(),
        "E1Retain".to_string(),
        "E2Retain".to_string(),
        "E4Retain".to_string(),
        "F1Retain".to_string(),
        "F2Retain".to_string(),
        "F4Retain".to_string(),
        "F6Retain".to_string(),
        "G1Retain".to_string(),
        "G2Retain".to_string(),
        "G3Retain".to_string(),
        "G4Retain".to_string(),
        "G5Retain".to_string(),
        "G6Retain".to_string(),
        "H1Retain".to_string(),
        "H2Retain".to_string(),
        "H4Retain".to_string(),
        "H5Retain".to_string(),
        "H6Retain".to_string(),
        "I1Retain".to_string(),
        "I2Retain".to_string(),
        "I3Retain".to_string(),
        "I4Retain".to_string(),
        "I6Retain".to_string(),
        "J6Retain".to_string()
    ];
    pub static ref KICKOFF_TO_GRID_RESULT: HashMap<String, String> = {
        let mut map = HashMap::new();
        map.insert("A1Retain".to_string(), "A1".to_string());
        map.insert("A1KickAway".to_string(), "A1".to_string());
        map.insert("A2Retain".to_string(), "A2".to_string());
        map.insert("A2KickAway".to_string(), "A2".to_string());
        map.insert("A4Retain".to_string(), "A4".to_string());
        map.insert("A4KickAway".to_string(), "A4".to_string());
        map.insert("A5Retain".to_string(), "A5".to_string());
        map.insert("B1Retain".to_string(), "B1".to_string());
        map.insert("B1KickAway".to_string(), "B1".to_string());
        map.insert("B2Retain".to_string(), "B2".to_string());
        map.insert("B2KickAway".to_string(), "B2".to_string());
        map.insert("B3Retain".to_string(), "B3".to_string());
        map.insert("B3KickAway".to_string(), "B3".to_string());
        map.insert("B4Retain".to_string(), "B4".to_string());
        map.insert("B4KickAway".to_string(), "B4".to_string());
        map.insert("B5Retain".to_string(), "B5".to_string());
        map.insert("B5KickAway".to_string(), "B5".to_string());
        map.insert("B6Retain".to_string(), "B6".to_string());
        map.insert("B6KickAway".to_string(), "B6".to_string());
        map.insert("C1KickAway".to_string(), "C1".to_string());
        map.insert("C2Retain".to_string(), "C2".to_string());
        map.insert("C2KickAway".to_string(), "C2".to_string());
        map.insert("C3Retain".to_string(), "C3".to_string());
        map.insert("C3KickAway".to_string(), "C3".to_string());
        map.insert("C4Retain".to_string(), "C4".to_string());
        map.insert("C4KickAway".to_string(), "C4".to_string());
        map.insert("C5KickAway".to_string(), "C5".to_string());
        map.insert("C6Retain".to_string(), "C6".to_string());
        map.insert("C6KickAway".to_string(), "C6".to_string());
        map.insert("D1KickAway".to_string(), "D1".to_string());
        map.insert("D2KickAway".to_string(), "D2".to_string());
        map.insert("D3KickAway".to_string(), "D3".to_string());
        map.insert("D4Retain".to_string(), "D4".to_string());
        map.insert("D4KickAway".to_string(), "D4".to_string());
        map.insert("D5KickAway".to_string(), "D5".to_string());
        map.insert("D6KickAway".to_string(), "D6".to_string());
        map.insert("E1Retain".to_string(), "E1".to_string());
        map.insert("E1KickAway".to_string(), "E1".to_string());
        map.insert("E2Retain".to_string(), "E2".to_string());
        map.insert("E2KickAway".to_string(), "E2".to_string());
        map.insert("E3KickAway".to_string(), "E3".to_string());
        map.insert("E4Retain".to_string(), "E4".to_string());
        map.insert("E4KickAway".to_string(), "E4".to_string());
        map.insert("E5KickAway".to_string(), "E5".to_string());
        map.insert("E6KickAway".to_string(), "E6".to_string());
        map.insert("F1Retain".to_string(), "F1".to_string());
        map.insert("F1KickAway".to_string(), "F1".to_string());
        map.insert("F2Retain".to_string(), "F2".to_string());
        map.insert("F2KickAway".to_string(), "F2".to_string());
        map.insert("F3KickAway".to_string(), "F3".to_string());
        map.insert("F4Retain".to_string(), "F4".to_string());
        map.insert("F4KickAway".to_string(), "F4".to_string());
        map.insert("F5KickAway".to_string(), "F5".to_string());
        map.insert("F6Retain".to_string(), "F6".to_string());
        map.insert("F6KickAway".to_string(), "F6".to_string());
        map.insert("G1Retain".to_string(), "G1".to_string());
        map.insert("G1KickAway".to_string(), "G1".to_string());
        map.insert("G2Retain".to_string(), "G2".to_string());
        map.insert("G2KickAway".to_string(), "G2".to_string());
        map.insert("G3Retain".to_string(), "G3".to_string());
        map.insert("G3KickAway".to_string(), "G3".to_string());
        map.insert("G4Retain".to_string(), "G4".to_string());
        map.insert("G4KickAway".to_string(), "G4".to_string());
        map.insert("G5Retain".to_string(), "G5".to_string());
        map.insert("G5KickAway".to_string(), "G5".to_string());
        map.insert("G6Retain".to_string(), "G6".to_string());
        map.insert("G6KickAway".to_string(), "G6".to_string());
        map.insert("H1Retain".to_string(), "H1".to_string());
        map.insert("H1KickAway".to_string(), "H1".to_string());
        map.insert("H2Retain".to_string(), "H2".to_string());
        map.insert("H2KickAway".to_string(), "H2".to_string());
        map.insert("H3KickAway".to_string(), "H3".to_string());
        map.insert("H4Retain".to_string(), "H4".to_string());
        map.insert("H4KickAway".to_string(), "H4".to_string());
        map.insert("H5Retain".to_string(), "H5".to_string());
        map.insert("H5KickAway".to_string(), "H5".to_string());
        map.insert("H6Retain".to_string(), "H6".to_string());
        map.insert("H6KickAway".to_string(), "H6".to_string());
        map.insert("I1Retain".to_string(), "I1".to_string());
        map.insert("I1KickAway".to_string(), "I1".to_string());
        map.insert("I2Retain".to_string(), "I2".to_string());
        map.insert("I2KickAway".to_string(), "I2".to_string());
        map.insert("I3Retain".to_string(), "I3".to_string());
        map.insert("I3KickAway".to_string(), "I3".to_string());
        map.insert("I4Retain".to_string(), "I4".to_string());
        map.insert("I4KickAway".to_string(), "I4".to_string());
        map.insert("I5KickAway".to_string(), "I5".to_string());
        map.insert("I6Retain".to_string(), "I6".to_string());
        map.insert("I6KickAway".to_string(), "I6".to_string());
        map.insert("J1KickAway".to_string(), "J1".to_string());
        map.insert("J2KickAway".to_string(), "J2".to_string());
        map.insert("J3KickAway".to_string(), "J3".to_string());
        map.insert("J4KickAway".to_string(), "J4".to_string());
        map.insert("J5KickAway".to_string(), "J5".to_string());
        map.insert("J6Retain".to_string(), "J6".to_string());
        map.insert("J6KickAway".to_string(), "J6".to_string());
        map
    };
    pub static ref NEXT_PLAY_TYPES: Vec<String> = vec![
        "Pass".to_string(),
        "Run".to_string(),
        "RunTackle".to_string(),
        "RunTry".to_string(),
        "KickRetain".to_string(),
        "KickRetainTackle".to_string(),
        "KickRetainTry".to_string(),
        "KickTurnover".to_string(),
        "ErrorAttack".to_string(),
        "ErrorDefence".to_string(),
        "ConcededPenalty".to_string(),
        "WonPenalty".to_string(),
        "LineDropout".to_string(),
        "FieldGoalAttempt".to_string()
    ];
    pub static ref PLAYER_MODEL_POSITIONS: Vec<String> = vec![
        "FullBack".to_string(),
        "WingerOne".to_string(),
        "CentreOne".to_string(),
        "CentreTwo".to_string(),
        "WingerTwo".to_string(),
        "FiveEighth".to_string(),
        "HalfBack".to_string(),
        "PropOne".to_string(),
        "Hooker".to_string(),
        "PropTwo".to_string(),
        "SecondRowOne".to_string(),
        "SecondRowTwo".to_string(),
        "Lock".to_string()
    ];
    pub static ref PLAYER_POSITION_SEQUENCE: Vec<String> = vec![
        "FullBack".to_string(),
        "WingerOne".to_string(),
        "CentreOne".to_string(),
        "CentreTwo".to_string(),
        "WingerTwo".to_string(),
        "FiveEighth".to_string(),
        "HalfBack".to_string(),
        "PropOne".to_string(),
        "Hooker".to_string(),
        "PropTwo".to_string(),
        "SecondRowOne".to_string(),
        "SecondRowTwo".to_string(),
        "Lock".to_string()
    ];
    pub static ref X_VALUES: Vec<(i32, i32)> = vec![
        (0, 100),
        (100, 200),
        (200, 300),
        (300, 400),
        (400, 500),
        (500, 600),
        (600, 700),
        (700, 800),
        (800, 900),
        (900, 1000),
        (-100, 1),
        (1000, 1100)
    ];
    pub static ref X_VALUES_AWAY: Vec<(i32, i32)> = vec![
        (900, 1000),
        (800, 900),
        (700, 800),
        (600, 700),
        (500, 600),
        (400, 500),
        (300, 400),
        (200, 300),
        (100, 200),
        (0, 100),
        (1000, 1100),
        (-100, 1)
    ];
    pub static ref Y_VALUES: Vec<(i32, i32)> = vec![
        (0, 118),
        (118, 234),
        (234, 351),
        (351, 468),
        (468, 584),
        (584, 700)
    ];
    pub static ref Y_VALUES_AWAY: Vec<(i32, i32)> = vec![
        (584, 700),
        (468, 584),
        (351, 468),
        (234, 351),
        (118, 234),
        (0, 118)
    ];
}
use lazy_static::lazy_static;
use std::collections::HashMap;
