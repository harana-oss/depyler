#[doc = "// NOTE: Map Python module '__future__'()"]
use rand as random;
#[derive(Debug, Clone)]
pub struct ZeroDivisionError {
    message: String,
}
impl std::fmt::Display for ZeroDivisionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "division by zero: {}", self.message)
    }
}
impl std::error::Error for ZeroDivisionError {}
impl ZeroDivisionError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
#[derive(Debug, Clone)]
pub struct IndexError {
    message: String,
}
impl std::fmt::Display for IndexError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "index out of range: {}", self.message)
    }
}
impl std::error::Error for IndexError {}
impl IndexError {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}
pub fn _goal_line_bucket(grid_coordinate: i32, k: f64) -> i32 {
    if grid_coordinate < GOAL_LINE_GRID_START_INDEX {
        return -1;
    }
    let y_band = grid_coordinate % 6;
    let weights = GOAL_LINE_ZONE_WEIGHTS
        .get(y_band as usize)
        .cloned()
        .unwrap();
    return sample(weights, k);
}
pub fn compute_conversion_location_from_grid(grid_coordinate: i32, k: f64) -> i32 {
    let bucket = _goal_line_bucket(grid_coordinate, k);
    if bucket < 0 {
        let _cse_temp_0 = CONVERSION_X_VALUES.len() as i32;
        let default_band = (_cse_temp_0 as f64) / (2 as f64);
        return CONVERSION_X_VALUES
            .get(default_band as usize)
            .cloned()
            .unwrap();
    }
    let bucket_row = (bucket as f64) / (5 as f64);
    let _cse_temp_1 = bucket_row * GOAL_LINE_Y_WIDTH + (GOAL_LINE_Y_WIDTH as f64) / (2 as f64);
    let _cse_temp_2 = (_cse_temp_1) as i32;
    let base_y = _cse_temp_2;
    let _cse_temp_3 = grid_coordinate % 6 * GOAL_LINE_Y_HEIGHT_INCREMENT;
    let goal_line_field_y = base_y + _cse_temp_3;
    let mut conversion_band = (goal_line_field_y as f64) / (35 as f64);
    let _cse_temp_4 = CONVERSION_X_VALUES.len() as i32;
    let _cse_temp_5 = f64::min(conversion_band, (_cse_temp_4 - 1) as f64);
    let _cse_temp_6 = f64::max((0) as f64, _cse_temp_5);
    conversion_band = _cse_temp_6;
    let conversion_location = CONVERSION_X_VALUES
        .get(conversion_band as usize)
        .cloned()
        .unwrap();
    return conversion_location;
}
pub fn goal_line_position(goal_line_index: i32, grid_index: i32) -> FieldPosition {
    let _cse_temp_0 = goal_line_index % 5 * GOAL_LINE_X_WIDTH;
    let _cse_temp_1 = PLAYING_FIELD_WIDTH + _cse_temp_0 + (GOAL_LINE_X_WIDTH as f64) / (2 as f64);
    let x = _cse_temp_1;
    let _cse_temp_2 = {
        let a = goal_line_index;
        let b = 5;
        let q = a / b;
        let r = a % b;
        let r_negative = r < 0;
        let b_negative = b < 0;
        let r_nonzero = r != 0;
        let signs_differ = r_negative != b_negative;
        let needs_adjustment = r_nonzero && signs_differ;
        if needs_adjustment {
            q - 1
        } else {
            q
        }
    } * GOAL_LINE_Y_WIDTH;
    let _cse_temp_3 = ((_cse_temp_2) as f64) + (GOAL_LINE_Y_WIDTH as f64) / (2 as f64);
    let _cse_temp_4 = (_cse_temp_3) as i32;
    let mut y = _cse_temp_4;
    let _cse_temp_5 = grid_index % 6 * GOAL_LINE_Y_HEIGHT_INCREMENT;
    y = y + _cse_temp_5;
    return FieldPosition::new((x) as i32, y);
}
pub fn convert_field_position(state: &State, grid_result: String, team: &Team) -> FieldPosition {
    let _cse_temp_0 = GRID_RESULT::index(grid_result);
    let y_position = _cse_temp_0 % 6;
    let x_position = {
        let a = _cse_temp_0;
        let b = 6;
        let q = a / b;
        let r = a % b;
        let r_negative = r < 0;
        let b_negative = b < 0;
        let r_nonzero = r != 0;
        let signs_differ = r_negative != b_negative;
        let needs_adjustment = r_nonzero && signs_differ;
        if needs_adjustment {
            q - 1
        } else {
            q
        }
    };
    let y_range;
    let x_range;
    if *team == Team.Home {
        x_range = X_VALUES.get(x_position as usize).cloned().unwrap();
        y_range = Y_VALUES.get(y_position as usize).cloned().unwrap();
    } else {
        x_range = X_VALUES_AWAY.get(x_position as usize).cloned().unwrap();
        y_range = Y_VALUES_AWAY.get(y_position as usize).cloned().unwrap();
    }
    return FieldPosition::new(
        x_range.get(0usize).cloned().unwrap(),
        y_range.get(1usize).cloned().unwrap(),
    );
}
pub fn derive_grid_coordinate(position: &FieldPosition, team: &Team) -> i32 {
    let x_ranges;
    let y_ranges;
    if *team == Team.Away {
        x_ranges = X_VALUES_AWAY;
        y_ranges = Y_VALUES_AWAY;
    } else {
        x_ranges = X_VALUES;
        y_ranges = Y_VALUES;
    }
    let x_index = _resolve_index(position.x, x_ranges);
    let y_index = _resolve_index(position.y, y_ranges);
    let _cse_temp_0 = (x_index < 0) || (y_index < 0);
    if _cse_temp_0 {
        return -1;
    }
    return x_index * 6 + y_index;
}
pub fn get_goal_line_coordinate(state: &State) -> i32 {
    let grid_coordinate = derive_grid_coordinate(&state.ball_location, &state.team_in_possession);
    if grid_coordinate < 0 {
        return 65;
    }
    return 65 + grid_coordinate % 6;
}
pub fn _resolve_index(coordinate: i32, ranges: Vec<(i32, i32)>) -> i32 {
    for (index, range_bounds) in ranges
        .iter()
        .enumerate()
        .map(|(i, x)| (i as i32, x.clone()))
    {
        let index = index as i32;
        let (lower, upper) = range_bounds;
        if (lower <= coordinate) && (coordinate < upper) {
            return index;
        }
    }
    return -1;
}
