use std::{fs::File, io::Read, time::Duration};

use rdkafka::{
    ClientConfig,
    producer::{FutureProducer, FutureRecord},
};
use simulator_games::{
    contracts::RunModelRequest,
    nrl::{
        executor::Executor,
        result::{SubModelResultProcessor, SubmodelResultRecorder},
    },
};

use clap::Parser;
use prost::Message;

#[derive(Parser)]
#[command(name = "simulator_cli")]
#[command(about = "A CLI tool to run NRL simulations and generate results")]
#[command(version = "1.0")]
struct Cli {
    #[arg(short, long)]
    input: String,

    #[arg(short, long, default_value_t = 15000)]
    rounds: usize,

    #[arg(short, long)]
    output: String,
}

#[tokio::main(flavor = "current_thread")]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let cli = Cli::parse();

    let input = cli.input;
    let output = cli.output;

    let mut file = File::open(input)?;
    let mut buf = Vec::new();
    file.read_to_end(&mut buf)?;

    let rmr = RunModelRequest::decode(&buf[..])
        .map_err(|e| format!("Failed to decode RunModelRequest: {}", e))?;

    let executor = Executor::new();

    let res = executor
        .run_simulation(rmr, Some(cli.rounds))
        .map_err(|e| format!("Simulation execution failed: {}", e))?;

    let sample_output: Vec<SubModelResultProcessor> = res.clone().into_iter().take(1).collect();

    let res_writer = SubmodelResultRecorder { rows: res };

    res_writer.to_csv_file(&output)?;

    let base_dir = if let Ok(manifest_dir) = std::env::var("CARGO_MANIFEST_DIR") {
        std::path::PathBuf::from(manifest_dir)
    } else {
        std::env::current_dir()?
            .parent()
            .unwrap()
            .parent()
            .unwrap()
            .to_path_buf()
    };

    let ca_cert_path = base_dir.join("simulator_cli/kafka_cred/AmazonRootCA1.pem");
    let client_cert_path = base_dir.join("simulator_cli/kafka_cred/certificate.pem");
    let client_key_path = base_dir.join("simulator_cli/kafka_cred/kafka-client-key.pem");

    println!("\nCreating Kafka producer...");

    let producer: FutureProducer = ClientConfig::new()
        .set(
            "bootstrap.servers",
            "b-1.dhfeedsinfra.k6emcj.c2.kafka.ap-southeast-2.amazonaws.com:9094",
        )
        .set("security.protocol", "SSL")
        .set("ssl.ca.location", ca_cert_path.to_str().unwrap())
        .set(
            "ssl.certificate.location",
            client_cert_path.to_str().unwrap(),
        )
        .set("ssl.key.location", client_key_path.to_str().unwrap())
        .create()
        .expect("Failed to create Kafka producer");

    let topic = "quants.nrl.matrix";
    let key = "output_matrix";
    let payload = serde_json::to_string(&sample_output)
        .map_err(|e| format!("Failed to serialize output: {}", e))?;

    println!("\nStart ending msg...");

    let delivery_status = producer
        .send(
            FutureRecord::to(topic).payload(&payload).key(key),
            Duration::from_secs(5),
        )
        .await
        .map_err(|_| "Failed to send message to Kafka".to_owned())?;

    println!("Delivery status: {:?}", delivery_status);

    Ok(())
}
