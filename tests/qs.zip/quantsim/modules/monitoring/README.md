# Quantsim Monitoring Module

A thread-safe monitoring module for tracking function execution metrics including call counts and execution times.

## Features

- **Count Tracking**: Track the number of times functions are called
- **Timing Metrics**: Record execution times for performance monitoring
- **Thread-Safe**: Built with `RwLock` for concurrent access
- **Statistics**: Calculate min, max, mean, median, and sum for timing data

## Usage

The monitoring module is automatically integrated into functions using the `#[step]`, `#[game]`, or similar macros via the macro system.

### Basic Usage

```rust
use quantsim_monitoring::MonitoringManager;

let monitor = MonitoringManager::new();

// Track function invocations
monitor.count("my_function", 1);

// Track execution time
monitor.time("my_function", 0.042); // 42ms

// Retrieve metrics
assert_eq!(monitor.get_count("my_function"), Some(1));
```

### Getting Statistics

```rust
let monitor = MonitoringManager::new();

// Record some timing data
monitor.time("process_data", 0.5);
monitor.time("process_data", 1.0);
monitor.time("process_data", 0.75);

// Get a snapshot
let snapshot = monitor.snapshot();

// Calculate statistics
if let Some(stats) = snapshot.timing_stats("process_data") {
    println!("Count: {}", stats.count);
    println!("Mean: {:.3}s", stats.mean);
    println!("Min: {:.3}s", stats.min);
    println!("Max: {:.3}s", stats.max);
    println!("Median: {:.3}s", stats.median);
}
```

### Automatic Integration

When you use macros like `#[step]`, monitoring is automatically added:

```rust
#[step]
pub fn my_step(state: &mut State) -> Result<(), Error> {
    // Your function logic here
    Ok(())
}
```

This will automatically:
1. Increment the call counter for "my_step"
2. Record the execution time for "my_step"

## API Reference

### `MonitoringManager`

- `new()` - Create a new monitoring manager
- `count(name: &str, value: u64)` - Increment a counter
- `time(name: &str, duration: f64)` - Record a timing in seconds
- `get_count(name: &str) -> Option<u64>` - Get current count
- `get_times(name: &str) -> Option<Vec<f64>>` - Get all recorded times
- `snapshot() -> MonitoringSnapshot` - Get a snapshot of all metrics
- `reset()` - Clear all metrics

### `MonitoringSnapshot`

- `timing_stats(name: &str) -> Option<TimingStats>` - Calculate timing statistics

### `TimingStats`

- `count: usize` - Number of measurements
- `sum: f64` - Total time
- `mean: f64` - Average time
- `min: f64` - Minimum time
- `max: f64` - Maximum time
- `median: f64` - Median time
