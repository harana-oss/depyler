#[cfg(test)]
mod tests {
    use crate::MonitoringManager;

    #[test]
    fn test_count() {
        let monitor = MonitoringManager::new();

        monitor.count("test_fn", 1);
        assert_eq!(monitor.get_count("test_fn"), Some(1));

        monitor.count("test_fn", 5);
        assert_eq!(monitor.get_count("test_fn"), Some(6));
    }

    #[test]
    fn test_time() {
        let monitor = MonitoringManager::new();

        monitor.time("test_fn", 0.5);
        monitor.time("test_fn", 1.0);
        monitor.time("test_fn", 0.75);

        let times = monitor.get_times("test_fn").unwrap();
        assert_eq!(times.len(), 3);
        assert_eq!(times, vec![0.5, 1.0, 0.75]);
    }

    #[test]
    fn test_snapshot() {
        let monitor = MonitoringManager::new();

        monitor.count("fn1", 10);
        monitor.count("fn2", 20);
        monitor.time("fn1", 1.5);
        monitor.time("fn2", 2.5);

        let snapshot = monitor.snapshot();
        assert_eq!(snapshot.counts.get("fn1"), Some(&10));
        assert_eq!(snapshot.counts.get("fn2"), Some(&20));
        assert!(snapshot.times.get("fn1").is_some());
        assert!(snapshot.times.get("fn2").is_some());
    }

    #[test]
    fn test_timing_stats() {
        let monitor = MonitoringManager::new();

        monitor.time("test_fn", 1.0);
        monitor.time("test_fn", 2.0);
        monitor.time("test_fn", 3.0);
        monitor.time("test_fn", 4.0);
        monitor.time("test_fn", 5.0);

        let snapshot = monitor.snapshot();
        let stats = snapshot.timing_stats("test_fn").unwrap();

        assert_eq!(stats.count, 5);
        assert_eq!(stats.sum, 15.0);
        assert_eq!(stats.mean, 3.0);
        assert_eq!(stats.min, 1.0);
        assert_eq!(stats.max, 5.0);
        assert_eq!(stats.median, 3.0);
    }

    #[test]
    fn test_reset() {
        let monitor = MonitoringManager::new();

        monitor.count("test_fn", 10);
        monitor.time("test_fn", 1.5);

        assert!(monitor.get_count("test_fn").is_some());
        assert!(monitor.get_times("test_fn").is_some());

        monitor.reset();

        assert!(monitor.get_count("test_fn").is_none());
        assert!(monitor.get_times("test_fn").is_none());
    }
}
