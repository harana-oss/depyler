use std::collections::HashMap;
use std::sync::RwLock;

#[cfg(test)]
mod tests;

pub struct MonitoringManager {
    counts: RwLock<HashMap<String, u64>>,
    times: RwLock<HashMap<String, Vec<f64>>>,
}

impl MonitoringManager {
    pub fn new() -> Self {
        Self {
            counts: RwLock::new(HashMap::new()),
            times: RwLock::new(HashMap::new()),
        }
    }

    pub fn count(&self, name: &str, value: u64) {
        let mut counts = self.counts.write().unwrap();
        *counts.entry(name.to_string()).or_insert(0) += value;
    }

    pub fn time(&self, name: &str, duration: f64) {
        let mut times = self.times.write().unwrap();
        times
            .entry(name.to_string())
            .or_insert_with(Vec::new)
            .push(duration);
    }

    pub fn get_count(&self, name: &str) -> Option<u64> {
        let counts = self.counts.read().unwrap();
        counts.get(name).copied()
    }

    pub fn get_times(&self, name: &str) -> Option<Vec<f64>> {
        let times = self.times.read().unwrap();
        times.get(name).cloned()
    }

    pub fn snapshot(&self) -> MonitoringSnapshot {
        let counts = self.counts.read().unwrap();
        let times = self.times.read().unwrap();

        MonitoringSnapshot {
            counts: counts.clone(),
            times: times.clone(),
        }
    }

    pub fn reset(&self) {
        let mut counts = self.counts.write().unwrap();
        let mut times = self.times.write().unwrap();
        counts.clear();
        times.clear();
    }
}

impl Default for MonitoringManager {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone)]
pub struct MonitoringSnapshot {
    pub counts: HashMap<String, u64>,
    pub times: HashMap<String, Vec<f64>>,
}

impl MonitoringSnapshot {
    pub fn timing_stats(&self, name: &str) -> Option<TimingStats> {
        self.times.get(name).map(|times| {
            if times.is_empty() {
                return TimingStats::default();
            }

            let sum: f64 = times.iter().sum();
            let count = times.len();
            let mean = sum / count as f64;

            let mut sorted = times.clone();
            sorted.sort_by(|a, b| a.partial_cmp(b).unwrap());

            let min = *sorted.first().unwrap();
            let max = *sorted.last().unwrap();
            let median = if count % 2 == 0 {
                (sorted[count / 2 - 1] + sorted[count / 2]) / 2.0
            } else {
                sorted[count / 2]
            };

            TimingStats {
                count,
                sum,
                mean,
                min,
                max,
                median,
            }
        })
    }
}

#[derive(Debug, Clone, Default)]
pub struct TimingStats {
    pub count: usize,
    pub sum: f64,
    pub mean: f64,
    pub min: f64,
    pub max: f64,
    pub median: f64,
}
