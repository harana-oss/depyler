use bitvec::{order::Msb0, vec::BitVec};
use serde::{Deserialize, Deserializer, Serialize, Serializer};
use std::collections::HashMap;
use strum::IntoEnumIterator;

use crate::nrl::result::{BinResultTypes, IntResultTypes};

pub trait RowOps<T> {
    fn get(&self, key: &str) -> Option<T>;
    fn contains_key(&self, key: &str) -> bool;
    fn keys(&self) -> Box<dyn Iterator<Item = &String> + '_>;
    fn len(&self) -> usize;
    fn is_empty(&self) -> bool;
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BinaryRow {
    #[serde(
        serialize_with = "serialize_bitvec",
        deserialize_with = "deserialize_bitvec"
    )]
    pub row: BitVec<u8, Msb0>,
    pub mapping: HashMap<String, usize>,
}

impl BinaryRow {
    pub fn new(enum_size: usize) -> Self {
        let mut row = BitVec::with_capacity(enum_size);
        row.resize(enum_size, false);
        let mut mapping: HashMap<String, usize> = HashMap::new();
        for i in BinResultTypes::iter() {
            mapping.insert(i.to_string(), 0);
        }

        Self { row, mapping }
    }

    pub fn insert_into_bitvec(&mut self, key: String, position: usize, value: bool) {
        self.mapping.insert(key, position);
        self.row.set(position, value);
    }
}

impl RowOps<bool> for BinaryRow {
    fn get(&self, key: &str) -> Option<bool> {
        self.mapping
            .get(key)
            .and_then(|&index| self.row.get(index))
            .map(|bit| *bit)
    }

    fn contains_key(&self, key: &str) -> bool {
        self.mapping.contains_key(key)
    }

    fn keys(&self) -> Box<dyn Iterator<Item = &String> + '_> {
        Box::new(self.mapping.keys())
    }

    fn len(&self) -> usize {
        self.row.len()
    }

    fn is_empty(&self) -> bool {
        self.row.is_empty()
    }
}

fn serialize_bitvec<S>(bitvec: &BitVec<u8, Msb0>, serializer: S) -> Result<S::Ok, S::Error>
where
    S: Serializer,
{
    let bytes: Vec<u8> = bitvec.as_raw_slice().to_vec();
    bytes.serialize(serializer)
}

fn deserialize_bitvec<'de, D>(deserializer: D) -> Result<BitVec<u8, Msb0>, D::Error>
where
    D: Deserializer<'de>,
{
    let bytes: Vec<u8> = Vec::deserialize(deserializer)?;
    Ok(BitVec::from_vec(bytes))
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IntegerRow {
    pub row: HashMap<String, i32>,
}

impl IntegerRow {
    pub fn new(size: usize) -> Self {
        let mut mapping = HashMap::with_capacity(size);
        for i in IntResultTypes::iter() {
            mapping.insert(i.to_string(), 0);
        }

        Self { row: mapping }
    }

    pub fn insert(&mut self, key: String, value: i32) {
        self.row.insert(key, value);
    }
}

impl RowOps<i32> for IntegerRow {
    fn get(&self, key: &str) -> Option<i32> {
        self.row.get(key).copied()
    }

    fn contains_key(&self, key: &str) -> bool {
        self.row.contains_key(key)
    }

    fn keys(&self) -> Box<dyn Iterator<Item = &String> + '_> {
        Box::new(self.row.keys())
    }

    fn len(&self) -> usize {
        self.row.len()
    }

    fn is_empty(&self) -> bool {
        self.row.is_empty()
    }
}

#[derive(Debug, Clone)]
pub struct FloatRow {
    pub row: HashMap<String, f64>,
}

impl FloatRow {
    pub fn new(size: usize) -> Self {
        Self {
            row: HashMap::with_capacity(size),
        }
    }

    pub fn insert(&mut self, key: String, value: f64) {
        self.row.insert(key, value);
    }
}

impl RowOps<f64> for FloatRow {
    fn get(&self, key: &str) -> Option<f64> {
        self.row.get(key).copied()
    }

    fn contains_key(&self, key: &str) -> bool {
        self.row.contains_key(key)
    }

    fn keys(&self) -> Box<dyn Iterator<Item = &String> + '_> {
        Box::new(self.row.keys())
    }

    fn len(&self) -> usize {
        self.row.len()
    }

    fn is_empty(&self) -> bool {
        self.row.is_empty()
    }
}
