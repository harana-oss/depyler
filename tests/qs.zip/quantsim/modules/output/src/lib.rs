use dashmap::DashMap;
use std::collections::HashMap;
use std::sync::OnceLock;

pub struct OutputManager {
    int_outputs: DashMap<String, i32>,
    bool_outputs: DashMap<String, bool>,
}

impl OutputManager {
    pub fn new() -> Self {
        Self {
            int_outputs: DashMap::new(),
            bool_outputs: DashMap::new(),
        }
    }

    pub fn record_int(&self, key: String, value: i32) {
        log::info!("Recording int output: {} = {}\n", key, value);
        self.int_outputs.insert(key, value);
    }

    pub fn record_bool(&self, key: String, value: bool) {
        log::info!("Recording bool output: {} = {}\n", key, value);
        self.bool_outputs.insert(key, value);
    }

    pub fn get_int_outputs(&self) -> HashMap<String, i32> {
        self.int_outputs.iter().map(|r| (r.key().clone(), *r.value())).collect()
    }

    pub fn get_bool_outputs(&self) -> HashMap<String, bool> {
        self.bool_outputs.iter().map(|r| (r.key().clone(), *r.value())).collect()
    }

    pub fn clear(&self) {
        self.int_outputs.clear();
        self.bool_outputs.clear();
    }
}

impl Default for OutputManager {
    fn default() -> Self {
        Self::new()
    }
}

static OUTPUT_MANAGER: OnceLock<OutputManager> = OnceLock::new();

pub fn set_output_manager(manager: OutputManager) {
    let _ = OUTPUT_MANAGER.set(manager);
}

pub fn get_output_manager() -> &'static OutputManager {
    OUTPUT_MANAGER.get_or_init(OutputManager::new)
}

pub fn record_int(key: String, value: i32) {
    get_output_manager().record_int(key, value);
}

pub fn record_bool(key: String, value: bool) {
    get_output_manager().record_bool(key, value);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_record_int() {
        let manager = OutputManager::new();
        manager.record_int("test_key".to_string(), 42);

        let outputs = manager.get_int_outputs();
        assert_eq!(outputs.get("test_key"), Some(&42));
    }

    #[test]
    fn test_record_bool() {
        let manager = OutputManager::new();
        manager.record_bool("test_flag".to_string(), true);

        let outputs = manager.get_bool_outputs();
        assert_eq!(outputs.get("test_flag"), Some(&true));
    }

    #[test]
    fn test_clear() {
        let manager = OutputManager::new();
        manager.record_int("key1".to_string(), 10);
        manager.record_bool("key2".to_string(), false);

        manager.clear();

        assert!(manager.get_int_outputs().is_empty());
        assert!(manager.get_bool_outputs().is_empty());
    }

    #[test]
    fn test_global_manager() {
        record_int("global_test".to_string(), 100);
        record_bool("global_flag".to_string(), true);

        let manager = get_output_manager();
        let int_outputs = manager.get_int_outputs();
        let bool_outputs = manager.get_bool_outputs();

        assert_eq!(int_outputs.get("global_test"), Some(&100));
        assert_eq!(bool_outputs.get("global_flag"), Some(&true));
    }
}