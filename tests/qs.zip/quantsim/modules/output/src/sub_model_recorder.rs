use crate::nrl::{
    model_data::{BasePlayer, MatchPeriod, PlayerOps, PointType, Team, TeamStatistics, constants},
    result::{
        BinResultTypes, BinaryRow, IntResultTypes, IntegerRow, PlayerStatsType, ResultRecorderError,
    },
    states::SimulationState,
};

use csv::Writer;
use rand::random_range;
use serde::{Deserialize, Serialize};
use std::io::Write;

const MINUTE_INTERVALS: [i32; 5] = [10, 20, 30, 50, 60];
const RACE_TO_POINTS: [i32; 7] = [10, 15, 20, 25, 30, 35, 40];
const TRY_INDEXES: [i32; 15] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];

const FIRST_HALF_PERIOD: [MatchPeriod; 1] = [MatchPeriod::FirstHalf];
const SECOND_HALF_AND_EXTRA_TIME_PERIOD: [MatchPeriod; 2] =
    [MatchPeriod::SecondHalf, MatchPeriod::ExtraTime];
const TRIES_GROUP: [IntResultTypes; 6] = IntResultTypes::group_tries();
const MATCH_PLAYER_GROUP: [IntResultTypes; 102] = IntResultTypes::group_match_player_stats();
const FIRST_HALF_PLAYER_GROUP: [IntResultTypes; 34] =
    IntResultTypes::group_first_half_player_stats();
const SECOND_HALF_AND_EXTRA_TIME_PLAYER_GROUP: [IntResultTypes; 34] =
    IntResultTypes::group_second_half_and_extra_time_player_stats();
const MATCH_TRY_SCORER: [IntResultTypes; 15] = IntResultTypes::group_match_try_scorer();
const WIN_MINUTE_MATCH: [BinResultTypes; 10] = BinResultTypes::group_win_minutes();
const NTH_TRY_MATCH: [BinResultTypes; 30] = BinResultTypes::group_nth_try_match();
const RACE_TO_POINTS_MATCH: [BinResultTypes; 14] = BinResultTypes::group_first_to_points_match();

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SubModelResultProcessor {
    pub binary: BinaryRow,
    pub integer: IntegerRow,
    // #[allow(dead_code)]
    // pub float: FloatRow,
    pub state: SubModelResultProcessorState,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct SubModelResultProcessorState {
    pub match_last_try_time: i32,
    pub first_try_time: i32,
    pub home_first_try_time: i32,
    pub away_first_try_time: i32,
    pub unanwered_tries: i32,
    pub three_unanwered_tries: bool,
    pub match_first_to_score: Team,
    pub second_half_first_to_score: Team,
    pub extra_time_first_to_score: Team,
    pub match_last_to_score: Team,
    pub second_half_last_to_score_try: Team,
    pub match_last_to_score_try: Team,
    pub try_index: i32,
    pub second_half_try_index: i32,
    pub rng: u64,
}

impl SubModelResultProcessor {
    pub fn record_minute_interval(
        &mut self,
        minute_elapsed: i32,
        home_score: i32,
        away_score: i32,
    ) {
        for (minute_interval, win_minute_types) in
            MINUTE_INTERVALS.iter().zip(WIN_MINUTE_MATCH.chunks(2))
        {
            let reached_target = minute_elapsed >= *minute_interval;
            if !reached_target {
                return;
            }
            let home_won = home_score > away_score;
            let away_won = away_score > home_score;

            if let [win_minute_a, win_minute_b] = win_minute_types {
                self.record_bin_result(*win_minute_a, home_won);
                self.record_bin_result(*win_minute_b, away_won);
            }
        }
    }

    pub fn record_points_scored(
        &mut self,
        half_index: i32,
        point_type: PointType,
        seconds_elapsed: f64,
        team: Team,
        home_match_score: i32,
        away_match_score: i32,
    ) {
        self.state.match_last_to_score = team;

        if point_type == PointType::Try {
            self.state.try_index += 1;

            if !self.state.three_unanwered_tries {
                if team == self.state.match_last_to_score {
                    self.state.unanwered_tries += 1;
                } else {
                    self.state.unanwered_tries = 1
                }

                if self.state.unanwered_tries == 3 {
                    self.state.three_unanwered_tries = true;
                    self.record_bin_result(BinResultTypes::ThreeUnansweredTriesMatchBin, true);
                }
            }
        }

        self.state.match_last_to_score = team;
        self.state.match_last_try_time = seconds_elapsed_to_minute(seconds_elapsed as i32);

        // Process match try index
        self.process_match_try_index(team, self.state.try_index);
        //

        if self.state.first_try_time == 0 {
            self.state.first_try_time = seconds_elapsed_to_minute(seconds_elapsed as i32);
            self.record_int_result(
                IntResultTypes::FirstTryTimeMatchInt,
                self.state.first_try_time,
            );
        }

        if half_index == constants::SECOND_HALF_INDEX {
            self.state.second_half_try_index += 1;
            self.process_second_half_try_index(team, self.state.second_half_try_index);
        }

        if team == Team::Home && self.state.home_first_try_time == 0 {
            self.state.home_first_try_time = seconds_elapsed_to_minute(seconds_elapsed as i32);
            self.record_int_result(
                IntResultTypes::FirstTryTimeMatchAInt,
                self.state.home_first_try_time,
            );
        }

        if team == Team::Away && self.state.away_first_try_time == 0 {
            self.state.away_first_try_time = seconds_elapsed_to_minute(seconds_elapsed as i32);
            self.record_int_result(
                IntResultTypes::FirstTryTimeMatchBInt,
                self.state.away_first_try_time,
            );
        }

        if (self.state.second_half_last_to_score_try == Team::NotSet
            && (half_index == constants::SECOND_HALF_INDEX
                || half_index == constants::EXTRA_TIME_INDEX))
            || (self.state.second_half_last_to_score_try != Team::NotSet
                && half_index == constants::EXTRA_TIME_INDEX)
        {
            self.state.second_half_last_to_score_try = team;
            self.record_bin_result(
                BinResultTypes::FirstTryHalf2AndExtraTimeABin,
                team == Team::Home,
            );
            self.record_bin_result(
                BinResultTypes::FirstTryHalf2AndExtraTimeBBin,
                team == Team::Away,
            );
        }

        if self.state.match_first_to_score == Team::NotSet {
            self.state.match_first_to_score = team;
            self.record_bin_result(BinResultTypes::FirstToScoreMatchABin, team == Team::Home);
            self.record_bin_result(BinResultTypes::FirstToScoreMatchBBin, team == Team::Away);
        }

        if self.state.second_half_first_to_score == Team::NotSet
            && (half_index == constants::SECOND_HALF_INDEX
                || half_index == constants::EXTRA_TIME_INDEX)
        {
            self.state.second_half_first_to_score = team;
            self.record_bin_result(
                BinResultTypes::FirstToScoreHalf2AndExtraTimeABin,
                team == Team::Home,
            );
            self.record_bin_result(
                BinResultTypes::FirstToScoreHalf2AndExtraTimeBBin,
                team == Team::Away,
            );
        }

        if self.state.extra_time_first_to_score == Team::NotSet
            && half_index == constants::EXTRA_TIME_INDEX
        {
            self.state.extra_time_first_to_score = team;
            self.record_bin_result(
                BinResultTypes::FirstToScoreExtraTimeABin,
                team == Team::Home,
            );
            self.record_bin_result(
                BinResultTypes::FirstToScoreExtraTimeBBin,
                team == Team::Away,
            );
        }

        self.process_first_points_to_match(home_match_score, away_match_score);
    }

    pub fn record_end_of_match(
        &mut self,
        state: &mut SimulationState,
        team_index: (&[usize; 17], &[usize; 17]),
    ) {
        let home_stats = &state.game_statistics.home_statistics;
        let away_stats = &state.game_statistics.away_statistics;
        let home_period_stats = &state.game_statistics.home_statistics.period_statistics;
        let home_match_stats = &state.game_statistics.home_statistics.match_statistics;
        let away_period_stats = &state.game_statistics.away_statistics.period_statistics;
        let away_match_stats = &state.game_statistics.away_statistics.match_statistics;

        // Record wins, points and draws for relevant periods
        self.record_scores(home_stats, away_stats);
        self.record_bin_result(
            BinResultTypes::ExtraTimeOccurredMatchBin,
            state.is_extra_time,
        );
        //

        // Record last to score in match
        self.record_bin_result(
            BinResultTypes::LastToScoreMatchABin,
            self.state.match_last_to_score == Team::Home,
        );
        self.record_bin_result(
            BinResultTypes::LastToScoreMatchBBin,
            self.state.match_last_to_score == Team::Away,
        );
        //

        // Record team statistics for 1st half, 2nd half and match
        // let home_first_half_score = home_period_stats[constants::FIRST_HALF_INDEX as usize]
        //     .scores
        //     .tries;
        let home_first_half_score = if home_period_stats.is_empty() {
            0
        } else {
            home_period_stats[constants::FIRST_HALF_INDEX as usize]
                .scores
                .tries
        };
        // let away_first_half_score = away_period_stats[constants::FIRST_HALF_INDEX as usize]
        //     .scores
        //     .tries;
        let away_first_half_score = if away_period_stats.is_empty() {
            0
        } else {
            away_period_stats[constants::FIRST_HALF_INDEX as usize]
                .scores
                .tries
        };
        // let home_second_half_score = home_period_stats[constants::SECOND_HALF_INDEX as usize]
        //     .scores
        //     .tries;
        let home_second_half_score = if home_period_stats.is_empty() {
            0
        } else {
            home_period_stats[constants::SECOND_HALF_INDEX as usize]
                .scores
                .tries
        };
        // let away_second_half_score = away_period_stats[constants::SECOND_HALF_INDEX as usize]
        //     .scores
        //     .tries;
        let away_second_half_score = if away_period_stats.is_empty() {
            0
        } else {
            away_period_stats[constants::SECOND_HALF_INDEX as usize]
                .scores
                .tries
        };
        // mock
        // let home_first_half_score = 10;
        // let away_first_half_score = 5;
        // let home_second_half_score = 5;
        // let away_second_half_score = 2;
        let home_match_score_total = home_match_stats.scores.tries;
        let away_match_score_total = away_match_stats.scores.tries;
        let stat_types_values = [
            home_first_half_score,
            away_first_half_score,
            home_second_half_score,
            away_second_half_score,
            home_match_score_total,
            away_match_score_total,
        ];
        for (stat_type, &value) in TRIES_GROUP.iter().zip(stat_types_values.iter()) {
            self.record_int_result(*stat_type, value);
        }

        // Last to score try + time
        self.record_bin_result(
            BinResultTypes::LastToScoreMatchABin,
            self.state.match_last_to_score_try == Team::Home,
        );
        self.record_bin_result(
            BinResultTypes::LastToScoreMatchBBin,
            self.state.match_last_to_score_try == Team::Away,
        );
        self.record_int_result(
            IntResultTypes::LastTryTimeMatchInt,
            self.state.match_last_try_time,
        );
        //

        // Record player statistics for match
        if state.include_players {
            self.record_player_stats(state, team_index);
        }
        //

        // Record player of the match
        if state.player_of_the_match.is_some() {
            self.record_int_result(
                IntResultTypes::PlayerOfTheMatchInt,
                state.player_of_the_match.unwrap(),
            );
        }
        //
    }
}

impl SubModelResultProcessor {
    pub fn new(bin_size: usize, int_size: usize) -> Self {
        Self {
            binary: BinaryRow::new(bin_size),
            integer: IntegerRow::new(int_size),
            // float: FloatRow::new(float_size),
            state: SubModelResultProcessorState::default(),
        }
    }

    fn process_match_try_index(&mut self, scorer: Team, state_try_index: i32) {
        for (index, nth_try_types) in TRY_INDEXES.iter().zip(NTH_TRY_MATCH.chunks(2)) {
            let reached_target = state_try_index >= *index;
            if !reached_target {
                return;
            }

            if let [nth_try_types_a, nth_try_types_b] = nth_try_types {
                self.record_bin_result(*nth_try_types_a, scorer == Team::Home);
                self.record_bin_result(*nth_try_types_b, scorer == Team::Away);
            }
        }
    }

    fn process_second_half_try_index(&mut self, scorer: Team, state_try_index: i32) {
        let reached_target = state_try_index >= 1;
        if !reached_target {
            return;
        }

        self.record_bin_result(BinResultTypes::FirstTrySecondHalfABin, scorer == Team::Home);
        self.record_bin_result(BinResultTypes::FirstTrySecondHalfBBin, scorer == Team::Away);
    }

    fn process_first_points_to_match(&mut self, home_match_score: i32, away_match_score: i32) {
        for (index, race_to_point_types) in
            RACE_TO_POINTS.iter().zip(RACE_TO_POINTS_MATCH.chunks(2))
        {
            let reached_home = home_match_score >= *index;
            let reached_away = away_match_score >= *index;
            let reached_target = reached_home || reached_away;

            if !reached_target {
                return;
            }

            let only_one = reached_home ^ reached_away;

            if let [race_to_point_type_a, race_to_point_type_b] = race_to_point_types {
                self.record_bin_result(*race_to_point_type_a, reached_home && only_one);
                self.record_bin_result(*race_to_point_type_b, reached_away && only_one);
            }
        }
    }

    pub fn process_player_stats(
        &mut self,
        players: &mut [BasePlayer],
        player_index: &[usize; 17],
        player_stat_type: &PlayerStatsType,
        match_period: Option<&[MatchPeriod]>,
        team: Team,
    ) {
        let mut players_vec = Vec::new();
        for i in player_index {
            let index = player_index[*i] as i32;
            let index_mapping = index + 1;
            let v = players.get_player_with_index(index);
            players_vec.push((index, index_mapping, v));
        }

        match player_stat_type {
            PlayerStatsType::Match => {
                for (index, index_mapping, player) in players_vec.iter() {
                    self.process_player_stats_inner(
                        player,
                        *index,
                        *index_mapping,
                        player_stat_type,
                        match_period,
                        team,
                    );
                }
            }
            PlayerStatsType::FirstHalf => {
                for (index, index_mapping, player) in players_vec.iter() {
                    self.process_player_stats_inner(
                        player,
                        *index,
                        *index_mapping,
                        player_stat_type,
                        match_period,
                        team,
                    );
                }
            }
            PlayerStatsType::SecondHalfAndExtraTime => {
                for (index, index_mapping, player) in players_vec.iter() {
                    self.process_player_stats_inner(
                        player,
                        *index,
                        *index_mapping,
                        player_stat_type,
                        match_period,
                        team,
                    );
                }
            }
        }
    }

    pub fn process_player_stats_inner(
        &mut self,
        player: &BasePlayer,
        index: i32,
        index_mapping: i32,
        player_stat_type: &PlayerStatsType,
        match_period: Option<&[MatchPeriod]>,
        team: Team,
    ) {
        let mut tries = 0;
        let mut score = 0;
        let mut tog = 0;

        if let Some(mp) = match_period {
            for period in mp.iter() {
                let mut players = player.clone();
                let player_stats = &players.get_period_statistics()[*period as usize];
                tries += player_stats.tries;
                score += player_stats.score;
                tog += player_stats.time_on_field as i32;
            }
        } else {
            tries = player.match_statistics.tries;
            score = player.match_statistics.score;
            tog = player.match_statistics.time_on_field as i32;
        }

        match player_stat_type {
            PlayerStatsType::Match => {
                // self.record_int_dynamic_result(index, index_mapping, team, res_type, tries);
                // self.record_int_dynamic_result(index, index_mapping, team, res_type, score);
                // self.record_int_dynamic_result(index, index_mapping, team, res_type, tog);
                match team {
                    Team::Home => {
                        for res_type in MATCH_PLAYER_GROUP
                            .iter()
                            .take(51)
                            .collect::<Vec<_>>()
                            .chunks(3)
                        {
                            self.record_int_dynamic_result(
                                index,
                                index_mapping,
                                team,
                                res_type[0],
                                tries,
                            );
                            self.record_int_dynamic_result(
                                index,
                                index_mapping,
                                team,
                                res_type[1],
                                score,
                            );
                            self.record_int_dynamic_result(
                                index,
                                index_mapping,
                                team,
                                res_type[2],
                                tog,
                            );
                        }
                    }
                    Team::Away => {
                        for res_type in MATCH_PLAYER_GROUP
                            .iter()
                            .skip(51)
                            .take(51)
                            .collect::<Vec<_>>()
                            .chunks(3)
                        {
                            self.record_int_dynamic_result(
                                index,
                                index_mapping,
                                team,
                                res_type[0],
                                tries,
                            );
                            self.record_int_dynamic_result(
                                index,
                                index_mapping,
                                team,
                                res_type[1],
                                score,
                            );
                            self.record_int_dynamic_result(
                                index,
                                index_mapping,
                                team,
                                res_type[2],
                                tog,
                            );
                        }
                    }
                    _ => unreachable!(),
                }
            }
            PlayerStatsType::FirstHalf => {
                // self.record_int_dynamic_result(index, index_mapping, team, res_type, tries);
                match team {
                    Team::Home => {
                        for res_type in FIRST_HALF_PLAYER_GROUP.iter().take(17).collect::<Vec<_>>()
                        {
                            self.record_int_dynamic_result(
                                index,
                                index_mapping,
                                team,
                                res_type,
                                tries,
                            );
                        }
                    }
                    Team::Away => {
                        for res_type in FIRST_HALF_PLAYER_GROUP
                            .iter()
                            .skip(17)
                            .take(17)
                            .collect::<Vec<_>>()
                        {
                            self.record_int_dynamic_result(
                                index,
                                index_mapping,
                                team,
                                res_type,
                                tries,
                            );
                        }
                    }
                    _ => unreachable!(),
                }
            }
            PlayerStatsType::SecondHalfAndExtraTime => {
                // self.record_int_dynamic_result(index, index_mapping, team, res_type, tries);
                match team {
                    Team::Home => {
                        for res_type in SECOND_HALF_AND_EXTRA_TIME_PLAYER_GROUP
                            .iter()
                            .take(17)
                            .collect::<Vec<_>>()
                        {
                            self.record_int_dynamic_result(
                                index,
                                index_mapping,
                                team,
                                res_type,
                                tries,
                            );
                        }
                    }
                    Team::Away => {
                        for res_type in SECOND_HALF_AND_EXTRA_TIME_PLAYER_GROUP
                            .iter()
                            .skip(17)
                            .take(17)
                            .collect::<Vec<_>>()
                        {
                            self.record_int_dynamic_result(
                                index,
                                index_mapping,
                                team,
                                res_type,
                                tries,
                            );
                        }
                    }
                    _ => unreachable!(),
                }
            }
        }
    }

    pub fn record_player_stats(
        &mut self,
        state: &mut SimulationState,
        team_index: (&[usize; 17], &[usize; 17]),
    ) {
        let home_players = &state.home_players;
        let away_players = &state.away_players;

        self.process_player_stats(
            &mut home_players.clone(),
            team_index.0,
            &PlayerStatsType::Match,
            None,
            Team::Home,
        );
        self.process_player_stats(
            &mut away_players.clone(),
            team_index.1,
            &PlayerStatsType::Match,
            None,
            Team::Away,
        );
        self.process_player_stats(
            &mut home_players.clone(),
            team_index.0,
            &PlayerStatsType::FirstHalf,
            Some(&FIRST_HALF_PERIOD),
            Team::Home,
        );
        self.process_player_stats(
            &mut away_players.clone(),
            team_index.1,
            &PlayerStatsType::FirstHalf,
            Some(&FIRST_HALF_PERIOD),
            Team::Away,
        );
        self.process_player_stats(
            &mut home_players.clone(),
            team_index.0,
            &PlayerStatsType::SecondHalfAndExtraTime,
            Some(&SECOND_HALF_AND_EXTRA_TIME_PERIOD),
            Team::Home,
        );
        self.process_player_stats(
            &mut away_players.clone(),
            team_index.1,
            &PlayerStatsType::SecondHalfAndExtraTime,
            Some(&SECOND_HALF_AND_EXTRA_TIME_PERIOD),
            Team::Away,
        );

        // Match try scorers
        for (stat_type, &value) in MATCH_TRY_SCORER
            .iter()
            .zip(state.try_tracker.match_tries.try_scorers.iter())
        {
            self.record_int_result(*stat_type, value.unwrap_or(0));
        }
        //

        // Try scorer jerseys
        let home_first_try_jersey =
            if state.try_tracker.home_match_tries.try_scorers[0].unwrap() == 0 {
                None
            } else {
                Some(state.home_players.get_player_with_index(
                    state.try_tracker.home_match_tries.try_scorers[0].unwrap(),
                ))
            };
        let away_first_try_jersey =
            if state.try_tracker.away_match_tries.try_scorers[0].unwrap() == 0 {
                None
            } else {
                Some(state.away_players.get_player_with_index(
                    state.try_tracker.away_match_tries.try_scorers[0].unwrap(),
                ))
            };
        let match_first_try_jersey = if state.try_tracker.match_tries.try_scorers[0].unwrap() == 0 {
            None
        } else {
            Some(
                state
                    .home_players
                    .get_player_with_index(state.try_tracker.match_tries.try_scorers[0].unwrap()),
            )
        };
        let match_last_try_jersey = if state.try_tracker.match_tries.last_try_scorer.unwrap() == 0 {
            None
        } else {
            Some(
                state
                    .home_players
                    .get_player_with_index(state.try_tracker.match_tries.last_try_scorer.unwrap()),
            )
        };
        self.record_int_result(
            IntResultTypes::FirstTryScorerJerseyMatchAInt,
            if let Some(bp) = home_first_try_jersey {
                bp.jersey_number
            } else {
                0
            },
        );
        self.record_int_result(
            IntResultTypes::FirstTryScorerJerseyMatchBInt,
            if let Some(bp) = away_first_try_jersey {
                bp.jersey_number
            } else {
                0
            },
        );
        self.record_int_result(
            IntResultTypes::FirstTryScorerJerseyMatchInt,
            if let Some(bp) = match_first_try_jersey {
                bp.jersey_number
            } else {
                0
            },
        );
        self.record_int_result(
            IntResultTypes::LastTryScorerJerseyMatchInt,
            if let Some(bp) = match_last_try_jersey {
                bp.jersey_number
            } else {
                0
            },
        );
        //

        // Match first try scorer player
        let home_match_tries = state.try_tracker.home_match_tries.try_scorers[0];
        let away_match_tries = state.try_tracker.away_match_tries.try_scorers[0];
        self.record_int_result(
            IntResultTypes::FirstTryScorerMatchAInt,
            home_match_tries.unwrap_or_default(),
        );
        self.record_int_result(
            IntResultTypes::FirstTryScorerMatchBInt,
            away_match_tries.unwrap_or_default(),
        );
        //

        // First half first try scorer
        let first_half_first_try_scorer =
            state.try_tracker.period_tries[constants::FIRST_HALF_INDEX as usize].try_scorers[0];
        self.record_int_result(
            IntResultTypes::FirstTryScorerHalf1Int,
            first_half_first_try_scorer.unwrap_or_default(),
        );
        //

        // Second half first try scorer
        let mut second_half_first_try_scorer =
            state.try_tracker.period_tries[constants::SECOND_HALF_INDEX as usize].try_scorers[0];
        let is_zero = if let Some(second_half_first_try_scorer) = second_half_first_try_scorer {
            second_half_first_try_scorer == 0
        } else {
            true
        };
        if is_zero {
            second_half_first_try_scorer =
                state.try_tracker.period_tries[constants::EXTRA_TIME_INDEX as usize].try_scorers[0];
        }
        self.record_int_result(
            IntResultTypes::FirstTryScorerHalf2AndExtraTimeInt,
            second_half_first_try_scorer.unwrap_or_default(),
        );
        //

        // Last try scorer player
        let last_try_scorer = state.try_tracker.match_tries.last_try_scorer;
        self.record_int_result(
            IntResultTypes::LastTryScorerMatchInt,
            last_try_scorer.unwrap_or_default(),
        );
        //

        // Last try scorer player per team
        let home_last_try_scorer_match = state.try_tracker.home_match_tries.last_try_scorer;
        let away_last_try_scorer_match = state.try_tracker.away_match_tries.last_try_scorer;
        self.record_int_result(
            IntResultTypes::LastTryScorerMatchAInt,
            home_last_try_scorer_match.unwrap_or_default(),
        );
        self.record_int_result(
            IntResultTypes::LastTryScorerMatchBInt,
            away_last_try_scorer_match.unwrap_or_default(),
        );
        //
    }

    pub fn record_scores(&mut self, home_stats: &TeamStatistics, away_stats: &TeamStatistics) {
        let home_period_stats = &home_stats.period_statistics;
        let home_match_stats = &home_stats.match_statistics;
        let away_period_stats = &away_stats.period_statistics;
        let away_match_stats = &away_stats.match_statistics;

        // let home_first_half_score = home_period_stats[constants::FIRST_HALF_INDEX as usize]
        //     .scores
        //     .total;
        let home_first_half_score = if home_period_stats.is_empty() {
            0
        } else {
            home_period_stats[constants::FIRST_HALF_INDEX as usize]
                .scores
                .total
        };
        // let away_first_half_score = away_period_stats[constants::FIRST_HALF_INDEX as usize]
        //     .scores
        //     .total;
        let away_first_half_score = if away_period_stats.is_empty() {
            0
        } else {
            away_period_stats[constants::FIRST_HALF_INDEX as usize]
                .scores
                .total
        };
        // mock
        // let home_first_half_score = 10;
        // let away_first_half_score = 5;
        let first_half_tie = home_first_half_score == away_first_half_score;
        let first_half_home_win = home_first_half_score > away_first_half_score;
        let first_half_away_win = away_first_half_score > home_first_half_score;
        self.record_int_result(IntResultTypes::PointsHalf1AInt, home_first_half_score);
        self.record_int_result(IntResultTypes::PointsHalf1BInt, away_first_half_score);
        self.record_bin_result(BinResultTypes::WinHalf1ABin, first_half_home_win);
        self.record_bin_result(BinResultTypes::WinHalf1BBin, first_half_away_win);
        if first_half_tie {
            let result = random_range(0.0..1.0);

            self.record_bin_result(BinResultTypes::AdjustedWinHalf1ABin, result <= 0.5);
            self.record_bin_result(BinResultTypes::AdjustedWinHalf1BBin, result > 0.5);
        } else {
            self.record_bin_result(BinResultTypes::AdjustedWinHalf1ABin, first_half_home_win);
            self.record_bin_result(BinResultTypes::AdjustedWinHalf1BBin, first_half_away_win);
        }
        //  qwer

        // let home_second_half_score = home_period_stats[constants::SECOND_HALF_INDEX as usize]
        //     .scores
        //     .total;
        let home_second_half_score = if home_period_stats.is_empty() {
            0
        } else {
            home_period_stats[constants::SECOND_HALF_INDEX as usize]
                .scores
                .total
        };
        // let away_second_half_score = away_period_stats[constants::SECOND_HALF_INDEX as usize]
        //     .scores
        //     .total;
        let away_second_half_score = if away_period_stats.is_empty() {
            0
        } else {
            away_period_stats[constants::SECOND_HALF_INDEX as usize]
                .scores
                .total
        };
        // mock
        // let home_second_half_score = 10;
        // let away_second_half_score = 5;
        self.record_int_result(IntResultTypes::PointsHalf2AInt, home_second_half_score);
        self.record_int_result(IntResultTypes::PointsHalf2BInt, away_second_half_score);
        //

        //
        let home_match_score_total = home_match_stats.scores.total;
        let away_match_score_total = away_match_stats.scores.total;
        self.record_int_result(IntResultTypes::PointsMatchAInt, home_match_score_total);
        self.record_int_result(IntResultTypes::PointsMatchBInt, away_match_score_total);
        //

        //
        let match_tie = home_match_score_total == away_match_score_total;
        let match_home_win = home_match_score_total > away_match_score_total;
        let match_away_win = away_match_score_total > home_match_score_total;
        self.record_bin_result(BinResultTypes::WinMatchABin, match_home_win);
        self.record_bin_result(BinResultTypes::WinMatchBBin, match_away_win);
        self.record_bin_result(BinResultTypes::DrawMatchBin, match_tie);
        if match_tie {
            let result = random_range(0.0..1.0);

            self.record_bin_result(BinResultTypes::AdjustedWinMatchABin, result <= 0.5);
            self.record_bin_result(BinResultTypes::AdjustedWinMatchBBin, result > 0.5);
        } else {
            self.record_bin_result(BinResultTypes::AdjustedWinMatchABin, match_home_win);
            self.record_bin_result(BinResultTypes::AdjustedWinMatchBBin, match_away_win);
        }
        //

        // let home_period_stats_second_half = home_period_stats
        //     [constants::SECOND_HALF_INDEX as usize]
        //     .scores
        //     .total;
        let home_period_stats_second_half = if home_period_stats.is_empty() {
            0
        } else {
            home_period_stats[constants::SECOND_HALF_INDEX as usize]
                .scores
                .total
        };
        // let home_period_stats_extra_time = home_period_stats[constants::EXTRA_TIME_INDEX as usize]
        //     .scores
        //     .total;
        let home_period_stats_extra_time = if home_period_stats.is_empty() {
            0
        } else {
            home_period_stats[constants::EXTRA_TIME_INDEX as usize]
                .scores
                .total
        };
        // mock
        // let home_period_stats_second_half = 10;
        // let home_period_stats_extra_time = 5;
        let home_second_half_and_extra_time_score =
            home_period_stats_second_half + home_period_stats_extra_time;

        // let away_period_stats_second_half = away_period_stats
        //     [constants::SECOND_HALF_INDEX as usize]
        //     .scores
        //     .total;
        let away_period_stats_second_half = if away_period_stats.is_empty() {
            0
        } else {
            away_period_stats[constants::SECOND_HALF_INDEX as usize]
                .scores
                .total
        };
        // let away_period_stats_extra_time = away_period_stats[constants::EXTRA_TIME_INDEX as usize]
        //     .scores
        //     .total;
        let away_period_stats_extra_time = if away_period_stats.is_empty() {
            0
        } else {
            away_period_stats[constants::EXTRA_TIME_INDEX as usize]
                .scores
                .total
        };
        // mock
        // let away_period_stats_second_half = 5;
        // let away_period_stats_extra_time = 2;
        let away_second_half_and_extra_time_score =
            away_period_stats_second_half + away_period_stats_extra_time;

        let second_half_and_extra_time_tie =
            home_second_half_and_extra_time_score == away_second_half_and_extra_time_score;
        let second_half_and_extra_time_home_win =
            home_second_half_and_extra_time_score > away_second_half_and_extra_time_score;
        let second_half_and_extra_time_away_win =
            away_second_half_and_extra_time_score > home_second_half_and_extra_time_score;
        self.record_bin_result(
            BinResultTypes::WinHalf2AndExtraTimeABin,
            second_half_and_extra_time_home_win,
        );
        self.record_bin_result(
            BinResultTypes::WinHalf2AndExtraTimeBBin,
            second_half_and_extra_time_away_win,
        );
        if second_half_and_extra_time_tie {
            let result = random_range(0.0..1.0);

            self.record_bin_result(
                BinResultTypes::AdjustedWinHalf2AndExtraTimeABin,
                result <= 0.5,
            );
            self.record_bin_result(
                BinResultTypes::AdjustedWinHalf2AndExtraTimeBBin,
                result > 0.5,
            );
        } else {
            self.record_bin_result(
                BinResultTypes::AdjustedWinHalf2AndExtraTimeABin,
                second_half_and_extra_time_home_win,
            );
            self.record_bin_result(
                BinResultTypes::AdjustedWinHalf2AndExtraTimeBBin,
                second_half_and_extra_time_away_win,
            );
        }

        // let home_first_half_score = home_period_stats[constants::FIRST_HALF_INDEX as usize]
        //     .scores
        //     .total;
        let home_first_half_score = if home_period_stats.is_empty() {
            0
        } else {
            home_period_stats[constants::FIRST_HALF_INDEX as usize]
                .scores
                .total
        };
        // let home_second_half_score = home_period_stats[constants::SECOND_HALF_INDEX as usize]
        //     .scores
        //     .total;
        let home_second_half_score = if home_period_stats.is_empty() {
            0
        } else {
            home_period_stats[constants::SECOND_HALF_INDEX as usize]
                .scores
                .total
        };
        // let away_first_half_score = away_period_stats[constants::FIRST_HALF_INDEX as usize]
        //     .scores
        //     .total;
        let away_first_half_score = if away_period_stats.is_empty() {
            0
        } else {
            away_period_stats[constants::FIRST_HALF_INDEX as usize]
                .scores
                .total
        };
        // let away_second_half_score = away_period_stats[constants::SECOND_HALF_INDEX as usize]
        //     .scores
        //     .total;
        let away_second_half_score = if away_period_stats.is_empty() {
            0
        } else {
            away_period_stats[constants::SECOND_HALF_INDEX as usize]
                .scores
                .total
        };
        // mock
        // let home_first_half_score = 10;
        // let home_second_half_score = 5;
        // let away_first_half_score = 5;
        // let away_second_half_score = 2;
        let normal_time_home_score = home_first_half_score + home_second_half_score;
        let normal_time_away_score = away_first_half_score + away_second_half_score;
        let normal_time_home_win = normal_time_home_score > normal_time_away_score;
        let normal_time_away_win = normal_time_away_score > normal_time_home_score;
        self.record_bin_result(BinResultTypes::WinNormalTimeABin, normal_time_home_win);
        self.record_bin_result(BinResultTypes::WinNormalTimeBBin, normal_time_away_win);
        self.record_int_result(IntResultTypes::PointsNormalTimeAInt, normal_time_home_score);
        self.record_int_result(IntResultTypes::PointsNormalTimeBInt, normal_time_away_score);
        //

        // let home_extra_time_score = home_period_stats[constants::EXTRA_TIME_INDEX as usize]
        //     .scores
        //     .total;
        let home_extra_time_score = if home_period_stats.is_empty() {
            0
        } else {
            home_period_stats[constants::EXTRA_TIME_INDEX as usize]
                .scores
                .total
        };
        // let away_extra_time_score = away_period_stats[constants::EXTRA_TIME_INDEX as usize]
        //     .scores
        //     .total;
        let away_extra_time_score = if away_period_stats.is_empty() {
            0
        } else {
            away_period_stats[constants::EXTRA_TIME_INDEX as usize]
                .scores
                .total
        };
        // mock
        // let home_extra_time_score = 5;
        // let away_extra_time_score = 2;
        self.record_int_result(IntResultTypes::PointsExtraTimeAInt, home_extra_time_score);
        self.record_int_result(IntResultTypes::PointsExtraTimeBInt, away_extra_time_score);
        //
    }
}

fn seconds_elapsed_to_minute(seconds_elapsed: i32) -> i32 {
    seconds_elapsed / 60 + 1
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SubmodelResultRecorder {
    pub rows: Vec<SubModelResultProcessor>,
}

impl SubmodelResultRecorder {
    pub fn new(num_simulations: usize) -> Self {
        let single_result_row = SubModelResultProcessor::new(85, 223);

        Self {
            rows: vec![single_result_row; num_simulations],
        }
    }

    pub fn get_processor(
        index: usize,
        recorder: &SubmodelResultRecorder,
    ) -> Result<&SubModelResultProcessor, ResultRecorderError> {
        if index >= recorder.rows.len() {
            return Err(ResultRecorderError::ProcessorNotFound(
                "sub model".to_owned(),
            ));
        }

        Ok(&recorder.rows[index])
    }

    pub fn to_csv<W: Write>(&self, writer: W) -> Result<(), Box<dyn std::error::Error>> {
        let mut csv_writer = Writer::from_writer(writer);

        if self.rows.is_empty() {
            return Ok(());
        }

        let headers = self.get_column_headers();
        csv_writer.write_record(&headers)?;

        for row in &self.rows {
            let record = self.row_to_record(row, &headers);
            csv_writer.write_record(&record)?;
        }

        csv_writer.flush()?;
        Ok(())
    }

    pub fn to_csv_file(&self, file_path: &str) -> Result<(), Box<dyn std::error::Error>> {
        let file = std::fs::File::create(file_path)?;
        self.to_csv(file)
    }

    pub fn to_csv_string(&self) -> Result<String, Box<dyn std::error::Error>> {
        let mut buffer = Vec::new();
        self.to_csv(&mut buffer)?;
        Ok(String::from_utf8(buffer)?)
    }

    fn get_column_headers(&self) -> Vec<String> {
        if self.rows.is_empty() {
            return Vec::new();
        }

        let first_row = &self.rows[0];
        let mut headers = Vec::new();

        let mut binary_keys: Vec<_> = first_row.binary.mapping.keys().collect();
        binary_keys.sort(); // Is this necessary?
        for key in binary_keys {
            headers.push(key.clone());
        }

        let mut integer_keys: Vec<_> = first_row.integer.row.keys().collect();
        integer_keys.sort(); // Is this necessary?
        for key in integer_keys {
            headers.push(key.clone());
        }

        headers
    }

    fn row_to_record(&self, row: &SubModelResultProcessor, headers: &[String]) -> Vec<String> {
        let mut record = Vec::with_capacity(headers.len());

        for header in headers {
            if let Some(&index) = row.binary.mapping.get(header) {
                if let Some(bit) = row.binary.row.get(index) {
                    record.push(if *bit { "1" } else { "0" }.to_string());
                } else {
                    record.push("0".to_string());
                }
            } else if let Some(&value) = row.integer.row.get(header) {
                record.push(value.to_string());
            } else {
                record.push("".to_string());
            }
        }

        record
    }
}
