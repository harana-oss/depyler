use strum::{Display, EnumDiscriminants, EnumIter};

use crate::nrl::{model_data::Team, result::SubModelResultProcessor};

#[derive(EnumIter, EnumDiscriminants, Display, Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[strum_discriminants(derive(EnumIter))]
pub enum BinResultTypes {
    // Win columns
    #[strum(serialize = "Win_Half1_A")]
    WinHalf1ABin,
    #[strum(serialize = "Win_Half1_B")]
    WinHalf1BBin,
    #[strum(serialize = "Win_Match_A")]
    WinMatchABin,
    #[strum(serialize = "Win_Match_B")]
    WinMatchBBin,
    #[strum(serialize = "Win_NormalTime_A")]
    WinNormalTimeABin,
    #[strum(serialize = "Win_NormalTime_B")]
    WinNormalTimeBBin,
    #[strum(serialize = "Win_Half2AndExtraTime_A")]
    WinHalf2AndExtraTimeABin,
    #[strum(serialize = "Win_Half2AndExtraTime_B")]
    WinHalf2AndExtraTimeBBin,

    // Adjusted Win columns
    #[strum(serialize = "AdjustedWin_Half1_A")]
    AdjustedWinHalf1ABin,
    #[strum(serialize = "AdjustedWin_Half1_B")]
    AdjustedWinHalf1BBin,
    #[strum(serialize = "AdjustedWin_Match_A")]
    AdjustedWinMatchABin,
    #[strum(serialize = "AdjustedWin_Match_B")]
    AdjustedWinMatchBBin,
    #[strum(serialize = "AdjustedWin_Half2AndExtraTime_A")]
    AdjustedWinHalf2AndExtraTimeABin,
    #[strum(serialize = "AdjustedWin_Half2AndExtraTime_B")]
    AdjustedWinHalf2AndExtraTimeBBin,

    // Draw and special events?
    #[strum(serialize = "Draw_Match")]
    DrawMatchBin,
    #[strum(serialize = "ExtraTimeOccurred_Match")]
    ExtraTimeOccurredMatchBin,
    #[strum(serialize = "ThreeUnansweredTries_Match")]
    ThreeUnansweredTriesMatchBin,

    // First to score columns
    #[strum(serialize = "FirstToScore_Match_A")]
    FirstToScoreMatchABin,
    #[strum(serialize = "FirstToScore_Match_B")]
    FirstToScoreMatchBBin,
    #[strum(serialize = "FirstToScore_Half2AndExtraTime_A")]
    FirstToScoreHalf2AndExtraTimeABin,
    #[strum(serialize = "FirstToScore_Half2AndExtraTime_B")]
    FirstToScoreHalf2AndExtraTimeBBin,
    #[strum(serialize = "FirstToScore_ExtraTime_A")]
    FirstToScoreExtraTimeABin,
    #[strum(serialize = "FirstToScore_ExtraTime_B")]
    FirstToScoreExtraTimeBBin,

    // First try columns
    #[strum(serialize = "FirstTry_Half2AndExtraTime_A")]
    FirstTryHalf2AndExtraTimeABin,
    #[strum(serialize = "FirstTry_Half2AndExtraTime_B")]
    FirstTryHalf2AndExtraTimeBBin,

    // Last try/score columns
    #[strum(serialize = "LastTry_Match_A")]
    LastTryMatchABin,
    #[strum(serialize = "LastTry_Match_B")]
    LastTryMatchBBin,
    #[strum(serialize = "LastToScore_Match_A")]
    LastToScoreMatchABin,
    #[strum(serialize = "LastToScore_Match_B")]
    LastToScoreMatchBBin,

    // Interval results columns
    #[strum(serialize = "Win10Minutes_Match_A")]
    Win10MinutesMatchABin,
    #[strum(serialize = "Win10Minutes_Match_B")]
    Win10MinutesMatchBBin,
    #[strum(serialize = "Win20Minutes_Match_A")]
    Win20MinutesMatchABin,
    #[strum(serialize = "Win20Minutes_Match_B")]
    Win20MinutesMatchBBin,
    #[strum(serialize = "Win30Minutes_Match_A")]
    Win30MinutesMatchABin,
    #[strum(serialize = "Win30Minutes_Match_B")]
    Win30MinutesMatchBBin,
    #[strum(serialize = "Win50Minutes_Match_A")]
    Win50MinutesMatchABin,
    #[strum(serialize = "Win50Minutes_Match_B")]
    Win50MinutesMatchBBin,
    #[strum(serialize = "Win60Minutes_Match_A")]
    Win60MinutesMatchABin,
    #[strum(serialize = "Win60Minutes_Match_B")]
    Win60MinutesMatchBBin,

    // Race to result columns
    #[strum(serialize = "FirstToPoints10_Match_A")]
    FirstToPoints10MatchABin,
    #[strum(serialize = "FirstToPoints10_Match_B")]
    FirstToPoints10MatchBBin,
    #[strum(serialize = "FirstToPoints15_Match_A")]
    FirstToPoints15MatchABin,
    #[strum(serialize = "FirstToPoints15_Match_B")]
    FirstToPoints15MatchBBin,
    #[strum(serialize = "FirstToPoints20_Match_A")]
    FirstToPoints20MatchABin,
    #[strum(serialize = "FirstToPoints20_Match_B")]
    FirstToPoints20MatchBBin,
    #[strum(serialize = "FirstToPoints25_Match_A")]
    FirstToPoints25MatchABin,
    #[strum(serialize = "FirstToPoints25_Match_B")]
    FirstToPoints25MatchBBin,
    #[strum(serialize = "FirstToPoints30_Match_A")]
    FirstToPoints30MatchABin,
    #[strum(serialize = "FirstToPoints30_Match_B")]
    FirstToPoints30MatchBBin,
    #[strum(serialize = "FirstToPoints35_Match_A")]
    FirstToPoints35MatchABin,
    #[strum(serialize = "FirstToPoints35_Match_B")]
    FirstToPoints35MatchBBin,
    #[strum(serialize = "FirstToPoints40_Match_A")]
    FirstToPoints40MatchABin,
    #[strum(serialize = "FirstToPoints40_Match_B")]
    FirstToPoints40MatchBBin,

    // Match try index result columns
    #[strum(serialize = "1thTry_Match_A")]
    FirstTryMatchABin,
    #[strum(serialize = "1thTry_Match_B")]
    FirstTryMatchBBin,
    #[strum(serialize = "2thTry_Match_A")]
    SecondTryMatchABin,
    #[strum(serialize = "2thTry_Match_B")]
    SecondTryMatchBBin,
    #[strum(serialize = "3thTry_Match_A")]
    ThirdTryMatchABin,
    #[strum(serialize = "3thTry_Match_B")]
    ThirdTryMatchBBin,
    #[strum(serialize = "4thTry_Match_A")]
    FourthTryMatchABin,
    #[strum(serialize = "4thTry_Match_B")]
    FourthTryMatchBBin,
    #[strum(serialize = "5thTry_Match_A")]
    FifthTryMatchABin,
    #[strum(serialize = "5thTry_Match_B")]
    FifthTryMatchBBin,
    #[strum(serialize = "6thTry_Match_A")]
    SixthTryMatchABin,
    #[strum(serialize = "6thTry_Match_B")]
    SixthTryMatchBBin,
    #[strum(serialize = "7thTry_Match_A")]
    SeventhTryMatchABin,
    #[strum(serialize = "7thTry_Match_B")]
    SeventhTryMatchBBin,
    #[strum(serialize = "8thTry_Match_A")]
    EighthTryMatchABin,
    #[strum(serialize = "8thTry_Match_B")]
    EighthTryMatchBBin,
    #[strum(serialize = "9thTry_Match_A")]
    NinthTryMatchABin,
    #[strum(serialize = "9thTry_Match_B")]
    NinthTryMatchBBin,
    #[strum(serialize = "10thTry_Match_A")]
    TenthTryMatchABin,
    #[strum(serialize = "10thTry_Match_B")]
    TenthTryMatchBBin,
    #[strum(serialize = "11thTry_Match_A")]
    EleventhTryMatchABin,
    #[strum(serialize = "11thTry_Match_B")]
    EleventhTryMatchBBin,
    #[strum(serialize = "12thTry_Match_A")]
    TwelfthTryMatchABin,
    #[strum(serialize = "12thTry_Match_B")]
    TwelfthTryMatchBBin,
    #[strum(serialize = "13thTry_Match_A")]
    ThirteenthTryMatchABin,
    #[strum(serialize = "13thTry_Match_B")]
    ThirteenthTryMatchBBin,
    #[strum(serialize = "14thTry_Match_A")]
    FourteenthTryMatchABin,
    #[strum(serialize = "14thTry_Match_B")]
    FourteenthTryMatchBBin,
    #[strum(serialize = "15thTry_Match_A")]
    FifteenthTryMatchABin,
    #[strum(serialize = "15thTry_Match_B")]
    FifteenthTryMatchBBin,

    // Second half try result columns
    #[strum(serialize = "1thTry_SecondHalf_A")]
    FirstTrySecondHalfABin,
    #[strum(serialize = "1thTry_SecondHalf_B")]
    FirstTrySecondHalfBBin,
}

impl BinResultTypes {
    pub const fn group_first_to_points_match() -> [BinResultTypes; 14] {
        [
            BinResultTypes::FirstToPoints10MatchABin,
            BinResultTypes::FirstToPoints10MatchBBin,
            BinResultTypes::FirstToPoints15MatchABin,
            BinResultTypes::FirstToPoints15MatchBBin,
            BinResultTypes::FirstToPoints20MatchABin,
            BinResultTypes::FirstToPoints20MatchBBin,
            BinResultTypes::FirstToPoints25MatchABin,
            BinResultTypes::FirstToPoints25MatchBBin,
            BinResultTypes::FirstToPoints30MatchABin,
            BinResultTypes::FirstToPoints30MatchBBin,
            BinResultTypes::FirstToPoints35MatchABin,
            BinResultTypes::FirstToPoints35MatchBBin,
            BinResultTypes::FirstToPoints40MatchABin,
            BinResultTypes::FirstToPoints40MatchBBin,
        ]
    }

    pub const fn group_nth_try_match() -> [BinResultTypes; 30] {
        [
            BinResultTypes::FirstTryMatchABin,
            BinResultTypes::FirstTryMatchBBin,
            BinResultTypes::SecondTryMatchABin,
            BinResultTypes::SecondTryMatchBBin,
            BinResultTypes::ThirdTryMatchABin,
            BinResultTypes::ThirdTryMatchBBin,
            BinResultTypes::FourthTryMatchABin,
            BinResultTypes::FourthTryMatchBBin,
            BinResultTypes::FifthTryMatchABin,
            BinResultTypes::FifthTryMatchBBin,
            BinResultTypes::SixthTryMatchABin,
            BinResultTypes::SixthTryMatchBBin,
            BinResultTypes::SeventhTryMatchABin,
            BinResultTypes::SeventhTryMatchBBin,
            BinResultTypes::EighthTryMatchABin,
            BinResultTypes::EighthTryMatchBBin,
            BinResultTypes::NinthTryMatchABin,
            BinResultTypes::NinthTryMatchBBin,
            BinResultTypes::TenthTryMatchABin,
            BinResultTypes::TenthTryMatchBBin,
            BinResultTypes::EleventhTryMatchABin,
            BinResultTypes::EleventhTryMatchBBin,
            BinResultTypes::TwelfthTryMatchABin,
            BinResultTypes::TwelfthTryMatchBBin,
            BinResultTypes::ThirteenthTryMatchABin,
            BinResultTypes::ThirteenthTryMatchBBin,
            BinResultTypes::FourteenthTryMatchABin,
            BinResultTypes::FourteenthTryMatchBBin,
            BinResultTypes::FifteenthTryMatchABin,
            BinResultTypes::FifteenthTryMatchBBin,
        ]
    }

    pub const fn group_win_minutes() -> [BinResultTypes; 10] {
        [
            BinResultTypes::Win10MinutesMatchABin,
            BinResultTypes::Win10MinutesMatchBBin,
            BinResultTypes::Win20MinutesMatchABin,
            BinResultTypes::Win20MinutesMatchBBin,
            BinResultTypes::Win30MinutesMatchABin,
            BinResultTypes::Win30MinutesMatchBBin,
            BinResultTypes::Win50MinutesMatchABin,
            BinResultTypes::Win50MinutesMatchBBin,
            BinResultTypes::Win60MinutesMatchABin,
            BinResultTypes::Win60MinutesMatchBBin,
        ]
    }
}

// To be turned into a macro later
impl SubModelResultProcessor {
    pub fn record_bin_result(&mut self, res_type: BinResultTypes, value: bool) {
        let index = res_type as usize;

        self.binary
            .insert_into_bitvec(res_type.to_string(), index, value);
    }

    pub fn record_int_result(&mut self, res_type: IntResultTypes, value: i32) {
        self.integer.insert(res_type.to_string(), value)
    }

    pub fn record_int_dynamic_result(
        &mut self,
        index: i32,
        index_mapping: i32,
        team: Team,
        res_type: &IntResultTypes,
        value: i32,
    ) {
        let i = match team {
            Team::Home => index_mapping,
            Team::Away => index_mapping + 17,
            _ => unreachable!(),
        };
        match i {
            1 => match res_type {
                IntResultTypes::TriesMatchPlayer1Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer1Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer1Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player1Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer1Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            2 => match res_type {
                IntResultTypes::TriesMatchPlayer2Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer2Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer2Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player2Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer2Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            3 => match res_type {
                IntResultTypes::TriesMatchPlayer3Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer3Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer3Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player3Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer3Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            4 => match res_type {
                IntResultTypes::TriesMatchPlayer4Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer4Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer4Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player4Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer4Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            5 => match res_type {
                IntResultTypes::TriesMatchPlayer5Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer5Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer5Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player5Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer5Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            6 => match res_type {
                IntResultTypes::TriesMatchPlayer6Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer6Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer6Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player6Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer6Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            7 => match res_type {
                IntResultTypes::TriesMatchPlayer7Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer7Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer7Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player7Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer7Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            8 => match res_type {
                IntResultTypes::TriesMatchPlayer8Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer8Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer8Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player8Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer8Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            9 => match res_type {
                IntResultTypes::TriesMatchPlayer9Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer9Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer9Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player9Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer9Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            10 => match res_type {
                IntResultTypes::TriesMatchPlayer10Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer10Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer10Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player10Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer10Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            11 => match res_type {
                IntResultTypes::TriesMatchPlayer11Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer11Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer11Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player11Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer11Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            12 => match res_type {
                IntResultTypes::TriesMatchPlayer12Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer12Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer12Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player12Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer12Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            13 => match res_type {
                IntResultTypes::TriesMatchPlayer13Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer13Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer13Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player13Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer13Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            14 => match res_type {
                IntResultTypes::TriesMatchPlayer14Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer14Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer14Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player14Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer14Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            15 => match res_type {
                IntResultTypes::TriesMatchPlayer15Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer15Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer15Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player15Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer15Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            16 => match res_type {
                IntResultTypes::TriesMatchPlayer16Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer16Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer16Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player16Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer16Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            17 => match res_type {
                IntResultTypes::TriesMatchPlayer17Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer17Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer17Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player17Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer17Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            18 => match res_type {
                IntResultTypes::TriesMatchPlayer18Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer18Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer18Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player18Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer18Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            19 => match res_type {
                IntResultTypes::TriesMatchPlayer19Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer19Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer19Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player19Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer19Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            20 => match res_type {
                IntResultTypes::TriesMatchPlayer20Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer20Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer20Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player20Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer20Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            21 => match res_type {
                IntResultTypes::TriesMatchPlayer21Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer21Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer21Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player21Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer21Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            22 => match res_type {
                IntResultTypes::TriesMatchPlayer22Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer22Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer22Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player22Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer22Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            23 => match res_type {
                IntResultTypes::TriesMatchPlayer23Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer23Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer23Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player23Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer23Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            24 => match res_type {
                IntResultTypes::TriesMatchPlayer24Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer24Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer24Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player24Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer24Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            25 => match res_type {
                IntResultTypes::TriesMatchPlayer25Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer25Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer25Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player25Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer25Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            26 => match res_type {
                IntResultTypes::TriesMatchPlayer26Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer26Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer26Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player26Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer26Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            27 => match res_type {
                IntResultTypes::TriesMatchPlayer27Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer27Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer27Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player27Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer27Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            28 => match res_type {
                IntResultTypes::TriesMatchPlayer28Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer28Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer28Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player28Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer28Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            29 => match res_type {
                IntResultTypes::TriesMatchPlayer29Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer29Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer29Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player29Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer29Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            30 => match res_type {
                IntResultTypes::TriesMatchPlayer30Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer30Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer30Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player30Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer30Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            31 => match res_type {
                IntResultTypes::TriesMatchPlayer31Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer31Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer31Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player31Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer31Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            32 => match res_type {
                IntResultTypes::TriesMatchPlayer32Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer32Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer32Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player32Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer32Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            33 => match res_type {
                IntResultTypes::TriesMatchPlayer33Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer33Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer33Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player33Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer33Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            34 => match res_type {
                IntResultTypes::TriesMatchPlayer34Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesMatchPlayer, index),
                    value,
                ),
                IntResultTypes::PointsMatchPlayer34Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::PointsMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TogMatchPlayer34Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TogMatchPlayer, index),
                    value,
                ),
                IntResultTypes::TriesHalf1Player34Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf1Player, index),
                    value,
                ),
                IntResultTypes::TriesHalf2AndExtraTimePlayer34Int => self.integer.insert(
                    format!("{}{}", IntDynamicTypes::TriesHalf2AndExtraTimePlayer, index),
                    value,
                ),
                _ => unreachable!(),
            },
            _ => unreachable!(),
        }
    }
}

#[derive(EnumIter, Display, Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum IntDynamicTypes {
    #[strum(serialize = "Tries_Match_Player_")]
    TriesMatchPlayer,
    #[strum(serialize = "Points_Match_Player_")]
    PointsMatchPlayer,
    #[strum(serialize = "TOG_Match_Player_")]
    TogMatchPlayer,
    #[strum(serialize = "Tries_Half1_Player_")]
    TriesHalf1Player,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_")]
    TriesHalf2AndExtraTimePlayer,
}

#[derive(EnumIter, EnumDiscriminants, Display, Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[strum_discriminants(derive(EnumIter))]
pub enum IntResultTypes {
    // Points columns
    #[strum(serialize = "Points_Half1_A")]
    PointsHalf1AInt,
    #[strum(serialize = "Points_Half1_B")]
    PointsHalf1BInt,
    #[strum(serialize = "Points_Half2_A")]
    PointsHalf2AInt,
    #[strum(serialize = "Points_Half2_B")]
    PointsHalf2BInt,
    #[strum(serialize = "Points_Match_A")]
    PointsMatchAInt,
    #[strum(serialize = "Points_Match_B")]
    PointsMatchBInt,
    #[strum(serialize = "Points_NormalTime_A")]
    PointsNormalTimeAInt,
    #[strum(serialize = "Points_NormalTime_B")]
    PointsNormalTimeBInt,
    #[strum(serialize = "Points_ExtraTime_A")]
    PointsExtraTimeAInt,
    #[strum(serialize = "Points_ExtraTime_B")]
    PointsExtraTimeBInt,

    // Tries columns
    #[strum(serialize = "Tries_Match_A")]
    TriesMatchAInt,
    #[strum(serialize = "Tries_Match_B")]
    TriesMatchBInt,
    #[strum(serialize = "Tries_Half1_A")]
    TriesHalf1AInt,
    #[strum(serialize = "Tries_Half1_B")]
    TriesHalf1BInt,
    #[strum(serialize = "Tries_Half2_A")]
    TriesHalf2AInt,
    #[strum(serialize = "Tries_Half2_B")]
    TriesHalf2BInt,
    #[strum(serialize = "Tries_ExtraTime_A")]
    TriesExtraTimeAInt,
    #[strum(serialize = "Tries_ExtraTime_B")]
    TriesExtraTimeBInt,

    // Try timing columns
    #[strum(serialize = "FirstTryTime_Match_A")]
    FirstTryTimeMatchAInt,
    #[strum(serialize = "FirstTryTime_Match_B")]
    FirstTryTimeMatchBInt,
    #[strum(serialize = "FirstTryTime_Match")]
    FirstTryTimeMatchInt,
    #[strum(serialize = "LastTryTime_Match")]
    LastTryTimeMatchInt,

    // Player statistics  - Match level
    #[strum(serialize = "Tries_Match_Player_1")]
    TriesMatchPlayer1Int,
    #[strum(serialize = "Points_Match_Player_1")]
    PointsMatchPlayer1Int,
    #[strum(serialize = "TOG_Match_Player_1")]
    TogMatchPlayer1Int,
    #[strum(serialize = "Tries_Match_Player_2")]
    TriesMatchPlayer2Int,
    #[strum(serialize = "Points_Match_Player_2")]
    PointsMatchPlayer2Int,
    #[strum(serialize = "TOG_Match_Player_2")]
    TogMatchPlayer2Int,
    #[strum(serialize = "Tries_Match_Player_3")]
    TriesMatchPlayer3Int,
    #[strum(serialize = "Points_Match_Player_3")]
    PointsMatchPlayer3Int,
    #[strum(serialize = "TOG_Match_Player_3")]
    TogMatchPlayer3Int,
    #[strum(serialize = "Tries_Match_Player_4")]
    TriesMatchPlayer4Int,
    #[strum(serialize = "Points_Match_Player_4")]
    PointsMatchPlayer4Int,
    #[strum(serialize = "TOG_Match_Player_4")]
    TogMatchPlayer4Int,
    #[strum(serialize = "Tries_Match_Player_5")]
    TriesMatchPlayer5Int,
    #[strum(serialize = "Points_Match_Player_5")]
    PointsMatchPlayer5Int,
    #[strum(serialize = "TOG_Match_Player_5")]
    TogMatchPlayer5Int,
    #[strum(serialize = "Tries_Match_Player_6")]
    TriesMatchPlayer6Int,
    #[strum(serialize = "Points_Match_Player_6")]
    PointsMatchPlayer6Int,
    #[strum(serialize = "TOG_Match_Player_6")]
    TogMatchPlayer6Int,
    #[strum(serialize = "Tries_Match_Player_7")]
    TriesMatchPlayer7Int,
    #[strum(serialize = "Points_Match_Player_7")]
    PointsMatchPlayer7Int,
    #[strum(serialize = "TOG_Match_Player_7")]
    TogMatchPlayer7Int,
    #[strum(serialize = "Tries_Match_Player_8")]
    TriesMatchPlayer8Int,
    #[strum(serialize = "Points_Match_Player_8")]
    PointsMatchPlayer8Int,
    #[strum(serialize = "TOG_Match_Player_8")]
    TogMatchPlayer8Int,
    #[strum(serialize = "Tries_Match_Player_9")]
    TriesMatchPlayer9Int,
    #[strum(serialize = "Points_Match_Player_9")]
    PointsMatchPlayer9Int,
    #[strum(serialize = "TOG_Match_Player_9")]
    TogMatchPlayer9Int,
    #[strum(serialize = "Tries_Match_Player_10")]
    TriesMatchPlayer10Int,
    #[strum(serialize = "Points_Match_Player_10")]
    PointsMatchPlayer10Int,
    #[strum(serialize = "TOG_Match_Player_10")]
    TogMatchPlayer10Int,
    #[strum(serialize = "Tries_Match_Player_11")]
    TriesMatchPlayer11Int,
    #[strum(serialize = "Points_Match_Player_11")]
    PointsMatchPlayer11Int,
    #[strum(serialize = "TOG_Match_Player_11")]
    TogMatchPlayer11Int,
    #[strum(serialize = "Tries_Match_Player_12")]
    TriesMatchPlayer12Int,
    #[strum(serialize = "Points_Match_Player_12")]
    PointsMatchPlayer12Int,
    #[strum(serialize = "TOG_Match_Player_12")]
    TogMatchPlayer12Int,
    #[strum(serialize = "Tries_Match_Player_13")]
    TriesMatchPlayer13Int,
    #[strum(serialize = "Points_Match_Player_13")]
    PointsMatchPlayer13Int,
    #[strum(serialize = "TOG_Match_Player_13")]
    TogMatchPlayer13Int,
    #[strum(serialize = "Tries_Match_Player_14")]
    TriesMatchPlayer14Int,
    #[strum(serialize = "Points_Match_Player_14")]
    PointsMatchPlayer14Int,
    #[strum(serialize = "TOG_Match_Player_14")]
    TogMatchPlayer14Int,
    #[strum(serialize = "Tries_Match_Player_15")]
    TriesMatchPlayer15Int,
    #[strum(serialize = "Points_Match_Player_15")]
    PointsMatchPlayer15Int,
    #[strum(serialize = "TOG_Match_Player_15")]
    TogMatchPlayer15Int,
    #[strum(serialize = "Tries_Match_Player_16")]
    TriesMatchPlayer16Int,
    #[strum(serialize = "Points_Match_Player_16")]
    PointsMatchPlayer16Int,
    #[strum(serialize = "TOG_Match_Player_16")]
    TogMatchPlayer16Int,
    #[strum(serialize = "Tries_Match_Player_17")]
    TriesMatchPlayer17Int,
    #[strum(serialize = "Points_Match_Player_17")]
    PointsMatchPlayer17Int,
    #[strum(serialize = "TOG_Match_Player_17")]
    TogMatchPlayer17Int,
    #[strum(serialize = "Tries_Match_Player_18")]
    TriesMatchPlayer18Int,
    #[strum(serialize = "Points_Match_Player_18")]
    PointsMatchPlayer18Int,
    #[strum(serialize = "TOG_Match_Player_18")]
    TogMatchPlayer18Int,
    #[strum(serialize = "Tries_Match_Player_19")]
    TriesMatchPlayer19Int,
    #[strum(serialize = "Points_Match_Player_19")]
    PointsMatchPlayer19Int,
    #[strum(serialize = "TOG_Match_Player_19")]
    TogMatchPlayer19Int,
    #[strum(serialize = "Tries_Match_Player_20")]
    TriesMatchPlayer20Int,
    #[strum(serialize = "Points_Match_Player_20")]
    PointsMatchPlayer20Int,
    #[strum(serialize = "TOG_Match_Player_20")]
    TogMatchPlayer20Int,
    #[strum(serialize = "Tries_Match_Player_21")]
    TriesMatchPlayer21Int,
    #[strum(serialize = "Points_Match_Player_21")]
    PointsMatchPlayer21Int,
    #[strum(serialize = "TOG_Match_Player_21")]
    TogMatchPlayer21Int,
    #[strum(serialize = "Tries_Match_Player_22")]
    TriesMatchPlayer22Int,
    #[strum(serialize = "Points_Match_Player_22")]
    PointsMatchPlayer22Int,
    #[strum(serialize = "TOG_Match_Player_22")]
    TogMatchPlayer22Int,
    #[strum(serialize = "Tries_Match_Player_23")]
    TriesMatchPlayer23Int,
    #[strum(serialize = "Points_Match_Player_23")]
    PointsMatchPlayer23Int,
    #[strum(serialize = "TOG_Match_Player_23")]
    TogMatchPlayer23Int,
    #[strum(serialize = "Tries_Match_Player_24")]
    TriesMatchPlayer24Int,
    #[strum(serialize = "Points_Match_Player_24")]
    PointsMatchPlayer24Int,
    #[strum(serialize = "TOG_Match_Player_24")]
    TogMatchPlayer24Int,
    #[strum(serialize = "Tries_Match_Player_25")]
    TriesMatchPlayer25Int,
    #[strum(serialize = "Points_Match_Player_25")]
    PointsMatchPlayer25Int,
    #[strum(serialize = "TOG_Match_Player_25")]
    TogMatchPlayer25Int,
    #[strum(serialize = "Tries_Match_Player_26")]
    TriesMatchPlayer26Int,
    #[strum(serialize = "Points_Match_Player_26")]
    PointsMatchPlayer26Int,
    #[strum(serialize = "TOG_Match_Player_26")]
    TogMatchPlayer26Int,
    #[strum(serialize = "Tries_Match_Player_27")]
    TriesMatchPlayer27Int,
    #[strum(serialize = "Points_Match_Player_27")]
    PointsMatchPlayer27Int,
    #[strum(serialize = "TOG_Match_Player_27")]
    TogMatchPlayer27Int,
    #[strum(serialize = "Tries_Match_Player_28")]
    TriesMatchPlayer28Int,
    #[strum(serialize = "Points_Match_Player_28")]
    PointsMatchPlayer28Int,
    #[strum(serialize = "TOG_Match_Player_28")]
    TogMatchPlayer28Int,
    #[strum(serialize = "Tries_Match_Player_29")]
    TriesMatchPlayer29Int,
    #[strum(serialize = "Points_Match_Player_29")]
    PointsMatchPlayer29Int,
    #[strum(serialize = "TOG_Match_Player_29")]
    TogMatchPlayer29Int,
    #[strum(serialize = "Tries_Match_Player_30")]
    TriesMatchPlayer30Int,
    #[strum(serialize = "Points_Match_Player_30")]
    PointsMatchPlayer30Int,
    #[strum(serialize = "TOG_Match_Player_30")]
    TogMatchPlayer30Int,
    #[strum(serialize = "Tries_Match_Player_31")]
    TriesMatchPlayer31Int,
    #[strum(serialize = "Points_Match_Player_31")]
    PointsMatchPlayer31Int,
    #[strum(serialize = "TOG_Match_Player_31")]
    TogMatchPlayer31Int,
    #[strum(serialize = "Tries_Match_Player_32")]
    TriesMatchPlayer32Int,
    #[strum(serialize = "Points_Match_Player_32")]
    PointsMatchPlayer32Int,
    #[strum(serialize = "TOG_Match_Player_32")]
    TogMatchPlayer32Int,
    #[strum(serialize = "Tries_Match_Player_33")]
    TriesMatchPlayer33Int,
    #[strum(serialize = "Points_Match_Player_33")]
    PointsMatchPlayer33Int,
    #[strum(serialize = "TOG_Match_Player_33")]
    TogMatchPlayer33Int,
    #[strum(serialize = "Tries_Match_Player_34")]
    TriesMatchPlayer34Int,
    #[strum(serialize = "Points_Match_Player_34")]
    PointsMatchPlayer34Int,
    #[strum(serialize = "TOG_Match_Player_34")]
    TogMatchPlayer34Int,

    // Half 1 player tries
    #[strum(serialize = "Tries_Half1_Player_1")]
    TriesHalf1Player1Int,
    #[strum(serialize = "Tries_Half1_Player_2")]
    TriesHalf1Player2Int,
    #[strum(serialize = "Tries_Half1_Player_3")]
    TriesHalf1Player3Int,
    #[strum(serialize = "Tries_Half1_Player_4")]
    TriesHalf1Player4Int,
    #[strum(serialize = "Tries_Half1_Player_5")]
    TriesHalf1Player5Int,
    #[strum(serialize = "Tries_Half1_Player_6")]
    TriesHalf1Player6Int,
    #[strum(serialize = "Tries_Half1_Player_7")]
    TriesHalf1Player7Int,
    #[strum(serialize = "Tries_Half1_Player_8")]
    TriesHalf1Player8Int,
    #[strum(serialize = "Tries_Half1_Player_9")]
    TriesHalf1Player9Int,
    #[strum(serialize = "Tries_Half1_Player_10")]
    TriesHalf1Player10Int,
    #[strum(serialize = "Tries_Half1_Player_11")]
    TriesHalf1Player11Int,
    #[strum(serialize = "Tries_Half1_Player_12")]
    TriesHalf1Player12Int,
    #[strum(serialize = "Tries_Half1_Player_13")]
    TriesHalf1Player13Int,
    #[strum(serialize = "Tries_Half1_Player_14")]
    TriesHalf1Player14Int,
    #[strum(serialize = "Tries_Half1_Player_15")]
    TriesHalf1Player15Int,
    #[strum(serialize = "Tries_Half1_Player_16")]
    TriesHalf1Player16Int,
    #[strum(serialize = "Tries_Half1_Player_17")]
    TriesHalf1Player17Int,
    #[strum(serialize = "Tries_Half1_Player_18")]
    TriesHalf1Player18Int,
    #[strum(serialize = "Tries_Half1_Player_19")]
    TriesHalf1Player19Int,
    #[strum(serialize = "Tries_Half1_Player_20")]
    TriesHalf1Player20Int,
    #[strum(serialize = "Tries_Half1_Player_21")]
    TriesHalf1Player21Int,
    #[strum(serialize = "Tries_Half1_Player_22")]
    TriesHalf1Player22Int,
    #[strum(serialize = "Tries_Half1_Player_23")]
    TriesHalf1Player23Int,
    #[strum(serialize = "Tries_Half1_Player_24")]
    TriesHalf1Player24Int,
    #[strum(serialize = "Tries_Half1_Player_25")]
    TriesHalf1Player25Int,
    #[strum(serialize = "Tries_Half1_Player_26")]
    TriesHalf1Player26Int,
    #[strum(serialize = "Tries_Half1_Player_27")]
    TriesHalf1Player27Int,
    #[strum(serialize = "Tries_Half1_Player_28")]
    TriesHalf1Player28Int,
    #[strum(serialize = "Tries_Half1_Player_29")]
    TriesHalf1Player29Int,
    #[strum(serialize = "Tries_Half1_Player_30")]
    TriesHalf1Player30Int,
    #[strum(serialize = "Tries_Half1_Player_31")]
    TriesHalf1Player31Int,
    #[strum(serialize = "Tries_Half1_Player_32")]
    TriesHalf1Player32Int,
    #[strum(serialize = "Tries_Half1_Player_33")]
    TriesHalf1Player33Int,
    #[strum(serialize = "Tries_Half1_Player_34")]
    TriesHalf1Player34Int,

    // Half 2 and extra time player tries
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_1")]
    TriesHalf2AndExtraTimePlayer1Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_2")]
    TriesHalf2AndExtraTimePlayer2Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_3")]
    TriesHalf2AndExtraTimePlayer3Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_4")]
    TriesHalf2AndExtraTimePlayer4Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_5")]
    TriesHalf2AndExtraTimePlayer5Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_6")]
    TriesHalf2AndExtraTimePlayer6Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_7")]
    TriesHalf2AndExtraTimePlayer7Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_8")]
    TriesHalf2AndExtraTimePlayer8Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_9")]
    TriesHalf2AndExtraTimePlayer9Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_10")]
    TriesHalf2AndExtraTimePlayer10Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_11")]
    TriesHalf2AndExtraTimePlayer11Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_12")]
    TriesHalf2AndExtraTimePlayer12Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_13")]
    TriesHalf2AndExtraTimePlayer13Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_14")]
    TriesHalf2AndExtraTimePlayer14Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_15")]
    TriesHalf2AndExtraTimePlayer15Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_16")]
    TriesHalf2AndExtraTimePlayer16Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_17")]
    TriesHalf2AndExtraTimePlayer17Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_18")]
    TriesHalf2AndExtraTimePlayer18Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_19")]
    TriesHalf2AndExtraTimePlayer19Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_20")]
    TriesHalf2AndExtraTimePlayer20Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_21")]
    TriesHalf2AndExtraTimePlayer21Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_22")]
    TriesHalf2AndExtraTimePlayer22Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_23")]
    TriesHalf2AndExtraTimePlayer23Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_24")]
    TriesHalf2AndExtraTimePlayer24Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_25")]
    TriesHalf2AndExtraTimePlayer25Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_26")]
    TriesHalf2AndExtraTimePlayer26Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_27")]
    TriesHalf2AndExtraTimePlayer27Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_28")]
    TriesHalf2AndExtraTimePlayer28Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_29")]
    TriesHalf2AndExtraTimePlayer29Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_30")]
    TriesHalf2AndExtraTimePlayer30Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_31")]
    TriesHalf2AndExtraTimePlayer31Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_32")]
    TriesHalf2AndExtraTimePlayer32Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_33")]
    TriesHalf2AndExtraTimePlayer33Int,
    #[strum(serialize = "Tries_Half2AndExtraTime_Player_34")]
    TriesHalf2AndExtraTimePlayer34Int,

    // Try scorer sequence
    #[strum(serialize = "1th_TryScorer_Match")]
    FirstTryScorerMatchInt,
    #[strum(serialize = "2th_TryScorer_Match")]
    SecondTryScorerMatchInt,
    #[strum(serialize = "3th_TryScorer_Match")]
    ThirdTryScorerMatchInt,
    #[strum(serialize = "4th_TryScorer_Match")]
    FourthTryScorerMatchInt,
    #[strum(serialize = "5th_TryScorer_Match")]
    FifthTryScorerMatchInt,
    #[strum(serialize = "6th_TryScorer_Match")]
    SixthTryScorerMatchInt,
    #[strum(serialize = "7th_TryScorer_Match")]
    SeventhTryScorerMatchInt,
    #[strum(serialize = "8th_TryScorer_Match")]
    EighthTryScorerMatchInt,
    #[strum(serialize = "9th_TryScorer_Match")]
    NinthTryScorerMatchInt,
    #[strum(serialize = "10th_TryScorer_Match")]
    TenthTryScorerMatchInt,
    #[strum(serialize = "11th_TryScorer_Match")]
    EleventhTryScorerMatchInt,
    #[strum(serialize = "12th_TryScorer_Match")]
    TwelfthTryScorerMatchInt,
    #[strum(serialize = "13th_TryScorer_Match")]
    ThirteenthTryScorerMatchInt,
    #[strum(serialize = "14th_TryScorer_Match")]
    FourteenthTryScorerMatchInt,
    #[strum(serialize = "15th_TryScorer_Match")]
    FifteenthTryScorerMatchInt,

    // Try scorer details
    #[strum(serialize = "First_TryScorer_Jersey_Match")]
    FirstTryScorerJerseyMatchInt,
    #[strum(serialize = "1th_TryScorer_Half1")]
    FirstTryScorerHalf1Int,
    #[strum(serialize = "1th_TryScorer_Half2AndExtraTime")]
    FirstTryScorerHalf2AndExtraTimeInt,
    #[strum(serialize = "Last_TryScorer_Match")]
    LastTryScorerMatchInt,
    #[strum(serialize = "Last_TryScorer_Jersey_Match")]
    LastTryScorerJerseyMatchInt,
    #[strum(serialize = "Last_TryScorer_Match_A")]
    LastTryScorerMatchAInt,
    #[strum(serialize = "Last_TryScorer_Match_B")]
    LastTryScorerMatchBInt,
    #[strum(serialize = "First_TryScorer_Match_A")]
    FirstTryScorerMatchAInt,
    #[strum(serialize = "First_TryScorer_Match_B")]
    FirstTryScorerMatchBInt,
    #[strum(serialize = "First_TryScorer_Jersey_Match_A")]
    FirstTryScorerJerseyMatchAInt,
    #[strum(serialize = "First_TryScorer_Jersey_Match_B")]
    FirstTryScorerJerseyMatchBInt,

    // Field goal attempts
    #[strum(serialize = "FieldGoalAttempts_Match_A")]
    FieldGoalAttemptsMatchAInt,
    #[strum(serialize = "FieldGoalAttempts_Match_B")]
    FieldGoalAttemptsMatchBInt,
    #[strum(serialize = "SuccessfulFieldGoalAttempts_Match_A")]
    SuccessfulFieldGoalAttemptsMatchAInt,
    #[strum(serialize = "SuccessfulFieldGoalAttempts_Match_B")]
    SuccessfulFieldGoalAttemptsMatchBInt,

    // Player of the match
    #[strum(serialize = "Player_Of_The_Match")]
    PlayerOfTheMatchInt,
}

pub enum PlayerStatsType {
    Match,
    FirstHalf,
    SecondHalfAndExtraTime,
}

impl IntResultTypes {
    pub const fn group_tries() -> [Self; 6] {
        [
            Self::TriesHalf1AInt,
            Self::TriesHalf1BInt,
            Self::TriesHalf2AInt,
            Self::TriesHalf2BInt,
            Self::TriesMatchAInt,
            Self::TriesMatchBInt,
        ]
    }

    pub const fn group_match_try_scorer() -> [Self; 15] {
        [
            Self::FirstTryScorerMatchInt,
            Self::SecondTryScorerMatchInt,
            Self::ThirdTryScorerMatchInt,
            Self::FourthTryScorerMatchInt,
            Self::FifthTryScorerMatchInt,
            Self::SixthTryScorerMatchInt,
            Self::SeventhTryScorerMatchInt,
            Self::EighthTryScorerMatchInt,
            Self::NinthTryScorerMatchInt,
            Self::TenthTryScorerMatchInt,
            Self::EleventhTryScorerMatchInt,
            Self::TwelfthTryScorerMatchInt,
            Self::ThirteenthTryScorerMatchInt,
            Self::FourteenthTryScorerMatchInt,
            Self::FifteenthTryScorerMatchInt,
        ]
    }

    pub const fn group_match_player_stats() -> [Self; 102] {
        [
            Self::TriesMatchPlayer1Int,
            Self::PointsMatchPlayer1Int,
            Self::TogMatchPlayer1Int,
            Self::TriesMatchPlayer2Int,
            Self::PointsMatchPlayer2Int,
            Self::TogMatchPlayer2Int,
            Self::TriesMatchPlayer3Int,
            Self::PointsMatchPlayer3Int,
            Self::TogMatchPlayer3Int,
            Self::TriesMatchPlayer4Int,
            Self::PointsMatchPlayer4Int,
            Self::TogMatchPlayer4Int,
            Self::TriesMatchPlayer5Int,
            Self::PointsMatchPlayer5Int,
            Self::TogMatchPlayer5Int,
            Self::TriesMatchPlayer6Int,
            Self::PointsMatchPlayer6Int,
            Self::TogMatchPlayer6Int,
            Self::TriesMatchPlayer7Int,
            Self::PointsMatchPlayer7Int,
            Self::TogMatchPlayer7Int,
            Self::TriesMatchPlayer8Int,
            Self::PointsMatchPlayer8Int,
            Self::TogMatchPlayer8Int,
            Self::TriesMatchPlayer9Int,
            Self::PointsMatchPlayer9Int,
            Self::TogMatchPlayer9Int,
            Self::TriesMatchPlayer10Int,
            Self::PointsMatchPlayer10Int,
            Self::TogMatchPlayer10Int,
            Self::TriesMatchPlayer11Int,
            Self::PointsMatchPlayer11Int,
            Self::TogMatchPlayer11Int,
            Self::TriesMatchPlayer12Int,
            Self::PointsMatchPlayer12Int,
            Self::TogMatchPlayer12Int,
            Self::TriesMatchPlayer13Int,
            Self::PointsMatchPlayer13Int,
            Self::TogMatchPlayer13Int,
            Self::TriesMatchPlayer14Int,
            Self::PointsMatchPlayer14Int,
            Self::TogMatchPlayer14Int,
            Self::TriesMatchPlayer15Int,
            Self::PointsMatchPlayer15Int,
            Self::TogMatchPlayer15Int,
            Self::TriesMatchPlayer16Int,
            Self::PointsMatchPlayer16Int,
            Self::TogMatchPlayer16Int,
            Self::TriesMatchPlayer17Int,
            Self::PointsMatchPlayer17Int,
            Self::TogMatchPlayer17Int,
            Self::TriesMatchPlayer18Int,
            Self::PointsMatchPlayer18Int,
            Self::TogMatchPlayer18Int,
            Self::TriesMatchPlayer19Int,
            Self::PointsMatchPlayer19Int,
            Self::TogMatchPlayer19Int,
            Self::TriesMatchPlayer20Int,
            Self::PointsMatchPlayer20Int,
            Self::TogMatchPlayer20Int,
            Self::TriesMatchPlayer21Int,
            Self::PointsMatchPlayer21Int,
            Self::TogMatchPlayer21Int,
            Self::TriesMatchPlayer22Int,
            Self::PointsMatchPlayer22Int,
            Self::TogMatchPlayer22Int,
            Self::TriesMatchPlayer23Int,
            Self::PointsMatchPlayer23Int,
            Self::TogMatchPlayer23Int,
            Self::TriesMatchPlayer24Int,
            Self::PointsMatchPlayer24Int,
            Self::TogMatchPlayer24Int,
            Self::TriesMatchPlayer25Int,
            Self::PointsMatchPlayer25Int,
            Self::TogMatchPlayer25Int,
            Self::TriesMatchPlayer26Int,
            Self::PointsMatchPlayer26Int,
            Self::TogMatchPlayer26Int,
            Self::TriesMatchPlayer27Int,
            Self::PointsMatchPlayer27Int,
            Self::TogMatchPlayer27Int,
            Self::TriesMatchPlayer28Int,
            Self::PointsMatchPlayer28Int,
            Self::TogMatchPlayer28Int,
            Self::TriesMatchPlayer29Int,
            Self::PointsMatchPlayer29Int,
            Self::TogMatchPlayer29Int,
            Self::TriesMatchPlayer30Int,
            Self::PointsMatchPlayer30Int,
            Self::TogMatchPlayer30Int,
            Self::TriesMatchPlayer31Int,
            Self::PointsMatchPlayer31Int,
            Self::TogMatchPlayer31Int,
            Self::TriesMatchPlayer32Int,
            Self::PointsMatchPlayer32Int,
            Self::TogMatchPlayer32Int,
            Self::TriesMatchPlayer33Int,
            Self::PointsMatchPlayer33Int,
            Self::TogMatchPlayer33Int,
            Self::TriesMatchPlayer34Int,
            Self::PointsMatchPlayer34Int,
            Self::TogMatchPlayer34Int,
        ]
    }

    pub const fn group_first_half_player_stats() -> [Self; 34] {
        [
            Self::TriesHalf1Player1Int,
            Self::TriesHalf1Player2Int,
            Self::TriesHalf1Player3Int,
            Self::TriesHalf1Player4Int,
            Self::TriesHalf1Player5Int,
            Self::TriesHalf1Player6Int,
            Self::TriesHalf1Player7Int,
            Self::TriesHalf1Player8Int,
            Self::TriesHalf1Player9Int,
            Self::TriesHalf1Player10Int,
            Self::TriesHalf1Player11Int,
            Self::TriesHalf1Player12Int,
            Self::TriesHalf1Player13Int,
            Self::TriesHalf1Player14Int,
            Self::TriesHalf1Player15Int,
            Self::TriesHalf1Player16Int,
            Self::TriesHalf1Player17Int,
            Self::TriesHalf1Player18Int,
            Self::TriesHalf1Player19Int,
            Self::TriesHalf1Player20Int,
            Self::TriesHalf1Player21Int,
            Self::TriesHalf1Player22Int,
            Self::TriesHalf1Player23Int,
            Self::TriesHalf1Player24Int,
            Self::TriesHalf1Player25Int,
            Self::TriesHalf1Player26Int,
            Self::TriesHalf1Player27Int,
            Self::TriesHalf1Player28Int,
            Self::TriesHalf1Player29Int,
            Self::TriesHalf1Player30Int,
            Self::TriesHalf1Player31Int,
            Self::TriesHalf1Player32Int,
            Self::TriesHalf1Player33Int,
            Self::TriesHalf1Player34Int,
        ]
    }

    pub const fn group_second_half_and_extra_time_player_stats() -> [Self; 34] {
        [
            Self::TriesHalf2AndExtraTimePlayer1Int,
            Self::TriesHalf2AndExtraTimePlayer2Int,
            Self::TriesHalf2AndExtraTimePlayer3Int,
            Self::TriesHalf2AndExtraTimePlayer4Int,
            Self::TriesHalf2AndExtraTimePlayer5Int,
            Self::TriesHalf2AndExtraTimePlayer6Int,
            Self::TriesHalf2AndExtraTimePlayer7Int,
            Self::TriesHalf2AndExtraTimePlayer8Int,
            Self::TriesHalf2AndExtraTimePlayer9Int,
            Self::TriesHalf2AndExtraTimePlayer10Int,
            Self::TriesHalf2AndExtraTimePlayer11Int,
            Self::TriesHalf2AndExtraTimePlayer12Int,
            Self::TriesHalf2AndExtraTimePlayer13Int,
            Self::TriesHalf2AndExtraTimePlayer14Int,
            Self::TriesHalf2AndExtraTimePlayer15Int,
            Self::TriesHalf2AndExtraTimePlayer16Int,
            Self::TriesHalf2AndExtraTimePlayer17Int,
            Self::TriesHalf2AndExtraTimePlayer18Int,
            Self::TriesHalf2AndExtraTimePlayer19Int,
            Self::TriesHalf2AndExtraTimePlayer20Int,
            Self::TriesHalf2AndExtraTimePlayer21Int,
            Self::TriesHalf2AndExtraTimePlayer22Int,
            Self::TriesHalf2AndExtraTimePlayer23Int,
            Self::TriesHalf2AndExtraTimePlayer24Int,
            Self::TriesHalf2AndExtraTimePlayer25Int,
            Self::TriesHalf2AndExtraTimePlayer26Int,
            Self::TriesHalf2AndExtraTimePlayer27Int,
            Self::TriesHalf2AndExtraTimePlayer28Int,
            Self::TriesHalf2AndExtraTimePlayer29Int,
            Self::TriesHalf2AndExtraTimePlayer30Int,
            Self::TriesHalf2AndExtraTimePlayer31Int,
            Self::TriesHalf2AndExtraTimePlayer32Int,
            Self::TriesHalf2AndExtraTimePlayer33Int,
            Self::TriesHalf2AndExtraTimePlayer34Int,
        ]
    }
}
