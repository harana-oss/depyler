use std::env;
use std::fs::{self, File};
use std::io::{Read, Result, Write};
use std::path::PathBuf;

fn main() -> Result<()> {
    let manifest_dir = env::var("CARGO_MANIFEST_DIR").unwrap();
    let proto_dir = PathBuf::from(&manifest_dir).join("src/contracts/proto");
    let out_dir = PathBuf::from(&manifest_dir).join("src/contracts");
    let tmp_out_dir = PathBuf::from(&manifest_dir).join("target/tmp");

    fs::create_dir_all(&out_dir)?;
    fs::create_dir_all(&tmp_out_dir)?;

    prost_build::Config::new()
        .out_dir(&tmp_out_dir)
        .compile_protos(
            &fs::read_dir(&proto_dir)?
                .filter_map(|entry| {
                    let path = entry.ok()?.path();
                    if path.extension()? == "proto" {
                        Some(path)
                    } else {
                        None
                    }
                })
                .collect::<Vec<_>>(),
            &[&proto_dir],
        )?;

    let mut contracts_rs = File::create(out_dir.join("mod.rs"))?;
    for entry in fs::read_dir(&tmp_out_dir)? {
        let entry = entry?;
        let path = entry.path();
        if path.extension().and_then(|s| s.to_str()) == Some("rs") {
            let mut file = File::open(&path)?;
            let mut contents = String::new();
            file.read_to_string(&mut contents)?;
            writeln!(
                contracts_rs,
                "// BEGIN: {}\n{}\n// END: {}\n",
                path.display(),
                contents,
                path.display()
            )?;
        }
    }

    println!("cargo:rerun-if-changed=src/contracts/proto/");

    Ok(())
}
