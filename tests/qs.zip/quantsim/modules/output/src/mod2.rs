pub mod ctx;
pub mod rng;
pub mod simulation_processor;
pub mod simulation_runner;

use std::{collections::HashMap, time::Instant};

use rayon::prelude::*;
// use simulator_core::monitor::{NrlSubModelsMetricsRecorder, aggregate};
use thiserror::Error;

use crate::{
    contracts::{GameStatus, ProductOfferingType, RunModelRequest},
    nrl::{
        executor::{
            // rng::RngGen,
            simulation_processor::{SimulationProcessor, SubModelRunnerCtx},
            simulation_runner::SimulationRunner,
        },
        invariants::SimulationInvariants,
        model_data::constants,
        result::{ResultRecorderType, SubModelResultProcessor, SubmodelResultRecorder},
        solver::{Nudges, PlayerParameters, SolverParameters, TraderState},
        states::{GameState, SimulationState, reset_state},
        submodels::ModelPackager,
    },
};

#[derive(Debug, Error)]
pub enum ExecutorError {
    #[error("Executor error: {0}")]
    Generic(String),
    #[error("Cannot run for prematch games already in running or finished game")]
    GameType,
    #[error("Invalid run model request: {0}")]
    InvalidRmr(String),
}

#[derive(Debug, Default)]
pub struct Executor {
    pub name: String,
}

impl Executor {
    pub fn new() -> Self {
        Self {
            name: "NRL Simulator".to_string(),
        }
    }
}

impl Executor {
    pub fn run_simulation(
        &self,
        rmr: RunModelRequest,
        num_simulations: Option<usize>,
    ) -> Result<Vec<SubModelResultProcessor>, ExecutorError> {
        let valid_rmr = self.validate_rmr(rmr)?;

        let res = self.run_model(&valid_rmr, num_simulations)?;
        Ok(res)
    }

    fn validate_rmr(&self, rmr: RunModelRequest) -> Result<RunModelRequest, ExecutorError> {
        if let Some(trading_state) = &rmr.trading_state {
            if trading_state.home_team_players.len() != 17
                || trading_state.away_team_players.len() != 17
            {
                Err(ExecutorError::InvalidRmr(
                    "Each team must have exactly 17 players".to_string(),
                ))
            } else if (trading_state.product_offering_type
                == ProductOfferingType::PrematchOnly as i32
                && rmr.game_has_started)
                || rmr.game_status == GameStatus::Ended as i32
            {
                Err(ExecutorError::GameType)
            } else {
                Ok(rmr)
            }
        } else {
            Err(ExecutorError::InvalidRmr(
                "Missing trading state".to_string(),
            ))
        }
    }

    fn run_model(
        &self,
        rmr: &RunModelRequest,
        num_simulations: Option<usize>,
    ) -> Result<Vec<SubModelResultProcessor>, ExecutorError> {
        let nudges = Nudges::from_rmr(rmr);
        let solver_params = SolverParameters::from_rmr(rmr);
        let player_params = PlayerParameters::from_rmr(rmr);
        let game_state = if rmr.game_has_started {
            GameState::from_rmr(rmr)
        } else {
            GameState::pre_match_default()
        };
        let event_id = &rmr.event_id;
        let correlation_id = &rmr.correlation_id;
        let logical_clock = rmr.logical_clock;

        let num_simulations =
            num_simulations.unwrap_or(constants::NUMBER_OF_SIMULATIONS_DEFAULT as usize);

        let res = self
            .run_model_inner(
                event_id,
                correlation_id,
                logical_clock,
                solver_params,
                player_params,
                nudges,
                game_state,
                num_simulations,
                // &rng,
            )
            .unwrap();

        Ok(res)
    }

    #[allow(clippy::too_many_arguments)]
    fn run_model_inner(
        &self,
        _event_id: &str,
        _correlation_id: &str,
        _logical_clock: i64,
        _solver_params: Option<SolverParameters>,
        _player_params: Option<PlayerParameters>,
        _nudges: Nudges,
        game_state: GameState,
        num_simulations: usize,
        // rng: &RngGen,
    ) -> Result<Vec<SubModelResultProcessor>, ExecutorError> {
        // let mut trader_state = self
        //     .get_solver_solution(
        //         _event_id,
        //         &solver_params.unwrap(),
        //         game_state,
        //         num_simulations,
        //         rng,
        //     )
        //     .map_err(|e| ExecutorError::GenError(format!("{}", e.to_string())))?;

        // let nudged_trader_state = trader_state.apply_nudges(nudges);

        // if player_params.is_some() {
        //     nudged_trader_state.set_player_parameters(player_params.unwrap());
        //     nudged_trader_state
        //         .set_solved_players(nudged_trader_state.solved_players.clone().unwrap());
        //     nudged_trader_state
        //         .set_player_of_the_match(nudged_trader_state.player_of_the_match_enabled);
        // }

        // mock
        let nudged_trader_state = TraderState {
            solved_players: HashMap::new(),
            player_parameters: None,
            total_points: 21.20302818878869,
            home_price: 2.0,
            handicap: 3.8773134403949188,
            player_of_the_match_enabled: false,
        };

        let simulation_invariants = SimulationInvariants::new(&game_state, nudged_trader_state);
        let simulation_state = SimulationState::new(&simulation_invariants);

        // println!("simulation_state: {:?}", simulation_state);

        let team_a_vec = game_state
            .home_players_trader_state
            .iter()
            .map(|p| p.player_index as usize)
            .collect::<Vec<usize>>();

        let team_b_vec = game_state
            .away_players_trader_state
            .iter()
            .map(|p| p.player_index as usize)
            .collect::<Vec<usize>>();

        let team_a: [usize; 17] = team_a_vec.clone().try_into().unwrap();

        let team_b: [usize; 17] = team_b_vec.clone().try_into().unwrap();

        // mock
        // let team_a = [
        //     71, 69, 42, 70, 38, 55, 50, 64, 54, 73, 44, 52, 56, 101, 102, 103, 104,
        // ];
        // let team_b = [
        //     29, 23, 31, 27, 6, 7, 36, 11, 26, 18, 20, 28, 15, 105, 106, 107, 108,
        // ];

        let team_all = Some((&team_a, &team_b));

        // println!("Sub model processor started...");
        let start_time_total = Instant::now();
        let submodel_res_recorder = SubmodelResultRecorder::new(num_simulations);
        // println!(
        //     "For {} simulations, the total size of result recorder allocated in bytes: {}\n",
        //     num_simulations,
        //     std::mem::size_of_val(&submodel_res_recorder),
        // );
        let mut recorder_rows = submodel_res_recorder.rows;
        // let mut sub_models_metrics_recoder = NrlSubModelsMetricsRecorder::new(num_simulations);

        // let rng_rows = &rng.rows;

        let mp = ModelPackager::global();

        // let mut combined_pairs: Vec<_> = recorder_rows
        //     .iter_mut()
        //     .zip(sub_models_metrics_recoder.iter_mut())
        //     .collect();

        #[allow(clippy::unused_enumerate_index)]
        recorder_rows.par_chunks_mut(64).enumerate().for_each(
            |(_batch_index, batched_processor)| {
                batched_processor
                    .iter_mut()
                    .enumerate()
                    .for_each(|(_, processor)| {
                        // let start_time_single = std::time::Instant::now();

                        // let run_idx = batch_index * 64 + idx;
                        // println!("runs {}...", run_idx);

                        let mut state = reset_state(&simulation_state);
                        // let recorder = &sub_models_recoder[run_idx];
                        let sim_ctx = SubModelRunnerCtx::new(
                            mp,
                            // rng_rows[idx] as f64,
                            // metrics_fetcher,
                            ResultRecorderType::SubModelOutputRecorder(processor),
                            &team_all,
                        );

                        let sim_processor = SimulationProcessor::new(sim_ctx);
                        let mut sim_runner = SimulationRunner::new(sim_processor);
                        sim_runner.run(&mut state);

                        // let end_time_single = start_time_single.elapsed();
                        // metrics_fetcher.single_running_time_nanosec =
                        //     end_time_single.as_nanos() as f64;
                        // println!("One run completed in: {:?}", end_time_single);
                    });
            },
        );

        // combined_pairs.par_chunks_mut(64).enumerate().for_each(
        //     |(batch_index, batched_processor)| {
        //         batched_processor.iter_mut().enumerate().for_each(
        //             |(idx, (processor, metrics_fetcher))| {
        //                 let start_time_single = std::time::Instant::now();

        //                 let run_idx = batch_index * 64 + idx;
        //                 println!("runs {}...", run_idx);

        //                 let mut state = reset_state(&simulation_state);
        //                 // let recorder = &sub_models_recoder[run_idx];
        //                 let sim_ctx = SubModelRunnerCtx::new(
        //                     mp,
        //                     // rng_rows[idx] as f64,
        //                     metrics_fetcher,
        //                     ResultRecorderType::SubModelOutputRecorder(processor),
        //                 );

        //                 let sim_processor = SimulationProcessor::new(sim_ctx);
        //                 let mut sim_runner = SimulationRunner::new(sim_processor, &team_all);
        //                 sim_runner.run(&mut state);

        //                 let end_time_single = start_time_single.elapsed();
        //                 metrics_fetcher.single_running_time_nanosec =
        //                     end_time_single.as_nanos() as f64;
        //                 println!("One run completed in: {:?}", end_time_single);
        //             },
        //         );
        //     },
        // );

        let end_time_total = start_time_total.elapsed();
        println!(
            "Total runs: {}, sub models completed in: {:?}\n",
            num_simulations, end_time_total
        );

        // let metrics = aggregate(sub_models_metrics_recoder, end_time_total.as_secs_f64());

        // if metrics.is_some() {
        //     let res = metrics.unwrap();
        //     println!("Metrics data collected: {}", json!(res));
        // } else {
        //     println!("No metrics data collected.");
        // };

        // println!(
        //     "The final size of recorded result in bytes: {}\n",
        //     std::mem::size_of_val(&recorder_rows),
        // );

        Ok(recorder_rows)
    }

    // fn _get_solver_solution(
    //     &self,
    //     _event_id: &str,
    //     solver_parameters: &SolverParameters,
    //     game_state: &GameState,
    //     num_simulations: usize,
    //     rng: &RngGen,
    // ) -> Result<TraderState, SolverError> {
    //     // Ignore cached solution retrieval for now
    //     println!("Solver started...");
    //     let start_time = Instant::now();
    //     let solver_res_recorder = SolverResultRecorder::new(
    //         num_simulations,
    //         solver_parameters.handicap,
    //         solver_parameters.total_points,
    //     );
    //     let trader_state =
    //         InitialGuessSolver::solve(solver_parameters, game_state, &solver_res_recorder, rng);

    //     let end_time = start_time.elapsed();
    //     println!("Solver completed in: {:?}", end_time);

    //     trader_state
    // }
}
