# OutputManager

## Overview
`OutputManager` is a thread-safe singleton manager for recording simulation outputs in the quantsim-output module, similar to the `ModelManager` pattern used in the quantsim-model module.

## Features
- **Thread-safe**: Uses `Mutex` for interior mutability
- **Singleton pattern**: Global instance accessible via `get_output_manager()`
- **Two data types**: Supports both integer (`i32`) and boolean (`bool`) outputs
- **Convenience functions**: Global `record_int()` and `record_bool()` functions for easy usage

## Public API

### OutputManager Methods
```rust
impl OutputManager {
    /// Create a new OutputManager instance
    pub fn new() -> Self

    /// Record an integer output with the given key
    pub fn record_int(&self, key: &str, value: i32)

    /// Record a boolean output with the given key
    pub fn record_bool(&self, key: &str, value: bool)

    /// Get a copy of all int outputs (for testing or inspection)
    pub fn get_int_outputs(&self) -> HashMap<String, i32>

    /// Get a copy of all bool outputs (for testing or inspection)
    pub fn get_bool_outputs(&self) -> HashMap<String, bool>

    /// Clear all outputs
    pub fn clear(&self)
}
```

### Global Functions
```rust
/// Set the global OutputManager instance
pub fn set_output_manager(manager: OutputManager)

/// Get the global OutputManager instance
pub fn get_output_manager() -> &'static OutputManager

/// Convenience function to record an integer output using the global manager
pub fn record_int(key: &str, value: i32)

/// Convenience function to record a boolean output using the global manager
pub fn record_bool(key: &str, value: bool)
```

## Usage Examples

### Using Convenience Functions (Recommended)
```rust
use quantsim_output::{record_int, record_bool};

// Record outputs
record_int("score_home", 24);
record_int("score_away", 18);
record_bool("home_win", true);
record_bool("overtime", false);
```

### Using the Global Manager Directly
```rust
use quantsim_output::get_output_manager;

let manager = get_output_manager();
manager.record_int("tries", 5);
manager.record_bool("golden_point", false);

// Inspect outputs
let int_outputs = manager.get_int_outputs();
let bool_outputs = manager.get_bool_outputs();
```

### Using a Custom Manager Instance
```rust
use quantsim_output::OutputManager;

let manager = OutputManager::new();
manager.record_int("custom_metric", 42);
manager.record_bool("flag", true);

// Clear when done
manager.clear();
```

## Architecture Comparison with ModelManager

### ModelManager (quantsim-model)
- Manages ONNX model loading and inference
- Uses Tract runtime for ONNX inference
- Thread-safe singleton via `OnceLock`
- Methods: `load_model()`, `infer()`, `runtime()`

### OutputManager (quantsim-output)
- Manages simulation output recording
- Stores int and bool outputs in `HashMap`s
- Thread-safe singleton via `OnceLock`
- Methods: `record_int()`, `record_bool()`, `clear()`

Both follow the same design pattern:
1. Struct with internal state
2. Global singleton using `OnceLock`
3. Setter function for custom instances
4. Getter function for global instance
5. Convenience functions that use the global instance

## Testing
The module includes comprehensive unit tests:
- `test_record_int()` - Tests integer recording
- `test_record_bool()` - Tests boolean recording
- `test_clear()` - Tests clearing outputs
- `test_global_manager()` - Tests global convenience functions

Run tests with:
```bash
cd modules/output
cargo test
```

## Thread Safety
The `OutputManager` uses `Mutex<HashMap<>>` for both int and bool outputs, ensuring thread-safe access even when shared across multiple threads. The global instance is stored in a `OnceLock`, which provides thread-safe one-time initialization.
