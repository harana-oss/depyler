use super::*;

#[test]
fn test_singleton_random() {
    // Test the singleton random() function
    let num1 = random();
    assert!(num1 >= 0.0 && num1 < 1.0);

    let num2 = random();
    assert!(num2 >= 0.0 && num2 < 1.0);

    // Should be different numbers (with high probability)
    assert_ne!(num1, num2);
}

#[test]
fn test_singleton_random_range() {
    for _ in 0..10 {
        let num = random_range(5.0, 10.0);
        assert!(num >= 5.0 && num < 10.0);
    }
}

#[test]
fn test_singleton_random_int_range() {
    for _ in 0..10 {
        let num = random_int_range(1, 6);
        assert!(num >= 1 && num <= 6);
    }
}

#[test]
fn test_get_rng_manager() {
    let manager = get_rng_manager();
    let num = manager.next();
    assert!(num >= 0.0 && num < 1.0);

    // Should return the same instance
    let manager2 = get_rng_manager();
    assert!(std::ptr::eq(manager, manager2));
}

#[test]
fn test_with_capacity_using_xoshiro() {
    let manager = RngManager::with_capacity(1000);

    // Verify capacity is rounded to next power of 2
    assert_eq!(manager.capacity(), 1024);

    // Verify we can generate valid random numbers
    let num = manager.next();
    assert!(
        num >= 0.0 && num < 1.0,
        "Random number should be in [0.0, 1.0), got {}",
        num
    );
}

#[test]
fn test_fill_bytes_generates_different_numbers() {
    let manager = RngManager::with_capacity(100);

    let mut numbers = Vec::new();
    for _ in 0..10 {
        numbers.push(manager.next());
    }

    // Check all numbers are in valid range
    for num in &numbers {
        assert!(*num >= 0.0 && *num < 1.0);
    }

    // Check numbers are different (with high probability)
    // Compare pairs to ensure we have variety
    let first = numbers[0];
    let all_same = numbers.iter().all(|&n| n == first);
    assert!(!all_same, "Should have different numbers");
}

#[test]
fn test_new_uses_default_capacity() {
    let manager = RngManager::new();
    assert_eq!(manager.capacity(), 131_072);
}

#[test]
fn test_next_range() {
    let manager = RngManager::with_capacity(100);

    for _ in 0..50 {
        let num = manager.next_range(10.0, 20.0);
        assert!(num >= 10.0 && num < 20.0);
    }
}

#[test]
fn test_performance_of_fill_bytes() {
    // This test just ensures we can create a large manager quickly
    let start = std::time::Instant::now();
    let manager = RngManager::with_capacity(100_000);
    let elapsed = start.elapsed();

    println!("Created 100k numbers in {:?}", elapsed);
    assert_eq!(manager.capacity(), 131_072); // Next power of 2

    // Verify we can access numbers
    let num = manager.next();
    assert!(num >= 0.0 && num < 1.0);
}
