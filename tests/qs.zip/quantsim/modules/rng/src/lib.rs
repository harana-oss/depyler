use rand::{RngCore, SeedableRng};
use rand_xoshiro::Xoshiro256PlusPlus;
use std::sync::OnceLock;
use std::sync::atomic::{AtomicUsize, Ordering};

/// Thread-safe pre-generated RNG with atomic index and power-of-2 masking.
#[repr(C, align(64))]
pub struct RngManager {
    numbers: Box<[f64]>,
    index: AtomicUsize,
    mask: usize,
}

impl RngManager {
    const DEFAULT_CAPACITY: usize = 131_072; // 2^17

    #[inline]
    pub fn new() -> Self {
        Self::with_capacity(Self::DEFAULT_CAPACITY)
    }

    /// Capacity rounded up to next power of 2
    pub fn with_capacity(capacity: usize) -> Self {
        let capacity = capacity.next_power_of_two();
        let mut rng = Xoshiro256PlusPlus::seed_from_u64(rand::random());

        // Allocate buffer for bytes (8 bytes per f64)
        let mut bytes = vec![0u8; capacity * 8];
        rng.fill_bytes(&mut bytes);

        // Convert bytes to f64 values in [0.0, 1.0)
        let numbers: Box<[f64]> = bytes
            .chunks_exact(8)
            .map(|chunk| {
                let bits = u64::from_le_bytes([
                    chunk[0], chunk[1], chunk[2], chunk[3], chunk[4], chunk[5], chunk[6], chunk[7],
                ]);
                // Convert to f64 in [0.0, 1.0) using the standard method
                // Use 53 bits of precision (mantissa of f64)
                (bits >> 11) as f64 * (1.0 / ((1u64 << 53) as f64))
            })
            .collect();

        Self {
            numbers,
            index: AtomicUsize::new(0),
            mask: capacity - 1,
        }
    }

    #[inline(always)]
    pub fn next(&self) -> f64 {
        let idx = self.index.fetch_add(1, Ordering::Relaxed) & self.mask;
        unsafe { *self.numbers.get_unchecked(idx) }
    }

    #[inline(always)]
    pub fn next_range(&self, min: f64, max: f64) -> f64 {
        min + (max - min) * self.next()
    }

    #[inline(always)]
    pub fn next_int_range(&self, min: i64, max: i64) -> i64 {
        min + ((max - min + 1) as f64 * self.next()) as i64
    }

    #[inline]
    pub fn current_index(&self) -> usize {
        self.index.load(Ordering::Relaxed) & self.mask
    }

    #[inline]
    pub fn reset(&self) {
        self.index.store(0, Ordering::Relaxed);
    }

    #[inline]
    pub fn capacity(&self) -> usize {
        self.mask + 1
    }
}

impl Default for RngManager {
    fn default() -> Self {
        Self::new()
    }
}

static RNG_MANAGER: OnceLock<RngManager> = OnceLock::new();

pub fn set_rng_manager(manager: RngManager) {
    let _ = RNG_MANAGER.set(manager);
}

pub fn get_rng_manager() -> &'static RngManager {
    RNG_MANAGER.get_or_init(|| RngManager::new())
}

/// Returns the next random number from the singleton RNG manager
#[inline(always)]
pub fn random() -> f64 {
    get_rng_manager().next()
}

/// Returns the next random number in a specified range [min, max)
#[inline(always)]
pub fn random_range(min: f64, max: f64) -> f64 {
    get_rng_manager().next_range(min, max)
}

/// Returns the next random integer in a specified range [min, max]
#[inline(always)]
pub fn random_int_range(min: i64, max: i64) -> i64 {
    get_rng_manager().next_int_range(min, max)
}

#[cfg(test)]
mod tests;
