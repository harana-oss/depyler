use std::error::Error as StdError;
use std::fmt;

mod destinations;

pub use destinations::{ConsoleDestination, FileDestination};

pub type EventHandler<S, E> = Box<dyn Fn(&S) -> Result<(), E> + Send + Sync>;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum LogLevel {
    Debug = 0,
    Info = 1,
    Warn = 2,
    Error = 3,
}

impl fmt::Display for LogLevel {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            LogLevel::Debug => write!(f, "DEBUG"),
            LogLevel::Info => write!(f, "INFO"),
            LogLevel::Warn => write!(f, "WARN"),
            LogLevel::Error => write!(f, "ERROR"),
        }
    }
}

pub trait LogDestination: Send + Sync {
    fn write(&self, level: LogLevel, message: &str) -> Result<(), Box<dyn StdError>>;
    fn flush(&self) -> Result<(), Box<dyn StdError>>;
}

pub struct LogManager {
    destinations: Vec<Box<dyn LogDestination>>,
    min_level: LogLevel,
}

impl LogManager {
    pub fn new(min_level: LogLevel) -> Self {
        Self {
            destinations: Vec::new(),
            min_level,
        }
    }

    pub fn add_destination(&mut self, destination: Box<dyn LogDestination>) {
        self.destinations.push(destination);
    }

    pub fn set_min_level(&mut self, level: LogLevel) {
        self.min_level = level;
    }

    pub fn min_level(&self) -> LogLevel {
        self.min_level
    }

    pub fn log(&self, level: LogLevel, message: &str) {
        if level < self.min_level {
            return;
        }

        for destination in &self.destinations {
            if let Err(e) = destination.write(level, message) {
                eprintln!("Failed to write log: {}", e);
            }
        }
    }

    pub fn debug(&self, message: &str) {
        self.log(LogLevel::Debug, message);
    }

    pub fn info(&self, message: &str) {
        self.log(LogLevel::Info, message);
    }

    pub fn warn(&self, message: &str) {
        self.log(LogLevel::Warn, message);
    }

    pub fn error(&self, message: &str) {
        self.log(LogLevel::Error, message);
    }

    pub fn flush(&self) -> Result<(), Box<dyn StdError>> {
        for destination in &self.destinations {
            destination.flush()?;
        }
        Ok(())
    }
}

impl Default for LogManager {
    fn default() -> Self {
        let mut manager = Self::new(LogLevel::Info);
        manager.add_destination(Box::new(ConsoleDestination::new()));
        manager
    }
}
