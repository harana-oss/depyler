use std::error::Error as StdError;
use std::io::{self, Write};

use crate::{LogDestination, LogLevel};

pub struct ConsoleDestination;

impl ConsoleDestination {
    pub fn new() -> Self {
        Self
    }
}

impl Default for ConsoleDestination {
    fn default() -> Self {
        Self::new()
    }
}

impl LogDestination for ConsoleDestination {
    fn write(&self, level: LogLevel, message: &str) -> Result<(), Box<dyn StdError>> {
        let timestamp = chrono::Local::now().format("%Y-%m-%d %H:%M:%S%.3f");
        match level {
            LogLevel::Error => eprintln!("[{}] [{}] {}", timestamp, level, message),
            _ => println!("[{}] [{}] {}", timestamp, level, message),
        }
        Ok(())
    }

    fn flush(&self) -> Result<(), Box<dyn StdError>> {
        io::stdout().flush()?;
        io::stderr().flush()?;
        Ok(())
    }
}
