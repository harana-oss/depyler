use std::error::Error as StdError;
use std::fs::{File, OpenOptions};
use std::io::{self, Write};
use std::path::Path;
use std::sync::{Arc, Mutex};

use crate::{LogDestination, LogLevel};

pub struct FileDestination {
    file: Arc<Mutex<File>>,
}

impl FileDestination {
    pub fn new<P: AsRef<Path>>(path: P) -> Result<Self, Box<dyn StdError>> {
        let file = OpenOptions::new().create(true).append(true).open(path)?;
        Ok(Self {
            file: Arc::new(Mutex::new(file)),
        })
    }

    fn lock_file(&self) -> Result<std::sync::MutexGuard<File>, Box<dyn StdError>> {
        self.file.lock().map_err(|e| {
            Box::new(io::Error::new(
                io::ErrorKind::Other,
                format!("Failed to lock file: {}", e),
            )) as Box<dyn StdError>
        })
    }
}

impl LogDestination for FileDestination {
    fn write(&self, level: LogLevel, message: &str) -> Result<(), Box<dyn StdError>> {
        let timestamp = chrono::Local::now().format("%Y-%m-%d %H:%M:%S%.3f");
        let mut file = self.lock_file()?;
        writeln!(file, "[{}] [{}] {}", timestamp, level, message)?;
        Ok(())
    }

    fn flush(&self) -> Result<(), Box<dyn StdError>> {
        self.lock_file()?.flush()?;
        Ok(())
    }
}
