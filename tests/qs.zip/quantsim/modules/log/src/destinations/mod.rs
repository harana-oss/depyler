mod console;
mod file;

pub use console::ConsoleDestination;
pub use file::FileDestination;
