pub mod tensor_pool;
pub mod tract;

use bevy_reflect::Reflect;
use log::info;
use std::collections::HashMap;
use std::hash::{Hash, Hasher};
use std::path::Path;
use std::sync::{Arc, LazyLock};
use tensor_pool::global_pool;
use tract::TractRuntime;
use tract_hir::internal::TractResult;
use tract_onnx::prelude::*;

pub use ndarray;

static MODEL_CACHE: LazyLock<papaya::HashMap<String, Arc<TypedSimplePlan<TypedModel>>>> =
    LazyLock::new(papaya::HashMap::new);
static INFERENCE_CACHE: LazyLock<
    papaya::HashMap<InferenceCacheKey, Arc<HashMap<String, Vec<f64>>>>,
> = LazyLock::new(papaya::HashMap::new);
static MODEL_MANAGER: LazyLock<ModelManager> = LazyLock::new(ModelManager::new);

#[derive(Clone, PartialEq, Eq)]
struct InferenceCacheKey {
    model_name: String,
    input_bits: Vec<u64>,
}

impl Hash for InferenceCacheKey {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.model_name.hash(state);
        self.input_bits.hash(state);
    }
}

impl InferenceCacheKey {
    fn new(model_name: &str, input: &[f64]) -> Self {
        Self {
            model_name: model_name.to_string(),
            input_bits: input.iter().map(|f| f.to_bits()).collect(),
        }
    }
}

pub struct ModelManager {
    runtime: TractRuntime,
}

impl ModelManager {
    pub fn new() -> Self {
        Self {
            runtime: TractRuntime::new(),
        }
    }

    pub fn load_model<P: AsRef<Path>>(
        &self,
        model_path: P,
        input_size: usize,
    ) -> TractResult<TypedSimplePlan<TypedModel>> {
        self.runtime.load(model_path, input_size)
    }

    pub fn infer(
        &self,
        model: &TypedSimplePlan<TypedModel>,
        input: Vec<f32>,
    ) -> Result<HashMap<String, Vec<f64>>, String> {
        let start = std::time::Instant::now();
        let shape = vec![1, input.len()];

        let pool = global_pool();
        let mut pooled_data = pool.acquire_f32(input.len());
        pooled_data.extend(input.iter().copied());

        let input_tensor = tract_hir::internal::tract_ndarray::ArrayD::from_shape_vec(
            shape,
            pooled_data.into_vec(),
        )
        .map_err(|e| format!("Failed to create tensor: {}", e))?
        .into();

        let result = TractRuntime::infer(model, input_tensor);
        log::info!("ModelManager::infer() took {:?}", start.elapsed());
        result
    }

    pub fn runtime(&self) -> &TractRuntime {
        &self.runtime
    }
}

fn run_inference(name: &str, input: &[f64]) -> HashMap<String, Vec<f64>> {
    let model_path = format!("../models/{}.onnx", name);

    let pool = global_pool();

    let mut pooled_input = pool.acquire_f32(input.len());
    pooled_input.extend(input.iter().map(|&x| x as f32));
    let input_f32 = pooled_input.into_vec();
    let input_size = input_f32.len();

    let cache = MODEL_CACHE.pin();
    let model = if let Some(model) = cache.get(name) {
        info!("Found cached model for '{}'", name);
        Arc::clone(model)
    } else {
        let loaded_model = Arc::new(
            MODEL_MANAGER
                .runtime()
                .load(&model_path, input_size)
                .unwrap(),
        );
        cache.insert(name.to_string(), Arc::clone(&loaded_model));
        loaded_model
    };

    let input_array = input_f32;

    info!(
        "{} inputs for model '{}': {:?}",
        input.len(),
        name,
        input_array
    );

    // let start = std::time::Instant::now();
    let output = MODEL_MANAGER
        .infer(&model, input_array)
        .unwrap_or_else(|e| panic!("{:?}", e));
    // log::info!("Model '{}' infer() took {:?}", name, start.elapsed());

    output
}

pub fn infer<E: Reflect + Default>(name: String, input: Vec<f64>) -> E {
    let cache_key = InferenceCacheKey::new(&name, &input);

    let cache = INFERENCE_CACHE.pin();
    let output = if let Some(cached_output) = cache.get(&cache_key) {
        Arc::clone(cached_output)
    } else {
        let raw_output = Arc::new(run_inference(&name, &input));
        cache.insert(cache_key, Arc::clone(&raw_output));
        raw_output
    };

    convert_output::<E>(&output)
}

fn convert_output<E: Reflect + Default>(output: &HashMap<String, Vec<f64>>) -> E {
    let mut instance = E::default();

    use bevy_reflect::ReflectMut;

    if let ReflectMut::Struct(struct_mut) = instance.reflect_mut() {
        for (field_name, array_data) in output {
            let Some(field) = struct_mut.field_mut(field_name) else {
                continue;
            };

            if array_data.len() == 1 {
                if let Some(f) = field.try_downcast_mut::<f64>() {
                    *f = array_data.iter().next().copied().unwrap_or_default();
                    continue;
                }
            }

            if let Some(field_vec) = field.try_downcast_mut::<Vec<f64>>() {
                *field_vec = array_data.clone();
            }
        }
    } else {
        panic!("Output type is not a struct");
    }

    instance
}
