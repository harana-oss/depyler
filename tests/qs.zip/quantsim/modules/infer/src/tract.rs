use crate::tensor_pool::global_pool;
use std::collections::HashMap;
use std::path::Path;
use tract_hir::internal::*;
use tract_onnx::{Onnx, prelude::TypedModel, tract_core::dims};

#[derive(Clone)]
pub struct TractRuntime {
    pub tract_rt: Onnx,
}

impl TractRuntime {
    pub fn new() -> Self {
        Self {
            tract_rt: tract_onnx::onnx(),
        }
    }

    pub fn load<P: AsRef<Path>>(
        &self,
        model_path: P,
        input_size: usize,
    ) -> TractResult<TypedSimplePlan<TypedModel>> {
        let mut model = self.tract_rt.model_for_path(model_path.as_ref())?;
        let fact = f32::fact(dims!(1, input_size)).into();
        model = model.with_input_fact(0, fact)?;
        TypedSimplePlan::new(model.into_optimized().unwrap())
    }

    pub fn infer(
        plan: &TypedSimplePlan<TypedModel>,
        input_tensor: Tensor,
    ) -> Result<HashMap<String, Vec<f64>>, String> {
        let mut state = SimpleState::new(plan).unwrap();

        let outputs = state
            .run(tvec!(input_tensor.into_tvalue()))
            .map_err(|e| format!("Inference failed: {:?}", e))?;

        let pool = global_pool();
        let mut result = HashMap::new();

        for (i, output_value) in outputs.into_iter().enumerate() {
            let output_name = plan
                .model()
                .output_outlets()
                .ok()
                .and_then(|outlets| outlets.get(i))
                .and_then(|outlet| plan.model().outlet_label(*outlet))
                .map(|s| s.to_string())
                .unwrap_or_else(|| format!("output_{}", i));

            let tensor = output_value.into_arc_tensor();
            let shape = tensor.shape().to_vec();
            let len: usize = shape.iter().product();

            let array = if let Ok(view) = tensor.to_array_view::<f32>() {
                let mut pooled = pool.acquire_f64(len);
                pooled.extend(view.iter().map(|&x| x as f64));
                pooled.into_vec()
            } else if let Ok(view) = tensor.to_array_view::<f64>() {
                let mut pooled = pool.acquire_f64(len);
                pooled.extend(view.iter().copied());
                pooled.into_vec()
            } else if let Ok(view) = tensor.to_array_view::<i64>() {
                let mut pooled = pool.acquire_f64(len);
                pooled.extend(view.iter().map(|&x| x as f64));
                pooled.into_vec()
            } else {
                return Err("Tensor has unsupported type".to_string());
            };
            result.insert(output_name, array);
        }
        Ok(result)
    }
}
