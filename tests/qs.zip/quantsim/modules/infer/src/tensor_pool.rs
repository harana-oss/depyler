// tensor_pool.rs
use parking_lot::Mutex;
use std::sync::OnceLock;
use tract_hir::prelude::TVec;

const DEFAULT_POOL_SIZE: usize = 100_000;
const BUFFER_SIZES: &[usize] = &[5, 7, 12, 16, 20];

pub struct TensorPool {
    f32_pools: Vec<Mutex<Vec<TVec<f32>>>>,
    f64_pools: Vec<Mutex<Vec<TVec<f64>>>>,
    bucket_sizes: Vec<usize>,
}

impl TensorPool {
    pub fn new(pool_size: usize) -> Self {
        let per_bucket = pool_size / BUFFER_SIZES.len();

        let f32_pools: Vec<_> = BUFFER_SIZES
            .iter()
            .map(|&size| {
                let buffers: Vec<TVec<f32>> =
                    (0..per_bucket).map(|_| TVec::with_capacity(size)).collect();
                Mutex::new(buffers)
            })
            .collect();

        let f64_pools: Vec<_> = BUFFER_SIZES
            .iter()
            .map(|&size| {
                let buffers: Vec<TVec<f64>> =
                    (0..per_bucket).map(|_| TVec::with_capacity(size)).collect();
                Mutex::new(buffers)
            })
            .collect();

        Self {
            f32_pools,
            f64_pools,
            bucket_sizes: BUFFER_SIZES.to_vec(),
        }
    }

    fn bucket_index(&self, size: usize) -> Option<usize> {
        self.bucket_sizes.iter().position(|&s| s >= size)
    }

    pub fn acquire_f32(&self, size: usize) -> PooledVecF32<'_> {
        let bucket = self.bucket_index(size);
        let mut vec = bucket
            .and_then(|i| self.f32_pools[i].lock().pop())
            .unwrap_or_else(|| TVec::with_capacity(size.max(64)));
        vec.clear();
        PooledVecF32 {
            vec: Some(vec),
            pool: self,
            bucket,
        }
    }

    pub fn acquire_f64(&self, size: usize) -> PooledVecF64<'_> {
        let bucket = self.bucket_index(size);
        let mut vec = bucket
            .and_then(|i| self.f64_pools[i].lock().pop())
            .unwrap_or_else(|| TVec::with_capacity(size.max(64)));
        vec.clear();
        PooledVecF64 {
            vec: Some(vec),
            pool: self,
            bucket,
        }
    }

    fn return_f32(&self, mut vec: TVec<f32>, bucket: Option<usize>) {
        if let Some(i) = bucket {
            vec.clear();
            self.f32_pools[i].lock().push(vec);
        }
    }

    fn return_f64(&self, mut vec: TVec<f64>, bucket: Option<usize>) {
        if let Some(i) = bucket {
            vec.clear();
            self.f64_pools[i].lock().push(vec);
        }
    }
}

impl Default for TensorPool {
    fn default() -> Self {
        Self::new(DEFAULT_POOL_SIZE)
    }
}

pub struct PooledVecF32<'a> {
    vec: Option<TVec<f32>>,
    pool: &'a TensorPool,
    bucket: Option<usize>,
}

impl std::ops::Deref for PooledVecF32<'_> {
    type Target = TVec<f32>;
    fn deref(&self) -> &Self::Target {
        self.vec.as_ref().unwrap()
    }
}

impl std::ops::DerefMut for PooledVecF32<'_> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.vec.as_mut().unwrap()
    }
}

impl PooledVecF32<'_> {
    pub fn into_inner(mut self) -> TVec<f32> {
        self.vec.take().unwrap()
    }

    pub fn into_vec(mut self) -> Vec<f32> {
        self.vec.take().unwrap().into_vec()
    }
}

impl Drop for PooledVecF32<'_> {
    fn drop(&mut self) {
        if let Some(vec) = self.vec.take() {
            self.pool.return_f32(vec, self.bucket);
        }
    }
}

pub struct PooledVecF64<'a> {
    vec: Option<TVec<f64>>,
    pool: &'a TensorPool,
    bucket: Option<usize>,
}

impl std::ops::Deref for PooledVecF64<'_> {
    type Target = TVec<f64>;
    fn deref(&self) -> &Self::Target {
        self.vec.as_ref().unwrap()
    }
}

impl std::ops::DerefMut for PooledVecF64<'_> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.vec.as_mut().unwrap()
    }
}

impl PooledVecF64<'_> {
    pub fn into_inner(mut self) -> TVec<f64> {
        self.vec.take().unwrap()
    }

    pub fn into_vec(mut self) -> Vec<f64> {
        self.vec.take().unwrap().into_vec()
    }
}

impl Drop for PooledVecF64<'_> {
    fn drop(&mut self) {
        if let Some(vec) = self.vec.take() {
            self.pool.return_f64(vec, self.bucket);
        }
    }
}

static TENSOR_POOL: OnceLock<TensorPool> = OnceLock::new();

pub fn global_pool() -> &'static TensorPool {
    TENSOR_POOL.get_or_init(TensorPool::default)
}
