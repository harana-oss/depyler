use crate::{
    contracts::{Player, RunModelRequest},
    nrl::model_data::PlayerPosition,
};

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct PlayerTraderState {
    pub position: PlayerPosition,
    pub expected_tries_per_minute: f64,
    pub tries_percentage: f64,
    pub tries_per_minute_in_use: bool,
    pub tries_percentage_in_use: bool,
    pub player_index: i32,
    pub is_starter: bool,
    pub is_interchange: bool,
    pub is_injured: bool,
    pub jersey_number: i32,
    pub home_team: bool,
    pub selected_for_points_market: bool,
    pub player_of_the_match_percentage: f64,
}

impl PlayerTraderState {
    fn from_player(player: &Player, is_home: bool) -> Self {
        Self {
            position: PlayerPosition::from(player.position),
            expected_tries_per_minute: player.tries_per_minute,
            tries_percentage: player.tries_percentage,
            tries_per_minute_in_use: player.tries_per_minute_in_use,
            tries_percentage_in_use: player.tries_percentage_in_use,
            player_index: player.player_index,
            is_starter: player.is_starter,
            is_interchange: player.is_interchange,
            is_injured: player.is_injured,
            jersey_number: player.jersey_number,
            home_team: is_home,
            selected_for_points_market: player.selected_for_points_market,
            player_of_the_match_percentage: player.player_of_the_match_percentage / 100.0,
        }
    }
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct PlayerParameters {
    pub home_players: Vec<PlayerTraderState>,
    pub away_players: Vec<PlayerTraderState>,
    pub all_players: Vec<PlayerTraderState>,
}

impl PlayerParameters {
    pub fn new(home_players: Vec<PlayerTraderState>, away_players: Vec<PlayerTraderState>) -> Self {
        let mut all_players = home_players.clone();
        all_players.extend(away_players.clone());

        Self {
            home_players,
            away_players,
            all_players,
        }
    }

    pub fn get_away_player_indexes(&self) -> Vec<i32> {
        self.away_players.iter().map(|p| p.player_index).collect()
    }

    pub fn get_home_player_indexes(&self) -> Vec<i32> {
        self.home_players.iter().map(|p| p.player_index).collect()
    }

    pub fn get_player_indexes(&self) -> Vec<i32> {
        self.all_players.iter().map(|p| p.player_index).collect()
    }
}

impl PlayerParameters {
    pub fn from_rmr(req: &RunModelRequest) -> Option<Self> {
        req.trading_state.as_ref()?;

        let trading_state = req.trading_state.as_ref().unwrap();

        let home_players: Vec<PlayerTraderState> = trading_state
            .home_team_players
            .iter()
            .map(|p| PlayerTraderState::from_player(p, true))
            .collect();

        let away_players: Vec<PlayerTraderState> = trading_state
            .away_team_players
            .iter()
            .map(|p| PlayerTraderState::from_player(p, false))
            .collect();

        Some(PlayerParameters::new(home_players, away_players))
    }
}
