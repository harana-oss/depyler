// use crate::nrl::executor::rng::RngGen;
// use crate::nrl::executor::simulation_processor::{SimulationProcessor, SubModelRunnerCtx};
// use crate::nrl::executor::simulation_runner::SimulationRunner;
// use crate::nrl::invariants::SimulationInvariants;
// use crate::nrl::result::ResultRecorderType;
// use crate::nrl::solver::{
//     SolverError, SolverParameters, SolverResultProcessor, SolverResultRecorder, TraderState,
//     calculate_probabilities,
// };
// use crate::nrl::states::{GameState, SimulationState, reset_state};
// use crate::nrl::submodels::ModelPackager;

// use nalgebra::{DMatrix, DVector};
// use rayon::prelude::*;
// use serde::de;

// const TOLERANCE: f64 = 0.003;
// const MAX_STRENGTH_LIMIT: f64 = 10000.0;
// const MIN_STRENGTH_LIMIT: f64 = -10000.0;

// pub struct DualObjectiveSolverProblemSpace {
//     solver_parameters: SolverParameters,
// }

// impl DualObjectiveSolverProblemSpace {
//     pub fn new(solver_parameters: SolverParameters) -> Self {
//         Self { solver_parameters }
//     }

//     pub fn initial_vector_from(initial_a: f64, initial_b: f64) -> Vec<f64> {
//         vec![initial_a, initial_b]
//     }
// }

// impl DualObjectiveSolverProblemSpace {
//     pub fn get_trader_state_for(&self, xx: &[f64]) -> TraderState {
//         let str_a = xx[0];
//         let str_b = xx[1];

//         TraderState {
//             total_points: str_a,
//             handicap: str_b,
//             home_price: 2.0,
//             ..Default::default()
//         }
//     }

//     pub fn get_errors_from(&self, result: Vec<SolverResultProcessor>) -> (Vec<f64>, String) {
//         let (handicap_home_prob, total_over_prob) = calculate_probabilities(result);
//         let err_home = handicap_home_prob - self.solver_parameters.handicap_prob_home;
//         let err_over = total_over_prob - self.solver_parameters.total_points_prob_over;

//         let log_string = format!("err over match {:.5}, err home {:.5}", err_over, err_home);
//         (vec![err_over, err_home], log_string)
//     }
// }

// #[derive(Debug, Default)]
// pub struct BroydenSolver {
//     pub model_type: String,
// }

// impl BroydenSolver {
//     pub fn new() -> Self {
//         Self {
//             model_type: "broyden".to_string(),
//         }
//     }

//     pub fn solve(
//         &self,
//         solver_parameters: &SolverParameters,
//         game_state: &GameState,
//         solver_space: DualObjectiveSolverProblemSpace,
//         initial_vector: Vec<f64>,
//         solver_res_recorder: &SolverResultRecorder,
//         rng: &RngGen,
//     ) -> Result<TraderState, SolverError> {
//         let roots = find_root_with_initial_jacobian(
//             initial_vector,
//             TOLERANCE,
//             100,
//             20.0,
//             solver_parameters,
//             &solver_space,
//             game_state,
//             solver_res_recorder,
//             rng,
//         )?;

//         let solved = solver_space.get_trader_state_for(&roots);

//         Ok(solved)
//     }
// }

// pub fn objective_func_probability_err(
//     xx: Vec<f64>,
//     _solver_parameters: &SolverParameters,
//     solver_space: &DualObjectiveSolverProblemSpace,
//     game_state: &GameState,
//     solver_res_recorder: &SolverResultRecorder,
//     rng: &RngGen,
// ) -> Result<Vec<f64>, SolverError> {
//     let trader_str = solver_space.get_trader_state_for(&xx);
//     let in_range = |par: f64| -> bool {
//         (MIN_STRENGTH_LIMIT..=MAX_STRENGTH_LIMIT).contains(&par) && par.is_finite()
//     };
//     if !in_range(trader_str.handicap) {
//         return Err(SolverError::NonConvergence(
//             trader_str.handicap.to_string(),
//             MIN_STRENGTH_LIMIT.to_string(),
//             MAX_STRENGTH_LIMIT.to_string(),
//         ));
//     }
//     if !in_range(trader_str.total_points) {
//         return Err(SolverError::NonConvergence(
//             trader_str.total_points.to_string(),
//             MIN_STRENGTH_LIMIT.to_string(),
//             MAX_STRENGTH_LIMIT.to_string(),
//         ));
//     }

//     let simulation_invariants = SimulationInvariants::new(game_state, trader_str);
//     let simulation_state = SimulationState::new(&simulation_invariants);

//     let recorder_rows = solver_res_recorder.rows.clone();
//     let rng_rows = &rng.rows;
//     let mp = ModelPackager::global();

//     // (0..recorder_rows.len()).into_par_iter().for_each(|idx| {
//     //     let mut state = reset_state(&simulation_state);
//     //     let sim_ctx = SubModelRunnerCtx::new(
//     //         mp,
//     //         rng_rows[idx] as f64,
//     //         ResultRecorderType::SolverOutputRecorder(recorder_rows[idx].clone()),
//     //     );

//     //     let sim_processor = SimulationProcessor::new(sim_ctx);

//     //     let mut sim_runner = SimulationRunner::new(sim_processor, None);

//     //     sim_runner.run(&mut state)
//     // });

//     // rows.par_iter_mut()
//     //     .enumerate()
//     //     .for_each(|(idx, processor)| {
//     //         let sim_ctx = SubModelRunnerCtx::new(
//     //             ModelPackager::global(),
//     //             &simulation_state,
//     //             rng_rows[idx] as f64,
//     //             ResultRecorderType::SolverOutputRecorder(processor),
//     //         );

//     //         let sim_processor = SimulationProcessor::new(sim_ctx);

//     //         let mut sim_runner = SimulationRunner::new(sim_processor, None);

//     //         sim_runner.run()
//     //     });

//     // rows.par_chunks_mut(64)
//     //     .enumerate()
//     //     .map(|(batch_index, batched_processor)| {
//     //         batched_processor
//     //             .iter_mut()
//     //             .enumerate()
//     //             .map(|(proc_index, processor)| {
//     //                 let sim_ctx = SubModelRunnerCtx::new(
//     //                     model_packager,
//     //                     &simulation_invariants,
//     //                     rng_rows[proc_index] as f64,
//     //                     ResultRecorderType::SolverOutputRecorder(processor),
//     //                 );

//     //                 let sim_processor = SimulationProcessor::new(sim_ctx);
//     //             })
//     //     })
//     //     .collect();

//     let (errors, _) = solver_space.get_errors_from(recorder_rows.to_vec());

//     Ok(errors)
// }

// #[allow(clippy::too_many_arguments)]
// pub fn find_root_with_initial_jacobian(
//     initial_vec: Vec<f64>,
//     accuracy: f64,
//     max_iterations: usize,
//     dx_limit: f64,
//     solver_parameters: &SolverParameters,
//     solver_space: &DualObjectiveSolverProblemSpace,
//     game_state: &GameState,
//     solver_res_recorder: &SolverResultRecorder,
//     rng: &RngGen,
// ) -> Result<Vec<f64>, SolverError> {
//     let mut x = DVector::from_vec(initial_vec.clone());

//     let y0 = objective_func_probability_err(
//         initial_vec.clone(),
//         solver_parameters,
//         solver_space,
//         game_state,
//         solver_res_recorder,
//         rng,
//     )?;
//     let mut y = DVector::from_vec(y0.clone());
//     let mut g = y.norm();

//     if y.amax() < accuracy {
//         return Ok(x.data.as_vec().clone());
//     }

//     let mut b = calculate_approximate_jacobian(
//         initial_vec,
//         y0,
//         solver_parameters,
//         solver_space,
//         game_state,
//         solver_res_recorder,
//         1.0,
//         rng,
//     )?;

//     for _ in 0..=max_iterations {
//         let lu = b.clone().lu();
//         let dx_vec = match lu.solve(&(-&y)) {
//             Some(solution) => solution,
//             // Need to verify this logic
//             None => {
//                 let mut dx = nalgebra::DVector::zeros(x.len());
//                 for j in 0..dx.len() {
//                     dx[j] = if j == 0 { -0.1 } else { 0.05 };
//                 }
//                 dx
//             }
//         };

//         let mut dx = dx_vec;

//         for ix in 0..dx.len() {
//             dx[ix] = dx[ix].max(-dx_limit).min(dx_limit);

//             if dx[ix].is_nan() {
//                 dx[ix] = 0.01;
//             }
//         }

//         let xnew = &x + &dx;
//         let ynew_vec = objective_func_probability_err(
//             xnew.data.as_vec().clone(),
//             solver_parameters,
//             solver_space,
//             game_state,
//             solver_res_recorder,
//             rng,
//         )?;
//         let ynew = DVector::from_vec(ynew_vec);
//         let gnew = ynew.norm();

//         let (final_dx, final_xnew, final_ynew, final_gnew) = if gnew > g {
//             let g2 = g * g;
//             let mut scale = g2 / (g2 + gnew * gnew);
//             if scale == 0.0 {
//                 scale = 1.0e-4;
//             }

//             let scaled_dx = &dx * scale;
//             let scaled_xnew = &x + &scaled_dx;
//             let scaled_ynew_vec = objective_func_probability_err(
//                 scaled_xnew.data.as_vec().clone(),
//                 solver_parameters,
//                 solver_space,
//                 game_state,
//                 solver_res_recorder,
//                 rng,
//             )?;
//             let scaled_ynew = DVector::from_vec(scaled_ynew_vec);
//             let scaled_gnew = scaled_ynew.norm();

//             (scaled_dx, scaled_xnew, scaled_ynew, scaled_gnew)
//         } else {
//             (dx, xnew, ynew, gnew)
//         };

//         if final_ynew.amax() < accuracy {
//             return Ok(final_xnew.data.as_vec().clone());
//         }

//         let df = &final_ynew - &y;
//         let dx_norm_sq = final_dx.norm_squared();
//         if dx_norm_sq > 0.0 {
//             let db = df.clone().insert_column(0, 0.0).remove_column(1) * final_dx.transpose()
//                 / dx_norm_sq;
//             b += db;
//         }

//         x = final_xnew;
//         y = final_ynew;
//         g = final_gnew;
//     }

//     Err(SolverError::SolutionNotFound(max_iterations.to_string()))
// }

// #[allow(clippy::too_many_arguments)]
// pub fn calculate_approximate_jacobian(
//     x0: Vec<f64>,
//     y0: Vec<f64>,
//     solver_parameters: &SolverParameters,
//     solver_space: &DualObjectiveSolverProblemSpace,
//     game_state: &GameState,
//     solver_res_recorder: &SolverResultRecorder,
//     jacobian_step_size: f64,
//     rng: &RngGen,
// ) -> Result<DMatrix<f64>, SolverError> {
//     let cols = x0.len();
//     let rows = y0.len();
//     let mut b = DMatrix::zeros(rows, cols);

//     for c in 0..cols {
//         let h = (1.0 + x0[c].abs()) * jacobian_step_size;

//         let mut x = x0.clone();
//         x[c] += h;

//         let y = objective_func_probability_err(
//             x,
//             solver_parameters,
//             solver_space,
//             game_state,
//             solver_res_recorder,
//             rng,
//         )?;

//         for r in 0..rows {
//             b[(r, c)] = (y[r] - y0[r]) / h;
//         }
//     }

//     Ok(b)
// }
