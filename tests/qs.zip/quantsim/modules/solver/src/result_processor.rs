use std::collections::HashMap;

use simulator_core::math::bool_to_byte;

use crate::nrl::states::SimulationState;

pub trait SolverResultProcessorOps {
    fn end_of_match(&self, state: &SimulationState);
}

#[derive(Debug, Clone, Default)]
pub struct SolverResultProcessor {
    pub handicap_line: f64,
    pub total_line: f64,
    pub handicap_home_count: i32,
    pub handicap_away_count: i32,
    pub total_over_count: i32,
    pub total_under_count: i32,
    pub total_sum_distribution: HashMap<i32, i32>,
    pub total_diff_distribution: HashMap<i32, i32>,
}

#[derive(Debug, Default)]
pub struct SolverResultRecorder {
    pub rows: Vec<SolverResultProcessor>,
}

impl SolverResultRecorder {
    pub fn new(num_simulations: usize, handicap_line: f64, total_line: f64) -> Self {
        let processor = SolverResultProcessor::new(handicap_line, total_line);
        Self {
            rows: vec![processor; num_simulations],
        }
    }
}

// Not happy, need to take them as refs
impl SolverResultProcessor {
    pub fn new(handicap_line: f64, total_line: f64) -> Self {
        Self {
            handicap_line,
            total_line,
            ..Default::default()
        }
    }

    pub fn record_end_of_match(&mut self, state: &SimulationState) {
        let home_match_score = state
            .game_statistics
            .home_statistics
            .match_statistics
            .scores
            .total as f64;
        let away_match_score = state
            .game_statistics
            .away_statistics
            .match_statistics
            .scores
            .total as f64;

        let handicap_home = (home_match_score + self.handicap_line) > away_match_score;
        let handicap_away = (home_match_score + self.handicap_line) < away_match_score;

        self.handicap_home_count += bool_to_byte(handicap_home) as i32;
        self.handicap_away_count += bool_to_byte(handicap_away) as i32;

        let over = home_match_score + away_match_score > self.total_line;
        let under = home_match_score + away_match_score < self.total_line;
        self.total_over_count += bool_to_byte(over) as i32;
        self.total_under_count += bool_to_byte(under) as i32;

        let sum = home_match_score + away_match_score;
        let diff = away_match_score - home_match_score;

        add_one(&mut self.total_sum_distribution, sum as i32);
        add_one(&mut self.total_diff_distribution, diff as i32);
    }
}

#[inline]
fn add_one(dist: &mut HashMap<i32, i32>, count: i32) {
    match dist.get_mut(&count) {
        Some(value) => *value += 1,
        None => {
            dist.insert(count, 1);
        }
    }
}

#[inline]
pub fn calculate_probabilities(result: Vec<SolverResultProcessor>) -> (f64, f64) {
    let num_sim = result.len() as f64;

    let mut add_home = 0f64;
    let mut add_away = 0f64;
    let mut add_over = 0f64;
    let mut add_under = 0f64;

    for i in result {
        add_home += i.handicap_home_count as f64;
        add_away += i.handicap_away_count as f64;
        add_over += i.total_over_count as f64;
        add_under += i.total_under_count as f64;
    }

    let prob_home = add_home / num_sim;
    let prob_away = add_away / num_sim;
    let prob_home_two_away = prob_home / (prob_home + prob_away);
    let prob_over = add_over / num_sim;
    let prob_under = add_under / num_sim;
    let prob_over_two_way = prob_over / (prob_over + prob_under);

    (prob_home_two_away, prob_over_two_way)
}
