use std::collections::HashMap;

use crate::nrl::{
    model_data::{PlayerSolution, constants},
    solver::{Nudges, PlayerParameters},
};

#[derive(Debug, Clone, Default, serde::Serialize, serde::Deserialize)]
pub struct TraderState {
    pub solved_players: HashMap<i32, PlayerSolution>,
    pub player_parameters: Option<PlayerParameters>,
    pub total_points: f64,
    pub home_price: f64,
    pub handicap: f64,
    pub player_of_the_match_enabled: bool,
}

impl TraderState {
    pub fn apply_nudges(&mut self, nudges: Nudges) -> &mut Self {
        self.handicap += nudges.handicap_nudges as f64 * constants::NUDGES_PERCENT;
        self.total_points += nudges.match_total_nudges as f64 * constants::NUDGES_PERCENT;
        self
    }

    pub fn set_player_parameters(&mut self, player_params: PlayerParameters) -> &mut Self {
        self.player_parameters = Some(player_params);
        self
    }

    pub fn set_solved_players(
        &mut self,
        solved_players: HashMap<i32, PlayerSolution>,
    ) -> &mut Self {
        self.solved_players = solved_players;
        self
    }

    pub fn set_player_of_the_match(&mut self, enabled: bool) -> &mut Self {
        self.player_of_the_match_enabled = enabled;
        self
    }
}
