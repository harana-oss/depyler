pub mod broyden_solver;
pub mod initial_guess_solver;
// pub mod nudges; // Requires generated code
// pub mod player_parameters; // Requires generated code
// pub mod result_processor; // Requires generated code
// pub mod solver_parameters; // Requires generated code
// pub mod trader_state; // Requires generated code

// pub use broyden_solver::*;
// pub use initial_guess_solver::*;
// pub use nudges::*;
// pub use player_parameters::*;
// pub use result_processor::*;
// pub use solver_parameters::*;
// pub use trader_state::*;

use thiserror::Error;

#[derive(Debug, Error)]
pub enum SolverError {
    #[error("Handicap={0} out of range in solver. Limit magnitude is between {1} and {2}.")]
    NonConvergence(String, String, String),
    #[error("Solutin not found after {0} iterations.")]
    SolutionNotFound(String),
}
