// use crate::nrl::{
//     executor::rng::RngGen,
//     model_data::constants,
//     solver::{
//         BroydenSolver, DualObjectiveSolverProblemSpace, SolverError, SolverParameters,
//         SolverResultRecorder, TraderState,
//     },
//     states::GameState,
// };

// #[derive(Debug)]
// pub struct InitialGuessSolver {}

// impl InitialGuessSolver {
//     pub fn solve(
//         solver_parameters: &SolverParameters,
//         game_state: &GameState,
//         solver_res_recorder: &SolverResultRecorder,
//         rng: &RngGen,
//     ) -> Result<TraderState, SolverError> {
//         let solver_space = DualObjectiveSolverProblemSpace::new(solver_parameters.clone());
//         let initial_vector = DualObjectiveSolverProblemSpace::initial_vector_from(
//             constants::INITIAL_SOLVER_TOTAL_POINTS as f64,
//             constants::INITIAL_SOLVER_HANDICAP as f64,
//         );
//         let solver = BroydenSolver::new();
//         let output = solver.solve(
//             solver_parameters,
//             game_state,
//             solver_space,
//             initial_vector,
//             solver_res_recorder,
//             rng,
//         )?;

//         Ok(output)
//     }
// }
