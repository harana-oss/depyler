use serde::{Deserialize, Serialize};

use crate::contracts::RunModelRequest;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SolverParameters {
    pub home_price: f64,
    pub handicap: f64,
    pub handicap_prob_home: f64,
    pub total_points: f64,
    pub total_points_prob_over: f64,
    pub player_of_the_match_enabled: bool,
}

impl Default for SolverParameters {
    fn default() -> Self {
        Self {
            home_price: 0.0,
            handicap: 0.0,
            handicap_prob_home: 0.5,
            total_points: 0.0,
            total_points_prob_over: 0.5,
            player_of_the_match_enabled: false,
        }
    }
}

impl SolverParameters {
    pub fn from_rmr(req: &RunModelRequest) -> Option<Self> {
        req.trading_state.as_ref()?;

        let trading_state = req.trading_state.as_ref().unwrap();

        Some(Self {
            home_price: trading_state.home_price,
            handicap: trading_state.handicap_line,
            total_points: trading_state.total_match_line,
            player_of_the_match_enabled: trading_state.player_of_the_match_enabled,
            ..Default::default()
        })
    }
}
