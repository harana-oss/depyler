use crate::{contracts::RunModelRequest, nrl::solver::TraderState};

#[derive(Debug, Clone, Default)]
pub struct Nudges {
    pub handicap_nudges: i32,
    pub match_total_nudges: i32,
}

impl Nudges {
    pub fn from_rmr(rmr: &RunModelRequest) -> Self {
        Self {
            handicap_nudges: rmr.trading_state.as_ref().unwrap().handicap_line as i32,
            match_total_nudges: rmr.trading_state.as_ref().unwrap().total_match_line as i32,
        }
    }

    pub fn apply_nudges(&self, mut trader_state: TraderState) -> TraderState {
        const NUDGE_PERCENT: f64 = 1.0;
        trader_state.handicap += self.handicap_nudges as f64 * NUDGE_PERCENT;
        trader_state.total_points += self.match_total_nudges as f64 * NUDGE_PERCENT;
        trader_state
    }
}
