use axum::{body::Bytes, debug_handler, extract::State, http::StatusCode, response::IntoResponse};
// use simulator_games::{contracts::RunModelRequest, nrl::executor::Executor};

use crate::services::routes::AppState;

#[debug_handler]
pub async fn simulator(State(_state): State<AppState>, _payload: Bytes) -> impl IntoResponse {
    // Commented out - requires generated simulator_games code
    // match RunModelRequest::decode(&payload[..]) {
    //     Ok(rmr) => {}
    // }
    println!("Starting NRL Simulator...\n");
    (StatusCode::OK, "OK - Requires generated code".to_owned())
}
