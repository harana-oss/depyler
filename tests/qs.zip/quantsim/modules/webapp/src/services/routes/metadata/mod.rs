pub mod metadata_info;

pub use metadata_info::*;

use axum::response::IntoResponse;

// just mock data for now
pub async fn metadata() -> impl IntoResponse {
    let metadata = CnCMetadata {
        simulator_version: "0.1.0".to_string(),
        description: "Champion Challenger Metadata".to_string(),
        model_info: vec![
            ModelInfo {
                model_name: "ClockModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::Tract,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::Tract,
            },
            ModelInfo {
                model_name: "ConversionModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::Tract,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::Tract,
            },
            ModelInfo {
                model_name: "FieldGoalAttemptModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::Tract,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::Tract,
            },
            ModelInfo {
                model_name: "FieldGoalModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::Tract,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::Tract,
            },
            ModelInfo {
                model_name: "GoalLineXyModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::Tract,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::Tract,
            },
            ModelInfo {
                model_name: "InterchangeModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::Tract,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::Tract,
            },
            ModelInfo {
                model_name: "KickoffModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::Tract,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::Tract,
            },
            ModelInfo {
                model_name: "NextPlayModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::BuiltIn,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::BuiltIn,
            },
            ModelInfo {
                model_name: "PenaltyModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::Tract,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::Tract,
            },
            ModelInfo {
                model_name: "PlayerInterchangeModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::Tract,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::Tract,
            },
            ModelInfo {
                model_name: "PlayerOfTheMatchModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::Tract,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::Tract,
            },
            ModelInfo {
                model_name: "PlayerSinBinModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::Tract,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::Tract,
            },
            ModelInfo {
                model_name: "PlayerTriesModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::Tract,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::Tract,
            },
            ModelInfo {
                model_name: "SinBinModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::Tract,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::Tract,
            },
            ModelInfo {
                model_name: "Model".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::Tract,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::Tract,
            },
            ModelInfo {
                model_name: "XyModel".to_string(),
                current_model_version: "0.0.2".to_string(),
                current_model_type: ModelType::BuiltIn,
                previous_model_version: "0.0.1".to_string(),
                previous_model_type: ModelType::BuiltIn,
            },
        ],
    };

    axum::Json(metadata)
}
