use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CnCMetadata {
    pub simulator_version: String,
    pub description: String,
    pub model_info: Vec<ModelInfo>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelInfo {
    pub model_name: String,
    pub current_model_version: String,
    pub previous_model_version: String,
    pub current_model_type: ModelType,
    pub previous_model_type: ModelType,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ModelType {
    #[serde(rename = "Built_In")]
    BuiltIn,
    Tract,
}
