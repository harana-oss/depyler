pub mod health;
pub mod metadata;
pub mod simulator;

pub use health::*;
pub use metadata::*;
pub use simulator::*;

use crate::kafka::OutputMatrixPublisher;

#[derive(Clone)]
pub struct AppState {
    pub kafka_publisher: OutputMatrixPublisher,
}
