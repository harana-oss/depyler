use std::path::PathBuf;

use rdkafka::{
    ClientConfig,
    error::KafkaError,
    message::OwnedMessage,
    producer::{FutureProducer, FutureRecord, future_producer::Delivery},
};

#[derive(Debug, Clone)]
pub struct OutputMatrixPublisher {
    pub ca_cert_path: PathBuf,
    pub client_cert_path: PathBuf,
    pub client_key_path: PathBuf,
    pub cluster_addr: String,
    pub topic: String,
    pub key: String,
}

impl OutputMatrixPublisher {
    pub fn new(
        ca_cert_path: PathBuf,
        client_cert_path: PathBuf,
        client_key_path: PathBuf,
        cluster_addr: String,
        topic: String,
        key: String,
    ) -> Self {
        let base_dir = if let Ok(manifest_dir) = std::env::var("CARGO_MANIFEST_DIR") {
            std::path::PathBuf::from(manifest_dir)
        } else {
            std::env::current_dir()
                .unwrap()
                .parent()
                .unwrap()
                .parent()
                .unwrap()
                .to_path_buf()
        };

        let ca_cert_path = base_dir.join(ca_cert_path);
        let client_cert_path = base_dir.join(client_cert_path);
        let client_key_path = base_dir.join(client_key_path);

        for (name, path) in [
            ("CA cert", &ca_cert_path),
            ("Client cert", &client_cert_path),
            ("Client key", &client_key_path),
        ] {
            if !path.exists() {
                panic!("{} not found at: {}", name, path.display());
            }
        }

        Self {
            ca_cert_path,
            client_cert_path,
            client_key_path,
            cluster_addr,
            topic,
            key,
        }
    }

    pub fn client_config(&self) -> Result<FutureProducer, KafkaError> {
        let mut config = ClientConfig::new();
        config
            .set("bootstrap.servers", &self.cluster_addr)
            .set("security.protocol", "ssl")
            .set("ssl.ca.location", self.ca_cert_path.to_str().unwrap())
            .set(
                "ssl.certificate.location",
                self.client_cert_path.to_str().unwrap(),
            )
            .set("ssl.key.location", self.client_key_path.to_str().unwrap())
            .create()
    }

    pub async fn send_message(
        &self,
        payload: &str,
        producer: &FutureProducer,
    ) -> Result<Delivery, (KafkaError, OwnedMessage)> {
        producer
            .send(
                FutureRecord::to(&self.topic)
                    .payload(payload)
                    .key(&self.key),
                std::time::Duration::from_secs(5),
            )
            .await
    }
}
