use axum::{
    Router,
    routing::{get, post},
};
use simulator_webapp::{
    kafka::OutputMatrixPublisher,
    services::routes::{AppState, health, metadata, simulator},
};

#[tokio::main(flavor = "current_thread")]
async fn main() {
    let kafka_publisher = OutputMatrixPublisher::new(
        "simulator_webapp/kafka_cred/AmazonRootCA1.pem".into(),
        "simulator_webapp/kafka_cred/certificate.pem".into(),
        "simulator_webapp/kafka_cred/kafka-client-key.pem".into(),
        "b-1.dhfeedsinfra.k6emcj.c2.kafka.ap-southeast-2.amazonaws.com:9094".to_string(),
        "quants.nrl.matrix".to_string(),
        "output_matrix".to_string(),
    );

    let app_state = AppState { kafka_publisher };

    let health_route = Router::new().route("/health", get(health));
    let metadata_route = Router::new().route("/metadata", get(metadata));
    let simulator_route = Router::new().route("/simulator", post(simulator));

    let app = Router::new()
        .merge(health_route)
        .merge(metadata_route)
        .merge(simulator_route)
        .with_state(app_state);

    let listener = tokio::net::TcpListener::bind("127.0.0.1:8080")
        .await
        .unwrap();
    println!(
        "NRL simulator listening on {}",
        listener.local_addr().unwrap()
    );

    axum::serve(listener, app).await.unwrap();
}
