use proc_macro::TokenStream;
use quote::quote;
use syn::{parse_macro_input, ItemFn};

pub fn transform<F>(
    _attr: TokenStream,
    item: TokenStream,
    module_prefix: &str,
    custom_transform: F,
) -> TokenStream
where
    F: FnOnce() -> proc_macro2::TokenStream,
{
    let input_fn = parse_macro_input!(item as ItemFn);
    let fn_name = &input_fn.sig.ident;
    let _fn_name_str = fn_name.to_string();
    let _module_name = syn::Ident::new(&format!("{}_{}", module_prefix, fn_name), fn_name.span());

    let vis = &input_fn.vis;
    let sig = &input_fn.sig;
    let inputs = &sig.inputs;
    let output = &sig.output;
    let block = &input_fn.block;
    let attrs = &input_fn.attrs;
    let asyncness = &sig.asyncness;
    let constness = &sig.constness;
    let unsafety = &sig.unsafety;
    let abi = &sig.abi;
    let generics = &sig.generics;

    let original_fn = syn::Ident::new(&format!("{}_original", fn_name), fn_name.span());

    // Extract just the parameter names for calling the original function
    let param_names: Vec<_> = inputs
        .iter()
        .map(|arg| match arg {
            syn::FnArg::Typed(pat_type) => &pat_type.pat,
            syn::FnArg::Receiver(_) => panic!("self parameters not supported"),
        })
        .collect();

    let custom_behavior = custom_transform();

    let transformed = quote! {
        use crate::*;

        #(#attrs)*
        fn #original_fn(#inputs) #output #block

        #(#attrs)*
        #vis #constness #asyncness #unsafety #abi fn #fn_name #generics(#inputs) #output {
            //let _start = std::time::Instant::now();
            // let monitoring = crate::monitoring_manager();
            let result = #original_fn(#(#param_names),*);
            #custom_behavior
            //let elapsed = _start.elapsed();
            // monitoring.count(#fn_name_str, 1);
            // monitoring.time(#fn_name_str, elapsed.as_secs_f64());

            result
        }
    };

    TokenStream::from(transformed)
}
