use proc_macro::TokenStream;
use quote::quote;

pub fn step(attr: TokenStream, item: TokenStream) -> TokenStream {
    crate::common::transform(attr, item, "step", || {
        quote! {}
    })
}
