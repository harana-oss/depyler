use proc_macro::TokenStream;

mod common;
mod event;
mod function;
mod game;
mod step;

#[proc_macro_attribute]
pub fn game(attr: TokenStream, item: TokenStream) -> TokenStream {
    game::game(attr, item)
}

#[proc_macro_attribute]
pub fn step(attr: TokenStream, item: TokenStream) -> TokenStream {
    step::step(attr, item)
}

#[proc_macro_attribute]
pub fn event(attr: TokenStream, item: TokenStream) -> TokenStream {
    event::event(attr, item)
}

#[proc_macro_attribute]
pub fn function(attr: TokenStream, item: TokenStream) -> TokenStream {
    function::function(attr, item)
}
