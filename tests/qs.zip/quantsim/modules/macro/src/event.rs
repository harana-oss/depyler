use proc_macro::TokenStream;
use quote::quote;

pub fn event(attr: TokenStream, item: TokenStream) -> TokenStream {
    crate::common::transform(attr, item, "event", || {
        quote! {}
    })
}
