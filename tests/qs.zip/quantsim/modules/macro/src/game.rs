use proc_macro::TokenStream;
use quote::quote;

pub fn game(attr: TokenStream, item: TokenStream) -> TokenStream {
    crate::common::transform(attr, item, "game", || {
        quote! {}
    })
}
