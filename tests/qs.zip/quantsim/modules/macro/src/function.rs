use proc_macro::TokenStream;
use quote::quote;

pub fn function(attr: TokenStream, item: TokenStream) -> TokenStream {
    crate::common::transform(attr, item, "function", || {
        quote! {}
    })
}
