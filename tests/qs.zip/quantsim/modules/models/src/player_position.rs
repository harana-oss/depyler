use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Hash, PartialOrd, Default, Serialize, Deserialize)]
pub enum PlayerPosition {
    #[default]
    NotSet,
    FullBack,
    WingerOne,
    CentreOne,
    CentreTwo,
    WingerTwo,
    FiveEighth,
    HalfBack,
    PropOne,
    Hooker,
    PropTwo,
    SecondRowOne,
    SecondRowTwo,
    Lock,
    Interchange,
}

impl From<i32> for PlayerPosition {
    fn from(value: i32) -> Self {
        match value {
            0 => PlayerPosition::NotSet,
            1 => PlayerPosition::FullBack,
            2 => PlayerPosition::WingerOne,
            3 => PlayerPosition::CentreOne,
            4 => PlayerPosition::CentreTwo,
            5 => PlayerPosition::WingerTwo,
            6 => PlayerPosition::FiveEighth,
            7 => PlayerPosition::HalfBack,
            8 => PlayerPosition::PropOne,
            9 => PlayerPosition::Hooker,
            10 => PlayerPosition::PropTwo,
            11 => PlayerPosition::SecondRowOne,
            12 => PlayerPosition::SecondRowTwo,
            13 => PlayerPosition::Lock,
            14 => PlayerPosition::Interchange,
            _ => PlayerPosition::NotSet,
        }
    }
}
