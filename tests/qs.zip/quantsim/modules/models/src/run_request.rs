// use crate::contracts::RunModelRequest;

// use prost::{Message, bytes::Bytes};
// use thiserror::Error;

// pub fn validate_run_model_request(buf: Bytes) -> RunModelRequest {
//     let rmr = RunModelRequest::decode(buf).unwrap();
//     rmr
// }

// #[derive(Error, Debug)]
// pub enum RunRequestError {
//     #[error("failed to decode run request for correlation_id `{0}`")]
//     DecodeError(String),
// }
