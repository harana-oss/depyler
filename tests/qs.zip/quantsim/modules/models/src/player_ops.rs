use crate::nrl::model_data::{
    BasePlayer, MatchPeriod, PlayerModelResult, PlayerPosition, constants,
};

use rand::random_range;

#[allow(dead_code)]
const POSITION_PRIORITIES: [[PlayerPosition; 13]; 13] = [
    // FullBack
    [
        PlayerPosition::FullBack,
        PlayerPosition::WingerOne,
        PlayerPosition::WingerTwo,
        PlayerPosition::CentreOne,
        PlayerPosition::CentreTwo,
        PlayerPosition::FiveEighth,
        PlayerPosition::HalfBack,
        PlayerPosition::SecondRowOne,
        PlayerPosition::SecondRowTwo,
        PlayerPosition::PropOne,
        PlayerPosition::PropTwo,
        PlayerPosition::Hooker,
        PlayerPosition::Lock,
    ],
    // WingerOne
    [
        PlayerPosition::WingerOne,
        PlayerPosition::WingerTwo,
        PlayerPosition::FullBack,
        PlayerPosition::CentreOne,
        PlayerPosition::CentreTwo,
        PlayerPosition::FiveEighth,
        PlayerPosition::HalfBack,
        PlayerPosition::SecondRowOne,
        PlayerPosition::SecondRowTwo,
        PlayerPosition::PropOne,
        PlayerPosition::PropTwo,
        PlayerPosition::Hooker,
        PlayerPosition::Lock,
    ],
    // CentreOne
    [
        PlayerPosition::CentreOne,
        PlayerPosition::CentreTwo,
        PlayerPosition::WingerOne,
        PlayerPosition::WingerTwo,
        PlayerPosition::FiveEighth,
        PlayerPosition::HalfBack,
        PlayerPosition::FullBack,
        PlayerPosition::SecondRowOne,
        PlayerPosition::SecondRowTwo,
        PlayerPosition::PropOne,
        PlayerPosition::PropTwo,
        PlayerPosition::Hooker,
        PlayerPosition::Lock,
    ],
    // CentreTwo
    [
        PlayerPosition::CentreTwo,
        PlayerPosition::CentreOne,
        PlayerPosition::WingerTwo,
        PlayerPosition::WingerOne,
        PlayerPosition::FiveEighth,
        PlayerPosition::HalfBack,
        PlayerPosition::FullBack,
        PlayerPosition::SecondRowOne,
        PlayerPosition::SecondRowTwo,
        PlayerPosition::PropOne,
        PlayerPosition::PropTwo,
        PlayerPosition::Hooker,
        PlayerPosition::Lock,
    ],
    // WingerTwo
    [
        PlayerPosition::WingerTwo,
        PlayerPosition::WingerOne,
        PlayerPosition::FullBack,
        PlayerPosition::CentreOne,
        PlayerPosition::CentreTwo,
        PlayerPosition::FiveEighth,
        PlayerPosition::HalfBack,
        PlayerPosition::SecondRowTwo,
        PlayerPosition::SecondRowOne,
        PlayerPosition::PropTwo,
        PlayerPosition::PropOne,
        PlayerPosition::Hooker,
        PlayerPosition::Lock,
    ],
    // FiveEighth
    [
        PlayerPosition::FiveEighth,
        PlayerPosition::HalfBack,
        PlayerPosition::FullBack,
        PlayerPosition::CentreOne,
        PlayerPosition::CentreTwo,
        PlayerPosition::SecondRowOne,
        PlayerPosition::SecondRowTwo,
        PlayerPosition::PropOne,
        PlayerPosition::PropTwo,
        PlayerPosition::Hooker,
        PlayerPosition::Lock,
        PlayerPosition::WingerOne,
        PlayerPosition::WingerTwo,
    ],
    // HalfBack
    [
        PlayerPosition::HalfBack,
        PlayerPosition::FiveEighth,
        PlayerPosition::CentreOne,
        PlayerPosition::CentreTwo,
        PlayerPosition::FullBack,
        PlayerPosition::WingerOne,
        PlayerPosition::WingerTwo,
        PlayerPosition::SecondRowOne,
        PlayerPosition::SecondRowTwo,
        PlayerPosition::PropOne,
        PlayerPosition::PropTwo,
        PlayerPosition::Hooker,
        PlayerPosition::Lock,
    ],
    // PropOne
    [
        PlayerPosition::PropOne,
        PlayerPosition::PropTwo,
        PlayerPosition::Hooker,
        PlayerPosition::Lock,
        PlayerPosition::SecondRowOne,
        PlayerPosition::SecondRowTwo,
        PlayerPosition::FiveEighth,
        PlayerPosition::HalfBack,
        PlayerPosition::CentreOne,
        PlayerPosition::CentreTwo,
        PlayerPosition::FullBack,
        PlayerPosition::WingerOne,
        PlayerPosition::WingerTwo,
    ],
    // Hooker
    [
        PlayerPosition::Hooker,
        PlayerPosition::Lock,
        PlayerPosition::PropOne,
        PlayerPosition::PropTwo,
        PlayerPosition::SecondRowOne,
        PlayerPosition::SecondRowTwo,
        PlayerPosition::FiveEighth,
        PlayerPosition::HalfBack,
        PlayerPosition::CentreOne,
        PlayerPosition::CentreTwo,
        PlayerPosition::FullBack,
        PlayerPosition::WingerOne,
        PlayerPosition::WingerTwo,
    ],
    // PropTwo
    [
        PlayerPosition::PropTwo,
        PlayerPosition::PropOne,
        PlayerPosition::Hooker,
        PlayerPosition::Lock,
        PlayerPosition::SecondRowTwo,
        PlayerPosition::SecondRowOne,
        PlayerPosition::FiveEighth,
        PlayerPosition::HalfBack,
        PlayerPosition::CentreTwo,
        PlayerPosition::CentreOne,
        PlayerPosition::FullBack,
        PlayerPosition::WingerTwo,
        PlayerPosition::WingerOne,
    ],
    // SecondRowOne
    [
        PlayerPosition::SecondRowOne,
        PlayerPosition::SecondRowTwo,
        PlayerPosition::PropOne,
        PlayerPosition::PropTwo,
        PlayerPosition::FiveEighth,
        PlayerPosition::Hooker,
        PlayerPosition::Lock,
        PlayerPosition::CentreOne,
        PlayerPosition::CentreTwo,
        PlayerPosition::HalfBack,
        PlayerPosition::FullBack,
        PlayerPosition::WingerOne,
        PlayerPosition::WingerTwo,
    ],
    // SecondRowTwo
    [
        PlayerPosition::SecondRowTwo,
        PlayerPosition::SecondRowOne,
        PlayerPosition::PropTwo,
        PlayerPosition::PropOne,
        PlayerPosition::FiveEighth,
        PlayerPosition::Hooker,
        PlayerPosition::Lock,
        PlayerPosition::CentreTwo,
        PlayerPosition::CentreOne,
        PlayerPosition::HalfBack,
        PlayerPosition::FullBack,
        PlayerPosition::WingerTwo,
        PlayerPosition::WingerOne,
    ],
    // Lock
    [
        PlayerPosition::Lock,
        PlayerPosition::Hooker,
        PlayerPosition::PropOne,
        PlayerPosition::PropTwo,
        PlayerPosition::SecondRowOne,
        PlayerPosition::SecondRowTwo,
        PlayerPosition::HalfBack,
        PlayerPosition::FiveEighth,
        PlayerPosition::CentreOne,
        PlayerPosition::CentreTwo,
        PlayerPosition::FullBack,
        PlayerPosition::WingerOne,
        PlayerPosition::WingerTwo,
    ],
];

pub trait PlayerOps {
    fn apply_time_on_ground(&mut self, period: MatchPeriod, seconds: f64);
    fn get_player_at_position(&self, position: PlayerPosition) -> &BasePlayer;
    fn get_player_at_position_mut(&mut self, position: PlayerPosition) -> &mut BasePlayer;
    fn get_player_at_position_from_result(&self, position: PlayerModelResult) -> &BasePlayer;
    fn get_player_with_index(&self, index: i32) -> &BasePlayer;
    fn process_interchange(&mut self, position: PlayerModelResult);
}

impl PlayerOps for [BasePlayer] {
    fn apply_time_on_ground(&mut self, period: MatchPeriod, seconds: f64) {
        for i in 0..constants::NUM_STARTING_PLAYERS_PER_TEAM {
            self[i as usize].apply_time_on_ground(period, seconds);
        }
    }

    fn get_player_at_position(&self, position: PlayerPosition) -> &BasePlayer {
        &self[position as usize - 1]
    }

    fn get_player_at_position_mut(&mut self, position: PlayerPosition) -> &mut BasePlayer {
        &mut self[position as usize - 1]
    }

    fn get_player_at_position_from_result(&self, position: PlayerModelResult) -> &BasePlayer {
        self.get_player_at_position(convert_player_model_result(position))
    }

    fn get_player_with_index(&self, index: i32) -> &BasePlayer {
        for player in self {
            if player.player_index == index {
                return player;
            }
        }
        panic!("Could not find player with player ID {}", index);
    }

    fn process_interchange(&mut self, position: PlayerModelResult) {
        let converted_position = convert_player_model_result(position);
        let off_index = converted_position as usize - 1;
        let on_index = self.get_interchange_player_index(off_index);

        if let Some(on_index) = on_index {
            let bp = &self[off_index];
            let off_position = bp.get_position();

            self[off_index].set_on_field(false);
            self[off_index].set_position(self[on_index as usize].get_position());

            self[on_index as usize].set_on_field(true);
            self[on_index as usize].set_position(off_position);

            self.swap(off_index, on_index as usize);
        }
    }
}

trait PlayerArrayHelpers {
    fn get_interchange_player_index(&self, off_index: usize) -> Option<i32>;
    #[allow(dead_code)]
    fn fresh_interchange_players_exist(&self) -> bool;
}

impl PlayerArrayHelpers for [BasePlayer] {
    fn get_interchange_player_index(&self, _off_index: usize) -> Option<i32> {
        let mut non_injured_available = false;

        for i in constants::NUM_STARTING_PLAYERS_PER_TEAM..self.len() as i32 {
            if !self[i as usize].is_injured {
                non_injured_available = true;
            }
        }

        if !non_injured_available {
            return Some(-1);
        }

        let mut player_index = 0;

        if !self[player_index as usize].is_injured {
            player_index =
                random_range(constants::NUM_STARTING_PLAYERS_PER_TEAM..self.len() as i32);
        }

        Some(player_index)
    }

    fn fresh_interchange_players_exist(&self) -> bool {
        for player in self {
            if !player.on_field && player.match_statistics.time_on_field == 0.0 {
                return true;
            }
        }
        false
    }
}

pub fn convert_player_model_result(player_position: PlayerModelResult) -> PlayerPosition {
    match player_position {
        PlayerModelResult::FullBack => PlayerPosition::FullBack,
        PlayerModelResult::WingerOne => PlayerPosition::WingerOne,
        PlayerModelResult::CentreOne => PlayerPosition::CentreOne,
        PlayerModelResult::CentreTwo => PlayerPosition::CentreTwo,
        PlayerModelResult::WingerTwo => PlayerPosition::WingerTwo,
        PlayerModelResult::FiveEighth => PlayerPosition::FiveEighth,
        PlayerModelResult::HalfBack => PlayerPosition::HalfBack,
        PlayerModelResult::PropOne => PlayerPosition::PropOne,
        PlayerModelResult::Hooker => PlayerPosition::Hooker,
        PlayerModelResult::PropTwo => PlayerPosition::PropTwo,
        PlayerModelResult::SecondRowOne => PlayerPosition::SecondRowOne,
        PlayerModelResult::SecondRowTwo => PlayerPosition::SecondRowTwo,
        PlayerModelResult::Lock => PlayerPosition::Lock,
    }
}
