use rand::random_range;

use crate::nrl::{model_data::Team, submodels::GridResult};

#[derive(Debug, Clone, Default, Copy, PartialEq, Eq)]
pub struct FieldPosition {
    pub x: i32,
    pub y: i32,
}

impl FieldPosition {
    pub fn y_values() -> [(i32, i32); 6] {
        [
            (0, 118),
            (118, 234),
            (234, 351),
            (351, 468),
            (468, 584),
            (584, 700),
        ]
    }

    pub fn y_values_away() -> [(i32, i32); 6] {
        [
            (584, 700),
            (468, 584),
            (351, 468),
            (234, 351),
            (118, 234),
            (0, 118),
        ]
    }

    pub fn x_values() -> [(i32, i32); 12] {
        [
            (0, 100),
            (100, 200),
            (200, 300),
            (300, 400),
            (400, 500),
            (500, 600),
            (600, 700),
            (700, 800),
            (800, 900),
            (900, 1000),
            (-100, 1),
            (1000, 1100),
        ]
    }

    pub fn x_values_away() -> [(i32, i32); 12] {
        [
            (900, 1000),
            (800, 900),
            (700, 800),
            (600, 700),
            (500, 600),
            (400, 500),
            (300, 400),
            (200, 300),
            (100, 200),
            (0, 100),
            (1000, 1100),
            (-100, 1),
        ]
    }
}

pub fn process_grid(coor: GridResult, possessing_team: Team) -> FieldPosition {
    let y_pos = (coor as usize) % 6;
    let x_pos = (coor as usize) % 6;

    let (x_range, y_range) = match possessing_team {
        Team::Home => (
            FieldPosition::x_values()[x_pos],
            FieldPosition::y_values()[y_pos],
        ),
        Team::Away => (
            FieldPosition::x_values_away()[x_pos],
            FieldPosition::y_values_away()[y_pos],
        ),
        Team::NotSet => (
            FieldPosition::x_values()[x_pos],
            FieldPosition::y_values()[y_pos],
        ),
    };

    FieldPosition {
        x: random_range(x_range.0..x_range.1),
        y: random_range(y_range.0..y_range.1),
    }
}
