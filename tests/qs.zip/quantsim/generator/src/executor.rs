use crate::codegen::{constants_to_python, python_to_rust, state_to_python, test_case_to_python};
use crate::yaml::loader::file::{FileLoaderError, find_yaml_files};
use crate::yaml::parser::{TestCase, parse_yaml_file};
use askama::Template;
use log::{error, info};
use std::fs;
use std::io;
use std::path::Path;

#[derive(Template)]
#[template(path = "cargo.toml.j2")]
struct CargoTomlTemplate {
    name: String,
    version: String,
}

#[derive(Template)]
#[template(path = "main.rs.j2")]
struct MainRsTemplate {}

#[derive(Template)]
#[template(path = "generated.rs.j2")]
struct GeneratedRsTemplate {}

#[derive(Clone, Debug)]
struct EventRegistration {
    function_name: String,
    when: Option<String>,
    repeat: bool,
    sort_key: String,
}

fn setup_cargo_project(rust_output_dir: &Path) -> Result<(), ExecutorError> {
    // Create src directory
    let src_dir = rust_output_dir.join("src");
    fs::create_dir_all(&src_dir)?;

    // Create Cargo.toml using template (always regenerate to ensure latest dependencies)
    let cargo_toml_path = rust_output_dir.join("Cargo.toml");
    let cargo_template = CargoTomlTemplate {
        name: "generated".to_string(),
        version: "0.1.0".to_string(),
    };
    let cargo_content = cargo_template.render().map_err(|e| {
        ExecutorError::CodegenError(format!("Failed to render Cargo.toml template: {}", e))
    })?;
    fs::write(&cargo_toml_path, cargo_content)?;
    info!("Created Cargo.toml in {}", rust_output_dir.display());

    // Create main.rs using template (always regenerate to ensure latest template changes)
    let main_rs_path = src_dir.join("main.rs");
    let main_template = MainRsTemplate {};
    let main_content = main_template.render().map_err(|e| {
        ExecutorError::CodegenError(format!("Failed to render main.rs template: {}", e))
    })?;
    fs::write(&main_rs_path, main_content)?;
    info!("Created main.rs in {}", src_dir.display());

    Ok(())
}

#[derive(Debug)]
pub enum ExecutorError {
    IoError(io::Error),
    ParseError(String),
    CodegenError(String),
    CompileError(String),
    RuntimeError(String),
}

impl From<io::Error> for ExecutorError {
    fn from(err: io::Error) -> Self {
        ExecutorError::IoError(err)
    }
}

impl From<FileLoaderError> for ExecutorError {
    fn from(err: FileLoaderError) -> Self {
        match err {
            FileLoaderError::IoError(e) => ExecutorError::IoError(e),
        }
    }
}

impl std::fmt::Display for ExecutorError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ExecutorError::IoError(e) => write!(f, "IO Error: {}", e),
            ExecutorError::ParseError(e) => write!(f, "Parse Error: {}", e),
            ExecutorError::CodegenError(e) => write!(f, "Codegen Error: {}", e),
            ExecutorError::CompileError(e) => write!(f, "Compile Error: {}", e),
            ExecutorError::RuntimeError(e) => write!(f, "Runtime Error: {}", e),
        }
    }
}

impl std::error::Error for ExecutorError {}

fn process_yaml_file(
    yaml_path: &Path,
    file_type: Option<&str>,
) -> Result<(String, TestCase), ExecutorError> {
    let content = fs::read_to_string(yaml_path)?;

    let test_case: TestCase =
        parse_yaml_file(&content).map_err(|e| ExecutorError::ParseError(e))?;

    let python_code = test_case_to_python(&test_case, file_type)
        .map_err(|e| ExecutorError::CodegenError(e.to_string()))?;

    Ok((python_code, test_case))
}

fn remove_common_imports(content: &str) -> String {
    let lines: Vec<&str> = content.lines().collect();
    let mut result = Vec::new();

    for line in lines {
        let trimmed = line.trim();
        // Skip the common import lines
        if trimmed == "from state import State" || trimmed == "from functions import *" {
            continue;
        }
        result.push(line);
    }

    // Join and trim any leading/trailing blank lines
    let joined = result.join("\n");
    joined.trim().to_string()
}

fn concatenate_python_files(
    python_output_dir: &Path,
    event_registrations: &[EventRegistration],
) -> Result<(), ExecutorError> {
    info!("Concatenating Python files...");

    if !python_output_dir.exists() {
        return Err(ExecutorError::IoError(io::Error::new(
            io::ErrorKind::NotFound,
            "Python output directory not found",
        )));
    }

    // Collect all .py files except generated.py (the output file)
    let mut python_files = Vec::new();
    for entry in fs::read_dir(python_output_dir)? {
        let entry = entry?;
        let path = entry.path();
        if path.is_file() {
            if let Some(file_name) = path.file_name().and_then(|n| n.to_str()) {
                if file_name.ends_with(".py") && file_name != "generated.py" {
                    python_files.push(path);
                }
            }
        }
    }

    // Sort files for consistent ordering
    python_files.sort();

    // Collect content from all files, removing common imports
    // Also track event functions for registration
    let mut file_contents = Vec::new();

    for file_path in &python_files {
        let content = fs::read_to_string(file_path)?;

        // Remove common import lines from each file
        let cleaned_content = remove_common_imports(&content);

        // Store the content with a comment indicating the original file
        if let Some(file_name) = file_path.file_name().and_then(|n| n.to_str()) {
            if !cleaned_content.trim().is_empty() {
                file_contents.push(format!("# From: {}\n{}", file_name, cleaned_content));

                // Track event functions (files starting with event_)
            }
        }
    }

    // Build the concatenated file
    let mut concatenated = String::new();

    // Add header comment
    concatenated.push_str("# Auto-generated concatenated Python file\n");
    concatenated.push_str("# This file combines all generated Python modules\n\n");

    // Add common imports once at the top
    concatenated.push_str("from enum import IntFlag\n");
    concatenated.push_str("from state import State\n");
    concatenated.push_str("from functions import *\n\n");

    // Add ExecutedEvents IntFlag enum if there are event registrations
    if !event_registrations.is_empty() {
        concatenated.push_str("class ExecutedEvents(IntFlag):\n");
        concatenated.push_str("    NONE                      = 0\n");

        for (idx, event_reg) in event_registrations.iter().enumerate() {
            if !event_reg.repeat {
                let event_name = &event_reg.function_name;
                // Convert event name to uppercase constant name
                let const_name = event_name
                    .trim_end_matches("_event")
                    .trim_end_matches("_helper")
                    .to_uppercase();
                concatenated.push_str(&format!("    {:<25} = 1 << {}\n", const_name, idx));
            }
        }
        concatenated.push_str("\n");
    }

    // Add all file contents
    for content in file_contents {
        concatenated.push_str(&content);
        concatenated.push_str("\n\n");
    }

    // Add execute_events function if there are event registrations
    if !event_registrations.is_empty() {
        concatenated.push_str("# Auto-generated event execution function\n");
        concatenated.push_str("def execute_events(state: State) -> None:\n");
        concatenated.push_str("    \"\"\"Execute all registered event functions.\"\"\"\n");

        for event_reg in event_registrations.iter() {
            let event_name = &event_reg.function_name;

            // Build condition parts
            let mut conditions = Vec::new();

            // Add repeat check if event should only fire once (using bitwise operations)
            // Check bitflag first for better performance (short-circuit evaluation)
            if !event_reg.repeat {
                let const_name = event_name
                    .trim_end_matches("_event")
                    .trim_end_matches("_helper")
                    .to_uppercase();
                conditions.push(format!(
                    "not (state.executed_events & ExecutedEvents.{})",
                    const_name
                ));
            }

            // Add when clause if present (wrap in parentheses if non-repeating to handle precedence)
            if let Some(when_clause) = &event_reg.when {
                if !event_reg.repeat
                    && (when_clause.contains(" or ") || when_clause.contains(" and "))
                {
                    // Wrap the when clause in parentheses to ensure correct operator precedence
                    conditions.push(format!("({})", when_clause));
                } else {
                    conditions.push(when_clause.clone());
                }
            }

            // Generate the conditional call
            if conditions.is_empty() {
                // No conditions, always execute
                concatenated.push_str(&format!("    {}(state)\n", event_name));
            } else {
                // Generate if statement with conditions
                let condition_str = conditions.join(" and ");
                concatenated.push_str(&format!("    if {}:\n", condition_str));
                concatenated.push_str(&format!("        {}(state)\n", event_name));

                // Track execution if non-repeating (using bitwise OR)
                if !event_reg.repeat {
                    let const_name = event_name
                        .trim_end_matches("_event")
                        .trim_end_matches("_helper")
                        .to_uppercase();
                    concatenated.push_str(&format!(
                        "        state.executed_events |= ExecutedEvents.{}\n",
                        const_name
                    ));
                }
            }
        }

        concatenated.push_str("\n");
    }

    // Write the concatenated file
    let output_path = python_output_dir.join("generated.py");
    fs::write(&output_path, concatenated)?;
    info!("Created concatenated file: {}", output_path.display());

    if !event_registrations.is_empty() {
        info!("Registered {} event functions", event_registrations.len());
    }

    Ok(())
}

pub fn execute(
    input_dir: &Path,
    python_output_dir: &Path,
    rust_output_dir: &Path,
) -> Result<(), ExecutorError> {
    info!("Starting pipeline...");
    info!("Input directory: {}", input_dir.display());
    info!("Python output directory: {}", python_output_dir.display());
    info!("Rust output directory: {}", rust_output_dir.display());

    fs::create_dir_all(python_output_dir)?;
    fs::create_dir_all(rust_output_dir)?;

    setup_cargo_project(rust_output_dir)?;

    let mut event_registrations: Vec<EventRegistration> = Vec::new();

    // Step 1: Generate all Python files from YAML
    info!("Step 1: Converting YAML to Python...");

    let functions_src = input_dir.join("functions");
    if functions_src.is_dir() {
        info!(
            "Processing function files from {} and generating individual fn_*.py files",
            functions_src.display()
        );

        for entry in fs::read_dir(&functions_src)? {
            let entry = entry?;
            let path = entry.path();
            if path.is_file() {
                if let Some(file_name) = path.file_name().and_then(|n| n.to_str()) {
                    // Skip __init__.py or any other special files we don't want to include
                    if file_name == "__init__.py" {
                        continue;
                    }

                    // Read the Python function file
                    let python_code = fs::read_to_string(&path)?;

                    let file_stem = path
                        .file_stem()
                        .and_then(|s| s.to_str())
                        .unwrap_or("unknown");

                    // Write individual Python file with fn_ prefix
                    let python_filename = format!("fn_{}.py", file_stem);

                    // Add depyler comment before function definition
                    let final_python_code = if let Some(comment) =
                        generate_function_depyler_comment(&python_filename)
                    {
                        insert_depyler_comment_before_def(&python_code, &comment)
                    } else {
                        python_code.clone()
                    };

                    let python_output_path = python_output_dir.join(&python_filename);
                    info!("Generating Python: fn_{}", file_stem);
                    fs::write(&python_output_path, &final_python_code)?;
                }
            }
        }
    }

    let yaml_files = find_yaml_files(input_dir)?;
    info!("Found {} YAML files", yaml_files.len());

    for yaml_path in &yaml_files {
        let relative_path = yaml_path.strip_prefix(input_dir).unwrap_or(yaml_path);
        let display_path = relative_path.to_string_lossy();
        let display_name = display_path
            .trim_end_matches(".yaml")
            .trim_end_matches(".yml");

        let file_name = yaml_path.file_name().and_then(|n| n.to_str()).unwrap_or("");

        let output_filename_temp = generate_output_filename(relative_path);
        let file_type = if output_filename_temp.starts_with("step_") {
            Some("step")
        } else if output_filename_temp.starts_with("event_") {
            Some("event")
        } else if output_filename_temp == "game.py" {
            Some("game")
        } else {
            None
        };

        let (python_code, test_case_opt) = if file_name == "constants.yaml" {
            let yaml_content = fs::read_to_string(yaml_path)?;
            match constants_to_python(&yaml_content) {
                Ok(code) => (code, None),
                Err(e) => {
                    error!("Error generating constants from {}: {}", display_name, e);
                    continue;
                }
            }
        } else if file_name == "state.yaml" {
            let yaml_content = fs::read_to_string(yaml_path)?;
            match state_to_python(&yaml_content) {
                Ok(code) => (code, None),
                Err(e) => {
                    error!("Error generating state from {}: {}", display_name, e);
                    continue;
                }
            }
        } else {
            match process_yaml_file(yaml_path, file_type) {
                Ok((code, test_case)) => (code, Some(test_case)),
                Err(e) => {
                    error!("Error processing {}: {}", display_name, e);
                    continue;
                }
            }
        };

        if matches!(file_type, Some("event")) {
            if let Some(test_case) = &test_case_opt {
                let function_name = test_case.name.to_lowercase().replace(" ", "_");
                event_registrations.push(EventRegistration {
                    function_name,
                    when: test_case.when.clone(),
                    repeat: test_case.repeat,
                    sort_key: output_filename_temp.clone(),
                });
            }
        }

        let output_filename = output_filename_temp.clone();
        let python_output_path = python_output_dir.join(&output_filename);

        let output_relative = python_output_path
            .strip_prefix(python_output_dir)
            .unwrap_or(&python_output_path);
        let output_display = output_relative.to_string_lossy();
        let output_name = output_display.trim_end_matches(".py");
        info!("Generating Python: {}", output_name);

        // Don't add depyler comment prefix anymore (it's added internally now)
        fs::write(&python_output_path, &python_code)?;
    }

    // Step 2: Concatenate all Python files into generated.py
    info!("Step 2: Concatenating Python files into generated.py...");
    concatenate_python_files(python_output_dir, &event_registrations)?;

    // Step 3: Convert individual Python files to Rust
    info!("Step 3: Converting individual Python files to Rust...");

    // Collect all .py files except generated.py
    let mut python_files_for_rust = Vec::new();
    for entry in fs::read_dir(python_output_dir)? {
        let entry = entry?;
        let path = entry.path();
        if path.is_file() {
            if let Some(file_name) = path.file_name().and_then(|n| n.to_str()) {
                if file_name.ends_with(".py") && file_name != "generated.py" {
                    python_files_for_rust.push(path);
                }
            }
        }
    }

    // Sort for consistent ordering
    python_files_for_rust.sort();

    // Convert each Python file to Rust
    for py_path in &python_files_for_rust {
        if let Some(file_stem) = py_path.file_stem().and_then(|s| s.to_str()) {
            let python_code = fs::read_to_string(py_path)?;

            match python_to_rust(&python_code, file_stem) {
                Ok(rust_code) => {
                    let rust_filename = format!("{}.rs", file_stem);
                    let rust_output_path = rust_output_dir.join("src").join(&rust_filename);
                    info!("Generating Rust: {}", file_stem);
                    fs::write(&rust_output_path, rust_code)?;
                }
                Err(e) => {
                    error!("Failed to convert {} to Rust: {}", file_stem, e);
                    continue;
                }
            }
        }
    }

    // Step 4: Convert concatenated Python to Rust
    info!("Step 4: Converting generated.py to Rust...");
    let generated_py_path = python_output_dir.join("generated.py");
    let python_code = fs::read_to_string(&generated_py_path)?;

    match python_to_rust(&python_code, "generated") {
        Ok(rust_code) => {
            // Render the template content to prepend
            let generated_template = GeneratedRsTemplate {};
            let template_content = generated_template.render().map_err(|e| {
                ExecutorError::CodegenError(format!(
                    "Failed to render generated.rs template: {}",
                    e
                ))
            })?;

            // Combine template content with generated Rust code
            let final_rust_code = format!("{}\n\n{}", template_content, rust_code);

            let rust_output_path = rust_output_dir.join("src").join("generated.rs");
            info!("Generating Rust: generated");
            fs::write(&rust_output_path, final_rust_code)?;
        }
        Err(e) => {
            return Err(ExecutorError::CodegenError(format!(
                "Failed to convert generated.py to Rust: {}",
                e
            )));
        }
    }

    info!("Pipeline completed successfully!");
    Ok(())
}

fn generate_output_filename(relative_path: &Path) -> String {
    let components: Vec<&str> = relative_path.iter().filter_map(|c| c.to_str()).collect();

    let file_stem = relative_path
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("unknown");

    if file_stem == "constants"
        || file_stem == "state"
        || file_stem == "game"
        || file_stem == "outputs"
    {
        if components.len() > 1 {
            let dir_prefix = components[..components.len() - 1].join("-");
            return format!("{}_{}.py", dir_prefix, file_stem);
        }
        return format!("{}.py", file_stem);
    }

    if let Some(idx) = components.iter().position(|&c| c == "steps") {
        if idx + 1 < components.len() {
            return format!("step_{}.py", file_stem);
        }
    } else if let Some(idx) = components.iter().position(|&c| c == "events") {
        if idx + 2 < components.len() {
            return format!("event_{}.py", file_stem);
        } else {
            return format!("event_{}.py", file_stem);
        }
    }

    format!("{}.py", file_stem)
}

fn generate_function_depyler_comment(filename: &str) -> Option<String> {
    if filename.starts_with("fn_disabled_") {
        Some("# @depyler: custom_attribute = \"function\"\n".to_string())
    } else {
        None
    }
}

fn insert_depyler_comment_before_def(python_code: &str, comment: &str) -> String {
    let lines: Vec<&str> = python_code.lines().collect();
    let mut result = Vec::new();
    let mut found_def = false;

    for line in lines {
        if !found_def && line.trim_start().starts_with("def ") {
            // Insert comment before the def line
            result.push(comment.trim_end());
            found_def = true;
        }
        result.push(line);
    }

    result.join("\n") + "\n"
}
