use simulator_core::executor;
use std::path::Path;

fn main() {
    env_logger::Builder::from_default_env()
        .filter_level(log::LevelFilter::Info)
        .format_target(false)
        .format_timestamp(None)
        .init();

    let input_dir = Path::new("../../quantsim-nrl/game");
    let python_output_dir = Path::new("../../quantsim-nrl/_generated/py");
    let rust_output_dir = Path::new("../../quantsim-nrl/_generated/rs");

    if let Err(e) = executor::execute(input_dir, python_output_dir, rust_output_dir) {
        eprintln!("Error executing generator: {:?}", e);
        std::process::exit(1);
    }
}
