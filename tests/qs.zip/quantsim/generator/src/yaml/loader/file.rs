use std::fs;
use std::io;
use std::path::{Path, PathBuf};

#[derive(Debug)]
pub enum FileLoaderError {
    IoError(io::Error),
}

impl From<io::Error> for FileLoaderError {
    fn from(err: io::Error) -> Self {
        FileLoaderError::IoError(err)
    }
}

impl std::fmt::Display for FileLoaderError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            FileLoaderError::IoError(e) => write!(f, "IO Error: {}", e),
        }
    }
}

impl std::error::Error for FileLoaderError {}

pub fn find_yaml_files(dir: &Path) -> Result<Vec<PathBuf>, FileLoaderError> {
    let mut yaml_files = Vec::new();

    if dir.is_dir() {
        for entry in fs::read_dir(dir)? {
            let entry = entry?;
            let path = entry.path();

            if path.is_dir() {
                yaml_files.extend(find_yaml_files(&path)?);
            } else if let Some(ext) = path.extension() {
                if ext == "yaml" || ext == "yml" {
                    yaml_files.push(path);
                }
            }
        }
    }

    Ok(yaml_files)
}

pub fn load_yaml_file(path: &Path) -> Result<String, FileLoaderError> {
    Ok(fs::read_to_string(path)?)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_find_yaml_files() {
        let test_dir = Path::new("test_cases/valid");
        if test_dir.exists() {
            let files = find_yaml_files(test_dir).unwrap();
            assert!(!files.is_empty());
        }
    }
}
