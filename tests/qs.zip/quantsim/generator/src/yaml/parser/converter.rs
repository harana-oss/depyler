use super::helpers;
use crate::models::action::{Action, RecordEntry};
use std::collections::HashMap;
use yaml_rust2::Yaml;

#[derive(Debug)]
pub struct TestCase {
    pub name: String,
    pub description: Option<String>,
    pub version: String,
    pub parameters: HashMap<String, Yaml>,
    pub constants: HashMap<String, Yaml>,
    pub variables: HashMap<String, Yaml>,
    pub when: Option<String>,
    pub repeat: bool, // Default false - event fires only once; true - fires every time
    pub steps: Vec<Action>,
}

pub(super) fn deserialize_test_case(value: Yaml, raw_yaml: &str) -> Result<TestCase, String> {
    let obj = value
        .as_hash()
        .ok_or_else(|| "Expected mapping for test case".to_string())?;

    let name = obj
        .get(&Yaml::String("name".to_string()))
        .and_then(|v| v.as_str())
        .map(|s| s.to_string())
        .unwrap_or_else(|| "Unnamed".to_string());

    let description = obj
        .get(&Yaml::String("description".to_string()))
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());

    let version = obj
        .get(&Yaml::String("version".to_string()))
        .and_then(|v| v.as_str())
        .map(|s| s.to_string())
        .unwrap_or_else(|| "1.0".to_string());

    let parameters = obj
        .get(&Yaml::String("parameters".to_string()))
        .and_then(|v| v.as_hash())
        .map(|h| {
            h.iter()
                .filter_map(|(k, v)| k.as_str().map(|s| (s.to_string(), v.clone())))
                .collect()
        })
        .unwrap_or_default();

    let constants = obj
        .get(&Yaml::String("constants".to_string()))
        .and_then(|v| v.as_hash())
        .map(|h| {
            h.iter()
                .filter_map(|(k, v)| k.as_str().map(|s| (s.to_string(), v.clone())))
                .collect()
        })
        .unwrap_or_default();

    let variables = obj
        .get(&Yaml::String("variables".to_string()))
        .and_then(|v| v.as_hash())
        .map(|h| {
            h.iter()
                .filter_map(|(k, v)| {
                    let var_name = k.as_str()?.to_string();

                    // Parse the value to support both "Type" and "Type = value" formats
                    let parsed_value = if let Some(type_str) = v.as_str() {
                        // Check if the value contains " = " to separate type from initial value
                        if let Some(eq_pos) = type_str.find(" = ") {
                            let var_type = type_str[..eq_pos].trim();
                            let init_value = type_str[eq_pos + 3..].trim();

                            // Create a hash with both type and initial value
                            let mut var_hash = yaml_rust2::yaml::Hash::new();
                            var_hash.insert(
                                Yaml::String("type".to_string()),
                                Yaml::String(var_type.to_string()),
                            );
                            var_hash.insert(
                                Yaml::String("initial".to_string()),
                                Yaml::String(init_value.to_string()),
                            );
                            Yaml::Hash(var_hash)
                        } else {
                            // Just the type, no initial value - keep as string
                            v.clone()
                        }
                    } else {
                        // Not a string, keep as-is
                        v.clone()
                    };

                    Some((var_name, parsed_value))
                })
                .collect()
        })
        .unwrap_or_default();

    let when = obj
        .get(&Yaml::String("when".to_string()))
        .and_then(|v| match v {
            Yaml::String(s) => Some(s.to_string()),
            Yaml::Boolean(b) => Some(if *b {
                "True".to_string()
            } else {
                "False".to_string()
            }),
            _ => v.as_str().map(|s| s.to_string()),
        });

    let repeat = obj
        .get(&Yaml::String("repeat".to_string()))
        .and_then(|v| v.as_bool())
        .unwrap_or(false); // Default to false - events fire only once unless explicitly repeated

    let steps_value = obj.get(&Yaml::String("steps".to_string()));

    let steps = if let Some(steps_value) = steps_value {
        if let Some(seq) = steps_value.as_vec() {
            seq.iter()
                .map(|v| deserialize_action(v.clone(), raw_yaml))
                .collect::<Result<Vec<Action>, _>>()?
        } else {
            Vec::new()
        }
    } else {
        Vec::new()
    };

    Ok(TestCase {
        name,
        description,
        version,
        parameters,
        constants,
        variables,
        when,
        repeat,
        steps,
    })
}

pub(super) fn deserialize_action(value: Yaml, raw_yaml: &str) -> Result<Action, String> {
    // Handle simple string "exit" as a special case
    if let Some(s) = value.as_str() {
        if s == "exit" {
            return Ok(Action::Exit {
                name: "Exit".to_string(),
            });
        }
    }

    let obj = value
        .as_hash()
        .ok_or_else(|| "Expected mapping for action".to_string())?;

    // Generate a default name if not provided, based on the action type
    let name = obj
        .get(&Yaml::String("name".to_string()))
        .and_then(|v| v.as_str())
        .map(|s| s.to_string())
        .unwrap_or_else(|| {
            // Auto-generate name based on action type
            if let Some(run_val) = obj
                .get(&Yaml::String("run".to_string()))
                .and_then(|v| v.as_str())
            {
                format!("Run {}", run_val)
            } else if let Some(infer_val) = obj
                .get(&Yaml::String("infer".to_string()))
                .and_then(|v| v.as_str())
            {
                format!("Infer {}", infer_val)
            } else if obj.contains_key(&Yaml::String("set".to_string())) {
                "Set variables".to_string()
            } else if obj.contains_key(&Yaml::String("log".to_string())) {
                "Log".to_string()
            } else if obj.contains_key(&Yaml::String("return".to_string())) {
                "Return".to_string()
            } else if obj.contains_key(&Yaml::String("exit".to_string())) {
                "Exit".to_string()
            } else if obj.contains_key(&Yaml::String("if".to_string())) {
                "If statement".to_string()
            } else if obj.contains_key(&Yaml::String("for".to_string())) {
                "For loop".to_string()
            } else if obj.contains_key(&Yaml::String("match".to_string())) {
                "Match statement".to_string()
            } else if obj.contains_key(&Yaml::String("repeat".to_string())) {
                "Repeat".to_string()
            } else if obj.contains_key(&Yaml::String("when".to_string())) {
                "When".to_string()
            } else if obj.contains_key(&Yaml::String("record".to_string())) {
                "Record".to_string()
            } else {
                "Unnamed action".to_string()
            }
        });

    // Check if there's a 'when' condition combined with another action type
    // If so, we need to wrap the action in a When action
    let has_when = obj.contains_key(&Yaml::String("when".to_string()));
    let has_other_action = obj.contains_key(&Yaml::String("record".to_string()))
        || obj.contains_key(&Yaml::String("set".to_string()))
        || obj.contains_key(&Yaml::String("log".to_string()))
        || obj.contains_key(&Yaml::String("run".to_string()))
        || obj.contains_key(&Yaml::String("infer".to_string()));

    if has_when && has_other_action {
        // Parse as a When action wrapping the other action
        deserialize_when_action(obj, name, raw_yaml)
    } else if obj.contains_key(&Yaml::String("if".to_string())) {
        deserialize_if_action(obj, name, raw_yaml)
    } else if obj.contains_key(&Yaml::String("for".to_string())) {
        deserialize_for_action(obj, name, raw_yaml)
    } else if obj.contains_key(&Yaml::String("match".to_string())) {
        deserialize_match_action(obj, name, raw_yaml)
    } else if obj.contains_key(&Yaml::String("record".to_string())) {
        deserialize_record_action(obj, name, raw_yaml)
    } else if obj.contains_key(&Yaml::String("repeat".to_string())) {
        deserialize_repeat_action(obj, name, raw_yaml)
    } else if obj.contains_key(&Yaml::String("when".to_string())) {
        deserialize_when_action(obj, name, raw_yaml)
    } else if obj.contains_key(&Yaml::String("log".to_string())) {
        deserialize_log_action(obj, name, raw_yaml)
    } else if obj.contains_key(&Yaml::String("infer".to_string())) {
        deserialize_infer_action(obj, name, raw_yaml)
    } else if obj.contains_key(&Yaml::String("run".to_string())) {
        deserialize_run_action(obj, name, raw_yaml)
    } else if obj.contains_key(&Yaml::String("set".to_string())) {
        deserialize_set_action(obj, name, raw_yaml)
    } else if obj.contains_key(&Yaml::String("return".to_string())) {
        deserialize_return_action(obj, name, raw_yaml)
    } else if obj.contains_key(&Yaml::String("exit".to_string())) {
        deserialize_exit_action(obj, name)
    } else {
        Err(format!("Unknown action type: {:?}", obj))
    }
}

fn deserialize_if_action(
    obj: &yaml_rust2::yaml::Hash,
    name: String,
    raw_yaml: &str,
) -> Result<Action, String> {
    let condition = obj
        .get(&Yaml::String("if".to_string()))
        .and_then(|v| v.as_str())
        .ok_or_else(|| "Missing 'if' condition".to_string())?
        .to_string();

    let then_value = obj
        .get(&Yaml::String("then".to_string()))
        .ok_or_else(|| "Missing 'then' branch".to_string())?;

    let then_actions = helpers::deserialize_action_list_with_context(then_value, raw_yaml)?;

    let else_actions = if let Some(else_value) = obj.get(&Yaml::String("else".to_string())) {
        helpers::deserialize_action_list_with_context(else_value, raw_yaml)?
    } else {
        Vec::new()
    };

    Ok(Action::If {
        name,

        condition,
        then_actions,
        else_actions,
    })
}

fn deserialize_match_action(
    obj: &yaml_rust2::yaml::Hash,
    name: String,
    raw_yaml: &str,
) -> Result<Action, String> {
    let key = obj
        .get(&Yaml::String("match".to_string()))
        .and_then(|v| v.as_str())
        .ok_or_else(|| "Missing 'match' key".to_string())?
        .to_string();

    let cases_value = obj
        .get(&Yaml::String("cases".to_string()))
        .and_then(|v| v.as_hash())
        .ok_or_else(|| "Missing or invalid 'cases'".to_string())?;

    let mut cases = HashMap::new();
    for (case_key, case_value) in cases_value {
        let case_name = case_key
            .as_str()
            .or_else(|| case_key.as_i64().map(|_| ""))
            .ok_or_else(|| format!("Invalid case key: {:?}", case_key))?
            .to_string();

        // Numeric keys
        let case_name = if case_name.is_empty() {
            case_key
                .as_i64()
                .map(|n| n.to_string())
                .ok_or_else(|| format!("Invalid case key: {:?}", case_key))?
        } else {
            case_name
        };

        let actions = helpers::deserialize_action_list_with_context(case_value, raw_yaml)?;
        cases.insert(case_name, actions);
    }

    let default = if let Some(default_value) = obj.get(&Yaml::String("default".to_string())) {
        helpers::deserialize_action_list_with_context(default_value, raw_yaml)?
    } else {
        Vec::new()
    };

    Ok(Action::Match {
        name,

        key,
        cases,
        default,
    })
}

fn deserialize_repeat_action(
    obj: &yaml_rust2::yaml::Hash,
    name: String,
    raw_yaml: &str,
) -> Result<Action, String> {
    let repeat_value = obj
        .get(&Yaml::String("repeat".to_string()))
        .ok_or_else(|| "Missing 'repeat' actions".to_string())?;

    let actions = helpers::deserialize_action_list_with_context(repeat_value, raw_yaml)?;

    let count = obj
        .get(&Yaml::String("count".to_string()))
        .and_then(|v| v.as_i64());

    let condition = obj
        .get(&Yaml::String("while".to_string()))
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());

    Ok(Action::Repeat {
        name,

        actions,
        count,
        condition,
    })
}

fn deserialize_when_action(
    obj: &yaml_rust2::yaml::Hash,
    name: String,
    raw_yaml: &str,
) -> Result<Action, String> {
    let condition = obj
        .get(&Yaml::String("when".to_string()))
        .and_then(|v| v.as_str())
        .ok_or_else(|| "Missing 'when' condition".to_string())?
        .to_string();

    // Action for 'when' can be under "do" or any other key
    let mut actions = None;

    if let Some(do_value) = obj.get(&Yaml::String("do".to_string())) {
        let action = deserialize_action(do_value.clone(), raw_yaml)?;
        actions = Some(action);
    } else {
        // Collect all keys except when and id for the nested action
        // Keep the name field for the nested action
        let action_hash: yaml_rust2::yaml::Hash = obj
            .iter()
            .filter(|(key, _)| {
                let key_str = key.as_str().unwrap_or("");
                key_str != "when" && key_str != "id"
            })
            .map(|(k, v)| (k.clone(), v.clone()))
            .collect();

        if !action_hash.is_empty() {
            let action = deserialize_action(Yaml::Hash(action_hash), raw_yaml)?;
            actions = Some(action);
        }
    }

    let actions = actions.ok_or_else(|| "Missing action in 'when'".to_string())?;

    Ok(Action::When {
        name,
        condition,
        actions: Box::new(actions),
    })
}

fn deserialize_log_action(
    obj: &yaml_rust2::yaml::Hash,
    name: String,
    raw_yaml: &str,
) -> Result<Action, String> {
    let log_value = obj
        .get(&Yaml::String("log".to_string()))
        .ok_or_else(|| "Missing 'log' value".to_string())?;

    let (message, with) = if let Some(msg) = log_value.as_str() {
        (msg.to_string(), HashMap::new())
    } else if let Some(mapping) = log_value.as_hash() {
        let msg = mapping
            .get(&Yaml::String("message".to_string()))
            .and_then(|v| v.as_str())
            .ok_or_else(|| "Missing 'message' in log".to_string())?
            .to_string();

        let vars = helpers::extract_variables_with_context(mapping, raw_yaml);
        (msg, vars)
    } else {
        return Err("Invalid 'log' format".to_string());
    };

    Ok(Action::Log {
        name,
        message,
        with,
    })
}

fn deserialize_set_action(
    obj: &yaml_rust2::yaml::Hash,
    name: String,
    raw_yaml: &str,
) -> Result<Action, String> {
    let set_value = obj
        .get(&Yaml::String("set".to_string()))
        .and_then(|v| v.as_hash())
        .ok_or_else(|| "Missing or invalid 'set' value".to_string())?;

    let with = helpers::extract_variables_with_context(set_value, raw_yaml);

    Ok(Action::Set { name, with })
}

fn deserialize_return_action(
    obj: &yaml_rust2::yaml::Hash,
    name: String,
    raw_yaml: &str,
) -> Result<Action, String> {
    let return_value = obj
        .get(&Yaml::String("return".to_string()))
        .and_then(|v| v.as_hash())
        .ok_or_else(|| "Missing or invalid 'return' value".to_string())?;

    let with = helpers::extract_variables_with_context(return_value, raw_yaml);

    Ok(Action::Return { name, with })
}

fn deserialize_run_action(
    obj: &yaml_rust2::yaml::Hash,
    name: String,
    raw_yaml: &str,
) -> Result<Action, String> {
    let run_value = obj
        .get(&Yaml::String("run".to_string()))
        .ok_or_else(|| "Missing 'run' value".to_string())?;

    // Handle two formats:
    // 1. run: function_name (with optional "with" at same level)
    // 2. run: { function: name, parameters: {...} }
    let (function, with) = if let Some(func_str) = run_value.as_str() {
        // Format 1: simple string
        let params = if let Some(with_value) = obj.get(&Yaml::String("with".to_string())) {
            if let Some(mapping) = with_value.as_hash() {
                helpers::extract_variables_with_context(mapping, raw_yaml)
            } else {
                HashMap::new()
            }
        } else {
            HashMap::new()
        };
        (func_str.to_string(), params)
    } else if let Some(run_mapping) = run_value.as_hash() {
        // Format 2: mapping with function and parameters
        let func = run_mapping
            .get(&Yaml::String("function".to_string()))
            .and_then(|v| v.as_str())
            .ok_or_else(|| "Missing 'function' in run".to_string())?
            .to_string();

        let params =
            if let Some(params_value) = run_mapping.get(&Yaml::String("parameters".to_string())) {
                if let Some(mapping) = params_value.as_hash() {
                    helpers::extract_variables_with_context(mapping, raw_yaml)
                } else {
                    HashMap::new()
                }
            } else {
                HashMap::new()
            };

        (func, params)
    } else {
        return Err("Invalid 'run' format".to_string());
    };

    // Parse the output attribute as a simple string: output: variable_name
    let output = obj
        .get(&Yaml::String("output".to_string()))
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());

    Ok(Action::Run {
        name,
        function,
        with,
        output,
    })
}

fn deserialize_infer_action(
    obj: &yaml_rust2::yaml::Hash,
    name: String,
    raw_yaml: &str,
) -> Result<Action, String> {
    let model = obj
        .get(&Yaml::String("infer".to_string()))
        .and_then(|v| v.as_str())
        .ok_or_else(|| "Missing 'infer' model name".to_string())?
        .to_string();

    let version = obj
        .get(&Yaml::String("version".to_string()))
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());

    let with = if let Some(with_value) = obj.get(&Yaml::String("with".to_string())) {
        if let Some(mapping) = with_value.as_hash() {
            helpers::extract_variables_with_context(mapping, raw_yaml)
        } else {
            HashMap::new()
        }
    } else {
        HashMap::new()
    };

    let extractor = obj
        .get(&Yaml::String("extractor".to_string()))
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());

    let categories = obj
        .get(&Yaml::String("categories".to_string()))
        .and_then(|v| v.as_i64());

    let inputs = obj
        .get(&Yaml::String("inputs".to_string()))
        .and_then(|v| v.as_vec())
        .map(|vec| {
            vec.iter()
                .filter_map(|item| item.as_str().map(|s| s.to_string()))
                .collect::<Vec<String>>()
        });

    let outputs = obj
        .get(&Yaml::String("outputs".to_string()))
        .and_then(|v| v.as_vec())
        .map(|vec| {
            vec.iter()
                .filter_map(|item| item.as_str().map(|s| s.to_string()))
                .collect::<Vec<String>>()
        });

    // Parse the output attribute as a simple string: output: variable_name
    let output = obj
        .get(&Yaml::String("output".to_string()))
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());

    Ok(Action::Infer {
        name,
        model,
        version,
        with,
        extractor,
        categories,
        inputs,
        outputs,
        output,
    })
}

fn deserialize_exit_action(_obj: &yaml_rust2::yaml::Hash, name: String) -> Result<Action, String> {
    // Exit can be just "exit" or "exit: { condition: ... }"
    // We don't need to parse condition for the Action::Exit struct
    Ok(Action::Exit { name })
}

fn deserialize_record_action(
    obj: &yaml_rust2::yaml::Hash,
    name: String,
    _raw_yaml: &str,
) -> Result<Action, String> {
    let record_value = obj
        .get(&Yaml::String("record".to_string()))
        .ok_or_else(|| "Missing 'record' value".to_string())?;

    let record_seq = record_value
        .as_vec()
        .ok_or_else(|| "Expected sequence for 'record'".to_string())?;

    let mut entries = Vec::new();
    for entry_value in record_seq {
        let entry_map = entry_value
            .as_hash()
            .ok_or_else(|| "Expected mapping for record entry".to_string())?;

        let key = entry_map
            .get(&Yaml::String("key".to_string()))
            .and_then(|v| v.as_str())
            .ok_or_else(|| "Missing 'key' in record entry".to_string())?
            .to_string();

        let value = entry_map
            .get(&Yaml::String("value".to_string()))
            .ok_or_else(|| "Missing 'value' in record entry".to_string())?;

        // Convert value to string - handle strings, booleans, numbers
        let value_str = match value {
            Yaml::String(s) => s.clone(),
            Yaml::Real(s) => s.clone(),
            Yaml::Integer(i) => i.to_string(),
            Yaml::Boolean(b) => {
                if *b {
                    "True".to_string()
                } else {
                    "False".to_string()
                }
            }
            _ => return Err(format!("Invalid value type in record entry: {:?}", value)),
        };

        let entry_type = entry_map
            .get(&Yaml::String("type".to_string()))
            .and_then(|v| v.as_str())
            .ok_or_else(|| "Missing 'type' in record entry".to_string())?
            .to_string();

        let for_loop = entry_map
            .get(&Yaml::String("for".to_string()))
            .and_then(|v| v.as_str())
            .map(|s| s.to_string());

        entries.push(RecordEntry {
            key,
            value: value_str,
            entry_type,
            for_loop,
        });
    }

    Ok(Action::Record { name, entries })
}

fn deserialize_for_action(
    obj: &yaml_rust2::yaml::Hash,
    name: String,
    raw_yaml: &str,
) -> Result<Action, String> {
    let for_value = obj
        .get(&Yaml::String("for".to_string()))
        .and_then(|v| v.as_str())
        .ok_or_else(|| "Missing 'for' loop expression".to_string())?
        .to_string();

    // Parse "iterator in collection" format
    let parts: Vec<&str> = for_value.split(" in ").collect();
    if parts.len() != 2 {
        return Err(format!(
            "Invalid 'for' loop format, expected 'iterator in collection', got: {}",
            for_value
        ));
    }

    let iterator = parts[0].trim().to_string();
    let collection = parts[1].trim().to_string();

    // Steps can be under "steps" or "record"
    let steps = if let Some(steps_value) = obj.get(&Yaml::String("steps".to_string())) {
        helpers::deserialize_action_list_with_context(steps_value, raw_yaml)?
    } else if obj.contains_key(&Yaml::String("record".to_string())) {
        // If there's a record key, create a Record action with a default name
        vec![deserialize_record_action(
            obj,
            "record".to_string(),
            raw_yaml,
        )?]
    } else {
        return Err("Missing 'steps' or 'record' in 'for' loop".to_string());
    };

    Ok(Action::For {
        name,

        iterator,
        collection,
        steps,
    })
}
