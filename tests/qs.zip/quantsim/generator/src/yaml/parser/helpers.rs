use crate::models::action::Action;
use std::collections::HashMap;
use yaml_rust2::Yaml;

const QUOTED_STRING_MARKER: &str = "___QUOTED___";

pub(super) fn deserialize_action_list_with_context(
    value: &Yaml,
    raw_yaml: &str,
) -> Result<Vec<Action>, String> {
    if let Some(seq) = value.as_vec() {
        seq.iter()
            .map(|v| super::converter::deserialize_action(v.clone(), raw_yaml))
            .collect()
    } else {
        Ok(vec![super::converter::deserialize_action(
            value.clone(),
            raw_yaml,
        )?])
    }
}

fn is_quoted_in_yaml(raw_yaml: &str, key: &str, value: &str) -> bool {
    // Look for patterns like: key: 'value' or key: "value"
    // This is a simple heuristic - looks for the key-value pair in the raw text
    let patterns = [
        format!("{}: '{}'", key, value),
        format!("{}: \"{}\"", key, value),
        format!("{}:'{}'", key, value),
        format!("{}:\"{}\"", key, value),
    ];

    patterns.iter().any(|pattern| raw_yaml.contains(pattern))
}

pub(super) fn extract_numeric_variables(
    mapping: &yaml_rust2::yaml::Hash,
    _raw_yaml: &str,
) -> HashMap<String, f32> {
    mapping
        .iter()
        .filter_map(|(k, v)| {
            let key = k.as_str()?.to_string();
            let value = if let Some(n) = v.as_i64() {
                n as f32
            } else if let Some(f) = v.as_f64() {
                f as f32
            } else {
                return None;
            };
            Some((key, value))
        })
        .collect()
}

pub(super) fn extract_variables_with_context(
    mapping: &yaml_rust2::yaml::Hash,
    raw_yaml: &str,
) -> HashMap<String, String> {
    mapping
        .iter()
        .filter_map(|(k, v)| {
            let key = k.as_str()?.to_string();
            let value = match v {
                Yaml::String(s) => {
                    let trimmed = s.trim_end().to_string();
                    // Check if this string was quoted in the original YAML
                    if !raw_yaml.is_empty() && is_quoted_in_yaml(raw_yaml, &key, &trimmed) {
                        // Mark as quoted string literal
                        format!("{}{}", QUOTED_STRING_MARKER, trimmed)
                    } else {
                        // Unquoted - treat as expression/variable reference
                        trimmed
                    }
                }
                Yaml::Real(s) => s.clone(),
                Yaml::Integer(n) => n.to_string(),
                Yaml::Boolean(b) => {
                    // Convert boolean to Python format (True/False with capital first letter)
                    if *b {
                        "True".to_string()
                    } else {
                        "False".to_string()
                    }
                }
                Yaml::Array(arr) => yaml_array_to_string(arr),
                _ => return None,
            };
            Some((key, value))
        })
        .collect()
}

fn yaml_array_to_string(arr: &[Yaml]) -> String {
    if arr.len() == 1 {
        if let Some(s) = arr[0].as_str() {
            return format!("[{}]", s.trim_end());
        }
    }

    let elements: Vec<String> = arr
        .iter()
        .filter_map(|v| match v {
            Yaml::String(s) => Some(format!("'{}'", s)),
            Yaml::Real(s) => Some(s.clone()),
            Yaml::Integer(n) => Some(n.to_string()),
            Yaml::Boolean(b) => Some(b.to_string()),
            _ => None,
        })
        .collect();

    format!("[{}]", elements.join(", "))
}

pub fn parse_yaml_file(content: &str) -> Result<super::converter::TestCase, String> {
    let docs = yaml_rust2::YamlLoader::load_from_str(content)
        .map_err(|e| format!("YAML parsing error: {}", e))?;

    let doc = docs
        .into_iter()
        .next()
        .ok_or_else(|| "No YAML document found".to_string())?;

    super::converter::deserialize_test_case(doc, content)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_quoted_vs_unquoted_detection() {
        let yaml = r#"
name: test_quotes
version: 1.0
steps:
  - name: Test
    set:
      quoted_string: 'za'
      unquoted_var: za
      expression: is_za or is_zj
"#;

        let test_case = parse_yaml_file(yaml).expect("Should parse");
        assert_eq!(test_case.steps.len(), 1);

        if let crate::models::action::Action::Set { with, .. } = &test_case.steps[0] {
            // quoted_string should have the marker
            assert!(
                with.get("quoted_string")
                    .unwrap()
                    .starts_with(QUOTED_STRING_MARKER),
                "quoted_string should have marker, got: {}",
                with.get("quoted_string").unwrap()
            );

            // unquoted_var should NOT have the marker
            assert!(
                !with
                    .get("unquoted_var")
                    .unwrap()
                    .starts_with(QUOTED_STRING_MARKER),
                "unquoted_var should not have marker, got: {}",
                with.get("unquoted_var").unwrap()
            );

            // expression should NOT have the marker
            assert!(
                !with
                    .get("expression")
                    .unwrap()
                    .starts_with(QUOTED_STRING_MARKER),
                "expression should not have marker, got: {}",
                with.get("expression").unwrap()
            );
        } else {
            panic!("Expected Set action");
        }
    }

    #[test]
    fn test_codegen_respects_quotes() {
        let yaml = r#"
name: test_quotes
version: 1.0
steps:
  - name: Test
    set:
      quoted_string: 'za'
      unquoted_var: za
      expression: is_za or is_zj
"#;

        let test_case = parse_yaml_file(yaml).expect("Should parse");
        let python_code =
            crate::codegen::test_case_to_python(&test_case, None).expect("Should generate Python");

        println!("Generated Python:\n{}", python_code);

        // quoted_string should be generated as a quoted string literal
        assert!(
            python_code.contains("quoted_string = \"za\""),
            "quoted_string should be quoted in Python"
        );

        // unquoted_var should be generated without quotes (as variable reference)
        assert!(
            python_code.contains("unquoted_var = za\n")
                || python_code.contains("unquoted_var = za "),
            "unquoted_var should not be quoted in Python"
        );

        // expression should be generated without quotes
        assert!(
            python_code.contains("expression = is_za or is_zj"),
            "expression should not be quoted in Python"
        );
    }

    #[test]
    fn test_zone_type_example() {
        // This tests the actual use case from the user's step.yaml file
        let yaml = r#"
name: end_zone
version: 1.0
variables:
  is_za_zone: Bool
  is_zj_zone: Bool
  zone_type: Str

steps:
  - name: Determine zone type string
    set:
      zone_type: |
        if is_za_zone then 'za'
        else if is_zj_zone then 'zj'
        else 'none'
"#;

        let test_case = parse_yaml_file(yaml).expect("Should parse");
        let python_code =
            crate::codegen::test_case_to_python(&test_case, None).expect("Should generate Python");

        println!("Generated Python for zone_type:\n{}", python_code);

        // Variables should have type-aware defaults
        assert!(
            python_code.contains("is_za_zone: bool = False"),
            "Bool variables should default to False"
        );
        assert!(
            python_code.contains("is_zj_zone: bool = False"),
            "Bool variables should default to False"
        );
        assert!(
            python_code.contains("zone_type: str = \"\""),
            "Str variables should default to empty string"
        );

        // The expression assignment should preserve the if-then-else with quotes inside
        assert!(
            python_code.contains("if is_za_zone then 'za'"),
            "Expression should preserve single quotes for string literals"
        );
    }
}
