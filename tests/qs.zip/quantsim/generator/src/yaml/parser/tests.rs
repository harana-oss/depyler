use super::*;
use std::fs;

fn load_test_file(filename: &str) -> String {
    let path = format!("src/test_cases/valid/{}", filename);
    fs::read_to_string(&path).unwrap_or_else(|_| panic!("Failed to read test file: {}", path))
}

#[test]
fn test_parse_if() {
    let yaml = load_test_file("if.yml");
    let result = parse_yaml_file(&yaml);
    assert!(result.is_ok(), "Failed to parse if.yml: {:?}", result.err());

    let test_case = result.unwrap();
    assert_eq!(test_case.name, "If");
    assert_eq!(test_case.steps.len(), 2);
}

#[test]
fn test_parse_exit() {
    let yaml = load_test_file("exit.yml");
    let result = parse_yaml_file(&yaml);
    assert!(
        result.is_ok(),
        "Failed to parse exit.yml: {:?}",
        result.err()
    );

    let test_case = result.unwrap();
    assert_eq!(test_case.name, "Exit");
    assert_eq!(test_case.steps.len(), 3);
}

#[test]
fn test_parse_match() {
    let yaml = load_test_file("match.yml");
    let result = parse_yaml_file(&yaml);
    assert!(
        result.is_ok(),
        "Failed to parse match.yml: {:?}",
        result.err()
    );

    let test_case = result.unwrap();
    assert_eq!(test_case.name, "Match");
    assert_eq!(test_case.steps.len(), 3);
}

#[test]
fn test_parse_repeat() {
    let yaml = load_test_file("repeat.yml");
    let result = parse_yaml_file(&yaml);
    assert!(
        result.is_ok(),
        "Failed to parse repeat.yml: {:?}",
        result.err()
    );

    let test_case = result.unwrap();
    assert_eq!(test_case.name, "repeat");
    assert_eq!(test_case.steps.len(), 3);
}

#[test]
fn test_parse_conditional() {
    let yaml = load_test_file("conditional.yml");
    let result = parse_yaml_file(&yaml);
    assert!(
        result.is_ok(),
        "Failed to parse conditional.yml: {:?}",
        result.err()
    );

    let test_case = result.unwrap();
    assert_eq!(test_case.name, "Complex Conditionals");
    assert_eq!(test_case.steps.len(), 3);
}

#[test]
fn test_parse_if_else() {
    let yaml = load_test_file("if-else.yml");
    let result = parse_yaml_file(&yaml);
    assert!(
        result.is_ok(),
        "Failed to parse if-else.yml: {:?}",
        result.err()
    );

    let test_case = result.unwrap();
    assert_eq!(test_case.name, "If-Else Chain");
    assert_eq!(test_case.steps.len(), 2);
}

#[test]
fn test_parse_if_nested() {
    let yaml = load_test_file("if-nested.yml");
    let result = parse_yaml_file(&yaml);
    assert!(
        result.is_ok(),
        "Failed to parse if-nested.yml: {:?}",
        result.err()
    );

    let test_case = result.unwrap();
    assert_eq!(test_case.name, "Nested If");
    assert_eq!(test_case.steps.len(), 2);
}

#[test]
fn test_parse_all_valid_files() {
    let test_files = vec![
        "conditional.yml",
        "exit.yml",
        "if-else.yml",
        "if.yml",
        "match.yml",
        "if-nested.yml",
        "repeat.yml",
    ];

    for filename in test_files {
        let yaml = load_test_file(filename);
        let result = parse_yaml_file(&yaml);
        assert!(
            result.is_ok(),
            "Failed to parse {}: {:?}",
            filename,
            result.err()
        );
    }
}
