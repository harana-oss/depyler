use std::collections::HashMap;

#[derive(Debug, Clone, PartialEq)]
pub struct RecordEntry {
    pub key: String,
    pub value: String,
    pub entry_type: String,
    pub for_loop: Option<String>,
}

#[derive(Debug, Clone, PartialEq)]
pub enum Action {
    Exit {
        name: String,
    },
    For {
        name: String,
        iterator: String,
        collection: String,
        steps: Vec<Action>,
    },
    If {
        name: String,
        condition: String,
        then_actions: Vec<Action>,
        else_actions: Vec<Action>,
    },
    Infer {
        name: String,
        model: String,
        version: Option<String>,
        with: HashMap<String, String>,
        extractor: Option<String>,
        categories: Option<i64>,
        inputs: Option<Vec<String>>,
        outputs: Option<Vec<String>>,
        output: Option<String>,
    },
    Log {
        name: String,
        message: String,
        with: HashMap<String, String>,
    },
    Match {
        name: String,
        key: String,
        cases: HashMap<String, Vec<Action>>,
        default: Vec<Action>,
    },
    Return {
        name: String,
        with: HashMap<String, String>,
    },
    Record {
        name: String,
        entries: Vec<RecordEntry>,
    },
    Repeat {
        name: String,
        actions: Vec<Action>,
        count: Option<i64>,
        condition: Option<String>,
    },
    Run {
        name: String,
        function: String,
        with: HashMap<String, String>,
        output: Option<String>,
    },
    Set {
        name: String,
        with: HashMap<String, String>,
    },
    When {
        name: String,
        condition: String,
        actions: Box<Action>,
    },
}

impl Action {
    pub fn name(&self) -> &str {
        match self {
            Action::Exit { name, .. } => name.as_str(),
            Action::For { name, .. } => name.as_str(),
            Action::If { name, .. } => name.as_str(),
            Action::Infer { name, .. } => name.as_str(),
            Action::Log { name, .. } => name.as_str(),
            Action::Match { name, .. } => name.as_str(),
            Action::Return { name, .. } => name.as_str(),
            Action::Record { name, .. } => name.as_str(),
            Action::Repeat { name, .. } => name.as_str(),
            Action::Run { name, .. } => name.as_str(),
            Action::Set { name, .. } => name.as_str(),
            Action::When { name, .. } => name.as_str(),
        }
    }
}
