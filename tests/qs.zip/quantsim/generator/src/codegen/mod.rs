pub mod python;
pub mod rust;

pub use python::action_to_python;
pub use python::constants_to_python;
pub use python::state_to_python;
pub use python::{generate_constants_file, generate_variables_file, test_case_to_python};

use regex::Regex;

pub fn python_to_rust(
    python_code: &str,
    _module_name: &str,
) -> Result<String, rust::ConversionError> {
    let converter = rust::RustConverter::new();
    let rust_code = converter.convert(python_code)?;

    // Post-process to fix type annotations
    let mut fixed_rust_code = fix_constant_types(&rust_code);

    // Replace "pub fn nrl" with "pub fn game"
    fixed_rust_code = fixed_rust_code.replace("pub fn nrl(", "pub fn game(");

    Ok(fixed_rust_code)
}

/// Fix incorrect type annotations in generated Rust code
/// Specifically handles cases where depyler_core generates serde_json::Value
/// for nested arrays and negative numbers
fn fix_constant_types(rust_code: &str) -> String {
    let mut result = rust_code.to_string();

    // Fix simple negative numbers first: serde_json::Value = -N -> i32
    let neg_number_pattern =
        Regex::new(r"pub const ([A-Z_]+): serde_json::Value = (-\d+);").unwrap();

    result = neg_number_pattern
        .replace_all(&result, "pub const $1: i32 = $2;")
        .to_string();

    // Fix nested Vec types using a more robust approach
    // Match the pattern across multiple lines
    let nested_vec_pattern = Regex::new(
        r"(?s)pub const ([A-Z_]+): serde_json::Value = vec!\[((?:\s*vec!\[-?\d+,\s*-?\d+\],?)+)\s*\];"
    ).unwrap();

    result = nested_vec_pattern
        .replace_all(&result, |caps: &regex::Captures| {
            let name = &caps[1];
            let inner_vecs = &caps[2];
            // Convert vec![a, b] to &[a, b]
            let converted = inner_vecs.replace("vec!", "&");
            format!("pub const {}: &[&[i32]] = &[{}];", name, converted)
        })
        .to_string();

    result
}

#[cfg(test)]
mod tests;
