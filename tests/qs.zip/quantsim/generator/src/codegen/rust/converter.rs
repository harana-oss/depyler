use std::fmt;
use std::panic;
use std::path::Path;

#[derive(Debug)]
pub enum ConversionError {
    CodeGenError(String),
    InvalidInput(String),
    PanicError(String),
    IoError(std::io::Error),
}

impl fmt::Display for ConversionError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ConversionError::CodeGenError(msg) => write!(f, "Code generation failed: {}", msg),
            ConversionError::InvalidInput(msg) => write!(f, "Invalid input: {}", msg),
            ConversionError::PanicError(msg) => write!(f, "Panic during conversion: {}", msg),
            ConversionError::IoError(err) => write!(f, "Failed to read file: {}", err),
        }
    }
}

impl std::error::Error for ConversionError {}

impl From<std::io::Error> for ConversionError {
    fn from(err: std::io::Error) -> Self {
        ConversionError::IoError(err)
    }
}

#[derive(Debug, Clone)]
pub struct ConversionOptions {
    pub include_docs: bool,
    pub generate_tests: bool,
    pub optimization_level: OptimizationLevel,
}

#[derive(Debug, Clone, Copy)]
pub enum OptimizationLevel {
    None,
    Balanced,
    Performance,
}

impl Default for ConversionOptions {
    fn default() -> Self {
        Self {
            include_docs: true,
            generate_tests: false,
            optimization_level: OptimizationLevel::Balanced,
        }
    }
}
pub struct RustConverter {
    options: ConversionOptions,
}

impl RustConverter {
    pub fn new() -> Self {
        Self {
            options: ConversionOptions::default(),
        }
    }

    pub fn with_options(options: ConversionOptions) -> Self {
        Self { options }
    }

    pub fn convert(&self, python_code: &str) -> Result<String, ConversionError> {
        // Catch any panics that might occur during transpilation
        let result = panic::catch_unwind(panic::AssertUnwindSafe(|| {
            let config = depyler_core::Config {
                enable_verification: false,
                enable_metrics: false,
                optimization_level: depyler_core::OptimizationLevel::default(),
            };
            let pipeline = depyler_core::DepylerPipeline::new_with_config(config);
            pipeline.transpile(python_code)
        }));

        match result {
            Ok(Ok(rust_code)) => Ok(rust_code),
            Ok(Err(e)) => Err(ConversionError::CodeGenError(format!(
                "Transpilation failed: {}",
                e
            ))),
            Err(panic_err) => {
                let panic_msg = if let Some(s) = panic_err.downcast_ref::<&str>() {
                    s.to_string()
                } else if let Some(s) = panic_err.downcast_ref::<String>() {
                    s.clone()
                } else {
                    "Unknown panic".to_string()
                };
                Err(ConversionError::PanicError(panic_msg))
            }
        }
    }

    pub fn convert_and_format(&self, python_code: &str) -> Result<String, ConversionError> {
        let rust_code = self.convert(python_code)?;
        Ok(rust_code)
    }

    pub fn convert_file<P: AsRef<Path>>(&self, path: P) -> Result<String, ConversionError> {
        let source = std::fs::read_to_string(path)?;
        self.convert(&source)
    }

    pub fn options(&self) -> &ConversionOptions {
        &self.options
    }

    pub fn set_options(&mut self, options: ConversionOptions) {
        self.options = options;
    }
}

impl Default for RustConverter {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_conversion_options_default() {
        let options = ConversionOptions::default();
        assert!(options.include_docs);
        assert!(!options.generate_tests);
    }

    #[test]
    fn test_converter_creation() {
        let converter = RustConverter::new();
        assert!(converter.options().include_docs);
    }

    #[test]
    fn test_converter_with_options() {
        let options = ConversionOptions {
            include_docs: false,
            generate_tests: true,
            optimization_level: OptimizationLevel::Performance,
        };

        let converter = RustConverter::with_options(options);
        assert!(!converter.options().include_docs);
        assert!(converter.options().generate_tests);
    }
}
