use depyler_core::type_mapper::TypeMapper;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RustType {
    I32,
    I64,
    U32,
    U64,
    F32,
    F64,
    Bool,
    String,
    Str,
    Vec(Box<RustType>),
    HashMap(Box<RustType>, Box<RustType>),
    Option(Box<RustType>),
    Result(Box<RustType>, Box<RustType>),
    Tuple(Vec<RustType>),
    Custom(String),
    Unit,
}

impl RustType {
    pub fn to_string(&self) -> String {
        match self {
            RustType::I32 => "i32".to_string(),
            RustType::I64 => "i64".to_string(),
            RustType::U32 => "u32".to_string(),
            RustType::U64 => "u64".to_string(),
            RustType::F32 => "f32".to_string(),
            RustType::F64 => "f64".to_string(),
            RustType::Bool => "bool".to_string(),
            RustType::String => "String".to_string(),
            RustType::Str => "&str".to_string(),
            RustType::Vec(inner) => format!("Vec<{}>", inner.to_string()),
            RustType::HashMap(k, v) => {
                format!("HashMap<{}, {}>", k.to_string(), v.to_string())
            }
            RustType::Option(inner) => format!("Option<{}>", inner.to_string()),
            RustType::Result(ok, err) => {
                format!("Result<{}, {}>", ok.to_string(), err.to_string())
            }
            RustType::Tuple(types) => {
                let type_strs: Vec<String> = types.iter().map(|t| t.to_string()).collect();
                format!("({})", type_strs.join(", "))
            }
            RustType::Custom(name) => name.clone(),
            RustType::Unit => "()".to_string(),
        }
    }
}

pub struct TypeInferrer {
    mapper: TypeMapper,
}

impl TypeInferrer {
    pub fn new() -> Self {
        Self {
            mapper: TypeMapper::new(),
        }
    }

    pub fn infer_from_string(&self, python_type: &str) -> RustType {
        match python_type {
            "int" => RustType::I64,
            "float" => RustType::F64,
            "bool" => RustType::Bool,
            "str" => RustType::String,
            "None" => RustType::Unit,
            _ => {
                if python_type.starts_with("List[") || python_type.starts_with("list[") {
                    let inner = python_type
                        .trim_start_matches("List[")
                        .trim_start_matches("list[")
                        .trim_end_matches(']');
                    RustType::Vec(Box::new(self.infer_from_string(inner)))
                } else if python_type.starts_with("Dict[") || python_type.starts_with("dict[") {
                    let inner = python_type
                        .trim_start_matches("Dict[")
                        .trim_start_matches("dict[")
                        .trim_end_matches(']');
                    let parts: Vec<&str> = inner.split(',').map(|s| s.trim()).collect();
                    if parts.len() == 2 {
                        RustType::HashMap(
                            Box::new(self.infer_from_string(parts[0])),
                            Box::new(self.infer_from_string(parts[1])),
                        )
                    } else {
                        RustType::Custom(python_type.to_string())
                    }
                } else if python_type.starts_with("Optional[") {
                    let inner = python_type
                        .trim_start_matches("Optional[")
                        .trim_end_matches(']');
                    RustType::Option(Box::new(self.infer_from_string(inner)))
                } else {
                    RustType::Custom(python_type.to_string())
                }
            }
        }
    }

    pub fn mapper(&self) -> &TypeMapper {
        &self.mapper
    }
}

impl Default for TypeInferrer {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_basic_type_inference() {
        let inferrer = TypeInferrer::new();

        assert_eq!(inferrer.infer_from_string("int"), RustType::I64);
        assert_eq!(inferrer.infer_from_string("float"), RustType::F64);
        assert_eq!(inferrer.infer_from_string("bool"), RustType::Bool);
        assert_eq!(inferrer.infer_from_string("str"), RustType::String);
    }

    #[test]
    fn test_collection_type_inference() {
        let inferrer = TypeInferrer::new();

        let vec_type = inferrer.infer_from_string("List[int]");
        assert_eq!(vec_type, RustType::Vec(Box::new(RustType::I64)));

        let dict_type = inferrer.infer_from_string("Dict[str, int]");
        assert_eq!(
            dict_type,
            RustType::HashMap(Box::new(RustType::String), Box::new(RustType::I64))
        );
    }

    #[test]
    fn test_optional_type_inference() {
        let inferrer = TypeInferrer::new();

        let optional_type = inferrer.infer_from_string("Optional[int]");
        assert_eq!(optional_type, RustType::Option(Box::new(RustType::I64)));
    }

    #[test]
    fn test_rust_type_to_string() {
        assert_eq!(RustType::I32.to_string(), "i32");
        assert_eq!(RustType::String.to_string(), "String");
        assert_eq!(
            RustType::Vec(Box::new(RustType::I64)).to_string(),
            "Vec<i64>"
        );
        assert_eq!(
            RustType::Option(Box::new(RustType::String)).to_string(),
            "Option<String>"
        );
    }
}
