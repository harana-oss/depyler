#[cfg(test)]
mod integration_tests {
    use crate::codegen::rust::{ConversionOptions, OptimizationLevel, RustConverter};

    #[test]
    fn test_converter_creation() {
        let _converter = RustConverter::new();
    }

    #[test]
    fn test_converter_with_custom_options() {
        let options = ConversionOptions {
            include_docs: false,
            generate_tests: true,
            optimization_level: OptimizationLevel::Performance,
        };

        let _converter = RustConverter::with_options(options);
    }

    #[test]
    fn test_options_configuration() {
        let mut converter = RustConverter::new();

        let new_options = ConversionOptions {
            include_docs: false,
            generate_tests: true,
            optimization_level: OptimizationLevel::Performance,
        };

        converter.set_options(new_options);
        assert!(!converter.options().include_docs);
        assert!(converter.options().generate_tests);
    }
}

#[cfg(test)]
mod type_inference_tests {
    use crate::codegen::rust::{RustType, TypeInferrer};

    #[test]
    fn test_python_to_rust_type_mapping() {
        let inferrer = TypeInferrer::new();

        // Test basic types
        assert_eq!(inferrer.infer_from_string("int"), RustType::I64);
        assert_eq!(inferrer.infer_from_string("float"), RustType::F64);
        assert_eq!(inferrer.infer_from_string("bool"), RustType::Bool);
        assert_eq!(inferrer.infer_from_string("str"), RustType::String);
    }

    #[test]
    fn test_complex_type_mapping() {
        let inferrer = TypeInferrer::new();

        let list_int = inferrer.infer_from_string("List[int]");
        assert_eq!(list_int.to_string(), "Vec<i64>");

        let list_str = inferrer.infer_from_string("list[str]");
        assert_eq!(list_str.to_string(), "Vec<String>");

        let dict_str_int = inferrer.infer_from_string("Dict[str, int]");
        assert_eq!(dict_str_int.to_string(), "HashMap<String, i64>");

        let optional_str = inferrer.infer_from_string("Optional[str]");
        assert_eq!(optional_str.to_string(), "Option<String>");
    }

    #[test]
    fn test_nested_types() {
        let inferrer = TypeInferrer::new();
        let nested_list = inferrer.infer_from_string("List[List[int]]");
        assert!(nested_list.to_string().contains("Vec"));
    }

    #[test]
    fn test_rust_type_to_string() {
        assert_eq!(RustType::I32.to_string(), "i32");
        assert_eq!(RustType::I64.to_string(), "i64");
        assert_eq!(RustType::String.to_string(), "String");
        assert_eq!(
            RustType::Vec(Box::new(RustType::I64)).to_string(),
            "Vec<i64>"
        );
        assert_eq!(
            RustType::Option(Box::new(RustType::String)).to_string(),
            "Option<String>"
        );
        assert_eq!(
            RustType::HashMap(Box::new(RustType::String), Box::new(RustType::I64)).to_string(),
            "HashMap<String, i64>"
        );
    }
}
