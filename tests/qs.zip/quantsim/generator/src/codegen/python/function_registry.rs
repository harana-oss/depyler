use regex::Regex;
use std::collections::HashMap;
use std::fs;
use std::path::PathBuf;

/// Registry of function return types extracted from Python files
#[derive(Debug, Clone)]
pub struct FunctionRegistry {
    /// Maps function names to their return types
    return_types: HashMap<String, String>,
    /// List of event function names
    event_functions: Vec<String>,
}

impl FunctionRegistry {
    /// Create a new empty registry
    pub fn new() -> Self {
        Self {
            return_types: HashMap::new(),
            event_functions: Vec::new(),
        }
    }

    /// Load function signatures from Python function files and generated step files
    pub fn load() -> Self {
        let mut registry = Self::new();

        // Load from game/functions/*.py
        registry.load_from_directory("../../quantsim-nrl/game/functions");

        // Load from _generated/py/fn_*.py
        registry.load_from_directory("../../quantsim-nrl/_generated/py");

        // Load event functions from _generated/py/event_*.py
        registry.load_event_functions("../../quantsim-nrl/_generated/py");

        registry
    }

    /// Load function signatures from a directory
    fn load_from_directory(&mut self, dir_path: &str) {
        self.load_from_directory_with_filter(dir_path, None);
    }

    /// Load event functions from a directory
    fn load_event_functions(&mut self, dir_path: &str) {
        self.load_from_directory_with_filter(dir_path, Some("event_"));
    }

    /// Load Python files from a directory with optional filename prefix filter
    fn load_from_directory_with_filter(&mut self, dir_path: &str, prefix_filter: Option<&str>) {
        let path = PathBuf::from(dir_path);

        if let Ok(entries) = fs::read_dir(&path) {
            for entry in entries.flatten() {
                let file_path = entry.path();

                // Check if this is a Python file
                if file_path.extension().and_then(|s| s.to_str()) != Some("py") {
                    continue;
                }

                // Apply prefix filter if specified
                if let Some(prefix) = prefix_filter {
                    if let Some(file_name) = file_path.file_name().and_then(|s| s.to_str()) {
                        if !file_name.starts_with(prefix) {
                            continue;
                        }
                    } else {
                        continue;
                    }
                }

                // Read and process the file
                if let Ok(content) = fs::read_to_string(&file_path) {
                    if prefix_filter.is_some() {
                        // For event files, extract and register event function names
                        self.extract_event_functions(&content);
                    } else {
                        // For regular files, extract function signatures
                        self.extract_signatures(&content);
                    }
                }
            }
        }
    }

    /// Extract event function names from Python code
    fn extract_event_functions(&mut self, content: &str) {
        // Look for event function definitions: def function_name(state: State) -> None:
        let re = Regex::new(
            r"(?m)^def\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\(\s*state\s*:\s*State\s*\)\s*->\s*None\s*:",
        )
        .unwrap();

        for caps in re.captures_iter(content) {
            if let Some(func_name) = caps.get(1) {
                self.register_event(func_name.as_str().to_string());
            }
        }
    }
    /// Extract function signatures from Python code
    fn extract_signatures(&mut self, content: &str) {
        // Regex to match: def function_name(...) -> ReturnType:
        // Handles multiline function definitions
        let re =
            Regex::new(r"(?m)^def\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\([^)]*\)\s*->\s*([^:]+):").unwrap();

        for caps in re.captures_iter(content) {
            if let (Some(func_name), Some(return_type)) = (caps.get(1), caps.get(2)) {
                let name = func_name.as_str().to_string();
                let ret_type = return_type.as_str().trim().to_string();
                self.return_types.insert(name, ret_type);
            }
        }
    }

    /// Get the return type for a function, if known
    pub fn get_return_type(&self, function_name: &str) -> Option<&String> {
        self.return_types.get(function_name)
    }

    /// Check if a function is registered
    pub fn has_function(&self, function_name: &str) -> bool {
        self.return_types.contains_key(function_name)
    }

    /// Register an event function
    pub fn register_event(&mut self, function_name: String) {
        if !self.event_functions.contains(&function_name) {
            self.event_functions.push(function_name);
        }
    }

    /// Get all registered event functions
    pub fn get_event_functions(&self) -> &[String] {
        &self.event_functions
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_extract_signatures() {
        let mut registry = FunctionRegistry::new();

        let python_code = r#"
def simple_function(state: State) -> int:
    return 42

def complex_function(
    state: State,
    param: str
) -> list[float]:
    return [1.0, 2.0]

def step_function(state: State) -> StepOutputs:
    return StepOutputs()
"#;

        registry.extract_signatures(python_code);

        assert_eq!(
            registry.get_return_type("simple_function"),
            Some(&"int".to_string())
        );
        assert_eq!(
            registry.get_return_type("complex_function"),
            Some(&"list[float]".to_string())
        );
        assert_eq!(
            registry.get_return_type("step_function"),
            Some(&"StepOutputs".to_string())
        );
    }
}
