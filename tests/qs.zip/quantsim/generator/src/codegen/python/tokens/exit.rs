use genco::prelude::*;

use crate::codegen::python::helpers::add_name_comment;

pub fn exit_to_tokens(name: &str) -> python::Tokens {
    let mut t = python::Tokens::new();
    add_name_comment(&mut t, name);
    t.append(quote!(break));
    t
}
