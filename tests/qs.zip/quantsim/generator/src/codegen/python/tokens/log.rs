use genco::prelude::*;
use std::collections::HashMap;

use crate::codegen::python::helpers::{add_name_comment, append_dict, append_string_literal};

pub fn log_to_tokens(name: &str, message: &str, with: &HashMap<String, String>) -> python::Tokens {
    let mut t = python::Tokens::new();
    add_name_comment(&mut t, name);

    t.append("print(");
    append_string_literal(&mut t, message);

    if !with.is_empty() {
        t.append(", variables={");
        append_dict(&mut t, with);
        t.append("}");
    }

    t.append(")");
    t
}
