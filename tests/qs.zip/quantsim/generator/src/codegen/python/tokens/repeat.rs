use genco::prelude::*;

use super::ConversionContext;
use crate::codegen::python::helpers::{add_name_comment, append_indented_block};
use crate::models::action::Action;

pub fn repeat_to_tokens(
    name: &str,
    actions: &[Action],
    count: &Option<i64>,
    condition: &Option<String>,
    ctx: &ConversionContext,
) -> python::Tokens {
    let mut t = python::Tokens::new();
    add_name_comment(&mut t, name);

    if let Some(c) = count {
        // Count-based loop
        t.append(quote!(for _ in range($(*c)):));
    } else if let Some(cond) = condition {
        // Condition-based loop
        t.append(quote!(while $(cond):));
    } else {
        // Infinite loop
        t.append(quote!(while True:));
    }

    append_indented_block(&mut t, actions, ctx);
    t
}
