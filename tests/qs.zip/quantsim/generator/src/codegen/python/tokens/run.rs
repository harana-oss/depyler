use genco::prelude::*;
use std::collections::HashMap;

use super::ConversionContext;
use crate::codegen::python::helpers::{add_name_comment, append_kwargs};

pub fn run_to_tokens(
    name: &str,
    function: &str,
    with: &HashMap<String, String>,
    output: &Option<String>,
    ctx: &ConversionContext,
) -> python::Tokens {
    let mut t = python::Tokens::new();
    add_name_comment(&mut t, name);

    // Determine the variable name to store the result
    let result_var = if let Some(var_name) = output {
        var_name.clone()
    } else {
        String::new()
    };

    // Assign to result variable with type annotation if we can determine it
    if !result_var.is_empty() {
        t.append(&result_var);

        // Try to get the return type from the function registry
        if let Some(return_type) = ctx.function_registry.get_return_type(function) {
            t.append(": ");
            t.append(return_type.as_str());
        }

        t.append(" = ");
    }

    t.append(function);
    t.append("(");

    // Always add 'state' as the first parameter
    t.append("state");

    // Then add any 'with' parameters
    if !with.is_empty() {
        t.append(", ");
        append_kwargs(&mut t, with);
    }

    t.append(")");
    t.line();

    t
}
