use crate::models::action::Action;
use genco::prelude::*;
use std::sync::Arc;

mod exit;
mod r#for;
mod r#if;
mod infer;
mod log;
mod r#match;
mod record;
mod repeat;
mod r#return;
mod run;
mod set;
mod when;

pub use exit::exit_to_tokens;
pub use r#for::for_to_tokens;
pub use r#if::if_to_tokens;
pub use infer::{OnnxOutput, get_onnx_model_outputs, infer_to_tokens};
pub use log::log_to_tokens;
pub use r#match::match_to_tokens;
pub use record::record_to_tokens;
pub use repeat::repeat_to_tokens;
pub use r#return::return_to_tokens;
pub use run::run_to_tokens;
pub use set::set_to_tokens;
pub use when::when_to_tokens;

use super::FunctionRegistry;
use std::cell::RefCell;

#[derive(Debug, Clone)]
pub struct ConversionContext {
    pub step_name: Option<String>,
    pub use_step_outputs: bool,
    pub step_outputs_class_name: Option<String>,
    pub output_counter: RefCell<usize>,
    pub function_registry: Arc<FunctionRegistry>,
    pub is_event: bool,
    pub is_step: bool,
}

impl ConversionContext {
    pub fn new() -> Self {
        Self {
            step_name: None,
            use_step_outputs: false,
            step_outputs_class_name: None,
            output_counter: RefCell::new(0),
            function_registry: Arc::new(FunctionRegistry::new()),
            is_event: false,
            is_step: false,
        }
    }

    pub fn with_registry(registry: Arc<FunctionRegistry>) -> Self {
        Self {
            step_name: None,
            use_step_outputs: false,
            step_outputs_class_name: None,
            output_counter: RefCell::new(0),
            function_registry: registry,
            is_event: false,
            is_step: false,
        }
    }

    pub fn with_step_name(step_name: String) -> Self {
        Self {
            step_name: Some(step_name),
            use_step_outputs: false,
            step_outputs_class_name: None,
            output_counter: RefCell::new(0),
            function_registry: Arc::new(FunctionRegistry::new()),
            is_event: false,
            is_step: false,
        }
    }

    pub fn with_step_outputs(
        step_name: String,
        use_step_outputs: bool,
        step_outputs_class_name: String,
    ) -> Self {
        Self {
            step_name: Some(step_name),
            use_step_outputs,
            step_outputs_class_name: Some(step_outputs_class_name),
            output_counter: RefCell::new(0),
            function_registry: Arc::new(FunctionRegistry::new()),
            is_event: false,
            is_step: false,
        }
    }

    pub fn with_step_outputs_and_registry(
        step_name: String,
        use_step_outputs: bool,
        step_outputs_class_name: String,
        registry: Arc<FunctionRegistry>,
    ) -> Self {
        Self {
            step_name: Some(step_name),
            use_step_outputs,
            step_outputs_class_name: Some(step_outputs_class_name),
            output_counter: RefCell::new(0),
            function_registry: registry,
            is_event: false,
            is_step: false,
        }
    }

    pub fn with_step_outputs_and_registry_and_event(
        step_name: String,
        use_step_outputs: bool,
        step_outputs_class_name: String,
        registry: Arc<FunctionRegistry>,
        is_event: bool,
    ) -> Self {
        Self {
            step_name: Some(step_name),
            use_step_outputs,
            step_outputs_class_name: Some(step_outputs_class_name),
            output_counter: RefCell::new(0),
            function_registry: registry,
            is_event,
            is_step: false,
        }
    }

    pub fn with_step_outputs_and_registry_and_flags(
        step_name: String,
        use_step_outputs: bool,
        step_outputs_class_name: String,
        registry: Arc<FunctionRegistry>,
        is_event: bool,
        is_step: bool,
    ) -> Self {
        Self {
            step_name: Some(step_name),
            use_step_outputs,
            step_outputs_class_name: Some(step_outputs_class_name),
            output_counter: RefCell::new(0),
            function_registry: registry,
            is_event,
            is_step,
        }
    }

    pub fn next_output_num(&self) -> usize {
        let mut counter = self.output_counter.borrow_mut();
        let current = *counter;
        *counter += 1;
        current
    }
}

pub fn action_to_tokens(action: &Action, ctx: &ConversionContext) -> python::Tokens {
    match action {
        Action::Exit { name, .. } => exit_to_tokens(name.as_str()),
        Action::For {
            name,
            iterator,
            collection,
            steps,
            ..
        } => for_to_tokens(name.as_str(), iterator, collection, steps, ctx),
        Action::If {
            name,
            condition,
            then_actions,
            else_actions,
            ..
        } => if_to_tokens(name.as_str(), condition, then_actions, else_actions, ctx),
        Action::Infer {
            name,
            model,
            version,
            with,
            extractor,
            categories,
            inputs,
            outputs,
            output,
        } => infer_to_tokens(
            name.as_str(),
            model,
            version,
            with,
            extractor,
            categories,
            inputs,
            outputs,
            output,
            ctx,
        ),
        Action::Log {
            name,
            message,
            with,
            ..
        } => log_to_tokens(name.as_str(), message, with),
        Action::Match {
            name,
            key,
            cases,
            default,
            ..
        } => match_to_tokens(name.as_str(), key, cases, default, ctx),
        Action::Return { name, with, .. } => return_to_tokens(name.as_str(), with, ctx),
        Action::Record { name, entries, .. } => record_to_tokens(name.as_str(), entries),
        Action::Repeat {
            name,
            actions,
            count,
            condition,
            ..
        } => repeat_to_tokens(name.as_str(), actions, count, condition, ctx),
        Action::Run {
            name,
            function,
            with,
            output,
        } => run_to_tokens(name.as_str(), function, with, output, ctx),
        Action::Set { name, with, .. } => set_to_tokens(name.as_str(), with),
        Action::When {
            name,
            condition,
            actions,
        } => when_to_tokens(name.as_str(), condition, actions, ctx),
    }
}
