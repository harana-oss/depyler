use genco::prelude::*;

use super::ConversionContext;
use crate::codegen::python::helpers::{add_name_comment, append_indented_block};
use crate::models::action::Action;

pub fn for_to_tokens(
    name: &str,
    iterator: &str,
    collection: &str,
    steps: &[Action],
    ctx: &ConversionContext,
) -> python::Tokens {
    let mut t = python::Tokens::new();
    add_name_comment(&mut t, name);

    t.append(quote!(for $(iterator) in $(collection):));
    append_indented_block(&mut t, steps, ctx);

    t
}
