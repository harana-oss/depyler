use genco::prelude::*;
use std::collections::HashMap;

use super::ConversionContext;
use crate::codegen::python::helpers::{
    add_name_comment, append_string_literal, check_and_strip_marker,
};

/// Check if an expression contains a comparison operator at the top level
/// (not within function calls or brackets)
fn contains_comparison_operator(expr: &str) -> bool {
    let trimmed = expr.trim();

    // Check for comparison operators: ==, !=, <, >, <=, >=
    let comparison_operators = [" == ", " != ", " <= ", " >= ", " < ", " > "];

    comparison_operators.iter().any(|op| trimmed.contains(op))
}

pub fn return_to_tokens(
    name: &str,
    with: &HashMap<String, String>,
    ctx: &ConversionContext,
) -> python::Tokens {
    let mut t = python::Tokens::new();
    add_name_comment(&mut t, name);

    if ctx.use_step_outputs {
        // Use StepOutputs class
        if !with.is_empty() {
            let default_class_name = "StepOutputs".to_string();
            let class_name = ctx
                .step_outputs_class_name
                .as_ref()
                .unwrap_or(&default_class_name);
            let mut sorted_keys: Vec<_> = with.keys().collect();
            sorted_keys.sort();

            t.append(format!("return {}(", class_name));
            t.push();
            t.indent();

            for (i, key) in sorted_keys.iter().enumerate() {
                let value = with.get(key.as_str()).unwrap();
                t.append(format!("{}=", key));
                // Use smart quoting for values - check for ___QUOTED___ marker
                let (should_quote, clean_value) = check_and_strip_marker(value);
                if should_quote {
                    append_string_literal(&mut t, &clean_value);
                } else {
                    // Wrap comparison expressions in parentheses
                    if contains_comparison_operator(&clean_value) {
                        t.append("(");
                        t.append(&clean_value);
                        t.append(")");
                    } else {
                        t.append(&clean_value);
                    }
                }
                if i < sorted_keys.len() - 1 {
                    t.append(",");
                }
                t.push();
            }

            t.unindent();
            t.append(")");
            t.push();
        }
    } else {
        // Use old dict-based approach
        // Add return variables to the outputs dictionary
        if !with.is_empty() {
            let vars: Vec<_> = with.iter().collect();
            for (k, v) in vars.iter() {
                t.append("outputs[");
                append_string_literal(&mut t, k);
                t.append("] = ");
                // Use smart quoting for values - check for ___QUOTED___ marker
                let (should_quote, clean_value) = check_and_strip_marker(v);
                if should_quote {
                    append_string_literal(&mut t, &clean_value);
                } else {
                    // Wrap comparison expressions in parentheses
                    if contains_comparison_operator(&clean_value) {
                        t.append("(");
                        t.append(&clean_value);
                        t.append(")");
                    } else {
                        t.append(&clean_value);
                    }
                }
                t.push();
            }
        }
    }

    t
}
