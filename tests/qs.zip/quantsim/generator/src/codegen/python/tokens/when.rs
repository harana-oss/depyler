use genco::prelude::*;

use super::{ConversionContext, action_to_tokens};
use crate::codegen::python::helpers::add_name_comment;
use crate::models::action::Action;

pub fn when_to_tokens(
    name: &str,
    condition: &str,
    actions: &Action,
    ctx: &ConversionContext,
) -> python::Tokens {
    let mut t = python::Tokens::new();
    add_name_comment(&mut t, name);

    t.append(quote!(if $(condition):));
    t.line();
    t.indent();
    t.append(action_to_tokens(actions, ctx));
    t.unindent();

    t
}
