use genco::prelude::*;

use crate::codegen::python::helpers::{
    add_name_comment, append_string_literal, should_quote_value,
};

fn to_snake_case(s: &str) -> String {
    let mut result = String::new();
    let mut chars = s.chars().peekable();

    while let Some(c) = chars.next() {
        if c.is_uppercase() {
            if !result.is_empty() {
                result.push('_');
            }
            result.push(c.to_lowercase().next().unwrap());
        } else {
            result.push(c);
        }
    }

    result
}

pub fn record_to_tokens(
    name: &str,
    entries: &[crate::models::action::RecordEntry],
) -> python::Tokens {
    let mut t = python::Tokens::new();
    add_name_comment(&mut t, name);

    for entry in entries {
        // Convert PascalCase to snake_case for Python function names
        let snake_case_type = to_snake_case(&entry.entry_type);

        if let Some(for_loop) = &entry.for_loop {
            // Handle inline for loops in record entries
            // Parse "iterator in collection" format
            let parts: Vec<&str> = for_loop.split(" in ").collect::<Vec<&str>>();
            if parts.len() == 2 {
                let iterator = parts[0].trim();
                let collection = parts[1].trim();
                t.append(quote!(for $(iterator) in $(collection):));
                t.indent();
                t.push();

                // Build record call with type-specific function name
                t.append(&format!("record_{}(", snake_case_type));
                append_string_literal(&mut t, &entry.key);
                t.append(", ");
                // Only quote value if it should be quoted (not a variable or expression)
                if should_quote_value(&entry.value) {
                    append_string_literal(&mut t, &entry.value);
                } else {
                    t.append(&entry.value);
                }
                t.append(")");

                t.unindent();
            }
        } else {
            // Build record call with type-specific function name
            t.append(&format!("record_{}(", snake_case_type));
            append_string_literal(&mut t, &entry.key);
            t.append(", ");
            // Only quote value if it should be quoted (not a variable or expression)
            if should_quote_value(&entry.value) {
                append_string_literal(&mut t, &entry.value);
            } else {
                t.append(&entry.value);
            }
            t.append(")");
        }
        if entry != entries.last().unwrap() {
            t.push();
        }
    }

    t
}
