use genco::prelude::*;
use std::collections::HashMap;

use super::ConversionContext;
use crate::codegen::python::helpers::{
    add_name_comment, append_indented_block, append_string_literal,
};
use crate::models::action::Action;

pub fn match_to_tokens(
    name: &str,
    key: &str,
    cases: &HashMap<String, Vec<Action>>,
    default: &[Action],
    ctx: &ConversionContext,
) -> python::Tokens {
    let mut t = python::Tokens::new();
    add_name_comment(&mut t, name);

    // Convert match to if/elif/else blocks
    let case_vec: Vec<_> = cases.iter().collect();

    // First case uses 'if'
    if let Some((case_key, actions)) = case_vec.first() {
        t.append("if ");
        t.append(key);
        t.append(" == ");
        // Check if the case key looks like an enum value (contains a dot)
        // If so, don't quote it; otherwise use string literal
        if case_key.contains('.') {
            t.append(case_key.as_str());
        } else {
            append_string_literal(&mut t, case_key);
        }
        t.append(":");
        append_indented_block(&mut t, actions, ctx);
    }

    // Remaining cases use 'elif'
    for (case_key, actions) in case_vec.iter().skip(1) {
        t.append("elif ");
        t.append(key);
        t.append(" == ");
        // Check if the case key looks like an enum value (contains a dot)
        // If so, don't quote it; otherwise use string literal
        if case_key.contains('.') {
            t.append(case_key.as_str());
        } else {
            append_string_literal(&mut t, case_key);
        }
        t.append(":");
        append_indented_block(&mut t, actions, ctx);
    }

    // Default case uses 'else' - only add if there are default actions
    if !default.is_empty() {
        t.append("else:");
        append_indented_block(&mut t, default, ctx);
    }

    t
}
