use genco::prelude::*;

use super::ConversionContext;
use crate::codegen::python::helpers::{add_name_comment, append_indented_block};
use crate::models::action::Action;

pub fn if_to_tokens(
    name: &str,
    condition: &str,
    then_actions: &[Action],
    else_actions: &[Action],
    ctx: &ConversionContext,
) -> python::Tokens {
    let mut t = python::Tokens::new();
    add_name_comment(&mut t, name);

    t.append(quote!(if $(condition):));
    append_indented_block(&mut t, then_actions, ctx);

    if !else_actions.is_empty() {
        t.append(quote!(else:));
        append_indented_block(&mut t, else_actions, ctx);
    }

    t
}
