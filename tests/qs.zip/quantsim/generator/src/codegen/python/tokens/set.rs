use genco::prelude::*;
use std::collections::HashMap;

use crate::codegen::python::helpers::{
    add_name_comment, append_string_literal, check_and_strip_marker,
};

/// Check if an expression contains a comparison operator at the top level
/// (not within function calls or brackets)
fn contains_comparison_operator(expr: &str) -> bool {
    let trimmed = expr.trim();

    // Check for comparison operators: ==, !=, <, >, <=, >=
    let comparison_operators = [" == ", " != ", " <= ", " >= ", " < ", " > "];

    comparison_operators.iter().any(|op| trimmed.contains(op))
}

pub fn set_to_tokens(name: &str, with: &HashMap<String, String>) -> python::Tokens {
    let mut t = python::Tokens::new();
    add_name_comment(&mut t, name);

    let vars: Vec<_> = with.iter().collect();

    // Group assignments by whether they're state fields or not
    let mut state_assignments: Vec<(&str, &str, bool, String)> = Vec::new();
    let mut regular_assignments: Vec<(&str, &str, bool, String)> = Vec::new();

    for (k, v) in vars.iter() {
        let (should_quote, clean_value) = check_and_strip_marker(v);
        if k.starts_with("state.") {
            state_assignments.push((*k, *v, should_quote, clean_value));
        } else {
            regular_assignments.push((*k, *v, should_quote, clean_value));
        }
    }

    // Handle regular assignments first
    for (idx, (k, _v, should_quote, clean_value)) in regular_assignments.iter().enumerate() {
        if idx > 0 {
            t.push();
        }
        t.append(*k);
        t.append(" = ");

        if *should_quote {
            append_string_literal(&mut t, &clean_value);
        } else {
            // Wrap comparison expressions in parentheses
            if contains_comparison_operator(&clean_value) {
                t.append("(");
                t.append(clean_value);
                t.append(")");
            } else {
                t.append(clean_value);
            }
        }
    }

    // Handle state assignments - use direct assignment
    for (idx, (k, _v, should_quote, clean_value)) in state_assignments.iter().enumerate() {
        if idx > 0 || !regular_assignments.is_empty() {
            t.push();
        }

        // Direct state assignment: state.field = value
        t.append(*k);
        t.append(" = ");

        if *should_quote {
            append_string_literal(&mut t, &clean_value);
        } else {
            // Wrap comparison expressions in parentheses
            if contains_comparison_operator(&clean_value) {
                t.append("(");
                t.append(clean_value);
                t.append(")");
            } else {
                t.append(clean_value);
            }
        }
    }

    t
}
