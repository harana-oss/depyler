use genco::prelude::*;
use std::collections::HashMap;
use std::path::Path;

use super::ConversionContext;
use crate::codegen::python::helpers::{
    add_name_comment, append_string_literal, check_and_strip_marker,
};

#[derive(Debug, Clone)]
pub struct OnnxOutput {
    pub name: String,
    pub data_type: String,
    pub shape: Option<Vec<String>>,
}

pub fn get_onnx_model_outputs<P: AsRef<Path>>(model_path: P) -> Result<Vec<OnnxOutput>, String> {
    use tract_onnx::prelude::*;

    let mut model = tract_onnx::onnx()
        .model_for_path(model_path.as_ref())
        .map_err(|e| format!("Failed to load ONNX model: {}", e))?;

    // Analyze the model to infer types
    model
        .analyse(false)
        .map_err(|e| format!("Failed to analyze ONNX model: {}", e))?;

    let mut outputs = Vec::new();

    let output_outlets = model
        .output_outlets()
        .map_err(|e| format!("Failed to get output outlets: {}", e))?;

    for (idx, outlet) in output_outlets.iter().enumerate() {
        // Get the actual output name from the model's output labels
        let output_name = model
            .outlet_label(*outlet)
            .map(|s| s.to_string())
            .unwrap_or_else(|| format!("output_{}", idx));

        let output_fact = model
            .outlet_fact(*outlet)
            .map_err(|e| format!("Failed to get output fact for '{}': {}", output_name, e))?;

        // Extract base type from the datum_type factoid
        let base_type = match &output_fact.datum_type {
            tract_onnx::tract_hir::infer::GenericFactoid::Only(dt) => match dt {
                DatumType::F32 | DatumType::F64 => "float",
                DatumType::I32 | DatumType::I64 | DatumType::I8 | DatumType::I16 => "int",
                DatumType::U8 | DatumType::U16 | DatumType::U32 | DatumType::U64 => "int",
                DatumType::Bool => "bool",
                _ => "Any",
            },
            _ => "Any",
        };

        // Determine if this is a list based on shape rank and dimensions
        let is_list = match output_fact.shape.rank() {
            tract_onnx::tract_hir::infer::GenericFactoid::Only(rank) => {
                if rank > 1 {
                    true
                } else if rank == 1 {
                    // For rank 1, check if the dimension size is greater than 1
                    match output_fact.shape.dim(0) {
                        Some(tract_onnx::tract_hir::infer::GenericFactoid::Only(ref dim)) => {
                            dim.to_i64().map(|d| d > 1).unwrap_or(true)
                        }
                        _ => true,
                    }
                } else {
                    false
                }
            }
            _ => false,
        };

        let shape_str = format!("{:?}", output_fact.shape);
        let data_type = if is_list {
            format!("list[{}]", base_type)
        } else {
            base_type.to_string()
        };

        outputs.push(OnnxOutput {
            name: output_name,
            data_type: data_type.to_string(),
            shape: Some(vec![shape_str]),
        });
    }

    Ok(outputs)
}

fn to_pascal_case(s: &str) -> String {
    s.split('_')
        .map(|word| {
            let mut chars = word.chars();
            match chars.next() {
                None => String::new(),
                Some(first) => first.to_uppercase().collect::<String>() + chars.as_str(),
            }
        })
        .collect()
}

pub fn infer_to_tokens(
    name: &str,
    model: &str,
    _version: &Option<String>,
    with: &HashMap<String, String>,
    _extractor: &Option<String>,
    _categories: &Option<i64>,
    inputs: &Option<Vec<String>>,
    _outputs: &Option<Vec<String>>,
    output: &Option<String>,
    ctx: &ConversionContext,
) -> python::Tokens {
    let mut t = python::Tokens::new();
    add_name_comment(&mut t, name);

    let (result_var, output_type) = if let Some(var_name) = output {
        let output_num = ctx.next_output_num();
        let model_string = model.to_string();
        let type_base = ctx.step_name.as_ref().unwrap_or(&model_string);
        let type_name = format!("{}InferOutputs{}", to_pascal_case(type_base), output_num);
        (var_name.clone(), Some(type_name))
    } else {
        ("result".to_string(), None)
    };

    t.append(&result_var);
    if let Some(type_name) = &output_type {
        t.append(": ");
        t.append(type_name);
    }
    t.append(" = infer");
    if let Some(type_name) = &output_type {
        t.append("[");
        t.append(type_name);
        t.append("]");
    }
    t.append("(name=");
    append_string_literal(&mut t, model);
    t.append(", input=[");

    if let Some(input_fields) = inputs {
        for (idx, field_name) in input_fields.iter().enumerate() {
            if idx > 0 {
                t.append(", ");
            }
            // Get the value from with
            if let Some(value) = with.get(field_name) {
                let (should_quote, clean_value) = check_and_strip_marker(value);
                if should_quote {
                    // This was a quoted string literal in YAML - output as string
                    append_string_literal(&mut t, &clean_value);
                } else {
                    // This was an unquoted value - treat as expression/variable reference
                    t.append(&clean_value);
                }
            } else {
                // Field not found in with, use 0.0 as default
                t.append("0.0");
            }
        }
    }

    t.append("])");
    t.line();

    t
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[ignore] // This test requires an actual ONNX model file to exist
    fn test_get_onnx_model_outputs() {
        // Example usage - replace with an actual model path
        let model_path = "../../quantsim-nrl/game/models/conversion.onnx";

        match get_onnx_model_outputs(model_path) {
            Ok(outputs) => {
                println!("Model outputs:");
                for (i, output) in outputs.iter().enumerate() {
                    println!(
                        "  Output {}: name='{}', type='{}'",
                        i, output.name, output.data_type
                    );
                }
                assert!(!outputs.is_empty(), "Model should have at least one output");
            }
            Err(e) => {
                println!("Failed to read model: {}", e);
                // Don't fail the test if the model doesn't exist
            }
        }
    }
}
