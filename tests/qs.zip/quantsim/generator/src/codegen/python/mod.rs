mod function_registry;
mod generators;
mod helpers;
pub mod tokens;

use crate::models::action::Action;
use tokens::action_to_tokens;

pub use function_registry::FunctionRegistry;
pub use generators::{
    constants_to_python, generate_constants_file, generate_variables_file, state_to_python,
    test_case_to_python,
};
pub use tokens::ConversionContext;

pub fn action_to_python(action: &Action) -> Result<String, genco::fmt::Error> {
    let t = action_to_tokens(action, &ConversionContext::new());
    t.to_file_string()
}
