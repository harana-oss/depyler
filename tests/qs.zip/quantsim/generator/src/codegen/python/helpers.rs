use crate::models::action::Action;
use genco::prelude::*;
use std::collections::HashMap;

use super::tokens::{ConversionContext, action_to_tokens};

const QUOTED_STRING_MARKER: &str = "___QUOTED___";

pub(super) fn add_name_comment(t: &mut python::Tokens, name: &str) {
    t.append(quote!(# $(name)));
    t.push();
}

pub(super) fn append_actions(t: &mut python::Tokens, actions: &[Action], ctx: &ConversionContext) {
    for (idx, action) in actions.iter().enumerate() {
        if idx > 0 {
            t.line();
        }

        let action_name = action.name();
        if !action_name.is_empty() {
            if let Some(step_name) = &ctx.step_name {
                let pascal_case_name = step_name
                    .split('_')
                    .map(|s| {
                        let mut chars = s.chars();
                        match chars.next() {
                            None => String::new(),
                            Some(first) => {
                                first.to_uppercase().collect::<String>() + chars.as_str()
                            }
                        }
                    })
                    .collect::<String>();
                t.append(format!("print(\"[{}] {}\")", pascal_case_name, action_name));
            } else {
                t.append(format!("print(\"[STEP] {}\")", action_name));
            }
            t.push();
        }

        t.append(action_to_tokens(action, ctx));

        // Execute all registered event functions after every action (but not within events or steps themselves)
        if !ctx.is_event && !ctx.is_step {
            t.line();
            t.append(quote!(execute_events(state)));
            t.push();
        }
    }
}

pub(super) fn append_indented_block(
    t: &mut python::Tokens,
    actions: &[Action],
    ctx: &ConversionContext,
) {
    t.line();
    t.indent();
    if actions.is_empty() {
        t.append(quote!(pass));
    } else {
        append_actions(t, actions, ctx);
    }
    t.unindent();
}

pub(super) fn append_dict(t: &mut python::Tokens, variables: &HashMap<String, String>) {
    let vars: Vec<_> = variables.iter().collect();
    for (idx, (k, v)) in vars.iter().enumerate() {
        if idx > 0 {
            t.append(", ");
        }
        // Append key with f-string support
        append_string_literal(t, k);
        t.append(": ");
        // Use smart quoting for dictionary values
        let (should_quote, clean_value) = check_and_strip_marker(v);
        if should_quote {
            // Append value with f-string support
            append_string_literal(t, &clean_value);
        } else {
            t.append(clean_value);
        }
    }
}

pub(super) fn append_kwargs(t: &mut python::Tokens, parameters: &HashMap<String, String>) {
    let params: Vec<_> = parameters.iter().collect();
    for (idx, (k, v)) in params.iter().enumerate() {
        if idx > 0 {
            t.append(", ");
        }
        t.append(k.as_str());
        t.append("=");
        let (should_quote, clean_value) = check_and_strip_marker(v);
        if should_quote {
            // Append value with f-string support
            append_string_literal(t, &clean_value);
        } else {
            t.append(clean_value);
        }
    }
}

pub(super) fn check_and_strip_marker(value: &str) -> (bool, String) {
    if value.starts_with(QUOTED_STRING_MARKER) {
        // It was originally quoted - should be a string literal
        (true, value[QUOTED_STRING_MARKER.len()..].to_string())
    } else {
        // No marker - use heuristic to determine if it should be quoted
        (should_quote_value(value), value.to_string())
    }
}

pub(super) fn needs_fstring(value: &str) -> bool {
    value.contains('{') && value.contains('}')
}

pub(super) fn format_string_literal(value: &str) -> String {
    if needs_fstring(value) {
        format!("f\"{}\"", value)
    } else {
        format!("\"{}\"", value)
    }
}

pub(super) fn append_string_literal(t: &mut python::Tokens, value: &str) {
    if needs_fstring(value) {
        t.append(format_string_literal(value));
    } else {
        t.append(quoted(value));
    }
}

pub(super) fn should_quote_value(value: &str) -> bool {
    let trimmed = value.trim();

    // Don't quote if it's a Python keyword/literal
    if trimmed == "True" || trimmed == "False" || trimmed == "None" {
        return false;
    }

    // Don't quote if it looks like a number
    if trimmed.parse::<f64>().is_ok() {
        return false;
    }

    // Don't quote if it starts with a list or dict literal
    if trimmed.starts_with('[') || trimmed.starts_with('{') {
        return false;
    }

    // Don't quote if it contains a dot (attribute/property access like player.name or model.output)
    if trimmed.contains('.') {
        return false;
    }

    // Don't quote if it contains operators or parentheses (expression or function call)
    let expression_chars = [
        '<', '>', '=', '+', '-', '*', '/', '(', ')', '[', ']', '!', '&', '|',
    ];
    if expression_chars.iter().any(|&c| trimmed.contains(c)) {
        return false;
    }

    // Check for Python keywords that indicate an expression
    let python_keywords = [
        " or ", " and ", " not ", " in ", " is ", " if ", " else ", " then ",
    ];
    if python_keywords.iter().any(|&kw| trimmed.contains(kw)) {
        return false;
    }

    if is_valid_python_identifier(trimmed) {
        // SCREAMING_SNAKE_CASE identifiers are constants and should not be quoted
        return false;
    }
    true
}

fn is_valid_python_identifier(s: &str) -> bool {
    if s.is_empty() {
        return false;
    }

    let mut chars = s.chars();
    if let Some(first) = chars.next() {
        if !first.is_alphabetic() && first != '_' {
            return false;
        }
    } else {
        return false;
    }
    chars.all(|c| c.is_alphanumeric() || c == '_')
}
