use genco::prelude::*;
use std::collections::BTreeMap;
use yaml_rust2::{Yaml, YamlLoader};

use super::super::helpers::{format_string_literal, needs_fstring};

pub fn constants_to_python(yaml_content: &str) -> Result<String, Box<dyn std::error::Error>> {
    let docs = YamlLoader::load_from_str(yaml_content)?;
    let yaml = &docs[0];

    let mut constants = BTreeMap::new();
    if let Yaml::Hash(hash) = yaml {
        for (key, value) in hash.iter() {
            if let Yaml::String(k) = key {
                constants.insert(k.clone(), value.clone());
            }
        }
    }

    let t = constants_to_tokens(&constants);
    Ok(t.to_file_string()?)
}

fn constants_to_tokens(constants: &BTreeMap<String, Yaml>) -> python::Tokens {
    let mut t = python::Tokens::new();

    for (key, value) in constants.iter() {
        let formatted_value = format_value(value);
        t.append(format!("{} = {}\n", key, formatted_value));
    }

    t
}

fn format_value(value: &Yaml) -> String {
    match value {
        Yaml::Integer(i) => i.to_string(),
        Yaml::Real(f) => f.to_string(),
        Yaml::String(s) => {
            // Check if the string represents a tuple: "(value1, value2, ...)"
            if s.starts_with('(') && s.ends_with(')') {
                // Return as-is - it's already a tuple representation
                s.clone()
            } else if needs_fstring(s) {
                format_string_literal(s)
            } else {
                format!("\"{}\"", s)
            }
        }
        Yaml::Boolean(b) => if *b { "True" } else { "False" }.to_string(),
        Yaml::Null => "None".to_string(),
        Yaml::Array(seq) => {
            let items: Vec<String> = seq.iter().map(format_value).collect();
            format!("[{}]", items.join(", "))
        }
        Yaml::Hash(map) => {
            let items: Vec<String> = map
                .iter()
                .map(|(k, v)| {
                    let key_str = match k {
                        Yaml::String(s) => {
                            // Use f-string for keys if needed
                            if needs_fstring(s) {
                                format_string_literal(s)
                            } else {
                                format!("\"{}\"", s)
                            }
                        }
                        _ => format_value(k),
                    };
                    format!("{}: {}", key_str, format_value(v))
                })
                .collect();
            format!("{{{}}}", items.join(", "))
        }
        Yaml::Alias(_) => "None".to_string(), // Handle aliases
        Yaml::BadValue => "None".to_string(), // Handle bad values
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_simple_constants() {
        let yaml = r#"
FIRST_VALUE: 10
SECOND_VALUE: 20.5
THIRD_VALUE: "hello"
BOOL_VALUE: true
"#;
        let result = constants_to_python(yaml).unwrap();
        assert!(result.contains("FIRST_VALUE = 10"));
        assert!(result.contains("SECOND_VALUE = 20.5"));
        assert!(result.contains("THIRD_VALUE = \"hello\""));
        assert!(result.contains("BOOL_VALUE = True"));
    }

    #[test]
    fn test_grouped_constants() {
        let yaml = r#"
TIME_FIRST: 100
TIME_SECOND: 200
SCORE_TRY: 4
SCORE_CONVERSION: 2
"#;
        let result = constants_to_python(yaml).unwrap();
        eprintln!("Result:\n{}", result);
        assert!(result.contains("TIME_FIRST = 100"));
        assert!(result.contains("TIME_SECOND = 200"));
        assert!(result.contains("SCORE_TRY = 4"));
        assert!(result.contains("SCORE_CONVERSION = 2"));
    }
}
