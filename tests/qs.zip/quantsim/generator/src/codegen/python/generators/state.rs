use genco::prelude::*;
use std::collections::HashMap;
use yaml_rust2::{Yaml, YamlLoader};

pub fn state_to_python(yaml_content: &str) -> Result<String, Box<dyn std::error::Error>> {
    let docs = YamlLoader::load_from_str(yaml_content)?;
    let yaml = &docs[0];

    let mut state_definitions = Vec::new();
    if let Yaml::Hash(hash) = yaml {
        for (key, value) in hash.iter() {
            if let Yaml::String(k) = key {
                state_definitions.push((k.clone(), value.clone()));
            }
        }
    }

    let t = state_to_tokens(&state_definitions);
    Ok(t.to_file_string()?)
}

fn state_to_tokens(state_definitions: &Vec<(String, Yaml)>) -> python::Tokens {
    let mut t = python::Tokens::new();

    // First pass: collect all enum types (both top-level and nested)
    let mut enums: HashMap<String, Vec<String>> = HashMap::new();
    let mut top_level_enums: Vec<String> = Vec::new();

    for (class_name, fields) in state_definitions.iter() {
        // Check if this is a top-level enum definition (value is a string with |)
        if let Yaml::String(type_str) = fields {
            if type_str.contains('|') {
                let variants: Vec<String> =
                    type_str.split('|').map(|s| s.trim().to_string()).collect();
                enums.insert(class_name.clone(), variants);
                top_level_enums.push(class_name.clone());
            }
        } else {
            // Otherwise, collect enum types from nested fields
            collect_enum_types(fields, &mut enums);
        }
    }

    // Add header and imports
    t.append("from dataclasses import dataclass, field");
    t.line();
    t.append("from enum import IntEnum");
    t.line();
    t.append("from typing import Any, Set");
    t.line();
    t.line();
    t.line();

    // Generate enum classes
    for (enum_name, variants) in enums.iter() {
        append_enum_definition(&mut t, enum_name, variants);
        t.line();
        t.line();
    }

    // Process each class definition in the order they appear in YAML
    // Skip top-level enums since they've already been generated
    for (class_name, fields) in state_definitions.iter() {
        if !top_level_enums.contains(class_name) {
            append_class_definition(&mut t, class_name, fields, &enums);
            t.line();
        }
    }

    t
}

fn collect_enum_types(fields: &Yaml, enums: &mut HashMap<String, Vec<String>>) {
    if let Yaml::Hash(field_map) = fields {
        for (field_name, field_type) in field_map.iter() {
            if let (Yaml::String(name), Yaml::String(type_str)) = (field_name, field_type) {
                // Check if this is an enum type (contains |)
                if type_str.contains('|') {
                    let variants: Vec<String> =
                        type_str.split('|').map(|s| s.trim().to_string()).collect();

                    // Generate enum class name from field name
                    let enum_name = field_name_to_enum_name(name);
                    enums.insert(enum_name, variants);
                }
            }
        }
    }
}

fn field_name_to_enum_name(field_name: &str) -> String {
    // Convert snake_case to PascalCase
    field_name
        .split('_')
        .map(|word| {
            let mut chars = word.chars();
            match chars.next() {
                None => String::new(),
                Some(first) => first.to_uppercase().collect::<String>() + chars.as_str(),
            }
        })
        .collect()
}

fn append_enum_definition(t: &mut python::Tokens, enum_name: &str, variants: &[String]) {
    t.push();
    t.append(format!("class {}(IntEnum):", enum_name));
    t.indent();

    for (index, variant) in variants.iter().enumerate() {
        t.push();
        // Use the variant as-is for the member name (keep original casing like Pass, Run, etc.)
        t.append(format!("{} = {}", variant, index));
    }

    t.unindent();
}

fn append_class_definition(
    t: &mut python::Tokens,
    class_name: &str,
    fields: &Yaml,
    enums: &HashMap<String, Vec<String>>,
) {
    // Add class decorator and definition
    t.push();
    t.append("@dataclass");
    t.push();
    t.append(format!("class {}:", class_name));
    t.indent();

    if let Yaml::Hash(field_map) = fields {
        if field_map.is_empty() {
            t.push();
            t.append("pass");
        } else {
            // Process each field
            for (field_name, field_type) in field_map.iter() {
                if let Yaml::String(name) = field_name {
                    let type_annotation = parse_type_annotation(field_type, name, enums);
                    t.push();

                    // Special handling for executed_events field - use int with default 0
                    if name == "executed_events" && type_annotation.starts_with("Set[") {
                        t.append(format!("{}: int = 0", name));
                    // If the field is a Set type, add a default factory
                    } else if type_annotation.starts_with("Set[") {
                        t.append(format!(
                            "{}: {} = field(default_factory=set)",
                            name, type_annotation
                        ));
                    } else {
                        t.append(format!("{}: {}", name, type_annotation));
                    }
                }
            }
        }
    } else {
        t.push();
        t.append("pass");
    }

    t.unindent();
}

fn parse_type_annotation(
    field_type: &Yaml,
    field_name: &str,
    _enums: &HashMap<String, Vec<String>>,
) -> String {
    match field_type {
        Yaml::String(s) => {
            let type_str = s.as_str();

            // Handle Set[...] syntax
            if type_str.starts_with("Set[") && type_str.ends_with(']') {
                let inner_type = &type_str[4..type_str.len() - 1];
                return format!("Set[{}]", map_yaml_type_to_python(inner_type));
            }

            // Handle list[...] syntax
            if type_str.starts_with("list[") && type_str.ends_with(']') {
                let inner_type = &type_str[5..type_str.len() - 1];
                return format!("list[{}]", map_yaml_type_to_python(inner_type));
            }

            // List
            if type_str.starts_with('[') && type_str.ends_with(']') {
                let inner_type = &type_str[1..type_str.len() - 1];
                return format!("list[{}]", map_yaml_type_to_python(inner_type));
            }

            // Enum - return the generated enum class name
            if type_str.contains('|') {
                let enum_name = field_name_to_enum_name(field_name);
                return enum_name;
            }

            // Dict
            if type_str.contains(':') {
                // This is an inline nested object definition
                return "dict[str, Any]".to_string();
            }

            // Other
            map_yaml_type_to_python(type_str)
        }
        Yaml::Array(seq) => {
            // List
            if !seq.is_empty() {
                if let Some(Yaml::String(inner_type)) = seq.first() {
                    return format!("list[{}]", map_yaml_type_to_python(inner_type));
                }
            }
            "list[Any]".to_string()
        }
        Yaml::Hash(_) => {
            // Dict
            "dict[str, Any]".to_string()
        }
        _ => "Any".to_string(),
    }
}

fn map_yaml_type_to_python(yaml_type: &str) -> String {
    // Trim and remove trailing commas (common YAML typo)
    let cleaned = yaml_type.trim().trim_end_matches(',');

    // Handle nested List[...] syntax recursively
    if cleaned.starts_with("List[") && cleaned.ends_with(']') {
        let inner_type = &cleaned[5..cleaned.len() - 1];
        return format!("list[{}]", map_yaml_type_to_python(inner_type));
    }

    // Handle lowercase list[...] syntax recursively
    if cleaned.starts_with("list[") && cleaned.ends_with(']') {
        let inner_type = &cleaned[5..cleaned.len() - 1];
        return format!("list[{}]", map_yaml_type_to_python(inner_type));
    }

    match cleaned {
        "Int" | "int" => "int".to_string(),
        "Float" | "float" => "float".to_string(),
        "String" | "str" => "str".to_string(),
        "Bool" | "Boolean" | "bool" => "bool".to_string(),
        "Duration" => "int".to_string(), // Duration as int (seconds)
        other => {
            // If it starts with uppercase, it's likely a custom class
            if other
                .chars()
                .next()
                .map(|c| c.is_uppercase())
                .unwrap_or(false)
            {
                other.to_string()
            } else {
                // Fallback to Any
                "Any".to_string()
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_simple_class() {
        let yaml = r#"
Person:
  name: String
  age: Int
  active: Boolean
"#;
        let result = state_to_python(yaml).unwrap();
        eprintln!("Result:\n{}", result);
        assert!(result.contains("@dataclass"));
        assert!(result.contains("class Person:"));
        assert!(result.contains("name: str"));
        assert!(result.contains("age: int"));
        assert!(result.contains("active: bool"));
    }

    #[test]
    fn test_list_type() {
        let yaml = r#"
Team:
  players: [Player]
  scores: [Int]
"#;
        let result = state_to_python(yaml).unwrap();
        eprintln!("Result:\n{}", result);
        assert!(result.contains("players: list[Player]"));
        assert!(result.contains("scores: list[int]"));
    }

    #[test]
    fn test_nested_list_type() {
        let yaml = r#"
State:
  away_period_try_scorers: List[List[Int]]
  home_period_try_scorers: List[List[Int]]
  scores_matrix: List[List[Float]]
"#;
        let result = state_to_python(yaml).unwrap();
        eprintln!("Result:\n{}", result);
        assert!(result.contains("away_period_try_scorers: list[list[int]]"));
        assert!(result.contains("home_period_try_scorers: list[list[int]]"));
        assert!(result.contains("scores_matrix: list[list[float]]"));
    }

    #[test]
    fn test_union_type() {
        let yaml = r#"
State:
  status: ACTIVE | INACTIVE | PENDING
  team: HOME | AWAY
"#;
        let result = state_to_python(yaml).unwrap();
        eprintln!("Result:\n{}", result);

        // Should generate enum classes
        assert!(result.contains("class Status(IntEnum):"));
        assert!(result.contains("class Team(IntEnum):"));

        // Should have enum values with integer assignments
        assert!(result.contains("ACTIVE = 0"));
        assert!(result.contains("INACTIVE = 1"));
        assert!(result.contains("PENDING = 2"));
        assert!(result.contains("HOME = 0"));
        assert!(result.contains("AWAY = 1"));

        // Should use enum types in the class
        assert!(result.contains("status: Status"));
        assert!(result.contains("team: Team"));
    }

    #[test]
    fn test_multiple_classes() {
        let yaml = r#"
Player:
  name: String
  number: Int

Team:
  name: String
  players: [Player]
"#;
        let result = state_to_python(yaml).unwrap();
        eprintln!("Result:\n{}", result);
        assert!(result.contains("class Player:"));
        assert!(result.contains("class Team:"));
        assert!(result.contains("name: str"));
        assert!(result.contains("number: int"));
        assert!(result.contains("players: list[Player]"));
    }

    #[test]
    fn test_lowercase_bool_type() {
        let yaml = r#"
Settings:
  enabled: bool
  active: Boolean
  count: int
  ratio: float
"#;
        let result = state_to_python(yaml).unwrap();
        eprintln!("Result:\n{}", result);
        assert!(result.contains("enabled: bool"));
        assert!(result.contains("active: bool"));
        assert!(result.contains("count: int"));
        assert!(result.contains("ratio: float"));
    }

    #[test]
    fn test_player_position() {
        let yaml = r#"
PlayerPosition:
  type: PROP_ONE | PROP_TWO | HOOKER | LOCK | FULL_BACK | CENTRE_ONE | CENTRE_TWO | HALF_BACK | SECOND_ROW_ONE | SECOND_ROW_TWO | INTERCHANGE | FIVE_EIGHTH | WINGER_ONE | WINGER_TWO | NOT_SET
"#;
        let result = state_to_python(yaml).unwrap();
        eprintln!("Result:\n{}", result);

        // Should generate enum class
        assert!(result.contains("class Type(IntEnum):"));
        assert!(result.contains("type: Type"));

        // Should have enum members with integer values
        assert!(result.contains("PROP_ONE = 0"));
        assert!(result.contains("NOT_SET = 14"));
    }
}
