use crate::models::action::Action;
use crate::yaml::parser::TestCase;
use genco::prelude::*;
use log::info;
use std::collections::HashMap;
use std::fs;
use std::path::PathBuf;
use std::sync::{Arc, OnceLock};
use yaml_rust2::Yaml;

use super::super::FunctionRegistry;
use super::super::helpers::append_actions;
use super::super::tokens::ConversionContext;

/// Load all Python function definitions from the functions directory
fn load_python_functions() -> String {
    let functions_dir = PathBuf::from("../../quantsim-nrl/game/functions");
    let mut all_functions = String::new();

    if let Ok(entries) = fs::read_dir(&functions_dir) {
        for entry in entries.flatten() {
            let path = entry.path();
            if path.extension().and_then(|s| s.to_str()) == Some("py") {
                if let Ok(content) = fs::read_to_string(&path) {
                    all_functions.push_str(&content);
                    all_functions.push('\n');
                }
            }
        }
    }

    all_functions
}

/// Load the generated state.py file for type context
fn load_state_definitions() -> String {
    let state_file = PathBuf::from("../../quantsim-nrl/_generated/py/state.py");

    if let Ok(content) = fs::read_to_string(&state_file) {
        content
    } else {
        String::new()
    }
}

/// Load the generated constants.py file for constant definitions
fn load_constants() -> String {
    let constants_file = PathBuf::from("../../quantsim-nrl/_generated/py/constants.py");

    if let Ok(content) = fs::read_to_string(&constants_file) {
        content
    } else {
        String::new()
    }
}

fn uses_outputs(actions: &[Action]) -> bool {
    for action in actions {
        match action {
            // Explicit return action
            Action::Return { .. } => return true,
            // Recursively check nested actions
            Action::If {
                then_actions,
                else_actions,
                ..
            } => {
                if uses_outputs(then_actions) || uses_outputs(else_actions) {
                    return true;
                }
            }
            Action::For { steps, .. } => {
                if uses_outputs(steps) {
                    return true;
                }
            }
            Action::Repeat { actions, .. } => {
                if uses_outputs(actions) {
                    return true;
                }
            }
            Action::Match { cases, default, .. } => {
                for case_actions in cases.values() {
                    if uses_outputs(case_actions) {
                        return true;
                    }
                }
                if uses_outputs(default) {
                    return true;
                }
            }
            Action::When { actions, .. } => {
                if uses_outputs(std::slice::from_ref(actions.as_ref())) {
                    return true;
                }
            }
            _ => {}
        }
    }
    false
}

fn get_return_variables(actions: &[Action]) -> Option<HashMap<String, String>> {
    for action in actions {
        match action {
            Action::Return { with, .. } => {
                return Some(with.clone());
            }
            Action::If {
                then_actions,
                else_actions,
                ..
            } => {
                if let Some(vars) = get_return_variables(then_actions) {
                    return Some(vars);
                }
                if let Some(vars) = get_return_variables(else_actions) {
                    return Some(vars);
                }
            }
            Action::For { steps, .. } => {
                if let Some(vars) = get_return_variables(steps) {
                    return Some(vars);
                }
            }
            Action::Repeat { actions, .. } => {
                if let Some(vars) = get_return_variables(actions) {
                    return Some(vars);
                }
            }
            Action::Match { cases, default, .. } => {
                for case_actions in cases.values() {
                    if let Some(vars) = get_return_variables(case_actions) {
                        return Some(vars);
                    }
                }
                if let Some(vars) = get_return_variables(default) {
                    return Some(vars);
                }
            }
            Action::When { actions, .. } => {
                if let Some(vars) = get_return_variables(std::slice::from_ref(actions.as_ref())) {
                    return Some(vars);
                }
            }
            _ => {}
        }
    }
    None
}

/// Collect all infer actions from the steps recursively with their index and outputs
fn collect_infer_actions(
    actions: &[Action],
    infer_list: &mut Vec<(
        usize,
        String,
        Option<Vec<String>>,
        Option<String>,
        Option<i64>,
    )>,
    counter: &mut usize,
) {
    for action in actions {
        match action {
            Action::Infer {
                model,
                output,
                outputs,
                extractor,
                categories,
                ..
            } => {
                if output.is_some() {
                    // Use explicitly defined outputs from YAML if provided
                    // Otherwise, we'll use actual ONNX outputs in dataclass generation
                    infer_list.push((
                        *counter,
                        model.clone(),
                        outputs.clone(),
                        extractor.clone(),
                        *categories,
                    ));
                    *counter += 1;
                }
            }
            Action::If {
                then_actions,
                else_actions,
                ..
            } => {
                collect_infer_actions(then_actions, infer_list, counter);
                collect_infer_actions(else_actions, infer_list, counter);
            }
            Action::For { steps, .. } => {
                collect_infer_actions(steps, infer_list, counter);
            }
            Action::Repeat { actions, .. } => {
                collect_infer_actions(actions, infer_list, counter);
            }
            Action::Match { cases, default, .. } => {
                for case_actions in cases.values() {
                    collect_infer_actions(case_actions, infer_list, counter);
                }
                collect_infer_actions(default, infer_list, counter);
            }
            Action::When { actions, .. } => {
                collect_infer_actions(std::slice::from_ref(actions.as_ref()), infer_list, counter);
            }
            _ => {}
        }
    }
}

/// Load state type definitions from state.yaml
fn load_state_type_definitions() -> HashMap<String, String> {
    use std::fs::File;
    use std::io::Read;
    use yaml_rust2::YamlLoader;

    let state_yaml_path = PathBuf::from("../../quantsim-nrl/game/state.yaml");
    let mut state_types = HashMap::new();

    if let Ok(mut file) = File::open(&state_yaml_path) {
        let mut contents = String::new();
        if file.read_to_string(&mut contents).is_ok() {
            if let Ok(docs) = YamlLoader::load_from_str(&contents) {
                if let Some(doc) = docs.first() {
                    // Look for the State definition
                    if let Some(state_hash) = doc["State"].as_hash() {
                        for (key, value) in state_hash {
                            if let Some(field_name) = key.as_str() {
                                let type_str = yaml_type_to_python(value);
                                state_types.insert(field_name.to_string(), type_str);
                            }
                        }
                    }
                }
            }
        }
    }

    state_types
}

fn load_constant_element_types() -> &'static HashMap<String, String> {
    use std::fs::File;
    use std::io::Read;
    use yaml_rust2::YamlLoader;

    static CONSTANT_ELEMENT_TYPES: OnceLock<HashMap<String, String>> = OnceLock::new();

    CONSTANT_ELEMENT_TYPES.get_or_init(|| {
        let mut element_types = HashMap::new();
        let constants_path = PathBuf::from("../../quantsim-nrl/game/constants.yaml");

        if let Ok(mut file) = File::open(&constants_path) {
            let mut contents = String::new();
            if file.read_to_string(&mut contents).is_ok() {
                if let Ok(docs) = YamlLoader::load_from_str(&contents) {
                    if let Some(doc) = docs.first() {
                        if let Some(constants_hash) = doc.as_hash() {
                            for (key, value) in constants_hash {
                                if let Some(name) = key.as_str() {
                                    if let Some(element_type) = infer_constant_element_type(value) {
                                        element_types.insert(name.to_string(), element_type);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        element_types
    })
}

fn infer_constant_element_type(value: &Yaml) -> Option<String> {
    match value {
        Yaml::Array(arr) => infer_array_element_type(arr),
        Yaml::Hash(hash) => infer_hash_value_type(hash),
        Yaml::String(_) => Some("str".to_string()),
        Yaml::Integer(_) => Some("int".to_string()),
        Yaml::Real(_) => Some("float".to_string()),
        Yaml::Boolean(_) => Some("bool".to_string()),
        _ => None,
    }
}

fn infer_array_element_type(arr: &[Yaml]) -> Option<String> {
    infer_collection_element_type(arr.iter())
}

fn infer_hash_value_type(hash: &yaml_rust2::yaml::Hash) -> Option<String> {
    infer_collection_element_type(hash.values())
}

fn infer_collection_element_type<'a, I>(iter: I) -> Option<String>
where
    I: IntoIterator<Item = &'a Yaml>,
{
    let mut current_type: Option<&'static str> = None;

    for element in iter {
        let element_type = match element {
            Yaml::String(_) => "str",
            Yaml::Integer(_) => "int",
            Yaml::Real(_) => "float",
            Yaml::Boolean(_) => "bool",
            Yaml::Array(_) | Yaml::Hash(_) => "Any",
            _ => "Any",
        };

        current_type = match (current_type, element_type) {
            (None, ty) => Some(ty),
            (Some("Any"), _) => Some("Any"),
            (Some(existing), ty) if existing == ty => Some(existing),
            (Some("int"), "float") | (Some("float"), "int") => Some("float"),
            (_, "Any") => Some("Any"),
            (Some(_), _) => Some("Any"),
        };

        if matches!(current_type, Some("Any")) {
            break;
        }
    }

    Some(current_type.unwrap_or("Any").to_string())
}

fn infer_type_from_constant_lookup(expr: &str) -> Option<String> {
    let trimmed = expr.trim();
    let bracket_pos = trimmed.find('[')?;
    if !trimmed.ends_with(']') {
        return None;
    }

    let constant_name = trimmed[..bracket_pos].trim();
    if constant_name.is_empty() {
        return None;
    }

    let constants = load_constant_element_types();
    constants.get(constant_name).cloned()
}

/// Infer the Python type of an expression based on its structure and available variables
fn infer_type_from_expression(expr: &str, variables: &HashMap<String, Yaml>) -> String {
    let expr_trimmed = expr.trim();

    if let Some(constant_type) = infer_type_from_constant_lookup(expr_trimmed) {
        return constant_type;
    }

    // Check for .get() method calls on constants (e.g., CONSTANT.get(...))
    // This pattern returns the value type of the constant dictionary/hash
    if let Some(dot_pos) = expr_trimmed.find(".get(") {
        let constant_name = expr_trimmed[..dot_pos].trim();
        if !constant_name.is_empty() {
            let constants = load_constant_element_types();
            if let Some(value_type) = constants.get(constant_name) {
                return value_type.clone();
            }
        }
    }

    // Check for quoted string marker - these are string literals
    if expr_trimmed.starts_with("___QUOTED___") {
        return "str".to_string();
    }

    // Check if it's a simple variable reference
    if let Some(var_type) = variables.get(expr_trimmed) {
        return yaml_type_to_python(var_type);
    }

    // Check for state field access patterns like "state.player_of_the_match"
    if expr_trimmed.starts_with("state.") {
        let field_name = &expr_trimmed[6..]; // Skip "state."

        // Load state type definitions
        let state_types = load_state_type_definitions();

        if let Some(field_type) = state_types.get(field_name) {
            return field_type.clone();
        }
    }

    // Check for list/array indexing patterns like "model.probabilities[0]" or "var.field[1]"
    // This is a common pattern where we access list elements from infer model outputs
    if let Some(bracket_pos) = expr_trimmed.rfind('[') {
        if expr_trimmed.ends_with(']') {
            let base_expr = &expr_trimmed[..bracket_pos];

            // Try to extract the type from the base expression
            // For patterns like "model.probabilities", we look for the variable "model"
            // and check if it has a field "probabilities"
            if let Some(dot_pos) = base_expr.rfind('.') {
                let var_name = &base_expr[..dot_pos];
                let field_name = &base_expr[dot_pos + 1..];

                // Look up the variable type
                if variables.get(var_name).is_some() {
                    // For infer outputs, we expect a String type that references a class
                    // The class structure is known: probabilities: list[float] or label: list[int]
                    if field_name == "probabilities" {
                        return "float".to_string();
                    } else if field_name == "label" {
                        return "int".to_string();
                    } else if field_name == "variable" {
                        // Some models use "variable" which is also list[float]
                        return "float".to_string();
                    }
                }
            }
        }
    }

    // Check for boolean operators (and, or, not)
    if expr_trimmed.contains(" and ")
        || expr_trimmed.contains(" or ")
        || expr_trimmed.starts_with("not ")
    {
        return "bool".to_string();
    }

    // Check for comparison operators (==, !=, <, >, <=, >=, in, is)
    if expr_trimmed.contains(" == ")
        || expr_trimmed.contains(" != ")
        || expr_trimmed.contains(" < ")
        || expr_trimmed.contains(" > ")
        || expr_trimmed.contains(" <= ")
        || expr_trimmed.contains(" >= ")
        || expr_trimmed.contains(" in ")
        || expr_trimmed.contains(" is ")
    {
        return "bool".to_string();
    }

    // Check for numeric operations (+, -, *, /, //, %, **)
    if expr_trimmed.contains(" + ")
        || expr_trimmed.contains(" - ")
        || expr_trimmed.contains(" * ")
        || expr_trimmed.contains(" / ")
    {
        // Try to infer if it's int or float based on operands
        // Look for decimal points or float() casts
        if expr_trimmed.contains('.') || expr_trimmed.contains("float(") {
            return "float".to_string();
        }
        // Check if any referenced variable is a float
        for var_name in variables.keys() {
            if expr_trimmed.contains(var_name) {
                if let Some(var_type) = variables.get(var_name) {
                    let type_str = yaml_type_to_python(var_type);
                    if type_str == "float" {
                        return "float".to_string();
                    }
                }
            }
        }
        return "int".to_string();
    }

    // Check for string literals
    if (expr_trimmed.starts_with('"') && expr_trimmed.ends_with('"'))
        || (expr_trimmed.starts_with('\'') && expr_trimmed.ends_with('\''))
    {
        return "str".to_string();
    }

    // Check for list literals
    if expr_trimmed.starts_with('[') && expr_trimmed.ends_with(']') {
        return "list".to_string();
    }

    // Check for dict literals
    if expr_trimmed.starts_with('{') && expr_trimmed.ends_with('}') {
        return "dict".to_string();
    }

    // Check for boolean literals
    if expr_trimmed == "True" || expr_trimmed == "False" {
        return "bool".to_string();
    }

    // Check for numeric literals
    if expr_trimmed.parse::<i64>().is_ok() {
        return "int".to_string();
    }
    if expr_trimmed.parse::<f64>().is_ok() {
        return "float".to_string();
    }

    // Check for constructor calls like FieldPosition(0, 0) or MyClass()
    // Pattern: ClassName(...) where ClassName starts with uppercase letter
    if expr_trimmed.contains('(') && expr_trimmed.ends_with(')') {
        if let Some(paren_pos) = expr_trimmed.find('(') {
            let class_name = &expr_trimmed[..paren_pos];
            // Check if it looks like a type name (starts with uppercase, contains only alphanumeric and underscores)
            if !class_name.is_empty()
                && class_name.chars().next().unwrap().is_uppercase()
                && class_name.chars().all(|c| c.is_alphanumeric() || c == '_')
            {
                return class_name.to_string();
            }
        }
    }

    // Default to Any if we can't infer
    "Any".to_string()
}

pub fn test_case_to_python(
    test_case: &TestCase,
    file_type: Option<&str>,
) -> Result<String, genco::fmt::Error> {
    let t = test_case_to_tokens(test_case, file_type);
    t.to_file_string()
}

fn test_case_to_tokens(test_case: &TestCase, file_type: Option<&str>) -> python::Tokens {
    let mut t = python::Tokens::new();

    // Load function registry for type annotations
    let function_registry = Arc::new(FunctionRegistry::load());

    // Determine what imports are needed
    let needs_final = !test_case.constants.is_empty();

    // Check if we need to generate a StepOutputs class to determine if Any is needed
    let has_outputs = uses_outputs(&test_case.steps);
    let return_variables = get_return_variables(&test_case.steps);

    // Collect infer actions to check if we need Any type
    let mut infer_actions = Vec::new();
    let mut infer_counter = 0;
    collect_infer_actions(&test_case.steps, &mut infer_actions, &mut infer_counter);

    // Check if Any is needed (when outputs can't be typed, dict[str, Any] is used, or infer outputs exist)
    let mut needs_any = !infer_actions.is_empty(); // Need Any for infer outputs

    if let Some(ref ret_vars) = return_variables {
        // Check if any output type can't be inferred from variables
        for var_expr in ret_vars.values() {
            if test_case.variables.get(var_expr.as_str()).is_none() {
                needs_any = true;
                break;
            }
        }
    } else if has_outputs {
        // If has_outputs but no return_variables, we use dict[str, Any]
        needs_any = true;
    }

    // Generate imports
    if needs_final || needs_any {
        let mut imports = vec![];
        if needs_any {
            imports.push("Any");
        }
        if needs_final {
            imports.push("Final");
        }
        t.append(format!("from typing import {}", imports.join(", ")));
        t.push();
    }

    // Always import State from state module
    t.append("from state import State");
    t.push();

    // Import all functions using wildcard import
    t.append("from functions import *");
    t.push();
    t.line();

    // Generate dataclass import if needed (for StepOutputs or InferOutputs)
    let needs_dataclass = return_variables.is_some() || !infer_actions.is_empty();

    if needs_dataclass {
        t.append("from dataclasses import dataclass");
        t.push();
        t.line();
    }

    // Generate InferOutputs dataclasses for each infer action
    // Store the dataclass definitions as strings for later use in Depyler type inference
    // Also store a mapping from output variable names to their InferOutputs class names
    let mut infer_outputs_definitions = String::new();
    let mut infer_output_var_to_class: HashMap<String, String> = HashMap::new();

    if !infer_actions.is_empty() {
        use super::super::tokens::get_onnx_model_outputs;
        use std::path::PathBuf;

        let function_name = test_case.name.to_lowercase().replace(" ", "_");
        let step_pascal_case = function_name
            .split('_')
            .map(|s| {
                let mut chars = s.chars();
                match chars.next() {
                    None => String::new(),
                    Some(first) => first.to_uppercase().collect::<String>() + chars.as_str(),
                }
            })
            .collect::<String>();

        // Build mapping from output variable names to class names
        let mut infer_counter_for_mapping = 0;
        for action in &test_case.steps {
            if let Action::Infer { output, .. } = action {
                if let Some(output_var) = output {
                    let class_name = format!(
                        "{}InferOutputs{}",
                        step_pascal_case, infer_counter_for_mapping
                    );
                    infer_output_var_to_class.insert(output_var.clone(), class_name);
                    infer_counter_for_mapping += 1;
                }
            }
        }

        for (output_num, model_name, outputs_opt, extractor_opt, _categories_opt) in &infer_actions
        {
            // Use the Infer step's model name to determine which ONNX file to open
            let model_file_name = model_name.to_lowercase().replace(" ", "_");
            let model_path = PathBuf::from("../../quantsim-nrl/game/models")
                .join(&format!("{}.onnx", model_file_name));
            let onnx_outputs_result = get_onnx_model_outputs(&model_path);

            // Log ONNX model information
            info!("ONNX Model: {}.onnx", model_file_name);
            let onnx_outputs = match onnx_outputs_result {
                Ok(ref onnx_outs) => {
                    info!("  Outputs count: {}", onnx_outs.len());
                    for (idx, onnx_out) in onnx_outs.iter().enumerate() {
                        info!(
                            "  Output {}: name='{}', data_type='{}'",
                            idx, onnx_out.name, onnx_out.data_type
                        );
                    }
                    Some(onnx_outs.clone())
                }
                Err(e) => {
                    info!("  Failed to load ONNX outputs from {:?}: {}", model_path, e);
                    None
                }
            };

            // Generate the InferOutputs dataclass
            let class_name = format!("{}InferOutputs{}", step_pascal_case, output_num);

            // Build the class definition as a string for Depyler
            infer_outputs_definitions.push_str("# @depyler: additional_derives = \"Reflect\"\n");
            infer_outputs_definitions.push_str("@dataclass\n");
            infer_outputs_definitions.push_str(&format!("class {}:\n", class_name));

            t.append("# @depyler: additional_derives = \"Reflect\"");
            t.push();
            t.append("@dataclass");
            t.push();
            t.append(format!("class {}:", class_name));
            t.push();
            t.indent();

            // Priority 1: Use YAML-specified outputs with types from ONNX if available
            if let Some(outputs) = outputs_opt {
                for (idx, output_name) in outputs.iter().enumerate() {
                    // Try to get type from ONNX model
                    let data_type = if let Some(ref onnx_outs) = onnx_outputs {
                        if let Some(onnx_out) = onnx_outs.get(idx) {
                            onnx_out.data_type.clone()
                        } else {
                            "Any".to_string()
                        }
                    } else {
                        "Any".to_string()
                    };
                    t.append(format!("{}: {}", output_name, data_type));
                    t.push();
                    infer_outputs_definitions
                        .push_str(&format!("    {}: {}\n", output_name, data_type));
                }
            } else if extractor_opt.is_some() {
                // Priority 2: If extractor is specified (like "regression"), use ONNX output names if available
                if let Some(ref onnx_outs) = onnx_outputs {
                    for onnx_out in onnx_outs {
                        t.append(format!("{}: {}", onnx_out.name, onnx_out.data_type));
                        t.push();
                        infer_outputs_definitions
                            .push_str(&format!("    {}: {}\n", onnx_out.name, onnx_out.data_type));
                    }
                } else {
                    // Fallback to standard names
                    t.append("label: Any");
                    t.push();
                    t.append("probabilities: Any");
                    t.push();
                    infer_outputs_definitions.push_str("    label: Any\n");
                    infer_outputs_definitions.push_str("    probabilities: Any\n");
                }
            } else {
                // Priority 3: Use actual ONNX outputs if available, otherwise generic result
                if let Some(ref onnx_outs) = onnx_outputs {
                    for onnx_out in onnx_outs {
                        t.append(format!("{}: {}", onnx_out.name, onnx_out.data_type));
                        t.push();
                        infer_outputs_definitions
                            .push_str(&format!("    {}: {}\n", onnx_out.name, onnx_out.data_type));
                    }
                } else {
                    t.append("result: Any");
                    t.push();
                    infer_outputs_definitions.push_str("    result: Any\n");
                }
            }

            t.unindent();
            t.line();
            infer_outputs_definitions.push('\n');
        }
    }

    // Generate StepOutputs class if there are return variables
    // Strategy: First generate the complete step file, pass it to Depyler for type inference,
    // then use the inferred types to create the StepOutputs class
    let step_outputs_class_tokens = if let Some(ref ret_vars) = return_variables {
        use depyler_core::dataflow::infer_python;

        // Generate step-specific StepOutputs class name (e.g., FieldGoalAttemptOutputs)
        let function_name = test_case.name.to_lowercase().replace(" ", "_");
        let step_outputs_class_name = function_name
            .split('_')
            .map(|s| {
                let mut chars = s.chars();
                match chars.next() {
                    None => String::new(),
                    Some(first) => first.to_uppercase().collect::<String>() + chars.as_str(),
                }
            })
            .collect::<String>()
            + "Outputs";

        // Sort output names for consistent output
        let mut output_names: Vec<_> = ret_vars.keys().collect();
        output_names.sort();

        // Generate a simple function with just temp variables for type inference
        // No dict, no outputs - just the expressions assigned to temp variables
        let mut temp_tokens = python::Tokens::new();

        // Generate the same imports and InferOutputs classes
        if !infer_outputs_definitions.is_empty() {
            temp_tokens.append("from dataclasses import dataclass");
            temp_tokens.push();
            temp_tokens.line();

            // Add the InferOutputs dataclasses
            temp_tokens.append(infer_outputs_definitions.clone());
            temp_tokens.line();
        }

        temp_tokens.append("from typing import Any");
        temp_tokens.push();
        temp_tokens.append("from state import State");
        temp_tokens.push();
        temp_tokens.append("from functions import *");
        temp_tokens.push();
        temp_tokens.line();

        // Generate function with None return type (we only care about temp variables)
        let mut function_params = vec!["state: State".to_string()];
        if !test_case.parameters.is_empty() {
            let mut param_names: Vec<String> = test_case.parameters.keys().cloned().collect();
            param_names.sort();
            for param_name in &param_names {
                if let Some(param_type) = test_case.parameters.get(param_name) {
                    let type_hint = yaml_to_python_type(param_type);
                    function_params.push(format!("{}: {}", param_name, type_hint));
                }
            }
        }

        temp_tokens.append(format!(
            "def {}({}) -> None:",
            function_name,
            function_params.join(", ")
        ));
        temp_tokens.push();
        temp_tokens.indent();

        // Generate variables
        if !test_case.variables.is_empty() {
            let mut var_names: Vec<String> = test_case.variables.keys().cloned().collect();
            var_names.sort();
            for var_name in &var_names {
                if let Some(var_value) = test_case.variables.get(var_name) {
                    let (type_annotation, _default_value) =
                        get_variable_type_and_default(var_value);
                    let clean_type = type_annotation.trim_end_matches(" | None");
                    temp_tokens.append(format!("{}: {}", var_name, clean_type));
                    temp_tokens.push();
                }
            }
            temp_tokens.line();
        }

        // Generate the step logic without outputs dict
        let is_event = file_type == Some("event");
        let is_step = file_type == Some("step");
        let temp_ctx = ConversionContext::with_step_outputs_and_registry_and_flags(
            test_case.name.clone(),
            false,
            String::new(),
            function_registry.clone(),
            is_event,
            is_step,
        );

        append_actions(&mut temp_tokens, &test_case.steps, &temp_ctx);

        // Add temporary variables for each output expression to help Depyler infer types
        // Assign the actual expressions directly to temp variables
        temp_tokens.line();
        for output_name in &output_names {
            let var_expr = ret_vars.get(output_name.as_str()).unwrap();
            // Convert ___QUOTED___ markers back to proper string literals
            let clean_expr = if var_expr.starts_with("___QUOTED___") {
                format!("\"{}\"", &var_expr["___QUOTED___".len()..])
            } else {
                var_expr.clone()
            };
            // Create a temp variable with the actual expression
            temp_tokens.append(format!("temp_{} = {}", output_name, clean_expr));
            temp_tokens.push();
        }

        temp_tokens.unindent();

        // Convert to Python code string
        let temp_python = temp_tokens.to_file_string().unwrap_or_default();

        // Load context for Depyler
        let state_definitions = load_state_definitions();
        let constants = load_constants();
        let python_functions = load_python_functions();

        let full_python = format!(
            "{}\n\n{}\n\n{}\n\n{}",
            state_definitions, constants, python_functions, temp_python
        );

        // Run type inference on the complete step file
        let inferred_types: HashMap<String, String> = match infer_python(&full_python) {
            Ok(results) => {
                if let Some(inferred) = results.get(&function_name) {
                    let mut types = HashMap::new();
                    for output_name in &output_names {
                        // Look for the temp variable we created for type inference
                        let temp_var_name = format!("temp_{}", output_name);

                        // Try to get the type of the temp variable
                        if let Some(var_type) = inferred.get_variable_type(&temp_var_name) {
                            let type_str = hir_type_to_python(var_type);
                            types.insert(output_name.to_string(), type_str);
                        } else {
                            // Depyler couldn't infer the type, try manual inference as fallback
                            let var_expr = ret_vars.get(output_name.as_str()).unwrap();
                            let fallback_type =
                                infer_type_from_expression(var_expr, &test_case.variables);

                            if fallback_type != "Any" {
                                eprintln!(
                                    "Could not infer type for '{}' via Depyler, using manual inference: {}",
                                    output_name, fallback_type
                                );
                                types.insert(output_name.to_string(), fallback_type);
                            } else {
                                eprintln!("Could not infer type for '{}', using Any", output_name);
                                types.insert(output_name.to_string(), "Any".to_string());
                            }
                        }
                    }
                    types
                } else {
                    eprintln!(
                        "Function '{}' not found in inference results",
                        function_name
                    );
                    output_names
                        .iter()
                        .map(|k| (k.to_string(), "Any".to_string()))
                        .collect()
                }
            }
            Err(e) => {
                eprintln!("Type inference failed: {:?}", e);
                output_names
                    .iter()
                    .map(|k| (k.to_string(), "Any".to_string()))
                    .collect()
            }
        };

        // Now generate the StepOutputs class with the inferred types
        let mut class_tokens = python::Tokens::new();
        class_tokens.append("@dataclass");
        class_tokens.push();
        class_tokens.append(format!("class {}:", step_outputs_class_name));
        class_tokens.push();
        class_tokens.indent();

        for output_name in output_names {
            let default_type = "Any".to_string();
            let output_type = inferred_types
                .get(output_name.as_str())
                .unwrap_or(&default_type);
            class_tokens.append(format!("{}: {}", output_name, output_type));
            class_tokens.push();
        }

        class_tokens.unindent();
        class_tokens.line();

        Some(class_tokens)
    } else {
        None
    };

    // Append the StepOutputs class if it was generated
    if let Some(class_tokens) = step_outputs_class_tokens {
        t.append(class_tokens);
    }

    // Add depyler comment based on file type
    if let Some(ftype) = file_type {
        let comment = match ftype {
            "step" => "# @depyler: custom_attribute_ignore = \"step\"",
            "event" => "# @depyler: custom_attribute_ignore = \"event\"",
            "game" => "# @depyler: custom_attribute_ignore = \"game\"",
            _ => "",
        };
        if !comment.is_empty() {
            t.append(comment);
            t.push();
        }
    }

    // Convert step name to lowercase with underscores
    let function_name = test_case.name.to_lowercase().replace(" ", "_");

    // Generate step-specific outputs class name (e.g., FieldGoalAttemptOutputs)
    let step_outputs_class_name = function_name
        .split('_')
        .map(|s| {
            let mut chars = s.chars();
            match chars.next() {
                None => String::new(),
                Some(first) => first.to_uppercase().collect::<String>() + chars.as_str(),
            }
        })
        .collect::<String>()
        + "Outputs";

    // Build function parameters
    let mut function_params = vec!["state: State".to_string()];

    if !test_case.parameters.is_empty() {
        let mut param_names: Vec<String> = test_case.parameters.keys().cloned().collect();
        param_names.sort();

        for param_name in &param_names {
            if let Some(param_type) = test_case.parameters.get(param_name) {
                let type_hint = yaml_to_python_type(param_type);
                function_params.push(format!("{}: {}", param_name, type_hint));
            }
        }
    }

    // Determine return type based on whether outputs are used
    let return_type = if return_variables.is_some() {
        format!(" -> {}", step_outputs_class_name)
    } else if has_outputs {
        " -> dict[str, Any]".to_string()
    } else {
        " -> None".to_string()
    };

    // Generate function definition with return type
    t.append(quote!(def $(function_name)($(function_params.join(", ")))$(return_type):));
    t.push();
    t.indent();

    // Generate constants
    if !test_case.constants.is_empty() {
        let mut const_names: Vec<String> = test_case.constants.keys().cloned().collect();
        const_names.sort();

        for const_name in &const_names {
            if let Some(const_value) = test_case.constants.get(const_name) {
                let py_value = format_yaml_value(const_value);
                let py_type = infer_python_type_from_yaml(const_value);
                let uppercase_name = const_name.to_uppercase();
                t.append(quote!($(uppercase_name): Final[$(py_type)] = $(py_value)));
                t.push();
            }
        }
        t.line();
    }

    // Generate variables
    if !test_case.variables.is_empty() {
        let mut var_names: Vec<String> = test_case.variables.keys().cloned().collect();
        var_names.sort();

        for var_name in &var_names {
            if let Some(var_value) = test_case.variables.get(var_name) {
                // Get type annotation and default value
                let (type_annotation, default_value) = get_variable_type_and_default(var_value);
                t.append(quote!($(var_name): $(type_annotation) = $(default_value)));
                t.push();
            }
        }
        t.line();
    }

    // Initialize outputs dictionary only if needed (but not when using StepOutputs)
    if has_outputs && return_variables.is_none() {
        t.append(quote!(outputs = {}));
        t.push();
        t.line();
    }

    // Create conversion context with the step name and use_step_outputs flag
    let use_step_outputs = return_variables.is_some();
    let is_event = file_type == Some("event");
    let is_step = file_type == Some("step");
    let ctx = ConversionContext::with_step_outputs_and_registry_and_flags(
        test_case.name.clone(),
        use_step_outputs,
        step_outputs_class_name.clone(),
        function_registry,
        is_event,
        is_step,
    );

    // Handle when condition
    if let Some(when_condition) = &test_case.when {
        t.append(quote!(if $(when_condition):));
        t.push();
        t.indent();
        append_actions(&mut t, &test_case.steps, &ctx);
        t.unindent();
    } else {
        append_actions(&mut t, &test_case.steps, &ctx);
    }

    // Execute events at the end of step files (but not events or game files)
    if is_step {
        t.line();
        t.append(quote!(execute_events(state)));
        t.push();
    }

    // Add return statement - note that when using StepOutputs,
    // the return statement is generated within the return action itself
    if !use_step_outputs {
        if has_outputs {
            t.line();
            t.append("return outputs");
            t.push();
        } else {
            t.line();
            t.append("return None");
            t.push();
        }
    }

    t.unindent();
    t
}

fn yaml_type_to_python(yaml: &Yaml) -> String {
    match yaml {
        // Handle new Hash format with "type" key (for variables with initial values)
        Yaml::Hash(h) => {
            if let Some(type_yaml) = h.get(&Yaml::String("type".to_string())) {
                return yaml_type_to_python(type_yaml);
            }
            // If it's a hash but doesn't have a "type" key, treat as dict
            "dict".to_string()
        }

        // Simple type names as strings: Int, Bool, Str, Float, List[Int], etc.
        Yaml::String(s) => {
            let s_str = s.as_str();

            // Handle Option[...] syntax - convert to Optional[...]
            if s_str.starts_with("Option[") && s_str.ends_with(']') {
                let inner_type = &s_str[7..s_str.len() - 1];

                // Recursively convert the inner type
                let inner_yaml = Yaml::String(inner_type.to_string());
                let converted_inner = yaml_type_to_python(&inner_yaml);
                return format!("Optional[{}]", converted_inner);
            }

            // Handle List[...] syntax (with capital L)
            if s_str.starts_with("List[") && s_str.ends_with(']') {
                let inner_type = &s_str[5..s_str.len() - 1];

                // Recursively convert the inner type
                let inner_yaml = Yaml::String(inner_type.to_string());
                let converted_inner = yaml_type_to_python(&inner_yaml);
                return format!("List[{}]", converted_inner);
            }

            // Convert known Python built-in type names to lowercase
            // Everything else (custom types like Team, Player, etc.) stays as-is
            match s_str {
                "Int" | "int" => "int".to_string(),
                "Bool" | "Boolean" | "bool" => "bool".to_string(),
                "Str" | "str" | "String" => "str".to_string(),
                "Float" | "float" => "float".to_string(),
                "List" | "list" => "list".to_string(),
                "Dict" | "dict" => "dict".to_string(),
                "Any" => "Any".to_string(),

                // For any other string (custom types), use it as-is
                _ => s.clone(),
            }
        }

        // Array type annotations like [Int], [Str], etc.
        Yaml::Array(arr) => {
            if arr.len() == 1 {
                // Single element array represents a list type: [Int] -> [int]
                format!("[{}]", yaml_type_to_python(&arr[0]))
            } else if arr.is_empty() {
                // Empty array
                "list".to_string()
            } else {
                // Multiple elements - this would be a union or tuple type
                // For now, just use list
                "list".to_string()
            }
        }

        // Null values should be None
        Yaml::Null => "None".to_string(),

        // For anything else, return a sensible default
        _ => "Any".to_string(),
    }
}

fn yaml_to_python_type(yaml: &Yaml) -> String {
    match yaml {
        Yaml::Real(_) => "float".to_string(),
        Yaml::String(s) => {
            // Handle special type string values
            match s.as_str() {
                // Map common primitives to lowercase Python types
                "Boolean" | "Bool" | "bool" => "bool".to_string(),
                "Int" | "int" => "int".to_string(),
                "Float" | "float" => "float".to_string(),
                "Str" | "str" => "str".to_string(),
                "String" => "str".to_string(), // Map String to str
                "List" | "list" => "list".to_string(),
                "Dict" | "dict" => "dict".to_string(),

                // For any other string (custom types like GameStatus, Expression, Team, etc.),
                // preserve the type name as-is
                _ => s.clone(),
            }
        }
        Yaml::Integer(_) => "int".to_string(),
        Yaml::Boolean(_) => "bool".to_string(),
        Yaml::Array(_) => "list".to_string(),
        Yaml::Hash(_) => "dict".to_string(),
        Yaml::Null => "None".to_string(),
        _ => "None".to_string(),
    }
}

/// Parse an initial value string from YAML to Python format
fn parse_initial_value_to_python(value: &str) -> String {
    let trimmed = value.trim();

    // Handle boolean values
    if trimmed.eq_ignore_ascii_case("true") {
        return "True".to_string();
    }
    if trimmed.eq_ignore_ascii_case("false") {
        return "False".to_string();
    }

    // Handle None/null
    if trimmed.eq_ignore_ascii_case("none") || trimmed.eq_ignore_ascii_case("null") {
        return "None".to_string();
    }

    // Handle numeric values (integers and floats)
    if trimmed.parse::<i64>().is_ok() {
        return trimmed.to_string();
    }
    if trimmed.parse::<f64>().is_ok() {
        return trimmed.to_string();
    }

    // Handle string values (add quotes if not already quoted)
    if (trimmed.starts_with('"') && trimmed.ends_with('"'))
        || (trimmed.starts_with('\'') && trimmed.ends_with('\''))
    {
        return trimmed.to_string();
    }

    // Handle list/array literals
    if trimmed.starts_with('[') && trimmed.ends_with(']') {
        return trimmed.to_string();
    }

    // Handle dict literals
    if trimmed.starts_with('{') && trimmed.ends_with('}') {
        return trimmed.to_string();
    }

    // Handle constructor calls and function calls (e.g., FieldPosition(0, 0), MyClass())
    if trimmed.contains('(') && trimmed.ends_with(')') {
        return trimmed.to_string();
    }

    // Default: treat as a string literal and add quotes
    format!("\"{}\"", trimmed)
}

fn get_variable_type_and_default(yaml: &Yaml) -> (String, String) {
    match yaml {
        // Handle new format: Hash with "type" and optional "initial" keys
        Yaml::Hash(h) => {
            if let Some(type_yaml) = h.get(&Yaml::String("type".to_string())) {
                // Get the type
                let (mut python_type, default_value) = get_variable_type_and_default(type_yaml);

                // Check if there's an initial value specified
                if let Some(initial_yaml) = h.get(&Yaml::String("initial".to_string())) {
                    if let Some(initial_str) = initial_yaml.as_str() {
                        // Parse the initial value to Python format
                        let python_initial = parse_initial_value_to_python(initial_str);

                        // If there's an initial value and the type ends with " | None",
                        // remove it since the variable is being initialized
                        if python_type.ends_with(" | None") {
                            python_type = python_type[..python_type.len() - 7].to_string();
                        }

                        return (python_type, python_initial);
                    }
                }

                // No initial value, use default
                return (python_type, default_value);
            }

            // Hash doesn't have expected format, fall back to default
            ("Any | None".to_string(), "None".to_string())
        }

        Yaml::String(s) => {
            let s_str = s.as_str();
            let s_lower = s_str.to_lowercase();

            // Handle option[...] syntax (case-insensitive) - convert to Optional[...]
            if s_lower.starts_with("option[") && s_lower.ends_with(']') {
                let inner_type = &s_str[7..s_str.len() - 1];
                let inner_yaml = Yaml::String(inner_type.to_string());
                let converted_inner = yaml_type_to_python(&inner_yaml);
                return (format!("Optional[{}]", converted_inner), "None".to_string());
            }

            // Handle list[...] syntax (case-insensitive)
            if s_lower.starts_with("list[") && s_lower.ends_with(']') {
                let inner_type = &s_str[5..s_str.len() - 1];
                let inner_yaml = Yaml::String(inner_type.to_string());
                let converted_inner = yaml_type_to_python(&inner_yaml);
                return (format!("list[{}]", converted_inner), "list()".to_string());
            }

            // Check for types and their appropriate defaults
            match s_lower.as_str() {
                "int" => ("int".to_string(), "0".to_string()),
                "boolean" | "bool" => ("bool".to_string(), "False".to_string()),
                "float" => ("float".to_string(), "0.0".to_string()),
                "str" | "string" => ("str".to_string(), "\"\"".to_string()),
                "list" => ("list".to_string(), "list()".to_string()),
                "dict" => ("dict".to_string(), "{}".to_string()),
                "any" => ("Any".to_string(), "None".to_string()),

                // For custom types (like Team, Player, Result, etc.), allow None
                _ => (format!("{} | None", s), "None".to_string()),
            }
        }

        // Array type annotations like [Int], [Str], etc. -> list[...] with []
        Yaml::Array(_) => {
            let type_str = yaml_type_to_python(yaml);
            (type_str, "[]".to_string())
        }

        // Null values should be None
        Yaml::Null => ("None".to_string(), "None".to_string()),

        // For anything else, use Any | None
        _ => ("Any | None".to_string(), "None".to_string()),
    }
}

fn infer_python_type_from_yaml(yaml: &Yaml) -> String {
    match yaml {
        Yaml::Integer(_) => "int".to_string(),
        Yaml::Real(_) => "float".to_string(),
        Yaml::String(_) => "str".to_string(),
        Yaml::Boolean(_) => "bool".to_string(),
        Yaml::Array(arr) => {
            // If array is empty, just use list
            if arr.is_empty() {
                return "list".to_string();
            }

            // If all elements are of the same type, infer list[element_type]
            let first_type = infer_python_type_from_yaml(&arr[0]);
            let all_same = arr
                .iter()
                .all(|elem| infer_python_type_from_yaml(elem) == first_type);
            if all_same {
                format!("list[{}]", first_type)
            } else {
                "list".to_string()
            }
        }
        Yaml::Hash(_) => "dict".to_string(),
        Yaml::Null => "None".to_string(),
        _ => "Any".to_string(),
    }
}

/// Convert HIR Type to Python type string
fn hir_type_to_python(ty: &depyler_core::hir::Type) -> String {
    use depyler_core::hir::Type;

    match ty {
        Type::Unknown => "Any".to_string(),
        Type::Int => "int".to_string(),
        Type::Float => "float".to_string(),
        Type::String => "str".to_string(),
        Type::Bool => "bool".to_string(),
        Type::None => "None".to_string(),
        Type::List(inner) => format!("list[{}]", hir_type_to_python(inner)),
        Type::Dict(key, val) => format!(
            "dict[{}, {}]",
            hir_type_to_python(key),
            hir_type_to_python(val)
        ),
        Type::Tuple(types) => {
            let type_strs: Vec<String> = types.iter().map(|t| hir_type_to_python(t)).collect();
            format!("tuple[{}]", type_strs.join(", "))
        }
        Type::Set(inner) => format!("set[{}]", hir_type_to_python(inner)),
        Type::Optional(inner) => format!("{} | None", hir_type_to_python(inner)),
        Type::Custom(name) => name.clone(),
        Type::TypeVar(name) => name.clone(),
        _ => "Any".to_string(),
    }
}

pub fn generate_constants_file(
    constants: &HashMap<String, Yaml>,
    step_name: &str,
) -> Result<String, genco::fmt::Error> {
    let t = constants_to_tokens(constants, step_name);
    t.to_file_string()
}

pub fn generate_variables_file(
    variables: &HashMap<String, Yaml>,
    step_name: &str,
) -> Result<String, genco::fmt::Error> {
    let t = variables_to_tokens(variables, step_name);
    t.to_file_string()
}

fn constants_to_tokens(constants: &HashMap<String, Yaml>, step_name: &str) -> python::Tokens {
    let mut t = python::Tokens::new();

    // Add header comment
    t.append(format!("# Constants for {} step\n", step_name));
    t.append("# Generated from step.yaml\n");
    t.line();

    // Sort keys for consistent output
    let mut keys: Vec<_> = constants.keys().collect();
    keys.sort();

    for key in keys {
        if let Some(value) = constants.get(key) {
            let formatted_value = format_yaml_value(value);

            // Add inline comment if the value has one (checking for comments in YAML)
            let comment = extract_comment_from_yaml(value);
            if let Some(comment_text) = comment {
                t.append(format!(
                    "{} = {}  # {}\n",
                    key, formatted_value, comment_text
                ));
            } else {
                t.append(format!("{} = {}\n", key, formatted_value));
            }
        }
    }

    t
}

fn variables_to_tokens(variables: &HashMap<String, Yaml>, step_name: &str) -> python::Tokens {
    let mut t = python::Tokens::new();

    // Add header comment
    t.append(format!("# Variables for {} step\n", step_name));
    t.append("# Generated from step.yaml\n");
    t.line();

    // Sort keys for consistent output
    let mut keys: Vec<_> = variables.keys().collect();
    keys.sort();

    for key in keys {
        if let Some(value) = variables.get(key) {
            // Get type-aware default value
            let (_type_annotation, default_value) = get_variable_type_and_default(value);
            t.append(format!("{} = {}\n", key, default_value));
        }
    }

    t
}

fn format_yaml_value(value: &Yaml) -> String {
    match value {
        Yaml::Real(s) => s.clone(),
        Yaml::Integer(i) => i.to_string(),
        Yaml::String(s) => {
            // Check if the string represents a tuple: "(value1, value2, ...)"
            if s.starts_with('(') && s.ends_with(')') {
                // Return as-is - it's already a tuple representation
                s.clone()
            } else {
                // Replace bare true/false with True/False in string values (not inside quotes)
                let replaced = s.replace("true", "True").replace("false", "False");
                format!("\"{}\"", replaced)
            }
        }
        Yaml::Boolean(b) => if *b { "True" } else { "False" }.to_string(),
        Yaml::Array(arr) => {
            let items: Vec<String> = arr.iter().map(format_yaml_value).collect();
            format!("[{}]", items.join(", "))
        }
        Yaml::Hash(hash) => {
            let items: Vec<String> = hash
                .iter()
                .map(|(k, v)| {
                    let key_str = match k {
                        Yaml::String(s) => format!("\"{}\"", s),
                        _ => format_yaml_value(k),
                    };
                    format!("{}: {}", key_str, format_yaml_value(v))
                })
                .collect();
            format!("{{{}}}", items.join(", "))
        }
        Yaml::Null => "None".to_string(),
        Yaml::BadValue => "None".to_string(),
        Yaml::Alias(_) => "None".to_string(),
    }
}

fn extract_comment_from_yaml(_value: &Yaml) -> Option<String> {
    // yaml_rust2 doesn't preserve comments directly in the parsed structure
    // This would need to be extracted from the original source if needed
    // For now, return None
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_generate_constants_file() {
        let mut constants = HashMap::new();
        constants.insert("PLAYING_FIELD_WIDTH".to_string(), Yaml::Integer(1000));
        constants.insert(
            "TWO_POINT_FIELD_GOAL_DISTANCE".to_string(),
            Yaml::Integer(400),
        );

        let result = generate_constants_file(&constants, "field_goal").unwrap();

        assert!(result.contains("# Constants for field_goal step"));
        assert!(result.contains("PLAYING_FIELD_WIDTH = 1000"));
        assert!(result.contains("TWO_POINT_FIELD_GOAL_DISTANCE = 400"));
    }

    #[test]
    fn test_generate_variables_file() {
        let mut variables = HashMap::new();
        // Variables are type annotations, not values
        variables.insert(
            "field_goal_result".to_string(),
            Yaml::String("FieldGoalResult".to_string()),
        );
        variables.insert("adjusted_x".to_string(), Yaml::String("Int".to_string()));
        variables.insert(
            "is_two_pointer".to_string(),
            Yaml::String("Bool".to_string()),
        );
        variables.insert("description".to_string(), Yaml::String("Str".to_string()));
        variables.insert("tags".to_string(), Yaml::String("List".to_string()));

        let result = generate_variables_file(&variables, "field_goal").unwrap();

        println!("Generated variables file:\n{}", result);

        assert!(result.contains("# Variables for field_goal step"));
        // Int should default to 0
        assert!(result.contains("adjusted_x = 0"));
        // Bool should default to False
        assert!(result.contains("is_two_pointer = False"));
        // Str should default to ""
        assert!(result.contains("description = \"\""));
        // List should default to list()
        assert!(result.contains("tags = list()"));
        // Custom types should default to None
        assert!(result.contains("field_goal_result = None"));
    }

    #[test]
    fn test_generate_variables_file_with_initial_values() {
        let mut variables = HashMap::new();

        // Variable with initial value: Bool = false
        let mut valid_hash = yaml_rust2::yaml::Hash::new();
        valid_hash.insert(
            Yaml::String("type".to_string()),
            Yaml::String("Bool".to_string()),
        );
        valid_hash.insert(
            Yaml::String("initial".to_string()),
            Yaml::String("false".to_string()),
        );
        variables.insert("valid".to_string(), Yaml::Hash(valid_hash));

        // Variable with initial value: Int = 42
        let mut count_hash = yaml_rust2::yaml::Hash::new();
        count_hash.insert(
            Yaml::String("type".to_string()),
            Yaml::String("Int".to_string()),
        );
        count_hash.insert(
            Yaml::String("initial".to_string()),
            Yaml::String("42".to_string()),
        );
        variables.insert("count".to_string(), Yaml::Hash(count_hash));

        // Variable with initial value: Str = "test"
        let mut name_hash = yaml_rust2::yaml::Hash::new();
        name_hash.insert(
            Yaml::String("type".to_string()),
            Yaml::String("Str".to_string()),
        );
        name_hash.insert(
            Yaml::String("initial".to_string()),
            Yaml::String("test".to_string()),
        );
        variables.insert("name".to_string(), Yaml::Hash(name_hash));

        // Variable without initial value (should use default)
        variables.insert("adjusted_x".to_string(), Yaml::String("Int".to_string()));

        let result = generate_variables_file(&variables, "test").unwrap();

        println!("Generated variables file with initial values:\n{}", result);

        assert!(result.contains("# Variables for test step"));
        // Bool with initial value false
        assert!(result.contains("valid = False"));
        // Int with initial value 42
        assert!(result.contains("count = 42"));
        // Str with initial value "test" (should be quoted)
        assert!(result.contains("name = \"test\""));
        // Int without initial value should use default 0
        assert!(result.contains("adjusted_x = 0"));
    }

    #[test]
    fn test_test_case_with_constants_and_parameters() {
        let mut test_case = TestCase {
            name: "kickoff".to_string(),
            version: "1.0".to_string(),
            description: None,
            parameters: HashMap::new(),
            constants: HashMap::new(),
            variables: HashMap::new(),
            when: None,
            repeat: false,
            steps: vec![],
        };

        // Add parameters
        test_case.parameters.insert(
            "force_possession_change".to_string(),
            Yaml::String("bool".to_string()),
        );
        test_case.parameters.insert(
            "is_line_dropout".to_string(),
            Yaml::String("bool".to_string()),
        );

        // Add constants
        test_case
            .constants
            .insert("DROPOUT_X".to_string(), Yaml::Integer(0));
        test_case
            .constants
            .insert("KICKOFF_X".to_string(), Yaml::Integer(500));

        // Add variables with type annotations (not values)
        test_case
            .variables
            .insert("new_team".to_string(), Yaml::String("Team".to_string()));
        test_case
            .variables
            .insert("valid".to_string(), Yaml::String("Bool".to_string()));

        let result = test_case_to_python(&test_case, Some("step")).unwrap();

        println!("Generated Python with imports:\n{}", result);

        // Check for imports
        assert!(
            result.contains("from typing import Final"),
            "Should import Final"
        );
        assert!(
            result.contains("from state import State"),
            "Should import State"
        );

        // Check for function signature with type annotation and return type
        assert!(
            result.contains(
                "def kickoff(state: State, force_possession_change: bool, is_line_dropout: bool) -> None:"
            ),
            "Should have state: State type annotation, other parameters, and return type"
        );

        // Check for constant with Final[type] annotation
        assert!(
            result.contains("DROPOUT_X: Final[int] = 0"),
            "Should have Final[int] annotation for integer constants"
        );

        // Check for variables with proper types and defaults
        assert!(
            result.contains("new_team: Team | None = None"),
            "Should have Team | None type for custom type variables"
        );
        assert!(
            result.contains("valid: bool = False"),
            "Should have bool type with False default for Bool variables"
        );
    }

    #[test]
    fn test_infer_type_from_constant_lookup_for_list_values() {
        let inferred = infer_type_from_constant_lookup("NEXT_PLAY_TYPES[0]")
            .expect("Expected to infer type from constants");
        assert_eq!(inferred, "str");
    }

    #[test]
    fn test_infer_type_from_expression_with_dict_get() {
        let variables = HashMap::new();

        // Test .get() method on a constant dictionary
        let inferred = infer_type_from_expression(
            "KICKOFF_TO_GRID_RESULT.get(str(kickoff_result), \"A1\")",
            &variables,
        );
        assert_eq!(
            inferred, "str",
            "Should infer str type from dictionary .get() method"
        );
    }

    #[test]
    fn test_dynamic_function_imports() {
        use crate::models::action::Action;

        // Test case - should always import from functions
        let test_case = TestCase {
            name: "simple".to_string(),
            version: "1.0".to_string(),
            description: None,
            parameters: HashMap::new(),
            constants: HashMap::new(),
            variables: HashMap::new(),
            when: None,
            repeat: false,
            steps: vec![Action::Set {
                name: "set variables".to_string(),
                with: {
                    let mut vars = HashMap::new();
                    vars.insert("x".to_string(), "5".to_string());
                    vars
                },
            }],
        };

        let result = test_case_to_python(&test_case, Some("step")).unwrap();
        println!("Generated Python:\n{}", result);

        assert!(
            result.contains("from state import State"),
            "Should always import State"
        );
        assert!(
            result.contains("from functions import *"),
            "Should always use wildcard import from functions"
        );
    }

    #[test]
    fn test_infer_python_type_from_yaml() {
        use yaml_rust2::Yaml;

        // Test integer
        assert_eq!(infer_python_type_from_yaml(&Yaml::Integer(42)), "int");

        // Test float
        assert_eq!(
            infer_python_type_from_yaml(&Yaml::Real("3.14".to_string())),
            "float"
        );

        // Test string
        assert_eq!(
            infer_python_type_from_yaml(&Yaml::String("hello".to_string())),
            "str"
        );

        // Test boolean
        assert_eq!(infer_python_type_from_yaml(&Yaml::Boolean(true)), "bool");

        // Test empty array
        assert_eq!(infer_python_type_from_yaml(&Yaml::Array(vec![])), "list");

        // Test array with integers
        assert_eq!(
            infer_python_type_from_yaml(&Yaml::Array(vec![Yaml::Integer(1), Yaml::Integer(2)])),
            "list[int]"
        );

        // Test array with mixed types
        assert_eq!(
            infer_python_type_from_yaml(&Yaml::Array(vec![
                Yaml::Integer(1),
                Yaml::String("x".to_string())
            ])),
            "list"
        );

        // Test dict
        use yaml_rust2::yaml::Hash;
        let mut hash = Hash::new();
        hash.insert(Yaml::String("key".to_string()), Yaml::Integer(42));
        assert_eq!(infer_python_type_from_yaml(&Yaml::Hash(hash)), "dict");

        // Test null
        assert_eq!(infer_python_type_from_yaml(&Yaml::Null), "None");
    }
}
