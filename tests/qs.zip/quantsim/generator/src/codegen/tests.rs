use super::action_to_python;
use crate::models::action::Action;
use std::collections::HashMap;

#[test]
fn test_exit_simple() {
    let action = Action::Exit {
        name: "exit step".to_string(),
    };

    let result = action_to_python(&action).unwrap();
    assert!(result.contains("# exit step"));
    assert!(result.contains("break"));
}

#[test]
fn test_if_simple() {
    let action = Action::If {
        name: "Check value".to_string(),
        condition: "x > 10".to_string(),
        then_actions: vec![Action::Exit {
            name: "exit on condition".to_string(),
        }],
        else_actions: vec![],
    };

    let result = action_to_python(&action).unwrap();
    assert!(result.contains("# Check value"));
    assert!(result.contains("if x > 10:"));
    assert!(result.contains("break"));
}

#[test]
fn test_log_simple() {
    let action = Action::Log {
        name: "Log message".to_string(),
        message: "Hello, world!".to_string(),
        with: HashMap::new(),
    };

    let result = action_to_python(&action).unwrap();
    assert!(result.contains("# Log message"));
    assert!(result.contains("print(\"Hello, world!\")"));
}

#[test]
fn test_set_variables() {
    let mut with = HashMap::new();
    with.insert("x".to_string(), "10".to_string());
    with.insert("y".to_string(), "20".to_string());

    let action = Action::Set {
        name: "Set variables".to_string(),
        with,
    };

    let result = action_to_python(&action).unwrap();
    assert!(result.contains("# Set variables"));
    assert!(result.contains("x = 10"));
    assert!(result.contains("y = 20"));
}
